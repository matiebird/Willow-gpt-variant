"use client";

/**
 * useCurrentUser
 * Reads willows_staff_id from localStorage, fetches role from /v1/staff/me,
 * and returns the user profile. Cached for the session — no repeated fetches.
 *
 * Returns null while loading. Returns null if no staff_id is stored
 * (e.g. first-ever login before any staff are registered).
 *
 * Exposes `deactivated: true` when the server confirms the account has been
 * offboarded — lets the UI show a proper deactivation screen.
 *
 * Call resetUserCache() on logout so the next mount fetches fresh state.
 */

import { useState, useEffect } from "react";
import { apiClient } from "@/lib/api";

export interface CurrentUser {
  user_id:     string;
  name:        string;
  role:        string;
  email:       string;
  is_admin:    boolean;
  active:      boolean;
  deactivated: boolean;
}

// ── Module-level cache ─────────────────────────────────────────────────────────
// undefined  = not yet fetched
// null       = fetched, no valid active user (not logged in OR deactivated)
let _cached:      CurrentUser | null | undefined = undefined;
let _deactivated: boolean                        = false;

const _listeners: Array<(u: CurrentUser | null, d: boolean) => void> = [];

function notify(u: CurrentUser | null, deactivated = false) {
  _cached      = u;
  _deactivated = deactivated;
  _listeners.forEach((fn) => fn(u, deactivated));
}

/** Call on logout to force a fresh fetch on the next mount. */
export function resetUserCache() {
  _cached      = undefined;
  _deactivated = false;
}

// ── Hook ───────────────────────────────────────────────────────────────────────

export function useCurrentUser(): {
  user:        CurrentUser | null;
  loading:     boolean;
  deactivated: boolean;
} {
  const [user,        setUser]        = useState<CurrentUser | null>(_cached ?? null);
  const [loading,     setLoading]     = useState(_cached === undefined);
  const [deactivated, setDeactivated] = useState(_deactivated);

  useEffect(() => {
    // Already resolved — no fetch needed
    if (_cached !== undefined) {
      setUser(_cached);
      setDeactivated(_deactivated);
      setLoading(false);
      return;
    }

    // Subscribe to cache updates
    const handler = (u: CurrentUser | null, d: boolean) => {
      setUser(u);
      setDeactivated(d);
      setLoading(false);
    };
    _listeners.push(handler);

    // First component to mount kicks off the fetch
    if (_listeners.length === 1) {
      const staffId =
        typeof window !== "undefined"
          ? localStorage.getItem("willows_staff_id")
          : null;

      if (!staffId) {
        notify(null, false);
        return;
      }

      apiClient
        .get<CurrentUser>(`/v1/staff/me`, { params: { staff_id: staffId } })
        .then((r) => {
          if (r.data.deactivated) {
            // Account exists but has been offboarded — show deactivation screen
            notify(null, true);
          } else {
            notify(r.data, false);
          }
        })
        .catch(() => {
          // Network error or unexpected failure — don't assume deactivated
          notify(null, false);
        });
    }

    return () => {
      const idx = _listeners.indexOf(handler);
      if (idx !== -1) _listeners.splice(idx, 1);
    };
  }, []);

  return { user, loading, deactivated };
}
