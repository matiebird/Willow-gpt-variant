/**
 * Willows AI — API Client
 * Typed Axios wrapper for all backend API calls.
 * All requests go to the local backend — no external endpoints.
 */

import axios, { AxiosInstance, AxiosError } from "axios";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type TransactionType = "income" | "expense" | "transfer" | "journal" | "opening_balance";
export type TransactionStatus = "draft" | "pending" | "cleared" | "reconciled" | "voided";
export type InvoiceType = "receivable" | "payable";
export type InvoiceStatus = "draft" | "sent" | "partial" | "paid" | "overdue" | "voided" | "written_off";

export interface Transaction {
  id: string;
  date: string;
  description: string;
  reference?: string;
  notes?: string;
  transaction_type: TransactionType;
  status: TransactionStatus;
  amount: number;
  tax_amount: number;
  currency: string;
  vendor_name?: string;
  category_id?: string;
  ai_categorised: boolean;
  ai_confidence?: number;
  receipt_id?: string;
  created_at: string;
  updated_at: string;
}

export interface TransactionListResponse {
  items: Transaction[];
  total: number;
  page: number;
  page_size: number;
  total_pages: number;
}

export interface TransactionSummary {
  period_start: string;
  period_end: string;
  total_income: number;
  total_expenses: number;
  net_profit: number;
  transaction_count: number;
  pending_count: number;
  currency: string;
}

export interface Account {
  id: string;
  code: string;
  name: string;
  account_type: string;
  account_subtype?: string;
  balance: number;
  currency: string;
  is_active: boolean;
  is_bank_account: boolean;
}

export interface Invoice {
  id: string;
  invoice_number: string;
  invoice_type: InvoiceType;
  status: InvoiceStatus;
  counterparty_name: string;
  counterparty_email?: string;
  issue_date: string;
  due_date?: string;
  subtotal: number;
  tax_total: number;
  total: number;
  amount_paid: number;
  currency: string;
  created_at: string;
}

export interface ExtractedReceiptData {
  vendor_name?: string;
  date?: string;
  total_amount: number;
  subtotal: number;
  tax_amount: number;
  tax_rate_percent?: number;
  currency: string;
  payment_method?: string;
  receipt_number?: string;
  abn?: string;
  category_suggestion: string;
  line_items: Array<{
    description: string;
    quantity: number;
    unit_price: number;
    amount: number;
  }>;
  confidence: number;
  notes?: string;
}

export interface ReceiptUploadResponse {
  receipt_id: string;
  status: string;
  confidence?: number;
  extracted_data?: ExtractedReceiptData;
  requires_human_review: boolean;
  message: string;
}

export interface AIHealthResponse {
  status: string;
  configured_model: string;
  model_available: boolean;
  available_models: string[];
  detail?: string;
}

// ---------------------------------------------------------------------------
// Client Factory
// ---------------------------------------------------------------------------

function createApiClient(): AxiosInstance {
  const baseURL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8080/api";

  const client = axios.create({
    baseURL,
    timeout: 180_000,   // 3 min — allow for LLM inference time
    headers: {
      "Content-Type": "application/json",
    },
  });

  // Request interceptor — attach auth token if present
  client.interceptors.request.use((config) => {
    if (typeof window !== "undefined") {
      const token = localStorage.getItem("willows_token");
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    }
    return config;
  });

  // Response interceptor — normalise errors
  client.interceptors.response.use(
    (res) => res,
    (error: AxiosError) => {
      const detail = (error.response?.data as { detail?: string })?.detail;
      const message = detail ?? error.message ?? "An unexpected error occurred.";
      return Promise.reject(new Error(message));
    }
  );

  return client;
}

export const apiClient = createApiClient();

// ---------------------------------------------------------------------------
// API Functions
// ---------------------------------------------------------------------------

export const transactionsApi = {
  list: (params?: {
    page?: number;
    page_size?: number;
    status?: TransactionStatus;
    type?: TransactionType;
    date_from?: string;
    date_to?: string;
    vendor?: string;
  }) =>
    apiClient
      .get<TransactionListResponse>("/v1/transactions", { params })
      .then((r) => r.data),

  get: (id: string) =>
    apiClient.get<Transaction>(`/v1/transactions/${id}`).then((r) => r.data),

  create: (data: Partial<Transaction>) =>
    apiClient.post<Transaction>("/v1/transactions", data).then((r) => r.data),

  update: (id: string, data: Partial<Transaction>) =>
    apiClient.patch<Transaction>(`/v1/transactions/${id}`, data).then((r) => r.data),

  delete: (id: string) =>
    apiClient.delete(`/v1/transactions/${id}`),

  summary: (params: { date_from?: string; date_to?: string }) =>
    apiClient
      .get<TransactionSummary>("/v1/transactions/summary", { params })
      .then((r) => r.data),
};

export const accountsApi = {
  list: (params?: { account_type?: string; active_only?: boolean }) =>
    apiClient.get<Account[]>("/v1/accounts", { params }).then((r) => r.data),

  get: (id: string) =>
    apiClient.get<Account>(`/v1/accounts/${id}`).then((r) => r.data),

  create: (data: Partial<Account>) =>
    apiClient.post<Account>("/v1/accounts", data).then((r) => r.data),
};

export const invoicesApi = {
  list: (params?: { invoice_type?: InvoiceType; status?: InvoiceStatus }) =>
    apiClient.get<Invoice[]>("/v1/invoices", { params }).then((r) => r.data),

  get: (id: string) =>
    apiClient.get<Invoice>(`/v1/invoices/${id}`).then((r) => r.data),

  create: (data: Record<string, unknown>) =>
    apiClient.post<Invoice>("/v1/invoices", data).then((r) => r.data),

  updateStatus: (id: string, status: InvoiceStatus) =>
    apiClient
      .patch<Invoice>(`/v1/invoices/${id}/status`, null, { params: { new_status: status } })
      .then((r) => r.data),
};

export const aiApi = {
  uploadReceipt: (file: File, autoCreate = false): Promise<ReceiptUploadResponse> => {
    const form = new FormData();
    form.append("file", file);
    return apiClient
      .post<ReceiptUploadResponse>("/v1/ai/upload", form, {
        headers: { "Content-Type": "multipart/form-data" },
        params: { auto_create_transaction: autoCreate },
      })
      .then((r) => r.data);
  },

  classify: (data: {
    description: string;
    amount: number;
    currency?: string;
    date?: string;
  }) =>
    apiClient.post("/v1/ai/classify", data).then((r) => r.data),

  health: () =>
    apiClient.get<AIHealthResponse>("/v1/ai/health").then((r) => r.data),
};
