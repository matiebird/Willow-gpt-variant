"use client";

import { useQuery } from "@tanstack/react-query";
import { transactionsApi, aiApi } from "@/lib/api";
import { format, startOfMonth, endOfMonth } from "date-fns";
import {
  TrendingUp, TrendingDown, DollarSign, FileText,
  AlertCircle, CheckCircle2, Cpu, Upload,
} from "lucide-react";

// ---------------------------------------------------------------------------
// Stat Card
// ---------------------------------------------------------------------------

function StatCard({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  className = "",
}: {
  title: string;
  value: string;
  subtitle?: string;
  icon: React.ElementType;
  trend?: "up" | "down" | "neutral";
  className?: string;
}) {
  return (
    <div className={`rounded-xl border bg-card p-6 shadow-sm ${className}`}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <p className="mt-2 text-2xl font-bold tracking-tight">{value}</p>
          {subtitle && (
            <p className="mt-1 text-xs text-muted-foreground">{subtitle}</p>
          )}
        </div>
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
          <Icon className="h-5 w-5 text-primary" />
        </div>
      </div>
      {trend && (
        <div className="mt-3 flex items-center gap-1 text-xs">
          {trend === "up" && <TrendingUp className="h-3 w-3 text-green-500" />}
          {trend === "down" && <TrendingDown className="h-3 w-3 text-red-500" />}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// AI Status Badge
// ---------------------------------------------------------------------------

function AIStatusBadge() {
  const { data, isLoading } = useQuery({
    queryKey: ["ai-health"],
    queryFn: aiApi.health,
    staleTime: 60_000,
  });

  if (isLoading) {
    return (
      <div className="flex items-center gap-2 rounded-lg border bg-muted/50 px-3 py-2 text-sm">
        <div className="h-2 w-2 animate-pulse rounded-full bg-yellow-500" />
        <span className="text-muted-foreground">Checking AI engine…</span>
      </div>
    );
  }

  const online = data?.status === "ok" && data?.model_available;

  return (
    <div
      className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-sm ${
        online ? "border-green-200 bg-green-50 dark:border-green-900 dark:bg-green-950" : "border-red-200 bg-red-50 dark:border-red-900 dark:bg-red-950"
      }`}
    >
      {online ? (
        <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
      ) : (
        <AlertCircle className="h-4 w-4 text-red-500" />
      )}
      <div>
        <span className={`font-medium ${online ? "text-green-700 dark:text-green-300" : "text-red-600"}`}>
          {online ? "Local AI Online" : "AI Engine Offline"}
        </span>
        {data && (
          <span className="ml-2 text-xs text-muted-foreground">
            {data.configured_model}
          </span>
        )}
      </div>
      <Cpu className="ml-auto h-4 w-4 text-muted-foreground" />
    </div>
  );
}

// ---------------------------------------------------------------------------
// Recent Transactions
// ---------------------------------------------------------------------------

function RecentTransactions() {
  const { data } = useQuery({
    queryKey: ["transactions", "recent"],
    queryFn: () => transactionsApi.list({ page: 1, page_size: 8 }),
  });

  const fmt = (amount: number, currency: string) =>
    new Intl.NumberFormat("en-AU", { style: "currency", currency }).format(amount);

  return (
    <div className="rounded-xl border bg-card shadow-sm">
      <div className="flex items-center justify-between border-b px-6 py-4">
        <h2 className="font-semibold">Recent Transactions</h2>
        <a href="/transactions" className="text-sm text-primary hover:underline">
          View all
        </a>
      </div>
      <div className="divide-y">
        {!data?.items.length && (
          <p className="px-6 py-8 text-center text-sm text-muted-foreground">
            No transactions yet. Upload a receipt or create one manually.
          </p>
        )}
        {data?.items.map((txn) => (
          <div key={txn.id} className="flex items-center gap-4 px-6 py-3">
            <div
              className={`flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full ${
                txn.transaction_type === "income"
                  ? "bg-green-100 dark:bg-green-950"
                  : "bg-red-100 dark:bg-red-950"
              }`}
            >
              {txn.transaction_type === "income" ? (
                <TrendingUp className="h-4 w-4 text-green-600 dark:text-green-400" />
              ) : (
                <TrendingDown className="h-4 w-4 text-red-500" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="truncate text-sm font-medium">{txn.description}</p>
              <p className="text-xs text-muted-foreground">
                {txn.vendor_name ?? "—"} · {format(new Date(txn.date), "d MMM yyyy")}
              </p>
            </div>
            <div className="text-right">
              <p
                className={`text-sm font-semibold ${
                  txn.transaction_type === "income" ? "text-green-600 dark:text-green-400" : ""
                }`}
              >
                {txn.transaction_type === "income" ? "+" : "−"}
                {fmt(txn.amount, txn.currency)}
              </p>
              <span
                className={`inline-block rounded-full px-2 py-0.5 text-[10px] font-medium ${
                  txn.status === "reconciled"
                    ? "bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-400"
                    : txn.status === "pending"
                    ? "bg-yellow-100 text-yellow-700 dark:bg-yellow-950 dark:text-yellow-400"
                    : "bg-muted text-muted-foreground"
                }`}
              >
                {txn.status}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Dashboard Page
// ---------------------------------------------------------------------------

export default function DashboardPage() {
  const now = new Date();
  const dateFrom = format(startOfMonth(now), "yyyy-MM-dd");
  const dateTo = format(endOfMonth(now), "yyyy-MM-dd");

  const { data: summary } = useQuery({
    queryKey: ["summary", dateFrom, dateTo],
    queryFn: () => transactionsApi.summary({ date_from: dateFrom, date_to: dateTo }),
  });

  const fmt = (n?: number) =>
    new Intl.NumberFormat("en-AU", { style: "currency", currency: "AUD" }).format(n ?? 0);

  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-sm text-muted-foreground">
            {format(now, "MMMM yyyy")} · All data processed locally
          </p>
        </div>
        <AIStatusBadge />
      </div>

      {/* Quick actions */}
      <div className="flex flex-wrap gap-3">
        <a
          href="/receipts"
          className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground shadow-sm hover:bg-primary/90 transition-colors"
        >
          <Upload className="h-4 w-4" />
          Upload Receipt
        </a>
        <a
          href="/transactions"
          className="inline-flex items-center gap-2 rounded-lg border bg-card px-4 py-2 text-sm font-medium shadow-sm hover:bg-accent transition-colors"
        >
          <FileText className="h-4 w-4" />
          New Transaction
        </a>
      </div>

      {/* Stats grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Income (MTD)"
          value={fmt(summary?.total_income)}
          subtitle="This month"
          icon={TrendingUp}
          trend="up"
        />
        <StatCard
          title="Expenses (MTD)"
          value={fmt(summary?.total_expenses)}
          subtitle="This month"
          icon={TrendingDown}
        />
        <StatCard
          title="Net Profit"
          value={fmt(summary?.net_profit)}
          subtitle="Income minus expenses"
          icon={DollarSign}
          trend={(summary?.net_profit ?? 0) >= 0 ? "up" : "down"}
        />
        <StatCard
          title="Pending Review"
          value={String(summary?.pending_count ?? 0)}
          subtitle="Transactions awaiting review"
          icon={AlertCircle}
        />
      </div>

      {/* Recent transactions */}
      <RecentTransactions />
    </div>
  );
}
