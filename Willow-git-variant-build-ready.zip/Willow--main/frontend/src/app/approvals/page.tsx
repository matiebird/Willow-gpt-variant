"use client";

/**
 * Willow — Pending Approvals
 * Staff review and approve/reject outbound emails before they are sent.
 * Calls the n8n Staff Approval Webhook (POST /willow-approve-followup).
 * Reads pending_approvals directly from the backend /v1/approvals endpoint.
 */

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import {
  CheckCircle2, XCircle, Clock, Mail, User, AlertTriangle, RefreshCw,
} from "lucide-react";
import { useState } from "react";
import { apiClient } from "@/lib/api";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

type ApprovalStatus = "pending" | "sent" | "rejected" | "expired";

interface PendingApproval {
  id: string;
  approval_type: string;
  client_id: string | null;
  sequence_id: string | null;
  to_email: string;
  subject: string;
  body: string;
  created_by: string;
  status: ApprovalStatus;
  approved_by: string | null;
  approved_at: string | null;
  created_at: string;
}

// ---------------------------------------------------------------------------
// API helpers
// ---------------------------------------------------------------------------

async function fetchApprovals(status: ApprovalStatus): Promise<PendingApproval[]> {
  const r = await apiClient.get<PendingApproval[]>("/v1/approvals", {
    params: { status },
  });
  return r.data;
}

async function submitApproval(payload: {
  approval_id: string;
  staff_id: string;
  action: "approve" | "reject";
}) {
  // Calls the n8n webhook directly — the backend proxies it
  const r = await apiClient.post("/v1/approvals/action", payload);
  return r.data;
}

// ---------------------------------------------------------------------------
// Status badge
// ---------------------------------------------------------------------------

function StatusBadge({ status }: { status: ApprovalStatus }) {
  const map: Record<ApprovalStatus, { label: string; className: string }> = {
    pending: { label: "Pending Review", className: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200" },
    sent:    { label: "Sent",           className: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200" },
    rejected:{ label: "Rejected",       className: "bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-200" },
    expired: { label: "Expired",        className: "bg-muted text-muted-foreground" },
  };
  const { label, className } = map[status] ?? map.pending;
  return (
    <span className={`inline-block rounded-full px-2 py-0.5 text-[11px] font-medium ${className}`}>
      {label}
    </span>
  );
}

// ---------------------------------------------------------------------------
// Approval card
// ---------------------------------------------------------------------------

function ApprovalCard({
  approval,
  staffId,
  onAction,
}: {
  approval: PendingApproval;
  staffId: string;
  onAction: (id: string, action: "approve" | "reject") => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const isPending = approval.status === "pending";

  return (
    <div className="rounded-xl border bg-card shadow-sm overflow-hidden">
      {/* Header row */}
      <div className="flex items-start gap-4 px-5 py-4">
        <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full bg-primary/10">
          <Mail className="h-5 w-5 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <p className="font-semibold text-sm truncate">{approval.subject}</p>
            <StatusBadge status={approval.status} />
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            To: <span className="font-medium text-foreground">{approval.to_email}</span>
            {approval.client_id && (
              <> · Client: <span className="font-mono">{approval.client_id}</span></>
            )}
          </p>
          <p className="text-xs text-muted-foreground mt-0.5">
            <Clock className="inline h-3 w-3 mr-1" />
            Queued {format(new Date(approval.created_at), "d MMM yyyy 'at' h:mm a")}
            {approval.approved_by && (
              <>
                {" · "}
                <User className="inline h-3 w-3 mr-1" />
                {approval.status === "sent" ? "Approved" : "Rejected"} by{" "}
                <span className="font-medium">{approval.approved_by}</span>
                {approval.approved_at &&
                  ` on ${format(new Date(approval.approved_at), "d MMM 'at' h:mm a")}`}
              </>
            )}
          </p>
        </div>

        {/* Action buttons — pending only */}
        {isPending && (
          <div className="flex gap-2 flex-shrink-0">
            <button
              onClick={() => onAction(approval.id, "approve")}
              className="inline-flex items-center gap-1.5 rounded-lg bg-green-600 px-3 py-1.5 text-xs font-medium text-white shadow-sm hover:bg-green-700 transition-colors"
            >
              <CheckCircle2 className="h-3.5 w-3.5" />
              Send
            </button>
            <button
              onClick={() => onAction(approval.id, "reject")}
              className="inline-flex items-center gap-1.5 rounded-lg border border-red-300 px-3 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50 dark:hover:bg-red-950 transition-colors"
            >
              <XCircle className="h-3.5 w-3.5" />
              Reject
            </button>
          </div>
        )}
      </div>

      {/* Email body preview */}
      <div className="border-t">
        <button
          onClick={() => setExpanded(!expanded)}
          className="w-full px-5 py-2 text-left text-xs text-muted-foreground hover:text-foreground hover:bg-muted/30 transition-colors"
        >
          {expanded ? "Hide email body ▲" : "Preview email body ▼"}
        </button>
        {expanded && (
          <div className="px-5 pb-4">
            <pre className="whitespace-pre-wrap text-xs font-mono bg-muted/40 rounded-lg p-4 text-foreground leading-relaxed">
              {approval.body}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Page
// ---------------------------------------------------------------------------

export default function ApprovalsPage() {
  const qc = useQueryClient();
  const [activeTab, setActiveTab] = useState<ApprovalStatus>("pending");

  // Derive staff ID from localStorage token or fall back to a prompt
  const staffId =
    typeof window !== "undefined"
      ? localStorage.getItem("willows_staff_id") ?? "staff"
      : "staff";

  const { data: approvals = [], isLoading, isError, refetch } = useQuery({
    queryKey: ["approvals", activeTab],
    queryFn: () => fetchApprovals(activeTab),
    refetchInterval: activeTab === "pending" ? 30_000 : false, // auto-refresh pending tab
  });

  const mutation = useMutation({
    mutationFn: submitApproval,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["approvals"] });
    },
  });

  const handleAction = (approvalId: string, action: "approve" | "reject") => {
    mutation.mutate({ approval_id: approvalId, staff_id: staffId, action });
  };

  const tabs: { label: string; value: ApprovalStatus; icon: React.ElementType }[] = [
    { label: "Pending",  value: "pending",  icon: Clock },
    { label: "Sent",     value: "sent",     icon: CheckCircle2 },
    { label: "Rejected", value: "rejected", icon: XCircle },
  ];

  const pendingCount = approvals.filter((a) => a.status === "pending").length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Pending Approvals</h1>
          <p className="text-sm text-muted-foreground">
            Review follow-up emails before they are sent to clients
          </p>
        </div>
        <button
          onClick={() => refetch()}
          className="inline-flex items-center gap-1.5 rounded-lg border bg-card px-3 py-2 text-sm font-medium shadow-sm hover:bg-accent transition-colors"
        >
          <RefreshCw className="h-4 w-4" />
          Refresh
        </button>
      </div>

      {/* Policy notice */}
      <div className="flex items-start gap-3 rounded-xl border border-yellow-200 bg-yellow-50 dark:border-yellow-900 dark:bg-yellow-950/40 px-4 py-3">
        <AlertTriangle className="h-5 w-5 flex-shrink-0 text-yellow-600 dark:text-yellow-400 mt-0.5" />
        <p className="text-sm text-yellow-800 dark:text-yellow-200">
          No email leaves the firm without your approval. Every follow-up is drafted by Willow
          and held here. Click <strong>Send</strong> to approve, or <strong>Reject</strong> to discard.
        </p>
      </div>

      {/* Mutation error */}
      {mutation.isError && (
        <div className="rounded-xl border border-red-200 bg-red-50 dark:border-red-900 dark:bg-red-950/40 px-4 py-3 text-sm text-red-700 dark:text-red-300">
          Action failed — {(mutation.error as Error)?.message ?? "please try again"}
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-1 rounded-lg border bg-muted/40 p-1 w-fit">
        {tabs.map(({ label, value, icon: Icon }) => (
          <button
            key={value}
            onClick={() => setActiveTab(value)}
            className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
              activeTab === value
                ? "bg-background shadow-sm text-foreground"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <Icon className="h-4 w-4" />
            {label}
            {value === "pending" && pendingCount > 0 && activeTab !== "pending" && (
              <span className="ml-1 rounded-full bg-primary px-1.5 py-0.5 text-[10px] font-bold text-primary-foreground">
                {pendingCount}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Content */}
      {isLoading && (
        <div className="flex items-center justify-center py-16 text-muted-foreground text-sm">
          <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
          Loading…
        </div>
      )}

      {isError && (
        <div className="rounded-xl border border-red-200 bg-red-50 dark:bg-red-950/30 px-4 py-8 text-center text-sm text-red-700 dark:text-red-300">
          Could not load approvals. Check that the backend is running.
        </div>
      )}

      {!isLoading && !isError && approvals.length === 0 && (
        <div className="flex flex-col items-center justify-center rounded-xl border bg-card py-16 text-center">
          <CheckCircle2 className="mb-3 h-10 w-10 text-muted-foreground/40" />
          <p className="font-medium text-muted-foreground">
            {activeTab === "pending" ? "Nothing waiting for review" : "No records in this category"}
          </p>
          <p className="mt-1 text-xs text-muted-foreground">
            {activeTab === "pending" &&
              "Willow will stage follow-up emails here each weekday morning."}
          </p>
        </div>
      )}

      {!isLoading && !isError && approvals.length > 0 && (
        <div className="space-y-3">
          {approvals.map((a) => (
            <ApprovalCard
              key={a.id}
              approval={a}
              staffId={staffId}
              onAction={handleAction}
            />
          ))}
        </div>
      )}
    </div>
  );
}
