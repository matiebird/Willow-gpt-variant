"use client";

/**
 * Willow — Login / First-Run Setup
 *
 * Two modes:
 *  1. Fresh install (no staff in DB) → First-Time Setup form (create first admin)
 *  2. Existing install → Staff selection (click your name to sign in)
 *
 * Stores willows_staff_id in localStorage on success → redirects to dashboard.
 */

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Leaf, Loader2, UserCircle2, ArrowRight, Lock } from "lucide-react";
import { apiClient } from "@/lib/api";

// ── Types ─────────────────────────────────────────────────────────────────────

interface StaffMember {
  user_id:  string;
  name:     string;
  role:     string;
  email:    string;
  active:   boolean;
}

interface StaffListResponse {
  staff: StaffMember[];
  total: number;
}

const ROLE_LABELS: Record<string, string> = {
  admin:              "Admin",
  manager:            "Manager",
  senior_bookkeeper:  "Senior Bookkeeper",
  bookkeeper:         "Bookkeeper",
};

// ── Component ─────────────────────────────────────────────────────────────────

export default function LoginPage() {
  const router = useRouter();

  const [staff,     setStaff]     = useState<StaffMember[]>([]);
  const [loading,   setLoading]   = useState(true);
  const [selecting, setSelecting] = useState<string | null>(null);
  const [error,     setError]     = useState<string | null>(null);
  const [isSetup,   setIsSetup]   = useState(false);

  // First-run form state
  const [setupName,    setSetupName]    = useState("");
  const [setupEmail,   setSetupEmail]   = useState("");
  const [setupLoading, setSetupLoading] = useState(false);
  const [setupError,   setSetupError]   = useState<string | null>(null);

  // ── Fetch staff list on mount ──────────────────────────────────────────────
  useEffect(() => {
    apiClient
      .get<StaffListResponse>("/v1/staff", { params: { active_only: true } })
      .then((r) => {
        if (r.data.total === 0) {
          setIsSetup(true); // No staff — show first-run setup
        } else {
          setStaff(r.data.staff);
        }
      })
      .catch(() => setError("Could not connect to Willow. Is the server running?"))
      .finally(() => setLoading(false));
  }, []);

  // ── Sign in as selected staff member ──────────────────────────────────────
  function signIn(member: StaffMember) {
    setSelecting(member.user_id);
    localStorage.setItem("willows_staff_id", member.user_id);
    router.replace("/");
  }

  // ── First-run bootstrap ───────────────────────────────────────────────────
  async function handleSetup(e: React.FormEvent) {
    e.preventDefault();
    setSetupLoading(true);
    setSetupError(null);

    try {
      const r = await apiClient.post<{ user_id: string; name: string }>(
        "/v1/staff/bootstrap",
        { name: setupName.trim(), email: setupEmail.trim() }
      );
      localStorage.setItem("willows_staff_id", r.data.user_id);
      router.replace("/");
    } catch (err: unknown) {
      setSetupError(
        err instanceof Error ? err.message : "Setup failed. Please try again."
      );
      setSetupLoading(false);
    }
  }

  // ── Shared card wrapper ────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4">

      {/* Brand */}
      <div className="flex items-center gap-3 mb-10">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary">
          <Leaf className="h-6 w-6 text-primary-foreground" />
        </div>
        <div>
          <span className="text-2xl font-bold tracking-tight">Willow</span>
          <span className="block text-xs text-muted-foreground">
            Your books. Your server. Your rules.
          </span>
        </div>
      </div>

      {/* Card */}
      <div className="w-full max-w-sm rounded-2xl border bg-card shadow-sm p-8">

        {/* Loading */}
        {loading && (
          <div className="flex flex-col items-center gap-3 py-8">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            <p className="text-sm text-muted-foreground">Starting up…</p>
          </div>
        )}

        {/* Error */}
        {error && !loading && (
          <div className="rounded-lg bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 p-4 text-sm text-red-700 dark:text-red-400">
            {error}
          </div>
        )}

        {/* ── First-run setup ── */}
        {isSetup && !loading && (
          <>
            <h1 className="text-lg font-semibold mb-1">Welcome to Willow</h1>
            <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
              This is a fresh install. Create your admin account to get started.
            </p>

            <form onSubmit={handleSetup} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1.5">
                  Your name
                </label>
                <input
                  type="text"
                  required
                  value={setupName}
                  onChange={(e) => setSetupName(e.target.value)}
                  placeholder="Jane Smith"
                  className="w-full rounded-lg border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary/40 transition"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1.5">
                  Email address
                </label>
                <input
                  type="email"
                  required
                  value={setupEmail}
                  onChange={(e) => setSetupEmail(e.target.value)}
                  placeholder="jane@example.com"
                  className="w-full rounded-lg border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary/40 transition"
                />
              </div>

              {setupError && (
                <p className="text-sm text-red-600 dark:text-red-400">
                  {setupError}
                </p>
              )}

              <button
                type="submit"
                disabled={setupLoading || !setupName.trim() || !setupEmail.trim()}
                className="w-full flex items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {setupLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <>Set up Willow <ArrowRight className="h-4 w-4" /></>
                )}
              </button>
            </form>
          </>
        )}

        {/* ── Staff selection ── */}
        {!isSetup && !loading && !error && staff.length > 0 && (
          <>
            <h1 className="text-lg font-semibold mb-1">Who are you?</h1>
            <p className="text-sm text-muted-foreground mb-5">
              Select your name to sign in.
            </p>

            <div className="space-y-2">
              {staff.map((member) => (
                <button
                  key={member.user_id}
                  onClick={() => signIn(member)}
                  disabled={selecting !== null}
                  className="w-full flex items-center gap-3 rounded-xl border bg-background px-4 py-3 text-left transition hover:border-primary hover:bg-primary/5 disabled:opacity-60 disabled:cursor-not-allowed group"
                >
                  <div className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full bg-muted group-hover:bg-primary/10 transition">
                    <UserCircle2 className="h-5 w-5 text-muted-foreground group-hover:text-primary transition" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold truncate">{member.name}</p>
                    <p className="text-xs text-muted-foreground truncate">
                      {ROLE_LABELS[member.role] ?? member.role}
                    </p>
                  </div>
                  {selecting === member.user_id ? (
                    <Loader2 className="h-4 w-4 animate-spin text-muted-foreground flex-shrink-0" />
                  ) : (
                    <ArrowRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition flex-shrink-0" />
                  )}
                </button>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Privacy note */}
      <div className="mt-6 flex items-center gap-1.5 text-xs text-muted-foreground">
        <Lock className="h-3 w-3" />
        <span>100% local · no internet connection required</span>
      </div>
    </div>
  );
}
