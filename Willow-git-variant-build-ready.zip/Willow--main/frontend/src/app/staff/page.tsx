"use client";

/**
 * Willow — Staff Management
 * Add, view, edit, and offboard staff members.
 * Calls GET/POST/PATCH /v1/staff via the backend API.
 */

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { format } from "date-fns";
import {
  Users, Plus, Pencil, UserMinus, ChevronDown, ChevronUp,
  ShieldCheck, RefreshCw, CheckCircle2, AlertTriangle,
} from "lucide-react";
import { apiClient } from "@/lib/api";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

type Role = "bookkeeper" | "senior_bookkeeper" | "manager" | "admin";

interface StaffMember {
  user_id: string;
  name: string;
  role: Role;
  email: string;
  phone?: string;
  approval_limit: number;
  timezone: string;
  client_ids: string[];
  active: boolean;
  created_at: string;
}

interface StaffCreate {
  name: string;
  role: Role;
  email: string;
  phone?: string;
  approval_limit: number;
  timezone: string;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const ROLE_LABELS: Record<Role, string> = {
  bookkeeper:        "Bookkeeper",
  senior_bookkeeper: "Senior Bookkeeper",
  manager:           "Manager",
  admin:             "Admin",
};

const ROLE_COLOURS: Record<Role, string> = {
  bookkeeper:        "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  senior_bookkeeper: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
  manager:           "bg-teal-100 text-teal-800 dark:bg-teal-900 dark:text-teal-200",
  admin:             "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
};

function RoleBadge({ role }: { role: Role }) {
  return (
    <span className={`inline-block rounded-full px-2 py-0.5 text-[11px] font-medium ${ROLE_COLOURS[role]}`}>
      {ROLE_LABELS[role]}
    </span>
  );
}

// ---------------------------------------------------------------------------
// API helpers
// ---------------------------------------------------------------------------

const getCurrentUserId = () =>
  typeof window !== "undefined" ? localStorage.getItem("willows_staff_id") ?? "" : "";

async function fetchStaff(): Promise<StaffMember[]> {
  const r = await apiClient.get<StaffMember[]>("/v1/staff");
  return r.data;
}

async function createStaff(payload: StaffCreate & { requested_by: string }) {
  const { requested_by, ...body } = payload;
  const r = await apiClient.post(`/v1/staff?requested_by=${encodeURIComponent(requested_by)}`, body);
  return r.data;
}

async function updateStaff(payload: Partial<StaffCreate> & { user_id: string; requested_by: string }) {
  const { user_id, requested_by, ...body } = payload;
  const r = await apiClient.patch(
    `/v1/staff/${user_id}?requested_by=${encodeURIComponent(requested_by)}`,
    body,
  );
  return r.data;
}

async function offboardStaff(payload: {
  user_id: string;
  reassign_to: string;
  reason: string;
  requested_by: string;
}) {
  const r = await apiClient.post(`/v1/staff/${payload.user_id}/offboard`, {
    reassign_to: payload.reassign_to,
    reason: payload.reason,
    requested_by: payload.requested_by,
  });
  return r.data;
}

// ---------------------------------------------------------------------------
// Add / Edit modal
// ---------------------------------------------------------------------------

function StaffModal({
  existing,
  onClose,
  onSave,
  isSaving,
  error,
}: {
  existing?: StaffMember;
  onClose: () => void;
  onSave: (data: StaffCreate) => void;
  isSaving: boolean;
  error?: string;
}) {
  const [form, setForm] = useState<StaffCreate>({
    name:           existing?.name ?? "",
    role:           existing?.role ?? "bookkeeper",
    email:          existing?.email ?? "",
    phone:          existing?.phone ?? "",
    approval_limit: existing?.approval_limit ?? 500,
    timezone:       existing?.timezone ?? "Australia/Brisbane",
  });

  const set = (k: keyof StaffCreate, v: string | number) =>
    setForm((f) => ({ ...f, [k]: v }));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="w-full max-w-md rounded-2xl bg-background shadow-2xl border">
        <div className="flex items-center justify-between border-b px-6 py-4">
          <h2 className="text-base font-semibold">
            {existing ? "Edit Staff Member" : "Add Staff Member"}
          </h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground text-lg leading-none">×</button>
        </div>
        <div className="px-6 py-5 space-y-4">
          {/* Name */}
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">Full name</label>
            <input
              className="w-full rounded-lg border bg-muted/30 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              value={form.name}
              onChange={(e) => set("name", e.target.value)}
              placeholder="Jane Smith"
            />
          </div>
          {/* Role */}
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">Role</label>
            <select
              className="w-full rounded-lg border bg-muted/30 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              value={form.role}
              onChange={(e) => set("role", e.target.value as Role)}
            >
              {Object.entries(ROLE_LABELS).map(([v, l]) => (
                <option key={v} value={v}>{l}</option>
              ))}
            </select>
          </div>
          {/* Email */}
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">Email</label>
            <input
              type="email"
              className="w-full rounded-lg border bg-muted/30 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              value={form.email}
              onChange={(e) => set("email", e.target.value)}
              placeholder="jane@yourfirm.com.au"
            />
          </div>
          {/* Phone */}
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">Phone (optional)</label>
            <input
              className="w-full rounded-lg border bg-muted/30 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              value={form.phone}
              onChange={(e) => set("phone", e.target.value)}
              placeholder="04XX XXX XXX"
            />
          </div>
          {/* Approval limit */}
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">
              Approval limit (AUD) — max invoice value this person can approve
            </label>
            <input
              type="number"
              min={0}
              className="w-full rounded-lg border bg-muted/30 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              value={form.approval_limit}
              onChange={(e) => set("approval_limit", parseFloat(e.target.value) || 0)}
            />
          </div>
          {/* Error */}
          {error && (
            <p className="text-xs text-red-600 dark:text-red-400">{error}</p>
          )}
        </div>
        <div className="flex justify-end gap-2 border-t px-6 py-4">
          <button
            onClick={onClose}
            className="rounded-lg border px-4 py-2 text-sm font-medium hover:bg-accent transition-colors"
          >
            Cancel
          </button>
          <button
            disabled={isSaving || !form.name || !form.email}
            onClick={() => onSave(form)}
            className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground shadow-sm hover:opacity-90 disabled:opacity-50 transition-opacity"
          >
            {isSaving ? "Saving…" : existing ? "Save changes" : "Add staff member"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Staff card
// ---------------------------------------------------------------------------

function StaffCard({
  member,
  allStaff,
  currentUserId,
  onEdit,
  onOffboard,
}: {
  member: StaffMember;
  allStaff: StaffMember[];
  currentUserId: string;
  onEdit: (m: StaffMember) => void;
  onOffboard: (m: StaffMember) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const isCurrentUser = member.user_id === currentUserId;

  return (
    <div className={`rounded-xl border bg-card shadow-sm overflow-hidden ${!member.active ? "opacity-60" : ""}`}>
      <div className="flex items-center gap-4 px-5 py-4">
        {/* Avatar */}
        <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary font-bold text-sm">
          {member.name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase()}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <p className="font-semibold text-sm">{member.name}</p>
            <RoleBadge role={member.role} />
            {isCurrentUser && (
              <span className="text-[10px] text-muted-foreground font-medium bg-muted px-1.5 py-0.5 rounded-full">You</span>
            )}
            {!member.active && (
              <span className="text-[10px] text-muted-foreground font-medium bg-muted px-1.5 py-0.5 rounded-full">Inactive</span>
            )}
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            {member.email}
            {member.phone && <> · {member.phone}</>}
          </p>
        </div>
        <div className="flex gap-2 flex-shrink-0">
          <button
            onClick={() => onEdit(member)}
            className="inline-flex items-center gap-1 rounded-lg border px-2.5 py-1.5 text-xs font-medium hover:bg-accent transition-colors"
          >
            <Pencil className="h-3 w-3" /> Edit
          </button>
          {member.active && !isCurrentUser && (
            <button
              onClick={() => onOffboard(member)}
              className="inline-flex items-center gap-1 rounded-lg border border-red-200 px-2.5 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50 dark:hover:bg-red-950 transition-colors"
            >
              <UserMinus className="h-3 w-3" /> Offboard
            </button>
          )}
          <button
            onClick={() => setExpanded(!expanded)}
            className="rounded-lg border px-2 py-1.5 hover:bg-accent transition-colors"
          >
            {expanded ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
          </button>
        </div>
      </div>
      {expanded && (
        <div className="border-t px-5 py-3 bg-muted/20 grid grid-cols-3 gap-3 text-xs">
          <div>
            <p className="text-muted-foreground">User ID</p>
            <p className="font-mono mt-0.5">{member.user_id}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Approval limit</p>
            <p className="font-medium mt-0.5">${member.approval_limit.toLocaleString("en-AU")}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Clients assigned</p>
            <p className="font-medium mt-0.5">{member.client_ids?.length ?? 0}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Timezone</p>
            <p className="font-medium mt-0.5">{member.timezone}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Added</p>
            <p className="font-medium mt-0.5">{format(new Date(member.created_at), "d MMM yyyy")}</p>
          </div>
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Offboard modal
// ---------------------------------------------------------------------------

function OffboardModal({
  member,
  allStaff,
  onClose,
  onConfirm,
  isSaving,
}: {
  member: StaffMember;
  allStaff: StaffMember[];
  onClose: () => void;
  onConfirm: (reassignTo: string, reason: string) => void;
  isSaving: boolean;
}) {
  const options = allStaff.filter((s) => s.active && s.user_id !== member.user_id);
  const [reassignTo, setReassignTo] = useState(options[0]?.user_id ?? "");
  const [reason, setReason] = useState("");

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="w-full max-w-md rounded-2xl bg-background shadow-2xl border">
        <div className="flex items-center gap-3 border-b px-6 py-4">
          <AlertTriangle className="h-5 w-5 text-red-500 flex-shrink-0" />
          <h2 className="text-base font-semibold">Offboard {member.name}?</h2>
        </div>
        <div className="px-6 py-5 space-y-4 text-sm">
          <p className="text-muted-foreground">
            This will deactivate {member.name}'s account and reassign their{" "}
            <strong>{member.client_ids?.length ?? 0} clients</strong> to another staff member.
          </p>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">Reassign clients to</label>
            <select
              className="w-full rounded-lg border bg-muted/30 px-3 py-2 text-sm"
              value={reassignTo}
              onChange={(e) => setReassignTo(e.target.value)}
            >
              {options.map((s) => (
                <option key={s.user_id} value={s.user_id}>{s.name} ({ROLE_LABELS[s.role]})</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">Reason</label>
            <textarea
              className="w-full rounded-lg border bg-muted/30 px-3 py-2 text-sm resize-none h-20"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Resignation, contract ended, etc."
            />
          </div>
        </div>
        <div className="flex justify-end gap-2 border-t px-6 py-4">
          <button onClick={onClose} className="rounded-lg border px-4 py-2 text-sm font-medium hover:bg-accent transition-colors">
            Cancel
          </button>
          <button
            disabled={isSaving || !reassignTo || reason.length < 5}
            onClick={() => onConfirm(reassignTo, reason)}
            className="rounded-lg bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700 disabled:opacity-50 transition-colors"
          >
            {isSaving ? "Offboarding…" : "Confirm offboard"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Page
// ---------------------------------------------------------------------------

export default function StaffPage() {
  const qc = useQueryClient();
  const currentUserId = getCurrentUserId();

  const [showAdd, setShowAdd]       = useState(false);
  const [editing, setEditing]       = useState<StaffMember | null>(null);
  const [offboarding, setOffboarding] = useState<StaffMember | null>(null);
  const [formError, setFormError]   = useState<string>();

  const { data: staff = [], isLoading, isError, refetch } = useQuery({
    queryKey: ["staff"],
    queryFn: fetchStaff,
  });

  const createMutation = useMutation({
    mutationFn: createStaff,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["staff"] }); setShowAdd(false); setFormError(undefined); },
    onError: (e: Error) => setFormError(e.message),
  });

  const updateMutation = useMutation({
    mutationFn: updateStaff,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["staff"] }); setEditing(null); setFormError(undefined); },
    onError: (e: Error) => setFormError(e.message),
  });

  const offboardMutation = useMutation({
    mutationFn: offboardStaff,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["staff"] }); setOffboarding(null); },
  });

  const activeStaff   = staff.filter((s) => s.active);
  const inactiveStaff = staff.filter((s) => !s.active);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Staff</h1>
          <p className="text-sm text-muted-foreground">
            {activeStaff.length} active · {inactiveStaff.length} inactive
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => refetch()}
            className="inline-flex items-center gap-1.5 rounded-lg border bg-card px-3 py-2 text-sm font-medium shadow-sm hover:bg-accent transition-colors"
          >
            <RefreshCw className="h-4 w-4" />
          </button>
          <button
            onClick={() => { setShowAdd(true); setFormError(undefined); }}
            className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground shadow-sm hover:opacity-90 transition-opacity"
          >
            <Plus className="h-4 w-4" />
            Add staff member
          </button>
        </div>
      </div>

      {/* Roles legend */}
      <div className="flex flex-wrap gap-2">
        {(Object.entries(ROLE_LABELS) as [Role, string][]).map(([role, label]) => (
          <div key={role} className="flex items-center gap-1.5">
            <RoleBadge role={role} />
            <span className="text-xs text-muted-foreground">
              {role === "bookkeeper" && "— standard access"}
              {role === "senior_bookkeeper" && "— higher approval limit"}
              {role === "manager" && "— can add/edit staff"}
              {role === "admin" && "— full access"}
            </span>
          </div>
        ))}
      </div>

      {/* Content */}
      {isLoading && (
        <div className="flex items-center justify-center py-16 text-muted-foreground text-sm">
          <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> Loading…
        </div>
      )}

      {isError && (
        <div className="rounded-xl border border-red-200 bg-red-50 dark:bg-red-950/30 px-4 py-8 text-center text-sm text-red-700">
          Could not load staff. Check that the backend is running.
        </div>
      )}

      {!isLoading && !isError && staff.length === 0 && (
        <div className="flex flex-col items-center justify-center rounded-xl border bg-card py-16 text-center">
          <Users className="mb-3 h-10 w-10 text-muted-foreground/40" />
          <p className="font-medium text-muted-foreground">No staff added yet</p>
          <p className="mt-1 text-xs text-muted-foreground">
            Add the first staff member above to get started.
          </p>
        </div>
      )}

      {activeStaff.length > 0 && (
        <div className="space-y-3">
          {activeStaff.map((m) => (
            <StaffCard
              key={m.user_id}
              member={m}
              allStaff={staff}
              currentUserId={currentUserId}
              onEdit={(s) => { setEditing(s); setFormError(undefined); }}
              onOffboard={setOffboarding}
            />
          ))}
        </div>
      )}

      {inactiveStaff.length > 0 && (
        <div className="space-y-2">
          <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Inactive / offboarded</h3>
          {inactiveStaff.map((m) => (
            <StaffCard
              key={m.user_id}
              member={m}
              allStaff={staff}
              currentUserId={currentUserId}
              onEdit={(s) => { setEditing(s); setFormError(undefined); }}
              onOffboard={setOffboarding}
            />
          ))}
        </div>
      )}

      {/* Add modal */}
      {showAdd && (
        <StaffModal
          onClose={() => setShowAdd(false)}
          onSave={(data) => createMutation.mutate({ ...data, requested_by: currentUserId })}
          isSaving={createMutation.isPending}
          error={formError}
        />
      )}

      {/* Edit modal */}
      {editing && (
        <StaffModal
          existing={editing}
          onClose={() => setEditing(null)}
          onSave={(data) => updateMutation.mutate({ ...data, user_id: editing.user_id, requested_by: currentUserId })}
          isSaving={updateMutation.isPending}
          error={formError}
        />
      )}

      {/* Offboard modal */}
      {offboarding && (
        <OffboardModal
          member={offboarding}
          allStaff={staff}
          onClose={() => setOffboarding(null)}
          onConfirm={(reassignTo, reason) =>
            offboardMutation.mutate({
              user_id: offboarding.user_id,
              reassign_to: reassignTo,
              reason,
              requested_by: currentUserId,
            })
          }
          isSaving={offboardMutation.isPending}
        />
      )}
    </div>
  );
}
