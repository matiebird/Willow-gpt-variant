"use client";

/**
 * Settings hub — visible to admin only.
 * Links to License and Integrations sub-pages.
 */

import Link from "next/link";
import { Key, Plug, ChevronRight } from "lucide-react";
import { AdminGuard } from "@/components/AdminGuard";

const sections = [
  {
    href:        "/settings/license",
    icon:        Key,
    label:       "License",
    description: "View license status, get your Hardware ID, and activate a new key.",
  },
  {
    href:        "/settings/integrations",
    icon:        Plug,
    label:       "Integrations",
    description: "Connect Xero, Gmail, or Outlook. Update credentials and reconnect expired tokens.",
  },
];

export default function SettingsPage() {
  return (
    <AdminGuard>
      <div className="max-w-xl space-y-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Administrator controls for Willow.
          </p>
        </div>

        <div className="space-y-3">
          {sections.map(({ href, icon: Icon, label, description }) => (
            <Link
              key={href}
              href={href}
              className="flex items-center gap-4 rounded-xl border bg-card px-5 py-4 shadow-sm hover:bg-accent transition-colors group"
            >
              <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg bg-primary/10">
                <Icon className="h-5 w-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm">{label}</p>
                <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{description}</p>
              </div>
              <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-foreground transition-colors flex-shrink-0" />
            </Link>
          ))}
        </div>
      </div>
    </AdminGuard>
  );
}
