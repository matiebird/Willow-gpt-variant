"use client";

/**
 * Willow — Integrations Settings
 * Configure Xero (accounting) and Gmail or Outlook (email).
 * Secrets are write-only — shown as •••• once saved.
 * "Test Connection" checks the live token without leaving the page.
 */

import { useEffect, useState } from "react";
import { AdminGuard } from "@/components/AdminGuard";
import { useCurrentUser } from "@/hooks/useCurrentUser";
import {
  CheckCircle2, XCircle, Loader2, RefreshCw, Plug, Unplug,
  ChevronDown, ChevronUp, AlertTriangle, Info,
} from "lucide-react";
import { apiClient } from "@/lib/api";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

type EmailProvider = "gmail" | "outlook" | null;

interface ProviderCfg {
  configured:   boolean;
  has_session:  boolean;
  client_id?:   string;
  tenant_id?:   string;
}

interface Integrations {
  email_provider: EmailProvider;
  xero:           ProviderCfg;
  gmail:          ProviderCfg;
  outlook:        ProviderCfg;
}

interface TestResult {
  connected: boolean;
  reason:    string;
}

// ---------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------

function StatusPill({ configured, has_session, testing }: {
  configured: boolean; has_session: boolean; testing: boolean;
}) {
  if (testing) {
    return (
      <span className="inline-flex items-center gap-1 rounded-full bg-muted px-2.5 py-1 text-xs font-medium text-muted-foreground">
        <Loader2 className="h-3 w-3 animate-spin" /> Testing…
      </span>
    );
  }
  if (!configured) {
    return (
      <span className="inline-flex items-center gap-1 rounded-full bg-muted px-2.5 py-1 text-xs font-medium text-muted-foreground">
        Not configured
      </span>
    );
  }
  if (!has_session) {
    return (
      <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 dark:bg-amber-900/40 px-2.5 py-1 text-xs font-medium text-amber-700 dark:text-amber-300">
        <AlertTriangle className="h-3 w-3" /> Needs authorisation
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-green-100 dark:bg-green-900/40 px-2.5 py-1 text-xs font-medium text-green-700 dark:text-green-300">
      <CheckCircle2 className="h-3 w-3" /> Connected
    </span>
  );
}

function Field({
  label, id, type = "text", value, onChange, placeholder, hint,
}: {
  label: string; id: string; type?: string;
  value: string; onChange: (v: string) => void;
  placeholder?: string; hint?: string;
}) {
  return (
    <div className="space-y-1.5">
      <label htmlFor={id} className="block text-sm font-medium">
        {label}
      </label>
      <input
        id={id}
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        autoComplete="off"
        spellCheck={false}
        className="w-full rounded-lg border bg-muted px-3 py-2 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-primary/40"
      />
      {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Xero card
// ---------------------------------------------------------------------------

function XeroCard({
  cfg, onSave, onTest, onDisconnect,
}: {
  cfg:          ProviderCfg;
  onSave:       (data: { client_id: string; client_secret: string }) => Promise<void>;
  onTest:       () => Promise<TestResult>;
  onDisconnect: () => Promise<void>;
}) {
  const [open,         setOpen]         = useState(!cfg.configured);
  const [clientId,     setClientId]     = useState(cfg.client_id ?? "");
  const [clientSecret, setClientSecret] = useState("");
  const [saving,       setSaving]       = useState(false);
  const [testing,      setTesting]      = useState(false);
  const [testResult,   setTestResult]   = useState<TestResult | null>(null);

  const handleSave = async () => {
    setSaving(true);
    await onSave({ client_id: clientId, client_secret: clientSecret });
    setSaving(false);
    setClientSecret("");   // clear secret field after save
  };

  const handleTest = async () => {
    setTesting(true);
    setTestResult(null);
    const res = await onTest();
    setTestResult(res);
    setTesting(false);
  };

  // Xero OAuth URL (opened in new tab — user completes auth, token returned via callback)
  const xeroAuthUrl =
    `https://login.xero.com/identity/connect/authorize` +
    `?response_type=code&client_id=${encodeURIComponent(clientId)}` +
    `&redirect_uri=${encodeURIComponent(window.location.origin + "/api/v1/oauth/xero/callback")}` +
    `&scope=openid%20profile%20email%20accounting.transactions%20accounting.contacts%20offline_access` +
    `&state=willow`;

  return (
    <div className="rounded-xl border bg-card shadow-sm overflow-hidden">
      <button
        className="flex w-full items-center justify-between px-5 py-4 hover:bg-accent/30 transition-colors"
        onClick={() => setOpen(!open)}
      >
        <div className="flex items-center gap-3">
          {/* Xero logo placeholder */}
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#13B5EA]/10 text-[#13B5EA] font-bold text-sm">
            X
          </div>
          <div className="text-left">
            <p className="font-semibold text-sm">Xero</p>
            <p className="text-xs text-muted-foreground">Accounting &amp; invoicing</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <StatusPill configured={cfg.configured} has_session={cfg.has_session} testing={testing} />
          {open ? <ChevronUp className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
        </div>
      </button>

      {open && (
        <div className="border-t px-5 pb-5 pt-4 space-y-4">
          <div className="flex items-start gap-2 rounded-lg bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 px-3 py-2.5 text-xs text-blue-700 dark:text-blue-300">
            <Info className="h-3.5 w-3.5 flex-shrink-0 mt-0.5" />
            <span>
              Create a Xero app at{" "}
              <a href="https://developer.xero.com/app/manage" target="_blank" rel="noopener noreferrer" className="underline">
                developer.xero.com/app/manage
              </a>
              . Use <strong>Web App</strong> type. Set the redirect URI to{" "}
              <code className="bg-blue-100 dark:bg-blue-900 px-1 rounded">
                {typeof window !== "undefined" ? window.location.origin : "http://willow.local"}/api/v1/oauth/xero/callback
              </code>
            </span>
          </div>

          <Field label="Client ID"     id="xero-client-id"     value={clientId}     onChange={setClientId}     placeholder="Your Xero app Client ID" />
          <Field label="Client Secret" id="xero-client-secret" value={clientSecret} onChange={setClientSecret} placeholder={cfg.configured ? "••••••••  (leave blank to keep existing)" : "Your Xero app Client Secret"} type="password" />

          {testResult && (
            <div className={`flex items-start gap-2 rounded-lg border px-3 py-2.5 text-xs ${
              testResult.connected
                ? "bg-green-50 border-green-200 text-green-700 dark:bg-green-950/40 dark:border-green-800 dark:text-green-300"
                : "bg-red-50 border-red-200 text-red-700 dark:bg-red-950/40 dark:border-red-800 dark:text-red-300"
            }`}>
              {testResult.connected
                ? <CheckCircle2 className="h-3.5 w-3.5 flex-shrink-0 mt-0.5" />
                : <XCircle className="h-3.5 w-3.5 flex-shrink-0 mt-0.5" />}
              {testResult.reason}
            </div>
          )}

          <div className="flex flex-wrap gap-2 pt-1">
            <button
              onClick={handleSave}
              disabled={saving || (!clientId)}
              className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 transition-colors disabled:opacity-50"
            >
              {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null}
              Save Credentials
            </button>

            {cfg.configured && (
              <>
                <a
                  href={xeroAuthUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-lg border bg-card px-4 py-2 text-sm font-medium hover:bg-accent transition-colors"
                >
                  <Plug className="h-3.5 w-3.5" />
                  {cfg.has_session ? "Reconnect Xero" : "Authorise Xero"}
                </a>

                <button
                  onClick={handleTest}
                  disabled={testing}
                  className="inline-flex items-center gap-1.5 rounded-lg border bg-card px-4 py-2 text-sm font-medium hover:bg-accent transition-colors disabled:opacity-50"
                >
                  <RefreshCw className={`h-3.5 w-3.5 ${testing ? "animate-spin" : ""}`} />
                  Test Connection
                </button>

                {cfg.has_session && (
                  <button
                    onClick={onDisconnect}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-red-200 px-4 py-2 text-sm font-medium text-red-600 hover:bg-red-50 dark:hover:bg-red-950 transition-colors"
                  >
                    <Unplug className="h-3.5 w-3.5" />
                    Disconnect
                  </button>
                )}
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Email card (Gmail or Outlook)
// ---------------------------------------------------------------------------

function EmailCard({
  provider, cfg, onProviderChange, onSave, onTest, onDisconnect,
}: {
  provider:         EmailProvider;
  cfg:              { gmail: ProviderCfg; outlook: ProviderCfg };
  onProviderChange: (p: EmailProvider) => Promise<void>;
  onSave:           (provider: "gmail" | "outlook", data: Record<string, string>) => Promise<void>;
  onTest:           (provider: "gmail" | "outlook") => Promise<TestResult>;
  onDisconnect:     (provider: "gmail" | "outlook") => Promise<void>;
}) {
  const [open,         setOpen]         = useState(false);
  const [selected,     setSelected]     = useState<"gmail" | "outlook">(provider ?? "gmail");
  const [clientId,     setClientId]     = useState("");
  const [clientSecret, setClientSecret] = useState("");
  const [tenantId,     setTenantId]     = useState(cfg.outlook.tenant_id ?? "common");
  const [saving,       setSaving]       = useState(false);
  const [testing,      setTesting]      = useState(false);
  const [testResult,   setTestResult]   = useState<TestResult | null>(null);

  const activeCfg = selected === "gmail" ? cfg.gmail : cfg.outlook;

  const handleProviderSwitch = async (p: "gmail" | "outlook") => {
    setSelected(p);
    setTestResult(null);
    await onProviderChange(p);
  };

  const handleSave = async () => {
    setSaving(true);
    const data: Record<string, string> = { client_id: clientId, client_secret: clientSecret };
    if (selected === "outlook") data.tenant_id = tenantId;
    await onSave(selected, data);
    setSaving(false);
    setClientSecret("");
  };

  const handleTest = async () => {
    setTesting(true);
    setTestResult(null);
    const res = await onTest(selected);
    setTestResult(res);
    setTesting(false);
  };

  const gmailAuthUrl =
    `https://accounts.google.com/o/oauth2/v2/auth` +
    `?response_type=code&client_id=${encodeURIComponent(clientId)}` +
    `&redirect_uri=${encodeURIComponent(typeof window !== "undefined" ? window.location.origin : "")}/api/v1/oauth/gmail/callback` +
    `&scope=https://www.googleapis.com/auth/gmail.modify%20https://www.googleapis.com/auth/gmail.send` +
    `&access_type=offline&prompt=consent`;

  const outlookAuthUrl =
    `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/authorize` +
    `?response_type=code&client_id=${encodeURIComponent(clientId)}` +
    `&redirect_uri=${encodeURIComponent(typeof window !== "undefined" ? window.location.origin : "")}/api/v1/oauth/outlook/callback` +
    `&scope=https://graph.microsoft.com/Mail.ReadWrite%20https://graph.microsoft.com/Mail.Send%20offline_access` +
    `&state=willow`;

  const authUrl = selected === "gmail" ? gmailAuthUrl : outlookAuthUrl;

  return (
    <div className="rounded-xl border bg-card shadow-sm overflow-hidden">
      <button
        className="flex w-full items-center justify-between px-5 py-4 hover:bg-accent/30 transition-colors"
        onClick={() => setOpen(!open)}
      >
        <div className="flex items-center gap-3">
          <div className={`flex h-9 w-9 items-center justify-center rounded-lg font-bold text-sm ${
            provider === "gmail"
              ? "bg-red-50 dark:bg-red-950/40 text-red-600"
              : provider === "outlook"
              ? "bg-blue-50 dark:bg-blue-950/40 text-blue-600"
              : "bg-muted text-muted-foreground"
          }`}>
            {provider === "gmail" ? "G" : provider === "outlook" ? "O" : "✉"}
          </div>
          <div className="text-left">
            <p className="font-semibold text-sm">
              Email{provider ? ` — ${provider === "gmail" ? "Gmail" : "Outlook 365"}` : ""}
            </p>
            <p className="text-xs text-muted-foreground">Incoming mail &amp; follow-up sending</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <StatusPill
            configured={activeCfg.configured}
            has_session={activeCfg.has_session}
            testing={testing}
          />
          {open ? <ChevronUp className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
        </div>
      </button>

      {open && (
        <div className="border-t px-5 pb-5 pt-4 space-y-4">

          {/* Provider toggle */}
          <div className="space-y-1.5">
            <p className="text-sm font-medium">Email provider</p>
            <div className="flex gap-2">
              {(["gmail", "outlook"] as const).map((p) => (
                <button
                  key={p}
                  onClick={() => handleProviderSwitch(p)}
                  className={`flex-1 rounded-lg border py-2 text-sm font-medium transition-colors ${
                    selected === p
                      ? "bg-primary text-primary-foreground border-primary"
                      : "bg-card hover:bg-accent text-foreground"
                  }`}
                >
                  {p === "gmail" ? "Gmail" : "Outlook 365"}
                </button>
              ))}
            </div>
            <p className="text-xs text-muted-foreground">
              {selected === "outlook"
                ? "Microsoft 365 / Exchange Online. Works with personal Outlook and work Microsoft accounts."
                : "Google Workspace or personal Gmail. Requires a Google Cloud OAuth2 app."}
            </p>
          </div>

          {/* Setup hint */}
          <div className="flex items-start gap-2 rounded-lg bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 px-3 py-2.5 text-xs text-blue-700 dark:text-blue-300">
            <Info className="h-3.5 w-3.5 flex-shrink-0 mt-0.5" />
            {selected === "gmail" ? (
              <span>
                Create OAuth2 credentials at{" "}
                <a href="https://console.cloud.google.com/apis/credentials" target="_blank" rel="noopener noreferrer" className="underline">
                  Google Cloud Console
                </a>
                . Choose <strong>Web application</strong>, add redirect URI:{" "}
                <code className="bg-blue-100 dark:bg-blue-900 px-1 rounded">
                  {typeof window !== "undefined" ? window.location.origin : ""}/api/v1/oauth/gmail/callback
                </code>
              </span>
            ) : (
              <span>
                Register an app at{" "}
                <a href="https://portal.azure.com/#view/Microsoft_AAD_RegisteredApps" target="_blank" rel="noopener noreferrer" className="underline">
                  Azure App Registrations
                </a>
                . Set redirect URI to:{" "}
                <code className="bg-blue-100 dark:bg-blue-900 px-1 rounded">
                  {typeof window !== "undefined" ? window.location.origin : ""}/api/v1/oauth/outlook/callback
                </code>
              </span>
            )}
          </div>

          <Field label="Client ID"     id="email-client-id"     value={clientId}     onChange={setClientId}     placeholder={`Your ${selected === "gmail" ? "Google" : "Azure"} Client ID`} />
          <Field label="Client Secret" id="email-client-secret" value={clientSecret} onChange={setClientSecret} placeholder={activeCfg.configured ? "•••••••• (leave blank to keep existing)" : "Your Client Secret"} type="password" />

          {selected === "outlook" && (
            <Field
              label="Tenant ID"
              id="outlook-tenant-id"
              value={tenantId}
              onChange={setTenantId}
              placeholder="common"
              hint='Use "common" for personal accounts, or your Azure tenant GUID for work accounts.'
            />
          )}

          {testResult && (
            <div className={`flex items-start gap-2 rounded-lg border px-3 py-2.5 text-xs ${
              testResult.connected
                ? "bg-green-50 border-green-200 text-green-700 dark:bg-green-950/40 dark:border-green-800 dark:text-green-300"
                : "bg-red-50 border-red-200 text-red-700 dark:bg-red-950/40 dark:border-red-800 dark:text-red-300"
            }`}>
              {testResult.connected
                ? <CheckCircle2 className="h-3.5 w-3.5 flex-shrink-0 mt-0.5" />
                : <XCircle className="h-3.5 w-3.5 flex-shrink-0 mt-0.5" />}
              {testResult.reason}
            </div>
          )}

          <div className="flex flex-wrap gap-2 pt-1">
            <button
              onClick={handleSave}
              disabled={saving || !clientId}
              className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 transition-colors disabled:opacity-50"
            >
              {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null}
              Save Credentials
            </button>

            {activeCfg.configured && (
              <>
                <a
                  href={authUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-lg border bg-card px-4 py-2 text-sm font-medium hover:bg-accent transition-colors"
                >
                  <Plug className="h-3.5 w-3.5" />
                  {activeCfg.has_session
                    ? `Reconnect ${selected === "gmail" ? "Gmail" : "Outlook"}`
                    : `Authorise ${selected === "gmail" ? "Gmail" : "Outlook"}`}
                </a>

                <button
                  onClick={handleTest}
                  disabled={testing}
                  className="inline-flex items-center gap-1.5 rounded-lg border bg-card px-4 py-2 text-sm font-medium hover:bg-accent transition-colors disabled:opacity-50"
                >
                  <RefreshCw className={`h-3.5 w-3.5 ${testing ? "animate-spin" : ""}`} />
                  Test Connection
                </button>

                {activeCfg.has_session && (
                  <button
                    onClick={() => onDisconnect(selected)}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-red-200 px-4 py-2 text-sm font-medium text-red-600 hover:bg-red-50 dark:hover:bg-red-950 transition-colors"
                  >
                    <Unplug className="h-3.5 w-3.5" />
                    Disconnect
                  </button>
                )}
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Page
// ---------------------------------------------------------------------------

export default function IntegrationsPage() {
  const [integrations, setIntegrations] = useState<Integrations | null>(null);
  const [loading,      setLoading]      = useState(true);
  const [saveError,    setSaveError]    = useState("");

  const { user } = useCurrentUser();
  const staffId = user?.user_id ?? "";

  const fetchIntegrations = async () => {
    setLoading(true);
    try {
      const res = await apiClient.get<Integrations>("/v1/settings/integrations", { params: { staff_id: staffId } });
      setIntegrations(res.data);
    } catch {
      // ignore — show skeleton
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchIntegrations(); }, []);

  const saveIntegrations = async (payload: Record<string, unknown>) => {
    setSaveError("");
    try {
      await apiClient.put("/v1/settings/integrations", payload, { params: { staff_id: staffId } });
      await fetchIntegrations();
    } catch (err: unknown) {
      setSaveError(err instanceof Error ? err.message : "Save failed");
    }
  };

  const testProvider = async (provider: "xero" | "gmail" | "outlook"): Promise<TestResult> => {
    try {
      const res = await apiClient.post<TestResult>(`/v1/settings/integrations/test/${provider}`, {}, { params: { staff_id: staffId } });
      await fetchIntegrations();  // refresh session status
      return res.data;
    } catch (err: unknown) {
      return { connected: false, reason: err instanceof Error ? err.message : "Test failed" };
    }
  };

  const disconnectProvider = async (provider: "xero" | "gmail" | "outlook") => {
    try {
      await apiClient.delete(`/v1/settings/integrations/${provider}`, { params: { staff_id: staffId } });
      await fetchIntegrations();
    } catch {/* ignore */}
  };

  const cfg = integrations ?? {
    email_provider: null,
    xero:    { configured: false, has_session: false },
    gmail:   { configured: false, has_session: false },
    outlook: { configured: false, has_session: false },
  };

  return (
    <AdminGuard>
      {loading ? (
        <div className="flex items-center gap-2 text-sm text-muted-foreground py-12">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading integrations…
        </div>
      ) : (
      <div className="max-w-2xl space-y-6">

      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Integrations</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Connect Willow to your accounting and email accounts.
          Credentials are stored locally — nothing leaves your server.
        </p>
      </div>

      {saveError && (
        <div className="flex items-start gap-2 rounded-xl border border-red-200 bg-red-50 dark:bg-red-950/30 px-4 py-3 text-sm text-red-700 dark:text-red-300">
          <AlertTriangle className="h-4 w-4 flex-shrink-0 mt-0.5" />
          {saveError}
        </div>
      )}

      {/* Xero */}
      <XeroCard
        cfg={cfg.xero}
        onSave={async (data) => {
          await saveIntegrations({ xero: data });
        }}
        onTest={async () => testProvider("xero")}
        onDisconnect={async () => disconnectProvider("xero")}
      />

      {/* Email */}
      <EmailCard
        provider={cfg.email_provider}
        cfg={{ gmail: cfg.gmail, outlook: cfg.outlook }}
        onProviderChange={async (p) => {
          await saveIntegrations({ email_provider: p });
        }}
        onSave={async (provider, data) => {
          await saveIntegrations({ [provider]: data, email_provider: provider });
        }}
        onTest={async (provider) => testProvider(provider)}
        onDisconnect={async (provider) => disconnectProvider(provider)}
      />

      {/* Footer */}
      <p className="text-xs text-muted-foreground pb-4">
        Token refresh happens automatically in the background.
        If a connection shows &quot;Needs authorisation&quot; click{" "}
        <strong>Reconnect</strong> — this re-runs the login flow and refreshes your token.
        No data leaves your local network during this process except the OAuth handshake
        with the provider.
      </p>

      </div>
      )}
    </AdminGuard>
  );
}
