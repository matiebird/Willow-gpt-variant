"use client";

import { useEffect, useState } from "react";

type LicenseStatus = {
  mode: string;
  firm: string;
  tier: string;
  seats: number;
  seats_used?: number;
  seats_available?: number | null;
  seats_unlimited?: boolean;
  expires: string;
  days_remaining: number;
  readonly: boolean;
  writes_allowed?: boolean;
  updates_enabled?: boolean;
  support_active?: boolean;
  support_plan?: string | null;
  support_expires?: string | null;
  message: string;
};

const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? "/api/v1";

function badge(mode: string) {
  if (mode === "full") return "bg-green-100 text-green-800";
  if (mode === "expiring") return "bg-yellow-100 text-yellow-900";
  if (mode === "expired") return "bg-amber-100 text-amber-900";
  if (mode === "readonly") return "bg-pink-100 text-pink-900";
  return "bg-slate-100 text-slate-800";
}

export default function LicenseSettingsPage() {
  const [status, setStatus] = useState<LicenseStatus | null>(null);

  useEffect(() => {
    fetch(`${API_BASE}/license/status`).then((r) => r.json()).then(setStatus).catch(() => null);
  }, []);

  if (!status) {
    return <div className="rounded-xl border bg-card p-6 shadow-sm">Loading licence status…</div>;
  }

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Licence & Support</h1>
        <p className="text-sm text-muted-foreground">
          Willow is local-first. Paid customers keep operating even if their updates subscription lapses.
        </p>
      </div>

      <div className="rounded-xl border bg-card p-6 shadow-sm">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Current status</p>
            <div className="mt-2 flex items-center gap-3">
              <span className={`rounded-full px-3 py-1 text-sm font-semibold ${badge(status.mode)}`}>
                {status.mode.replace("_", " ").toUpperCase()}
              </span>
              <span className="text-lg font-semibold">{status.firm || "Unlicensed"}</span>
            </div>
            <p className="mt-3 max-w-3xl text-sm text-muted-foreground">{status.message}</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-muted-foreground">Tier</p>
            <p className="text-lg font-semibold capitalize">{status.tier}</p>
          </div>
        </div>

        <div className="mt-6 grid gap-4 md:grid-cols-4">
          <div className="rounded-lg border p-4">
            <p className="text-xs text-muted-foreground">Writes</p>
            <p className="mt-1 text-lg font-semibold">{status.writes_allowed === false ? "Blocked" : "Allowed"}</p>
          </div>
          <div className="rounded-lg border p-4">
            <p className="text-xs text-muted-foreground">Updates</p>
            <p className="mt-1 text-lg font-semibold">{status.updates_enabled ? "Enabled" : "Paused"}</p>
          </div>
          <div className="rounded-lg border p-4">
            <p className="text-xs text-muted-foreground">Support</p>
            <p className="mt-1 text-lg font-semibold">{status.support_active ? status.support_plan || "Active" : "Not active"}</p>
          </div>
          <div className="rounded-lg border p-4">
            <p className="text-xs text-muted-foreground">Seats</p>
            <p className="mt-1 text-lg font-semibold">
              {status.seats_unlimited ? `${status.seats_used ?? 0} / unlimited` : `${status.seats_used ?? 0} / ${status.seats}`}
            </p>
          </div>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <div className="rounded-xl border bg-card p-6 shadow-sm">
          <h2 className="font-semibold">Perpetual fallback promise</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            If a paid licence expires, Willow keeps processing work. Your team can still create tasks, handle calls,
            triage emails and access records. Renewal resumes updates, new premium features and optional support.
          </p>
        </div>
        <div className="rounded-xl border bg-card p-6 shadow-sm">
          <h2 className="font-semibold">Trial expiry rule</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Read-only mode only applies when the initial trial expires and no paid licence has ever been installed.
            This protects the product without holding customer data hostage.
          </p>
        </div>
      </div>
    </div>
  );
}
