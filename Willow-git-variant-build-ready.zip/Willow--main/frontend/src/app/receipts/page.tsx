"use client";

import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { useMutation } from "@tanstack/react-query";
import { aiApi, ReceiptUploadResponse } from "@/lib/api";
import {
  Upload, CheckCircle2, AlertCircle, Loader2, FileImage, FileType,
} from "lucide-react";

export default function ReceiptsPage() {
  const [result, setResult] = useState<ReceiptUploadResponse | null>(null);
  const [autoCreate, setAutoCreate] = useState(false);

  const uploadMutation = useMutation({
    mutationFn: (file: File) => aiApi.uploadReceipt(file, autoCreate),
    onSuccess: (data) => setResult(data),
  });

  const onDrop = useCallback(
    (acceptedFiles: File[]) => {
      if (acceptedFiles[0]) {
        setResult(null);
        uploadMutation.mutate(acceptedFiles[0]);
      }
    },
    [uploadMutation]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "image/jpeg": [],
      "image/png": [],
      "image/webp": [],
      "application/pdf": [],
    },
    maxFiles: 1,
    maxSize: 20 * 1024 * 1024,
  });

  const fmt = (n: number) =>
    new Intl.NumberFormat("en-AU", { style: "currency", currency: "AUD" }).format(n);

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">AI Receipt Scanner</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Upload a receipt or invoice. Text is extracted locally via OCR, then
          structured data is pulled by the on-device LLM. Nothing leaves your network.
        </p>
      </div>

      {/* Drop zone */}
      <div
        {...getRootProps()}
        className={`cursor-pointer rounded-xl border-2 border-dashed p-12 text-center transition-colors ${
          isDragActive
            ? "border-primary bg-primary/5"
            : "border-border bg-card hover:border-primary/50 hover:bg-accent/30"
        }`}
      >
        <input {...getInputProps()} />
        {uploadMutation.isPending ? (
          <div className="flex flex-col items-center gap-3">
            <Loader2 className="h-10 w-10 animate-spin text-primary" />
            <p className="font-medium">Processing receipt locally…</p>
            <p className="text-sm text-muted-foreground">
              OCR → Local LLM extraction. This may take 15–60s.
            </p>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-3">
            <div className="flex items-center gap-2">
              <FileImage className="h-8 w-8 text-muted-foreground" />
              <Upload className="h-10 w-10 text-primary" />
            </div>
            <p className="font-medium">
              {isDragActive ? "Drop it here" : "Drop a receipt or click to browse"}
            </p>
            <p className="text-xs text-muted-foreground">
              JPEG · PNG · WEBP · PDF — up to 20MB
            </p>
          </div>
        )}
      </div>

      {/* Auto-create toggle */}
      <label className="flex cursor-pointer items-center gap-3">
        <input
          type="checkbox"
          checked={autoCreate}
          onChange={(e) => setAutoCreate(e.target.checked)}
          className="h-4 w-4 rounded border-input"
        />
        <span className="text-sm">
          Auto-create Draft transaction if confidence ≥ 80%
        </span>
      </label>

      {/* Error */}
      {uploadMutation.isError && (
        <div className="flex gap-3 rounded-lg border border-red-200 bg-red-50 p-4 dark:border-red-900 dark:bg-red-950">
          <AlertCircle className="h-5 w-5 flex-shrink-0 text-red-500 mt-0.5" />
          <div>
            <p className="font-medium text-red-700 dark:text-red-400">Processing failed</p>
            <p className="text-sm text-red-600 dark:text-red-300">
              {(uploadMutation.error as Error).message}
            </p>
          </div>
        </div>
      )}

      {/* Result */}
      {result && result.extracted_data && (
        <div className="rounded-xl border bg-card shadow-sm">
          <div className="flex items-center justify-between border-b px-6 py-4">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-green-500" />
              <h2 className="font-semibold">Extraction Complete</h2>
            </div>
            <span
              className={`rounded-full px-3 py-1 text-xs font-medium ${
                (result.confidence ?? 0) >= 0.8
                  ? "bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-400"
                  : "bg-yellow-100 text-yellow-700 dark:bg-yellow-950 dark:text-yellow-400"
              }`}
            >
              {((result.confidence ?? 0) * 100).toFixed(0)}% confidence
            </span>
          </div>

          <div className="grid grid-cols-2 gap-x-6 gap-y-4 px-6 py-5 text-sm">
            {[
              ["Vendor", result.extracted_data.vendor_name],
              ["Date", result.extracted_data.date],
              ["Total", fmt(result.extracted_data.total_amount)],
              ["Tax (GST)", fmt(result.extracted_data.tax_amount)],
              ["Category", result.extracted_data.category_suggestion],
              ["Payment", result.extracted_data.payment_method],
              ["Receipt #", result.extracted_data.receipt_number],
              ["ABN", result.extracted_data.abn],
            ].map(([label, value]) =>
              value ? (
                <div key={label as string}>
                  <p className="text-xs text-muted-foreground">{label}</p>
                  <p className="font-medium">{value}</p>
                </div>
              ) : null
            )}
          </div>

          {result.requires_human_review && (
            <div className="border-t px-6 py-3">
              <p className="text-sm text-yellow-600 dark:text-yellow-400">
                Low confidence — please review and correct before saving.
              </p>
            </div>
          )}

          {result.message && (
            <div className="border-t px-6 py-3 text-sm text-muted-foreground">
              {result.message}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
