"use client";

/**
 * Willow License Banner — perpetual-fallback model.
 *
 * Paid licences that lapse do not lock customer workflows or data. They enter
 * `expired` mode: writes continue and updates/support are paused. Read-only is
 * reserved for never-paid trial expiry.
 */

import { useEffect, useState } from "react";

type LicenseMode = "full" | "trial" | "expiring" | "expired" | "readonly" | "invalid";

interface LicenseStatus {
  mode: LicenseMode;
  firm: string;
  tier: string;
  days_remaining: number;
  expires: string;
  readonly: boolean;
  writes_allowed?: boolean;
  updates_enabled?: boolean;
  support_active?: boolean;
  support_plan?: string | null;
  message: string;
  banner?: string;
}

const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? "/api/v1";

const BANNER_CONFIG: Record<
  Exclude<LicenseMode, "full">,
  { bg: string; border: string; text: (s: LicenseStatus) => string }
> = {
  trial: {
    bg: "#01696F",
    border: "#0C4E54",
    text: (s) =>
      s.banner ||
      `Trial mode — ${s.days_remaining} day${s.days_remaining !== 1 ? "s" : ""} remaining · ` +
        `Install a paid licence to unlock perpetual fallback`,
  },
  expiring: {
    bg: "#964219",
    border: "#6B2E10",
    text: (s) =>
      s.banner ||
      `Licence renewal due in ${s.days_remaining} day${s.days_remaining !== 1 ? "s" : ""} · ` +
        `Willow keeps running; renew for updates/support`,
  },
  expired: {
    bg: "#6B5B00",
    border: "#4D4100",
    text: (s) =>
      s.banner ||
      `Updates paused — Willow continues operating normally · Renew to resume updates/support`,
  },
  readonly: {
    bg: "#A12C7B",
    border: "#7A1F5C",
    text: (s) =>
      s.banner ||
      `Trial expired — read-only until a paid licence is installed · Existing data remains accessible`,
  },
  invalid: {
    bg: "#A12C7B",
    border: "#7A1F5C",
    text: (s) => `Licence needs attention · ${s.message}`,
  },
};

export function LicenseBanner() {
  const [status, setStatus] = useState<LicenseStatus | null>(null);

  useEffect(() => {
    fetch(`${API_BASE}/license/status`)
      .then((r) => (r.ok ? r.json() : null))
      .then((data: LicenseStatus | null) => {
        if (data && data.mode !== "full") setStatus(data);
      })
      .catch(() => {
        // Silent fail — never break the app over a license check.
      });
  }, []);

  if (!status || status.mode === "full") return null;

  const config = BANNER_CONFIG[status.mode as Exclude<LicenseMode, "full">];
  if (!config) return null;

  return (
    <div
      role="alert"
      style={{
        backgroundColor: config.bg,
        borderBottom: `2px solid ${config.border}`,
        color: "#fff",
        textAlign: "center",
        padding: "7px 16px",
        fontSize: "13px",
        fontWeight: 500,
        letterSpacing: "0.015em",
        lineHeight: "1.4",
        position: "sticky",
        top: 0,
        zIndex: 9999,
        fontFamily:
          "Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      }}
    >
      {config.text(status)}
    </div>
  );
}

export default LicenseBanner;
