"use client";

export function Header() {
  return (
    <header className="flex h-16 items-center justify-between border-b bg-card px-6">
      <div />
      <div className="flex items-center gap-3 text-sm text-muted-foreground">
        <span className="inline-flex items-center gap-1.5 rounded-full bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-900 px-2.5 py-1 text-xs font-medium text-green-700 dark:text-green-300">
          <span className="h-1.5 w-1.5 rounded-full bg-green-500 animate-pulse" />
          All processing is local
        </span>
      </div>
    </header>
  );
}
