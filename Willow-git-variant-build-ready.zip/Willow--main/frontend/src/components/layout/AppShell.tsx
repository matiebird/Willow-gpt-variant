"use client";

/**
 * AppShell
 * Wraps all authenticated pages with the Sidebar + Header layout.
 * Redirects to /login if no staff_id is stored in localStorage.
 * Renders the login page full-screen (no sidebar/header).
 */

import { useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { Sidebar } from "./Sidebar";
import { Header } from "./Header";
import { LicenseBanner } from "../LicenseBanner";

const PUBLIC_PATHS = ["/login"];

export function AppShell({ children }: { children: React.ReactNode }) {
  const router   = useRouter();
  const pathname = usePathname();
  const isPublic = PUBLIC_PATHS.includes(pathname);

  // Track whether we've completed the auth check to avoid flash
  const [ready, setReady] = useState(isPublic);

  useEffect(() => {
    const staffId = localStorage.getItem("willows_staff_id");

    if (!staffId && !isPublic) {
      // Not logged in — send to login
      router.replace("/login");
      return;
    }

    if (staffId && pathname === "/login") {
      // Already logged in — send to dashboard
      router.replace("/");
      return;
    }

    setReady(true);
  }, [isPublic, pathname, router]);

  // Login page — full screen, no shell chrome
  if (isPublic) {
    return <>{children}</>;
  }

  // Auth check pending — render nothing to avoid layout flash
  if (!ready) return null;

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar />
      <div className="flex flex-1 flex-col overflow-hidden">
        <LicenseBanner />
        <Header />
        <main className="flex-1 overflow-y-auto p-6">{children}</main>
      </div>
    </div>
  );
}
