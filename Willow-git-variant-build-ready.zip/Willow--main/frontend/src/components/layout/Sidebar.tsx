"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import {
  LayoutDashboard, ArrowLeftRight, FileText, Users,
  Upload, BarChart2, Settings, Lock, Leaf, Clock,
  UserCog, Key, Plug, UserX, LogOut,
} from "lucide-react";
import { apiClient } from "@/lib/api";
import { useCurrentUser, resetUserCache } from "@/hooks/useCurrentUser";

type LicenseMode = "full" | "trial" | "expiring" | "readonly" | "invalid";

const nav = [
  { href: "/",             label: "Dashboard",    icon: LayoutDashboard },
  { href: "/transactions", label: "Transactions", icon: ArrowLeftRight },
  { href: "/invoices",     label: "Invoices",     icon: FileText },
  { href: "/accounts",     label: "Accounts",     icon: Users },
  { href: "/receipts",     label: "AI Receipts",  icon: Upload },
  { href: "/approvals",    label: "Approvals",    icon: Clock },
  { href: "/staff",        label: "Staff",        icon: UserCog },
  { href: "/reports",      label: "Reports",      icon: BarChart2 },
];

const bottom = [
  { href: "/settings/integrations", label: "Integrations", icon: Plug },
  { href: "/settings/license",      label: "License",      icon: Key  },
  { href: "/settings",              label: "Settings",     icon: Settings },
];

// Dot colour by license mode — only shown when action is needed
const LICENSE_DOT: Partial<Record<LicenseMode, string>> = {
  trial:    "bg-primary",
  expiring: "bg-amber-500",
  readonly: "bg-red-500",
  invalid:  "bg-red-500",
};

export function Sidebar() {
  const pathname    = usePathname();
  const router      = useRouter();
  const [licenseMode, setLicenseMode] = useState<LicenseMode | null>(null);
  const { user, loading, deactivated } = useCurrentUser();

  function handleLogout() {
    localStorage.removeItem("willows_staff_id");
    localStorage.removeItem("willows_token");
    resetUserCache();
    router.replace("/login");
  }

  useEffect(() => {
    apiClient
      .get<{ mode: LicenseMode }>("/v1/license/status")
      .then((r) => setLicenseMode(r.data.mode))
      .catch(() => {/* silent */});
  }, []);

  const isActive = (href: string) =>
    href === "/" ? pathname === "/" : pathname.startsWith(href);

  const dotColor = licenseMode ? LICENSE_DOT[licenseMode] : undefined;

  // ── Deactivated account screen ─────────────────────────────────────────────
  if (!loading && deactivated) {
    return (
      <aside className="flex h-full w-56 flex-col border-r bg-card">
        {/* Brand */}
        <div className="flex h-16 items-center gap-2.5 border-b px-5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
            <Leaf className="h-5 w-5 text-primary-foreground" />
          </div>
          <div>
            <span className="font-bold text-base leading-none">Willow</span>
            <span className="block text-[10px] text-muted-foreground leading-none mt-0.5">
              Your books. Your server.
            </span>
          </div>
        </div>
        {/* Deactivated notice */}
        <div className="flex flex-1 flex-col items-center justify-center px-5 text-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-red-100 dark:bg-red-900/30">
            <UserX className="h-6 w-6 text-red-600 dark:text-red-400" />
          </div>
          <div className="space-y-1.5">
            <p className="text-sm font-semibold text-foreground">Account Deactivated</p>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Your account has been deactivated. Contact your Willow administrator for assistance.
            </p>
          </div>
        </div>
      </aside>
    );
  }

  return (
    <aside className="flex h-full w-56 flex-col border-r bg-card">
      {/* Brand */}
      <div className="flex h-16 items-center gap-2.5 border-b px-5">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
          <Leaf className="h-5 w-5 text-primary-foreground" />
        </div>
        <div>
          <span className="font-bold text-base leading-none">Willow</span>
          <span className="block text-[10px] text-muted-foreground leading-none mt-0.5">
            Your books. Your server.
          </span>
        </div>
      </div>

      {/* Privacy badge */}
      <div className="mx-3 mt-3 flex items-center gap-1.5 rounded-lg bg-green-50 dark:bg-green-950 px-3 py-1.5">
        <Lock className="h-3 w-3 text-green-600 dark:text-green-400 flex-shrink-0" />
        <span className="text-[10px] font-medium text-green-700 dark:text-green-400">
          100% Local · No Cloud
        </span>
      </div>

      {/* Navigation */}
      <nav className="flex-1 space-y-1 px-3 py-4">
        {nav.map(({ href, label, icon: Icon }) => (
          <Link
            key={href}
            href={href}
            className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
              isActive(href)
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
            }`}
          >
            <Icon className="h-4 w-4 flex-shrink-0" />
            {label}
          </Link>
        ))}
      </nav>

      {/* Bottom nav — Settings + License + Integrations (admin only) */}
      {user?.is_admin && (
      <div className="border-t px-3 py-3 space-y-1">
        {bottom.map(({ href, label, icon: Icon }) => {
          const isLicense = href === "/settings/license";
          return (
            <Link
              key={href}
              href={href}
              className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                isActive(href)
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              }`}
            >
              <div className="relative flex-shrink-0">
                <Icon className="h-4 w-4" />
                {/* Status dot — only on License item, only when action needed */}
                {isLicense && dotColor && !isActive(href) && (
                  <span
                    className={`absolute -top-0.5 -right-0.5 h-2 w-2 rounded-full ${dotColor} ring-1 ring-background`}
                  />
                )}
              </div>
              {label}
              {/* Inline badge for trial/expiring/expired */}
              {isLicense && licenseMode && licenseMode !== "full" && (
                <span className={`ml-auto rounded-full px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide ${
                  isActive(href)
                    ? "bg-primary-foreground/20 text-primary-foreground"
                    : licenseMode === "trial"
                    ? "bg-primary/10 text-primary"
                    : licenseMode === "expiring"
                    ? "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300"
                    : "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300"
                }`}>
                  {licenseMode === "trial" ? "Trial" : licenseMode === "expiring" ? "Expiring" : "Action"}
                </span>
              )}
            </Link>
          );
        })}
      </div>
      )}

      {/* Sign out */}
      <div className="border-t px-3 py-2">
        <button
          onClick={handleLogout}
          className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
        >
          <LogOut className="h-4 w-4 flex-shrink-0" />
          Sign out
        </button>
      </div>
    </aside>
  );
}
