"use client";

/**
 * AdminGuard
 * Wraps any page that requires admin access.
 * Shows a neutral "admin only" message to non-admins instead of the page content.
 * Renders nothing while the role is still loading.
 */

import { ShieldOff } from "lucide-react";
import { useCurrentUser } from "@/hooks/useCurrentUser";

interface AdminGuardProps {
  children: React.ReactNode;
}

export function AdminGuard({ children }: AdminGuardProps) {
  const { user, loading } = useCurrentUser();

  // Still resolving — render nothing (avoids flash of content)
  if (loading) return null;

  if (!user?.is_admin) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-center select-none">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-muted mb-5">
          <ShieldOff className="h-7 w-7 text-muted-foreground/50" />
        </div>
        <h2 className="text-lg font-semibold">Admin access only</h2>
        <p className="mt-2 text-sm text-muted-foreground max-w-xs leading-relaxed">
          These settings can only be changed by a Willow administrator.
          Ask your admin if you need something updated.
        </p>
      </div>
    );
  }

  return <>{children}</>;
}
