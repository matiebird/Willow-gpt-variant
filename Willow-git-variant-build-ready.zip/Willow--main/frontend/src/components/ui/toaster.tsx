"use client";
// Minimal toast placeholder — replace with full shadcn/ui Toaster
export function Toaster() {
  return null;
}
