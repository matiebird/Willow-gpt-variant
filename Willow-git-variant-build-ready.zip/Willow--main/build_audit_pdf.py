#!/usr/bin/env python3
"""Build the Willow AI Repository Audit PDF."""

import urllib.request
from pathlib import Path

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import inch, mm
from reportlab.lib.colors import HexColor, white, Color
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, KeepTogether, HRFlowable,
)
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics

# -- Colours ------------------------------------------------------------------
TEAL = HexColor("#01696F")
BG = HexColor("#F7F6F2")
TEXT_COLOR = HexColor("#1C1917")
SURFACE_BG = HexColor("#EEEDEA")
WHITE = white
LIGHT_TEAL = HexColor("#E0F0F0")
RED_ISSUE = HexColor("#A12C7B")
ORANGE_WARN = HexColor("#964219")
GREEN_GOOD = HexColor("#437A22")
BORDER_GREY = HexColor("#D4D1CA")
TEXT_MUTED = HexColor("#7A7974")

# -- Fonts --------------------------------------------------------------------
FONT_DIR = Path("/tmp/fonts")
FONT_DIR.mkdir(exist_ok=True)

# Download DM Sans Bold from Google Fonts
dmsans_path = FONT_DIR / "DMSans-Bold.ttf"
if not dmsans_path.exists():
    print("Downloading DMSans-Bold...")
    urllib.request.urlretrieve(
        "https://github.com/google/fonts/raw/main/ofl/dmsans/DMSans%5Bopsz%2Cwght%5D.ttf",
        dmsans_path,
    )
pdfmetrics.registerFont(TTFont("DMSans-Bold", str(dmsans_path)))

# Use system Noto Sans fonts (no download needed)
pdfmetrics.registerFont(TTFont("NotoSans", "/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf"))
pdfmetrics.registerFont(TTFont("NotoSans-Bold", "/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf"))

# -- Page setup ---------------------------------------------------------------
PAGE_W, PAGE_H = A4
MARGIN = 54  # 0.75 inch

doc = SimpleDocTemplate(
    "/home/user/workspace/Willow-Repo-Audit.pdf",
    pagesize=A4,
    title="Willow AI -- Repository Audit",
    author="Perplexity Computer",
    leftMargin=MARGIN,
    rightMargin=MARGIN,
    topMargin=MARGIN,
    bottomMargin=MARGIN,
)

CONTENT_W = PAGE_W - 2 * MARGIN

# -- Styles -------------------------------------------------------------------
styles = getSampleStyleSheet()

s_cover_title = ParagraphStyle(
    "CoverTitle", fontName="DMSans-Bold", fontSize=28, leading=34,
    textColor=TEAL, alignment=TA_CENTER, spaceAfter=16,
)
s_cover_sub = ParagraphStyle(
    "CoverSub", fontName="NotoSans", fontSize=12, leading=16,
    textColor=TEXT_COLOR, alignment=TA_CENTER, spaceAfter=6,
)
s_section = ParagraphStyle(
    "SectionH", fontName="DMSans-Bold", fontSize=16, leading=20,
    textColor=TEAL, spaceBefore=20, spaceAfter=10,
)
s_subsection = ParagraphStyle(
    "SubH", fontName="DMSans-Bold", fontSize=12, leading=16,
    textColor=TEAL, spaceBefore=14, spaceAfter=6,
)
s_body = ParagraphStyle(
    "Body", fontName="NotoSans", fontSize=9.5, leading=14,
    textColor=TEXT_COLOR, spaceAfter=6,
)
s_body_indent = ParagraphStyle(
    "BodyIndent", parent=s_body, leftIndent=18,
)
s_bullet = ParagraphStyle(
    "Bullet", parent=s_body, leftIndent=18, bulletIndent=6,
    spaceAfter=3,
)
s_code = ParagraphStyle(
    "Code", fontName="Courier", fontSize=8, leading=11,
    textColor=HexColor("#333333"), leftIndent=18, spaceAfter=8,
    backColor=HexColor("#F0EFEB"),
)
s_table_header = ParagraphStyle(
    "TH", fontName="DMSans-Bold", fontSize=8.5, leading=11,
    textColor=WHITE, alignment=TA_LEFT,
)
s_table_cell = ParagraphStyle(
    "TC", fontName="NotoSans", fontSize=8.5, leading=11,
    textColor=TEXT_COLOR, alignment=TA_LEFT,
)
s_table_cell_small = ParagraphStyle(
    "TCS", fontName="NotoSans", fontSize=7.5, leading=10,
    textColor=TEXT_COLOR, alignment=TA_LEFT,
)


def badge_good(text="Good"):
    return f'<font color="#437A22">[GOOD] {text}</font>'

def badge_warn(text="Warning"):
    return f'<font color="#964219">[WARN] {text}</font>'

def badge_issue(text="Issue"):
    return f'<font color="#A12C7B">[ISSUE] {text}</font>'

def MISSING():
    return '<font color="#A12C7B">MISSING</font>'


# -- Header / Footer ---------------------------------------------------------
def header_footer(canvas_obj, doc_t):
    canvas_obj.saveState()
    # Footer
    canvas_obj.setFont("NotoSans", 7)
    canvas_obj.setFillColor(TEXT_MUTED)
    canvas_obj.drawString(MARGIN, 28, "Willow AI -- Repository Audit  |  Perplexity Computer  |  15 April 2026")
    canvas_obj.drawRightString(PAGE_W - MARGIN, 28, f"Page {doc_t.page}")
    # Thin teal line above footer
    canvas_obj.setStrokeColor(TEAL)
    canvas_obj.setLineWidth(0.5)
    canvas_obj.line(MARGIN, 40, PAGE_W - MARGIN, 40)
    canvas_obj.restoreState()

def cover_footer(canvas_obj, doc_t):
    pass  # no footer on cover


# -- Build story --------------------------------------------------------------
story = []

# -- COVER PAGE ---------------------------------------------------------------
story.append(Spacer(1, 2.5 * inch))
story.append(Paragraph("Willow AI -- Repository Audit", s_cover_title))
story.append(Spacer(1, 0.3 * inch))

# Teal divider
story.append(HRFlowable(width="40%", thickness=2, color=TEAL, spaceAfter=20, spaceBefore=10, hAlign="CENTER"))

story.append(Paragraph("Prepared by: Perplexity Computer", s_cover_sub))
story.append(Paragraph("Date: 15 April 2026", s_cover_sub))
story.append(Spacer(1, 0.3 * inch))
story.append(Paragraph(
    "Scope: Full codebase review cross-referenced against the "
    "EtienneLescot/n8n-as-code reference implementation.",
    ParagraphStyle("CoverScope", parent=s_cover_sub, fontSize=10, leading=14, textColor=TEXT_MUTED),
))

story.append(PageBreak())

# -- EXECUTIVE SUMMARY --------------------------------------------------------
story.append(Paragraph("Executive Summary", s_section))
story.append(Paragraph(
    "The Willow repository is well-structured and architecturally sound. The stack covers all required "
    "layers -- ingress, frontend, backend, agents, voice, database, and deployment automation. The n8n "
    "workflows are logically coherent and the Xero draft enforcement is correctly implemented at the "
    "service layer.",
    s_body,
))
story.append(Paragraph(
    "Four issues were found that need attention before production deployment: one critical policy breach "
    "in a workflow, three workflows missing required JSON fields, a gap in the database migration "
    "sequence, and the absence of workflow version tracking tooling used by n8n-as-code.",
    s_body,
))

# -- SECTION 1 -- N8N WORKFLOW AUDIT ------------------------------------------
story.append(Spacer(1, 10))
story.append(Paragraph("Section 1 -- N8N Workflow Audit", s_section))

# 1.1 Workflow Inventory
story.append(Paragraph("1.1  Workflow Inventory", s_subsection))
story.append(Paragraph("All 14 workflows were catalogued with their key fields:", s_body))

inv_header = [
    Paragraph("Workflow", s_table_header),
    Paragraph("ID", s_table_header),
    Paragraph("Active", s_table_header),
    Paragraph("execOrder", s_table_header),
    Paragraph("Issues", s_table_header),
]

inv_rows = [
    ["willow-main-assistant", MISSING(), MISSING(), "v1", "See 1.2"],
    ["willow-grace-extraction", "willow-grace-extraction-001", "[OK]", "v1", "None"],
    ["willow-hayley-reconciliation", "willow-hayley-reconciliation-001", "[OK]", "v1", "None"],
    ["willow-email-triage", "willow-email-triage-001", "[OK]", "v1", "None"],
    ["willow-morning-briefing", "willow-morning-briefing-001", "[OK]", "v1", "None"],
    ["willow-deadline-warning", MISSING(), MISSING(), "v1", "See 1.2"],
    ["willow-follow-up-executor", MISSING(), MISSING(), "v1", "See 1.3"],
    ["willow-client-onboarding", MISSING(), MISSING(), "v1", "See 1.2"],
    ["willow-receptionist", "willow-receptionist", "[OK]", "v1", "None"],
    ["willow-task-queue", "willow-task-queue", "[OK]", "v1", "None"],
    ["willow-ato-lookup", "willow-ato-lookup-001", MISSING(), "v1", "See 1.2"],
    ["willow-client-status", "willow-client-status-001", "[OK]", "v1", "None"],
    ["willow-sms", "willow-sms-001", "[OK]", "v1", "None"],
    ["willow-telegram", "willow-telegram-001", "[OK]", "v1", "None"],
]

table_data = [inv_header]
for row in inv_rows:
    table_data.append([Paragraph(c, s_table_cell_small) for c in row])

col_ws = [CONTENT_W * f for f in [0.25, 0.30, 0.10, 0.12, 0.23]]
inv_table = Table(table_data, colWidths=col_ws, repeatRows=1)
inv_table.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), TEAL),
    ("TEXTCOLOR", (0, 0), (-1, 0), WHITE),
    ("FONTNAME", (0, 0), (-1, 0), "DMSans-Bold"),
    ("FONTSIZE", (0, 0), (-1, -1), 8.5),
    ("ALIGN", (0, 0), (-1, -1), "LEFT"),
    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ("GRID", (0, 0), (-1, -1), 0.4, BORDER_GREY),
    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [WHITE, HexColor("#F9F8F5")]),
    ("TOPPADDING", (0, 0), (-1, -1), 5),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ("LEFTPADDING", (0, 0), (-1, -1), 5),
    ("RIGHTPADDING", (0, 0), (-1, -1), 5),
]))
story.append(inv_table)
story.append(Spacer(1, 8))

# 1.2 Missing id and active fields
story.append(Paragraph(f"1.2  Missing id and active fields  ({badge_warn()})", s_subsection))
story.append(Paragraph(
    'Four workflow JSON files are missing either the "id" field, the "active" field, or both:',
    s_body,
))
missing_items = [
    "willow-main-assistant.json -- missing both id and active",
    "willow-deadline-warning.json -- missing both id and active",
    "willow-follow-up-executor.json -- missing both id and active",
    "willow-client-onboarding.json -- missing both id and active",
    "willow-ato-lookup.json -- has id, missing active only",
]
for item in missing_items:
    story.append(Paragraph(f"-   {item}", s_bullet))

story.append(Paragraph(
    'The n8n-as-code WorkflowSanitizer (cleanForStorage) expects "id" and "active" to be present '
    'in every stored workflow JSON. When "active" is absent, n8n defaults to inactive on import -- '
    'meaning these workflows will silently do nothing after deployment until manually activated.',
    s_body,
))
story.append(Paragraph(
    '<b>Fix:</b> Add "active": true (or false for workflows that should start disabled) and a '
    'static string ID to each affected file.',
    s_body,
))
story.append(Paragraph(
    'Example fix for willow-main-assistant.json:',
    s_body,
))
story.append(Paragraph(
    '{<br/>'
    '&nbsp;&nbsp;"id": "willow-main-assistant-001",<br/>'
    '&nbsp;&nbsp;"name": "Willow Main Assistant",<br/>'
    '&nbsp;&nbsp;"active": true,<br/>'
    '&nbsp;&nbsp;...<br/>'
    '}',
    s_code,
))

# 1.3 Follow-up Executor -- POLICY BREACH
story.append(Paragraph(f"1.3  Follow-up Executor sends email directly -- POLICY BREACH  ({badge_issue('Critical')})", s_subsection))
story.append(Paragraph(
    'The willow-follow-up-executor workflow contains a Gmail node with operation: "send" that fires '
    "automatically on a 9AM Monday-Friday cron schedule with no human approval gate.",
    s_body,
))
story.append(Paragraph(
    'This directly violates the stated policy: "never publishes to Xero only ever as draft -- never auto-sends."',
    s_body,
))
story.append(Paragraph("The node sequence is:", s_body))
story.append(Paragraph(
    "Cron -> Get Due Sequences -> Any Due? -> Set Tone -> Compose Email -> "
    "Send Follow-up (Gmail) -> Advance Sequence",
    s_code,
))
story.append(Paragraph(
    'There is no webhook-wait, no dashboard approval step, and no human-in-the-loop between '
    '"Compose Email" and "Send Follow-up (Gmail)".',
    s_body,
))
story.append(Paragraph("<b>Fix:</b> Replace the direct Gmail send with a two-step pattern:", s_body))
story.append(Paragraph(
    "-   <b>Step 1</b> -- Write the composed email as a pending_approval record to the database "
    "(or create a Kanboard task with the draft content attached).",
    s_bullet,
))
story.append(Paragraph(
    "-   <b>Step 2</b> -- Add a separate approval webhook that a staff member triggers from the "
    "dashboard before the Gmail node actually sends.",
    s_bullet,
))
story.append(Paragraph(
    "This matches the pattern already used correctly in Hayley, where high-confidence documents still "
    "require the staff approval_limit check before anything goes to Xero.",
    s_body,
))

# 1.4 Task Manager Tool
story.append(Paragraph(f"1.4  Task Manager Tool -- broken environment variable reference  ({badge_warn()})", s_subsection))
story.append(Paragraph(
    "The willow-main-assistant workflow references {{ $env.TASK_WORKFLOW_ID }} for the Task Manager "
    "Tool, but this variable is intentionally commented out in .env.example with a note that the "
    "workflow does not yet exist.",
    s_body,
))
story.append(Paragraph(
    'Meanwhile, willow-task-queue.json does exist and has id: "willow-task-queue". The variable '
    "simply needs to be added to .env.example and the compose file.",
    s_body,
))
story.append(Paragraph("<b>Fix:</b> Add to .env.example:", s_body))
story.append(Paragraph("TASK_WORKFLOW_ID=willow-task-queue", s_code))

# 1.5 executionOrder
story.append(Paragraph(f"1.5  executionOrder -- all correct  ({badge_good()})", s_subsection))
story.append(Paragraph(
    'All 14 workflows correctly set "executionOrder": "v1" in their settings block. This is the most '
    "important setting the n8n-as-code sanitizer checks for -- it ensures AI agent tools run before "
    "the agent produces its final response. No issues here.",
    s_body,
))

# 1.6 No error handler workflows
story.append(Paragraph(f"1.6  No error handler workflows  ({badge_warn()})", s_subsection))
story.append(Paragraph(
    "None of the 14 workflows include an Error Trigger node. The n8n-as-code reference recommends "
    "a dedicated error-handling workflow that catches failures and routes them to an audit log or "
    "staff notification. Currently, any node failure in production will silently stop execution "
    "with no alert.",
    s_body,
))
story.append(Paragraph(
    "<b>Fix:</b> Create a willow-error-handler.json workflow with an Error Trigger node that writes "
    "to the audit_log table and optionally sends a staff notification via the existing backend "
    "/notify endpoint.",
    s_body,
))

# -- SECTION 2 -- DATABASE MIGRATION AUDIT ------------------------------------
story.append(PageBreak())
story.append(Paragraph("Section 2 -- Database Migration Audit", s_section))

# 2.1 Missing migration 002
story.append(Paragraph(f"2.1  Missing migration 002  ({badge_warn()})", s_subsection))
story.append(Paragraph("The migrations folder contains:", s_body))
mig_files = [
    "001_initial_schema.sql",
    "003_voice_and_queue.sql",
    "004_channels_and_intake.sql",
    "005_staff_client_management.sql",
    "006_policy_rag.sql",
]
for f in mig_files:
    story.append(Paragraph(f"-   {f}", s_bullet))

story.append(Paragraph(
    "Migration 002 is absent. PostgreSQL and Alembic apply migrations strictly in sequence. If 002 "
    "ever existed and was applied to a production database, it cannot be skipped. If it was deliberately "
    "removed, the gap in the numbering will confuse the Ansible database_migrations role and any "
    "future developer.",
    s_body,
))
story.append(Paragraph(
    "<b>Fix:</b> Either create a placeholder 002_placeholder.sql that is empty but exists to fill the "
    "gap, or renumber 003-006 to 002-005 (only safe to do before first production deployment).",
    s_body,
))

# 2.2 Schema coverage
story.append(Paragraph(f"2.2  Schema coverage -- solid  ({badge_good()})", s_subsection))
story.append(Paragraph(
    "The schema covers all required tables: staff_registry, client_registry, audit_log, "
    "invoice_fingerprints, follow_up_sequences, chat_sessions, kanboard_projects, accounts, "
    "tax_rates, categories, transactions, transaction_entries, invoices, invoice_items, receipts. "
    "The debit/credit balance trigger and soft-delete pattern are both present. No gaps found.",
    s_body,
))

# -- SECTION 3 -- XERO DRAFT ENFORCEMENT AUDIT --------------------------------
story.append(Spacer(1, 10))
story.append(Paragraph("Section 3 -- Xero Draft Enforcement Audit", s_section))

# 3.1
story.append(Paragraph(f"3.1  Backend service -- correctly implemented  ({badge_good()})", s_subsection))
story.append(Paragraph(
    "The xero_service.py correctly implements the _enforce_draft() gate. Every payload that reaches "
    "Xero -- whether via create_invoice_draft(), create_bill_draft(), or any direct post/put call -- "
    "passes through _enforce_draft() which raises a XeroDraftViolation exception if Status is anything "
    "other than DRAFT. The enforcement is at the lowest level of the call chain, meaning no code path "
    "above it can accidentally bypass it.",
    s_body,
))

# 3.2
story.append(Paragraph(f"3.2  Hayley n8n workflow -- Status: DRAFT hardcoded  ({badge_good()})", s_subsection))
story.append(Paragraph(
    'The willow-hayley-reconciliation workflow hardcodes "Status": "DRAFT" in the Xero Create Draft '
    "node JSON body. Even if the backend enforcement was somehow bypassed, the n8n payload itself "
    "would still only ever send DRAFT. Two layers of protection. Correct.",
    s_body,
))

# 3.3
story.append(Paragraph("3.3  Follow-up email send -- does not involve Xero", s_subsection))
story.append(Paragraph(
    "The direct Gmail send in willow-follow-up-executor does not affect Xero draft status. These are "
    "separate concerns -- the Xero enforcement is sound, the email send is a different policy issue "
    "(note: separate issue covered in 1.3).",
    s_body,
))

# -- SECTION 4 -- N8N-AS-CODE TOOLING GAP -------------------------------------
story.append(Spacer(1, 10))
story.append(Paragraph("Section 4 -- N8N-as-Code Tooling Gap", s_section))

# 4.1
story.append(Paragraph(f"4.1  No .n8n-state.json or n8nac config present  ({badge_warn()})", s_subsection))
story.append(Paragraph(
    "The n8n-as-code reference implementation uses a state tracking file (.n8n-state.json) in the "
    "workflows directory to track hash-based change detection, workflow ID mappings, and sync status "
    "(local-only, remote-only, tracked, conflict). Without this, the only way to push workflow "
    "changes to a running n8n instance is manual import through the UI.",
    s_body,
))
story.append(Paragraph(
    "Currently the willow-existing/n8n/workflows/ directory has no .n8n-state.json and no "
    "n8nac-config.json. This means:",
    s_body,
))
impact_items = [
    "There is no automated way to push workflow updates from Git to the running n8n container",
    "Workflow IDs in .env (e.g. GRACE_WORKFLOW_ID) must be manually kept in sync with whatever n8n assigns on import",
    "There is no conflict detection if someone edits a workflow in the UI directly",
]
for item in impact_items:
    story.append(Paragraph(f"-   {item}", s_bullet))

story.append(Paragraph(
    "<b>Fix:</b> Install n8nac (npm install -g @n8n-as-code/cli), run n8nac init in the "
    "n8n/workflows directory pointing at the local n8n instance, then run n8nac push to push all "
    "14 workflows. This will generate .n8n-state.json and lock in the workflow IDs. From that "
    "point forward, workflow changes can be deployed with a single n8nac push from the Ansible playbook.",
    s_body,
))

# 4.2
story.append(Paragraph(f"4.2  Workflow JSON format is n8nac-compatible  ({badge_good()})", s_subsection))
story.append(Paragraph(
    "All 14 workflow JSON files use the correct structure that n8nac's WorkflowSanitizer expects: "
    "nodes array, connections object, settings with executionOrder, tags array. Once the missing id "
    "and active fields are added (Section 1.2), the files will be fully importable and syncable.",
    s_body,
))

# -- SECTION 5 -- SUMMARY OF FINDINGS -----------------------------------------
story.append(PageBreak())
story.append(Paragraph("Section 5 -- Summary of Findings", s_section))

summary_header = [
    Paragraph("#", s_table_header),
    Paragraph("Severity", s_table_header),
    Paragraph("Area", s_table_header),
    Paragraph("Finding", s_table_header),
]

summary_rows = [
    ["1", badge_issue("Critical"), "Workflow",
     "Follow-up executor sends email automatically with no approval gate -- policy breach"],
    ["2", badge_warn(), "Workflow",
     "5 workflow files missing id and/or active fields -- will import as inactive"],
    ["3", badge_warn(), "Workflow",
     "TASK_WORKFLOW_ID missing from .env.example -- Task Manager Tool will 404"],
    ["4", badge_warn(), "Workflow",
     "No error handler workflow -- failures are silent"],
    ["5", badge_warn(), "Database",
     "Migration 002 missing -- gap in sequence numbering"],
    ["6", badge_warn(), "Tooling",
     "No n8nac state tracking -- workflow deployment is manual"],
    ["7", badge_good(), "Xero",
     "Draft enforcement correctly implemented at two layers"],
    ["8", badge_good(), "Schema",
     "Full bookkeeping schema present with balance trigger and soft deletes"],
    ["9", badge_good(), "executionOrder",
     "All 14 workflows correctly set executionOrder: v1"],
    ["10", badge_good(), "Architecture",
     "Stack covers all required layers -- no missing services"],
]

sum_data = [summary_header]
for row in summary_rows:
    sum_data.append([
        Paragraph(row[0], s_table_cell),
        Paragraph(row[1], s_table_cell),
        Paragraph(row[2], s_table_cell),
        Paragraph(row[3], s_table_cell),
    ])

sum_col_ws = [CONTENT_W * f for f in [0.05, 0.12, 0.12, 0.71]]
sum_table = Table(sum_data, colWidths=sum_col_ws, repeatRows=1)
sum_table.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), TEAL),
    ("TEXTCOLOR", (0, 0), (-1, 0), WHITE),
    ("FONTNAME", (0, 0), (-1, 0), "DMSans-Bold"),
    ("FONTSIZE", (0, 0), (-1, -1), 8.5),
    ("ALIGN", (0, 0), (0, -1), "CENTER"),
    ("ALIGN", (1, 0), (-1, -1), "LEFT"),
    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ("GRID", (0, 0), (-1, -1), 0.4, BORDER_GREY),
    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [WHITE, HexColor("#F9F8F5")]),
    ("TOPPADDING", (0, 0), (-1, -1), 5),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ("LEFTPADDING", (0, 0), (-1, -1), 5),
    ("RIGHTPADDING", (0, 0), (-1, -1), 5),
]))
story.append(sum_table)

# -- SECTION 6 -- RECOMMENDED ACTIONS -----------------------------------------
story.append(Spacer(1, 14))
story.append(Paragraph("Section 6 -- Recommended Actions (in order of priority)", s_section))

actions = [
    ("<b>1. Fix willow-follow-up-executor</b> -- remove the direct Gmail send node, replace with a "
     "pending_approval write to database and a dashboard-triggered webhook. This is the only "
     "policy-breaking issue."),
    ("<b>2. Add missing id and active fields</b> to the 5 affected workflow JSON files before "
     "first deployment."),
    ("<b>3. Add TASK_WORKFLOW_ID=willow-task-queue</b> to .env.example and docker-compose.yml."),
    ("<b>4. Create a 002_placeholder.sql</b> migration file to fill the sequence gap."),
    ("<b>5. Install n8nac</b> and initialise the state tracker after first deployment so future "
     "workflow updates can be pushed from Git without manual UI imports."),
    ("<b>6. Create a willow-error-handler</b> workflow to catch and alert on node failures."),
]

for action in actions:
    story.append(Paragraph(action, s_body))
    story.append(Spacer(1, 2))

# -- End of report ------------------------------------------------------------
story.append(Spacer(1, 30))
story.append(HRFlowable(width="100%", thickness=1, color=BORDER_GREY, spaceAfter=12, spaceBefore=12))
story.append(Paragraph(
    "End of report.",
    ParagraphStyle("EndNote", parent=s_body, alignment=TA_CENTER, textColor=TEXT_MUTED, fontSize=9),
))

# -- Build --------------------------------------------------------------------
doc.build(story, onFirstPage=cover_footer, onLaterPages=header_footer)
print("PDF built successfully.")
