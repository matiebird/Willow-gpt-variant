# Willow Ready-to-Go Product Package Changelog

## Product layer completed

This package moves Willow toward a sellable architecture:

- n8n is now intended as trigger/transport only.
- FastAPI product endpoints own classification, extraction, reconciliation, audit and task creation.
- AI results are never treated as final authority. They create reviewable tasks.

## Added / updated backend

### `backend/app/api/v1/product.py`

Added production-facing internal endpoints:

- `GET /v1/product/health`
- `POST /v1/product/email/triage`
- `POST /v1/product/grace/extract`
- `POST /v1/product/hayley/reconcile`
- `POST /v1/product/voice/turn`
- `GET /v1/product/tasks`
- `PATCH /v1/product/tasks/{task_id}`

### `backend/app/services/ai_orchestrator.py`

Added robust AI helpers:

- Willow email classifier
- Grace document extractor
- Hayley reconciliation recommender
- Willow receptionist response engine
- safe fallback mode if Ollama/model is offline
- JSON extraction hardening
- confidence normalization

## Added database migration

### `database/migrations/008_grace_hayley_product_flow.sql`

Adds:

- `product_documents`
- `product_reconciliations`
- `product_approval_events`
- first-boot default firm
- first-boot routing fallback rules

## Updated deployment

### `docker/docker-compose.yml`

- Mounts `n8n/workflows-product` into n8n as read-only.
- Keeps `WILLOW_API_KEY` available to n8n workflows.

## Added workflow

### `n8n/workflows-product/willow-product-smoke-test.json`

Manual n8n smoke test:

```text
Manual Trigger -> Willow Email Triage -> Grace Extract -> Hayley Reconcile
```

This proves the product API path before Gmail/Xero/phone integrations are configured.

## Added scripts and docs

- `scripts/smoke-product-api.sh`
- `docs/product/READY_TO_GO_FIRST_BOOT.md`
- `docs/product/PRODUCT_ARCHITECTURE.md`

## Validation performed

- Python syntax compile check for `backend/app` passed.
- All n8n workflow JSON files are valid JSON.
- All n8n workflow connections point to existing nodes.

## Still customer-specific / cannot be pre-filled

- Gmail/Outlook OAuth credentials
- Xero OAuth credentials
- real domain/TLS/Cloudflare tunnel
- phone/PBX credentials
- production staff users and routing rules
- production secrets in `.env`

## Known runtime caveats

- Existing legacy workflows remain in `n8n/workflows` for reference/backward compatibility. Productized flows are in `n8n/workflows-product`.
- The first API smoke test can run without Ollama but will use fallback mode; proper AI quality requires pulling/configuring the Ollama model.
- Existing customer databases only run `/docker-entrypoint-initdb.d` migrations on a fresh Postgres volume. For upgrades, manually apply `database/migrations/007_product_layer_security.sql` and `008_grace_hayley_product_flow.sql` or run them through your migration process.
