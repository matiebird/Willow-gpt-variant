# Willow Licence System Implementation

Implemented the perpetual-fallback commercial model.

## Code changes

- `backend/app/api/v1/license.py`
  - Added explicit `expired` mode for paid licences that lapse.
  - Read-only now applies only to expired trials where no paid licence has ever been installed.
  - Added `.paid-license-installed` marker support.
  - Added `writes_allowed`, `updates_enabled`, `paid_license_installed`, `support_active`, `support_plan`, `support_expires`, and `banner` fields to licence status output.
  - Expired paid licences continue allowing writes and daily operations.
  - Invalid/corrupt keys on previously paid appliances fall back to writable expired mode with updates paused.

- `backend/app/main.py`
  - Middleware now enforces `readonly` only.
  - Paid `expired` mode no longer blocks write endpoints.
  - Adds response headers: `X-Willow-Mode`, `X-Willow-Updates-Enabled`, `X-Willow-Writes-Allowed`.

- `scripts/verify-license.py`
  - Updated CLI verifier for perpetual fallback.
  - Added `expired` exit mode.
  - Added support entitlement fields.
  - Removed clock-integrity dead-man lock behaviour.

- `scripts/verify-license.sh`
  - Writes support fields into `.license.env`.
  - Displays paid-expired fallback status clearly.

- `scripts/generate-license.py`
  - Added optional `--support-plan priority` and `--support-days`.
  - Licence payload now includes `fallback: perpetual`.

- `frontend/src/components/LicenseBanner.tsx`
  - Updated banner copy and states for trial, expiring, expired, readonly and invalid.

- `frontend/src/components/layout/AppShell.tsx`
  - Added global licence banner to the authenticated shell.

- `frontend/src/app/settings/license/page.tsx`
  - Added a licence/support settings screen.

- `docker/docker-compose.yml` and `docker/.env.example`
  - Added support entitlement env vars.

## Documentation changes

- `docs/licensing.md`
  - New source-of-truth licence model documentation.

- `README.md`
  - Updated pricing, FAQ-level behaviour, Support SKU and licence mode table.

- `docs/data-ownership.md`
  - Reconciled data ownership with perpetual fallback.

- `docs/website/pricing-and-faq.md`
  - Website-ready pricing and FAQ copy.

- `docs/product/SECURITY_MODEL.md`
  - Added licensing/security/nosy-IT boundary.

## Screen renders

Added rendered PNG mockups in `docs/product/renders/`:

- `license-expired-fallback.png`
- `license-readonly-trial-expired.png`
- `pricing-support-sku.png`
- `security-data-ownership.png`

## Validation performed

- `python3 -m compileall -q backend/app` passed.
- `python3 -m py_compile scripts/verify-license.py scripts/generate-license.py` passed.
- `bash -n scripts/verify-license.sh` passed.
