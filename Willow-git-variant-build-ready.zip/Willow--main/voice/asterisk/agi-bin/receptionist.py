#!/usr/bin/env python3
"""
Willow Receptionist AGI Script
Runs inside Asterisk for every inbound call routed to Willow.

Flow per turn:
  1. Play greeting / previous response
  2. Record caller utterance (silence-detected)
  3. POST audio to willow-voice API → STT → n8n receptionist → TTS
  4. Play response audio
  5. Loop until action = transfer | voicemail | hangup

Environment (set in Asterisk dialplan):
  WILLOW_API_URL  — http://willow-voice:8100
  WILLOW_API_KEY  — from .env
  3CX_HOST        — 3CX server IP for SIP transfers
"""
import asterisk.agi as _agi
import sys
import os
import uuid
import json
import time
import urllib.request
import urllib.parse

WILLOW_API  = os.getenv("WILLOW_API_URL", "http://willow-voice:8100")
API_KEY     = os.getenv("WILLOW_API_KEY", "")
N8N_URL     = os.getenv("N8N_BASE_URL", "http://n8n:5678")
RECORD_DIR  = "/tmp/willow_recordings"
TTS_DIR     = "/tmp/willow_tts"
MAX_TURNS   = 10
SILENCE_SEC = 3   # seconds of silence to end recording
MAX_REC_SEC = 20  # max recording length

os.makedirs(RECORD_DIR, exist_ok=True)

GREETING = "thank-you-for-calling"  # pre-recorded fallback in /var/lib/asterisk/sounds/willow/


def api_post(path: str, payload: dict) -> dict:
    """Synchronous HTTP POST to willow-voice API (AGI is sync)."""
    url = f"{WILLOW_API}{path}"
    data = json.dumps(payload).encode()
    req = urllib.request.Request(
        url, data=data,
        headers={"Content-Type": "application/json", "X-Api-Key": API_KEY},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return json.loads(resp.read())
    except Exception as e:
        return {"error": str(e)}


def api_get(path: str) -> dict:
    url = f"{WILLOW_API}{path}"
    req = urllib.request.Request(url, headers={"X-Api-Key": API_KEY})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read())
    except Exception as e:
        return {"error": str(e)}


def n8n_receptionist(call_id, caller_number, transcript, turn, history) -> dict:
    """Call n8n receptionist webhook. Returns {response_text, action, extension}."""
    url = f"{N8N_URL}/webhook/willow-receptionist"
    payload = {
        "call_id": call_id,
        "caller_number": caller_number,
        "transcript": transcript,
        "turn_number": turn,
        "session_history": history,
    }
    data = json.dumps(payload).encode()
    req = urllib.request.Request(
        url, data=data,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return json.loads(resp.read())
    except Exception as e:
        return {
            "response_text": "I'm sorry, I'm having technical difficulties. Please hold while I transfer you.",
            "action": "transfer",
            "extension": os.getenv("DEFAULT_EXTENSION", "101"),
        }


def tts_request(text: str, call_id: str, turn: int) -> str | None:
    """Ask willow-voice API to synthesise TTS and return the audio file path."""
    result = api_post("/v1/voice/tts", {
        "text": text,
        "call_id": call_id,
        "turn": turn,
    })
    return result.get("audio_path")  # path Asterisk can play


def main():
    agi = _agi.AGI()

    caller_number = agi.env.get("agi_callerid", "unknown")
    call_id       = str(uuid.uuid4())
    session_history = []

    agi.verbose(f"[Willow] Call started — caller={caller_number} call_id={call_id}", 1)

    # Register call in DB
    api_post("/v1/voice/calls", {
        "call_id": call_id,
        "caller_number": caller_number,
        "direction": "inbound",
    })

    # Answer and set Asterisk audio format to SLIN (16-bit PCM, 8kHz)
    agi.answer()
    agi.set_variable("CHANNEL(audioreadformat)", "slin")
    agi.set_variable("CHANNEL(audiowriteformat)", "slin")

    # Brief pause for audio path to settle
    agi.execute("Wait", "0.5")

    # Check if any staff are available (to decide initial greeting tone)
    staff_status = api_get("/v1/voice/staff/available")
    staff_available = staff_status.get("available", True)

    # ── Main conversation loop ─────────────────────────────────────────────────
    for turn in range(1, MAX_TURNS + 1):
        rec_path = f"{RECORD_DIR}/{call_id}_{turn}"

        # ── Step 1: Record caller utterance ───────────────────────────────────
        if turn == 1:
            # First turn: play greeting then wait
            # Try TTS greeting, fall back to pre-recorded
            greeting_text = (
                "Thank you for calling. I'm Willow, your bookkeeping assistant. "
                "How can I help you today?"
            )
            tts_path = tts_request(greeting_text, call_id, 0)
            if tts_path:
                agi.execute("Playback", tts_path)
            else:
                agi.execute("Playback", "willow/greeting")

        # Record: filename, silence threshold (ms), max silence, max duration (ms)
        agi.execute(
            "Record",
            f"{rec_path}.wav,{SILENCE_SEC * 1000},{MAX_REC_SEC * 1000},beep"
        )
        agi.verbose(f"[Willow] Recorded turn {turn}: {rec_path}.wav", 1)

        # ── Step 2: Transcribe via Whisper (sync call to voice API) ───────────
        stt_result = api_post("/v1/voice/stt", {
            "audio_path": f"{rec_path}.wav",
            "call_id": call_id,
        })
        transcript = stt_result.get("text", "").strip()
        agi.verbose(f"[Willow] Transcript: {transcript}", 1)

        if not transcript:
            # No speech detected — prompt once, then hang up
            if turn == 1:
                agi.execute("Playback", "willow/no-input")
                continue
            else:
                break

        # ── Step 3: Get response from n8n receptionist workflow ────────────────
        n8n_resp = n8n_receptionist(
            call_id, caller_number, transcript, turn, session_history
        )
        response_text = n8n_resp.get("response_text", "")
        action        = n8n_resp.get("action", "continue")
        extension     = n8n_resp.get("extension", os.getenv("DEFAULT_EXTENSION", "101"))

        # Add to conversation history
        session_history.append({"role": "user",    "content": transcript})
        session_history.append({"role": "assistant", "content": response_text})
        # Keep only last 6 turns (3 exchanges) to avoid token overflow
        session_history = session_history[-6:]

        # ── Step 4: Synthesise and play response ──────────────────────────────
        tts_path = tts_request(response_text, call_id, turn)
        if tts_path:
            agi.execute("Playback", tts_path)
        else:
            agi.verbose("[Willow] TTS failed, skipping audio playback", 1)

        agi.verbose(f"[Willow] Action: {action} | Extension: {extension}", 1)

        # ── Step 5: Route based on action ─────────────────────────────────────
        if action == "transfer":
            # Transfer to staff extension via 3CX SIP trunk
            three_cx_host = os.getenv("THREE_CX_HOST", "3cx")
            agi.verbose(f"[Willow] Transferring to {extension}@{three_cx_host}", 1)
            api_post(f"/v1/voice/calls/{call_id}", {
                "status": "transferred",
                "transferred_to": extension,
                "intent": n8n_resp.get("reason", ""),
            })
            agi.execute("Dial", f"SIP/{extension}@{three_cx_host},30,tT")
            break

        elif action == "voicemail":
            # Record a voicemail, create task
            vm_path = f"{RECORD_DIR}/{call_id}_voicemail"
            agi.execute("Playback", "willow/voicemail-prompt")
            agi.execute("Record", f"{vm_path}.wav,5000,60000,beep")
            api_post(f"/v1/voice/calls/{call_id}", {
                "status": "voicemail",
                "intent": "voicemail",
            })
            agi.execute("Playback", "willow/voicemail-thankyou")
            break

        elif action == "callback":
            api_post(f"/v1/voice/calls/{call_id}", {
                "status": "callback_requested",
                "intent": "callback",
            })
            break

        elif action == "hangup":
            agi.execute("Playback", "willow/goodbye")
            break

        # action == "continue" → loop for next turn

    # ── Cleanup ───────────────────────────────────────────────────────────────
    api_post(f"/v1/voice/calls/{call_id}", {"status": "completed"})
    api_post(f"/v1/voice/tts/cleanup", {"call_id": call_id})
    agi.hangup()


if __name__ == "__main__":
    main()
