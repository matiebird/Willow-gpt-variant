#!/bin/bash
set -e

echo "[willow-voice] Starting Asterisk..."
asterisk -f -C /etc/asterisk/asterisk.conf &
ASTERISK_PID=$!

# Wait for Asterisk to come up
sleep 5

echo "[willow-voice] Starting Willow Voice API..."
exec uvicorn app.main:app --host 0.0.0.0 --port 8100 --log-level info
