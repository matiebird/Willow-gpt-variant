"""
Speech-to-Text via faster-whisper-gpu (OpenAI-compatible API).
Converts 8kHz/16-bit/mono WAV from Asterisk to transcribed text.
"""
import httpx
import subprocess
import tempfile
import os
import structlog

log = structlog.get_logger()

WHISPER_URL = os.getenv("WHISPER_BASE_URL", "http://faster-whisper-gpu:9000")


def convert_to_whisper_format(input_path: str) -> str:
    """
    Asterisk records in 8kHz SLIN16. Whisper performs best on 16kHz WAV.
    Use sox/ffmpeg to convert.
    """
    out_path = input_path.replace(".wav", "_16k.wav")
    result = subprocess.run(
        ["sox", input_path, "-r", "16000", "-c", "1", "-b", "16", out_path],
        capture_output=True,
        timeout=10,
    )
    if result.returncode != 0:
        log.warning("stt.convert_failed", stderr=result.stderr.decode())
        return input_path  # fallback: send as-is
    return out_path


async def transcribe(audio_path: str, language: str = "en") -> str:
    """
    Send audio file to faster-whisper-gpu and return transcription text.
    """
    converted_path = convert_to_whisper_format(audio_path)
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            with open(converted_path, "rb") as f:
                resp = await client.post(
                    f"{WHISPER_URL}/v1/audio/transcriptions",
                    files={"file": ("audio.wav", f, "audio/wav")},
                    data={"model": "whisper-1", "language": language},
                )
            resp.raise_for_status()
            text = resp.json().get("text", "").strip()
            log.info("stt.transcribed", chars=len(text), preview=text[:60])
            return text
    except httpx.HTTPError as e:
        log.error("stt.http_error", error=str(e))
        return ""
    finally:
        # Clean up converted file
        if converted_path != audio_path and os.path.exists(converted_path):
            os.unlink(converted_path)
