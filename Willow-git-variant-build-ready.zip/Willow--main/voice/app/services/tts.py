"""
Text-to-Speech via Piper (OpenAI-compatible API).
Outputs WAV in a format Asterisk can play back directly:
  - 8000 Hz, mono, 16-bit signed PCM (SLIN)
"""
import httpx
import subprocess
import tempfile
import os
import structlog

log = structlog.get_logger()

PIPER_URL = os.getenv("PIPER_BASE_URL", "http://piper:5000")
AUDIO_DIR = "/tmp/willow_tts"
os.makedirs(AUDIO_DIR, exist_ok=True)


def convert_to_asterisk_format(input_path: str, output_path: str) -> bool:
    """Convert Piper's 22050Hz WAV output to 8kHz/16-bit/mono for Asterisk."""
    result = subprocess.run(
        ["sox", input_path, "-r", "8000", "-c", "1", "-b", "16", "-e", "signed-integer", output_path],
        capture_output=True,
        timeout=15,
    )
    if result.returncode != 0:
        log.warning("tts.convert_failed", stderr=result.stderr.decode())
        return False
    return True


async def synthesize(text: str, call_id: str, turn: int) -> str:
    """
    Convert text to speech via Piper. Returns path to 8kHz WAV file
    that Asterisk can play with the Playback() application.
    
    Returns None on failure (AGI should fall back to a pre-recorded prompt).
    """
    raw_path = os.path.join(AUDIO_DIR, f"{call_id}_{turn}_raw.wav")
    ast_path = os.path.join(AUDIO_DIR, f"{call_id}_{turn}")  # Asterisk strips extension

    try:
        async with httpx.AsyncClient(timeout=20.0) as client:
            resp = await client.post(
                f"{PIPER_URL}/v1/audio/speech",
                json={
                    "model": "piper",
                    "input": text,
                    "voice": os.getenv("PIPER_VOICE", "en_AU-cmu-arctic-medium"),
                    "response_format": "wav",
                    "speed": 1.0,
                },
            )
            resp.raise_for_status()

        with open(raw_path, "wb") as f:
            f.write(resp.content)

        success = convert_to_asterisk_format(raw_path, f"{ast_path}.wav")
        if not success:
            return None

        log.info("tts.synthesized", chars=len(text), path=ast_path)
        return ast_path  # Return without .wav — Asterisk adds it

    except httpx.HTTPError as e:
        log.error("tts.http_error", error=str(e))
        return None
    finally:
        if os.path.exists(raw_path):
            os.unlink(raw_path)


def cleanup_call_audio(call_id: str):
    """Remove all TTS audio files for a completed call."""
    for f in os.listdir(AUDIO_DIR):
        if f.startswith(call_id):
            try:
                os.unlink(os.path.join(AUDIO_DIR, f))
            except OSError:
                pass
