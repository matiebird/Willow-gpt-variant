"""
Willow Voice API
FastAPI service that manages voice call state, exposes status endpoints,
and coordinates with the Asterisk AGI scripts for call handling.
"""
from contextlib import asynccontextmanager
from typing import Optional
import asyncpg
import structlog
from fastapi import FastAPI, HTTPException, Header, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from pydantic_settings import BaseSettings

log = structlog.get_logger()


class Settings(BaseSettings):
    database_url: str
    willow_api_key: str
    n8n_base_url: str = "http://n8n:5678"
    whisper_base_url: str = "http://faster-whisper-gpu:9000"
    piper_base_url: str = "http://piper:5000"

    class Config:
        env_file = ".env"


settings = Settings()
db_pool: Optional[asyncpg.Pool] = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global db_pool
    # Convert asyncpg DSN format
    dsn = settings.database_url.replace("postgresql+asyncpg://", "postgresql://")
    db_pool = await asyncpg.create_pool(dsn, min_size=2, max_size=10)
    log.info("willow_voice.db_connected")
    yield
    await db_pool.close()


app = FastAPI(
    title="Willow Voice API",
    version="1.0.0",
    lifespan=lifespan,
)


def verify_api_key(x_api_key: str = Header(...)):
    if x_api_key != settings.willow_api_key:
        raise HTTPException(status_code=403, detail="Invalid API key")
    return x_api_key


# ── Models ────────────────────────────────────────────────────────────────────

class CallCreateRequest(BaseModel):
    call_id: str
    caller_number: str
    direction: str = "inbound"


class StaffStatusUpdate(BaseModel):
    staff_id: str
    staff_name: str
    status: str  # available | busy | dnd | offline
    active_call_id: Optional[str] = None


class QueueStatusRequest(BaseModel):
    pending_count: int
    assigned_count: int
    escalated_count: int
    overdue_count: int = 0


# ── Endpoints ─────────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    return {"status": "ok", "service": "willow-voice"}


@app.post("/v1/voice/calls", dependencies=[Depends(verify_api_key)])
async def create_call(req: CallCreateRequest):
    """Called by Asterisk AGI at call start to register the call in the DB."""
    async with db_pool.acquire() as conn:
        row = await conn.fetchrow(
            """
            INSERT INTO calls (call_id, caller_number, direction, status, willow_handled)
            VALUES ($1, $2, $3, 'active', TRUE)
            ON CONFLICT (call_id) DO UPDATE SET status='active'
            RETURNING id, call_id, caller_number
            """,
            req.call_id, req.caller_number, req.direction
        )
    log.info("call.created", call_id=req.call_id, caller=req.caller_number)
    return dict(row)


@app.get("/v1/voice/calls/{call_id}", dependencies=[Depends(verify_api_key)])
async def get_call(call_id: str):
    async with db_pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT * FROM calls WHERE call_id = $1", call_id
        )
    if not row:
        raise HTTPException(status_code=404, detail="Call not found")
    return dict(row)


@app.patch("/v1/voice/calls/{call_id}", dependencies=[Depends(verify_api_key)])
async def update_call(call_id: str, body: dict):
    """Update call status, transfer target, transcript, etc."""
    allowed = {"status", "transferred_to", "transcript", "duration_seconds", "intent"}
    updates = {k: v for k, v in body.items() if k in allowed}
    if not updates:
        raise HTTPException(status_code=400, detail="No valid fields to update")

    set_clause = ", ".join(f"{k} = ${i+2}" for i, k in enumerate(updates))
    values = [call_id] + list(updates.values())

    async with db_pool.acquire() as conn:
        await conn.execute(
            f"UPDATE calls SET {set_clause}, completed_at = NOW() WHERE call_id = $1",
            *values
        )
    return {"updated": True}


@app.get("/v1/voice/calls", dependencies=[Depends(verify_api_key)])
async def list_calls(limit: int = 20, status: Optional[str] = None):
    async with db_pool.acquire() as conn:
        if status:
            rows = await conn.fetch(
                "SELECT * FROM calls WHERE status=$1 ORDER BY created_at DESC LIMIT $2",
                status, limit
            )
        else:
            rows = await conn.fetch(
                "SELECT * FROM calls ORDER BY created_at DESC LIMIT $1", limit
            )
    return [dict(r) for r in rows]


@app.put("/v1/voice/staff/{staff_id}/status", dependencies=[Depends(verify_api_key)])
async def update_staff_status(staff_id: str, req: StaffStatusUpdate):
    """
    Called by 3CX presence webhook (via n8n) when a staff member's
    availability changes. Drives Willow's overflow routing logic.
    """
    async with db_pool.acquire() as conn:
        await conn.execute(
            """
            INSERT INTO staff_capacity (staff_id, staff_name, status, active_call_id, updated_at)
            VALUES ($1, $2, $3, $4, NOW())
            ON CONFLICT (staff_id) DO UPDATE SET
                status = EXCLUDED.status,
                staff_name = EXCLUDED.staff_name,
                active_call_id = EXCLUDED.active_call_id,
                updated_at = NOW()
            """,
            staff_id, req.staff_name, req.status, req.active_call_id
        )
    log.info("staff.status_updated", staff_id=staff_id, status=req.status)
    return {"updated": True}


@app.get("/v1/voice/staff", dependencies=[Depends(verify_api_key)])
async def get_staff_availability():
    """Returns current availability of all staff. Used by AGI to decide routing."""
    async with db_pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT * FROM staff_capacity ORDER BY task_count ASC, updated_at DESC"
        )
    return [dict(r) for r in rows]


@app.get("/v1/voice/staff/available", dependencies=[Depends(verify_api_key)])
async def get_available_staff():
    """Returns the best available staff member for a transfer."""
    async with db_pool.acquire() as conn:
        row = await conn.fetchrow(
            """
            SELECT * FROM staff_capacity
            WHERE status = 'available'
            ORDER BY task_count ASC, updated_at DESC
            LIMIT 1
            """
        )
    if not row:
        return {"available": False, "staff": None}
    return {"available": True, "staff": dict(row)}


@app.post("/v1/voice/queue-status", dependencies=[Depends(verify_api_key)])
async def queue_status(req: QueueStatusRequest):
    """Receives task queue summary from n8n task-queue workflow."""
    log.info(
        "task_queue.status",
        pending=req.pending_count,
        assigned=req.assigned_count,
        escalated=req.escalated_count,
    )
    return {"received": True}


@app.get("/v1/voice/queue", dependencies=[Depends(verify_api_key)])
async def get_queue(status: Optional[str] = "pending", limit: int = 50):
    async with db_pool.acquire() as conn:
        rows = await conn.fetch(
            """
            SELECT tq.*, cr.business_name
            FROM task_queue tq
            LEFT JOIN client_registry cr ON tq.client_id = cr.id
            WHERE tq.status = $1
            ORDER BY tq.priority ASC, tq.created_at ASC
            LIMIT $2
            """,
            status, limit
        )
    return [dict(r) for r in rows]


# ── TTS / STT proxy endpoints (called by sync AGI script) ─────────────────────

class TTSRequest(BaseModel):
    text: str
    call_id: str
    turn: int


class STTRequest(BaseModel):
    audio_path: str
    call_id: str


@app.post("/v1/voice/tts", dependencies=[Depends(verify_api_key)])
async def tts_endpoint(req: TTSRequest):
    """Synthesise TTS and return the audio file path for Asterisk Playback."""
    import httpx, os, subprocess
    piper_url = settings.piper_base_url
    audio_dir = "/tmp/willow_tts"
    os.makedirs(audio_dir, exist_ok=True)
    raw_path = f"{audio_dir}/{req.call_id}_{req.turn}_raw.wav"
    ast_path = f"{audio_dir}/{req.call_id}_{req.turn}.wav"

    async with httpx.AsyncClient(timeout=20.0) as client:
        resp = await client.post(
            f"{piper_url}/v1/audio/speech",
            json={"model": "piper", "input": req.text,
                  "voice": "en_AU-cmu-arctic-medium",
                  "response_format": "wav", "speed": 1.0},
        )
        resp.raise_for_status()

    with open(raw_path, "wb") as f:
        f.write(resp.content)

    result = subprocess.run(
        ["sox", raw_path, "-r", "8000", "-c", "1", "-b", "16", "-e", "signed-integer", ast_path],
        capture_output=True, timeout=15,
    )
    if os.path.exists(raw_path):
        os.unlink(raw_path)

    if result.returncode != 0:
        raise HTTPException(status_code=500, detail="TTS conversion failed")

    # Return path WITHOUT extension — Asterisk Playback() adds it
    return {"audio_path": ast_path.replace(".wav", "")}


@app.post("/v1/voice/tts/cleanup", dependencies=[Depends(verify_api_key)])
async def tts_cleanup(body: dict):
    """Remove TTS audio files for a completed call."""
    import os
    call_id = body.get("call_id", "")
    audio_dir = "/tmp/willow_tts"
    removed = 0
    for f in os.listdir(audio_dir):
        if f.startswith(call_id):
            try:
                os.unlink(os.path.join(audio_dir, f))
                removed += 1
            except OSError:
                pass
    return {"removed": removed}


@app.post("/v1/voice/stt", dependencies=[Depends(verify_api_key)])
async def stt_endpoint(req: STTRequest):
    """Transcribe a recorded WAV file via Faster-Whisper."""
    import httpx, subprocess, os
    converted = req.audio_path.replace(".wav", "_16k.wav")
    subprocess.run(
        ["sox", req.audio_path, "-r", "16000", "-c", "1", "-b", "16", converted],
        capture_output=True, timeout=10,
    )
    src = converted if os.path.exists(converted) else req.audio_path
    async with httpx.AsyncClient(timeout=30.0) as client:
        with open(src, "rb") as f:
            resp = await client.post(
                f"{settings.whisper_base_url}/v1/audio/transcriptions",
                files={"file": ("audio.wav", f, "audio/wav")},
                data={"model": "whisper-1", "language": "en"},
            )
        resp.raise_for_status()
        text = resp.json().get("text", "").strip()
    if converted != req.audio_path and os.path.exists(converted):
        os.unlink(converted)
    log.info("stt.done", call_id=req.call_id, chars=len(text))
    return {"text": text}
