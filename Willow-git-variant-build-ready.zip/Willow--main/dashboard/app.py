"""
Willow AI Hybrid Dashboard
Engineered Data Systems — Streamlit frontend for the Willow n8n stack.

Config resolution order (highest wins):
  1. dashboard/.willow.conf  — written by the first-run setup wizard
  2. Environment variables   — N8N_HOST, N8N_CHAT_PATH, N8N_VOICE_PATH,
                               WILLOW_STAFF_ID, WILLOW_TITLE
  3. Built-in defaults

Hardware microphone options
  • Laptop / desktop browser mic  — works out of the box via st.audio_input.
    Any mic the OS exposes to the browser (built-in, USB, Bluetooth headset)
    is usable with zero extra configuration.

  • M5Stack Echo / ESP32 smart speaker — connects to the SAME n8n voice
    webhook but entirely bypasses this Streamlit app.  The device firmware
    POSTs WAV audio directly to N8N_VOICE_WEBHOOK, receives the JSON reply,
    and plays TTS audio from the piper container.  Configure the device with
    the same IP/host saved in .willow.conf.  See docs/m5stack-voice.md for
    the Arduino / UIFlow firmware sketch.
"""

import json
import os
import uuid
from pathlib import Path

import requests
import streamlit as st

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

CONF_PATH = Path(__file__).parent / ".willow.conf"
REQUEST_TIMEOUT = 120  # seconds — generous for local LLM inference
WILLOW_VERSION = "1.1"

# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

_DEFAULTS = {
    "n8n_host": "192.168.0.50",        # Unraid box LAN IP
    "n8n_port": "5678",
    "n8n_chat_path": "/webhook/willow-chat",
    "n8n_voice_path": "/webhook/willow-voice",
    "staff_id": "",                     # filled in at first-run wizard
    "title": "Willow",
}


def _load_conf() -> dict:
    """Return merged config: file → env vars → defaults (file wins over env)."""
    conf = dict(_DEFAULTS)

    # Layer 1: file
    if CONF_PATH.exists():
        try:
            conf.update(json.loads(CONF_PATH.read_text()))
        except json.JSONDecodeError:
            pass

    # Layer 2: environment variables (only override if file value is still default)
    env_map = {
        "N8N_HOST": "n8n_host",
        "N8N_PORT": "n8n_port",
        "N8N_CHAT_PATH": "n8n_chat_path",
        "N8N_VOICE_PATH": "n8n_voice_path",
        "WILLOW_STAFF_ID": "staff_id",
        "WILLOW_TITLE": "title",
    }
    for env_key, conf_key in env_map.items():
        val = os.getenv(env_key)
        if val and conf[conf_key] == _DEFAULTS[conf_key]:
            conf[conf_key] = val

    return conf


def _save_conf(conf: dict) -> None:
    CONF_PATH.write_text(json.dumps(conf, indent=2))


def _build_url(conf: dict, path_key: str) -> str:
    host = conf["n8n_host"].rstrip("/")
    port = conf["n8n_port"]
    path = conf[path_key].lstrip("/")
    # Support full URLs passed directly (e.g. from environment)
    if host.startswith("http"):
        return f"{host}:{port}/{path}"
    return f"http://{host}:{port}/{path}"


# ---------------------------------------------------------------------------
# Page config  (must be first Streamlit call)
# ---------------------------------------------------------------------------

conf = _load_conf()

st.set_page_config(
    page_title=conf["title"],
    page_icon="🌿",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------------------------
# First-run setup wizard
# ---------------------------------------------------------------------------

def _is_configured(c: dict) -> bool:
    """Config is valid when host is not the default placeholder and staff_id set."""
    return bool(c["staff_id"]) and c["n8n_host"] != _DEFAULTS["n8n_host"] or CONF_PATH.exists()


if not _is_configured(conf):
    st.title("🌿 Welcome to Willow")
    st.subheader("First-run setup")
    st.markdown(
        "Willow needs to know where your **n8n server** is running and who you are. "
        "This is saved to `dashboard/.willow.conf` and only needs to be done once."
    )

    with st.form("setup_form"):
        st.markdown("#### n8n Server")
        host = st.text_input(
            "n8n host IP or hostname",
            value=conf["n8n_host"],
            help="LAN IP of your Unraid box, e.g. 192.168.0.50  —  or a hostname like willow.local",
        )
        port = st.text_input("n8n port", value=conf["n8n_port"])

        st.markdown("#### Webhook paths")
        chat_path = st.text_input("Chat webhook path", value=conf["n8n_chat_path"])
        voice_path = st.text_input("Voice webhook path", value=conf["n8n_voice_path"])

        st.markdown("#### Identity")
        staff_id = st.text_input(
            "Your Staff ID",
            placeholder="e.g. jen",
            help="Must match a user_id in the staff_registry table.",
        )

        title = st.text_input("Display name for this dashboard", value=conf["title"])

        submitted = st.form_submit_button("Save and launch Willow", type="primary")

    if submitted:
        if not staff_id.strip():
            st.error("Staff ID is required.")
        elif not host.strip():
            st.error("n8n host is required.")
        else:
            new_conf = {
                "n8n_host": host.strip(),
                "n8n_port": port.strip(),
                "n8n_chat_path": chat_path.strip(),
                "n8n_voice_path": voice_path.strip(),
                "staff_id": staff_id.strip(),
                "title": title.strip() or "Willow",
            }
            _save_conf(new_conf)
            st.success("Config saved! Launching Willow…")
            st.rerun()

    # Show hardware mic note during setup too
    with st.expander("Microphone options"):
        st.markdown(
            """
**Browser mic (laptop / desktop)**
Works immediately — `st.audio_input` uses whatever mic your OS exposes to the
browser (built-in, USB, Bluetooth headset). No extra configuration needed.

**M5Stack Echo or equivalent smart speaker**
The device connects to the same `n8n_voice_path` webhook *directly* — it never
talks to this Streamlit app. Flash the device with the host IP you entered above
and it will POST audio straight to n8n, get Willow's reply, and play it back via
the onboard speaker. Useful for a **hands-free, always-on desk device**.
See `docs/m5stack-voice.md` for the firmware sketch.
            """
        )

    st.stop()  # Don't render the main UI until setup is complete

# ---------------------------------------------------------------------------
# Session state initialisation
# ---------------------------------------------------------------------------

if "messages" not in st.session_state:
    st.session_state.messages = []

if "session_id" not in st.session_state:
    # Prefer the configured staff_id; fall back to a UUID for anonymous sessions
    st.session_state.session_id = conf["staff_id"] or str(uuid.uuid4())

# Derive webhook URLs from current conf
N8N_CHAT_WEBHOOK = _build_url(conf, "n8n_chat_path")
N8N_VOICE_WEBHOOK = _build_url(conf, "n8n_voice_path")

# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------

with st.sidebar:
    st.markdown(f"## 🌿 {conf['title']}")
    st.caption("Engineered Data Systems")
    st.divider()

    st.markdown(f"**Logged in as:** `{st.session_state.session_id}`")
    st.caption(f"n8n: `{conf['n8n_host']}:{conf['n8n_port']}`")

    if st.button("Clear chat history", use_container_width=True):
        st.session_state.messages = []
        st.rerun()

    st.divider()

    with st.expander("Settings"):
        with st.form("settings_form"):
            s_host = st.text_input("n8n host", value=conf["n8n_host"])
            s_port = st.text_input("n8n port", value=conf["n8n_port"])
            s_chat = st.text_input("Chat path", value=conf["n8n_chat_path"])
            s_voice = st.text_input("Voice path", value=conf["n8n_voice_path"])
            s_staff = st.text_input("Staff ID", value=conf["staff_id"])
            s_title = st.text_input("Title", value=conf["title"])
            if st.form_submit_button("Save"):
                _save_conf({
                    "n8n_host": s_host, "n8n_port": s_port,
                    "n8n_chat_path": s_chat, "n8n_voice_path": s_voice,
                    "staff_id": s_staff, "title": s_title,
                })
                st.session_state.session_id = s_staff
                st.success("Saved. Reloading…")
                st.rerun()

    with st.expander("Microphone options"):
        st.markdown(
            """
**Browser mic** — works now, uses whatever mic your OS exposes.

**M5Stack Echo / ESP32** — flash with your n8n IP and it POSTs audio
directly to the voice webhook, bypassing this UI. Good for a desk device.
See `docs/m5stack-voice.md`.
            """
        )

    st.divider()
    st.caption(f"Willow v{WILLOW_VERSION} · All data stays local.")

# ---------------------------------------------------------------------------
# Request helpers
# ---------------------------------------------------------------------------

def send_text_message(user_text: str) -> str:
    """POST to n8n chatTrigger; return Willow's reply or a friendly error."""
    try:
        resp = requests.post(
            N8N_CHAT_WEBHOOK,
            json={"chatInput": user_text, "sessionId": st.session_state.session_id},
            timeout=REQUEST_TIMEOUT,
        )
        resp.raise_for_status()
        data = resp.json()
        return data.get("output") or data.get("text") or str(data)
    except requests.exceptions.Timeout:
        return "⏱️ Willow is taking longer than expected. Please try again."
    except requests.exceptions.ConnectionError:
        return (
            f"🔌 Cannot reach n8n at `{N8N_CHAT_WEBHOOK}`.  \n"
            f"Check the stack is running and the IP in **Settings** is correct."
        )
    except Exception as exc:  # noqa: BLE001
        return f"❌ Unexpected error: {exc}"


def send_voice_message(audio_bytes: bytes) -> tuple[str, str]:
    """
    POST audio to the n8n voice webhook.

    Expected n8n response:
        { "transcription": "what was said", "output": "Willow's reply" }

    Returns (transcription, reply).  On error transcription is empty and
    reply contains the error message.
    """
    try:
        resp = requests.post(
            N8N_VOICE_WEBHOOK,
            files={"audio": ("recording.wav", audio_bytes, "audio/wav")},
            data={"sessionId": st.session_state.session_id},
            timeout=REQUEST_TIMEOUT,
        )
        resp.raise_for_status()
        data = resp.json()
        return data.get("transcription", "").strip(), (
            data.get("output") or data.get("text") or str(data)
        )
    except requests.exceptions.Timeout:
        return "", "⏱️ Voice processing timed out. Please try again."
    except requests.exceptions.ConnectionError:
        return "", (
            f"🔌 Cannot reach voice webhook at `{N8N_VOICE_WEBHOOK}`.  \n"
            f"Check the IP in **Settings** or that faster-whisper is running."
        )
    except Exception as exc:  # noqa: BLE001
        return "", f"❌ Voice error: {exc}"

# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------

col1, col2 = st.columns([1.2, 2], gap="large")

# ---------------------------------------------------------------------------
# col1 — Dashboard panels (Phase 4 will populate these from Postgres/Kanboard)
# ---------------------------------------------------------------------------

with col1:
    st.header("Dashboard")
    st.info(
        "Task tables, follow-up sequences, and deadline tracker will appear here "
        "once the Kanboard and PostgreSQL integrations are wired up (Phase 4).",
        icon="📋",
    )
    st.subheader("Upcoming Deadlines")
    st.caption("BAS · PAYG · Super · FBT · STP")
    st.warning("Connect to Willow Deadline Warning workflow to populate.", icon="📅")

    st.subheader("Active Follow-ups")
    st.warning("Connect to follow_up_sequences table to populate.", icon="📬")

# ---------------------------------------------------------------------------
# col2 — Chat interface
# ---------------------------------------------------------------------------

with col2:
    st.header(f"Chat with {conf['title']}")

    chat_container = st.container(height=480)
    with chat_container:
        for msg in st.session_state.messages:
            with st.chat_message(msg["role"]):
                st.markdown(msg["content"])

    # Text input
    user_input = st.chat_input("Message Willow…")
    if user_input:
        st.session_state.messages.append({"role": "user", "content": user_input})
        with st.spinner("Willow is thinking…"):
            reply = send_text_message(user_input)
        st.session_state.messages.append({"role": "assistant", "content": reply})
        st.rerun()

    # Voice input
    st.markdown("**Or dictate:**")
    audio_value = st.audio_input("Dictate to Willow")
    if audio_value is not None:
        audio_bytes = audio_value.read()
        if audio_bytes:
            with st.spinner("Transcribing and processing…"):
                transcription, reply = send_voice_message(audio_bytes)

            st.session_state.messages.append({
                "role": "user",
                "content": f"🎤 {transcription}" if transcription else "🎤 *(voice message)*",
            })
            st.session_state.messages.append({"role": "assistant", "content": reply})
            st.rerun()
