#!/usr/bin/env bash
# =============================================================================
# WILLOW AI — Interactive Installer
# Engineered Data Systems
# =============================================================================
# Usage:
#   ./install.sh               # Interactive (default — Docker Compose, Unraid)
#   ./install.sh --mode ansible # Remote Ansible deploy (DGX Spark / fresh Linux)
#   ./install.sh --yes          # Accept all generated defaults (CI/scripted use)
#   ./install.sh --help
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$SCRIPT_DIR/docker/.env"
COMPOSE_FILE="$SCRIPT_DIR/docker/docker-compose.yml"
INVENTORY_FILE="$SCRIPT_DIR/ansible/inventory.yml"

# ── Colours ───────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[0;33m'
BLU='\033[0;34m'; MAG='\033[0;35m'; CYN='\033[0;36m'
WHT='\033[1;37m'; DIM='\033[2m';    NC='\033[0m'

info()    { echo -e "${BLU}  ➜${NC}  $*"; }
success() { echo -e "${GRN}  ✓${NC}  $*"; }
warn()    { echo -e "${YLW}  ⚠${NC}  $*"; }
error()   { echo -e "${RED}  ✗${NC}  $*" >&2; }
header()  { echo -e "\n${MAG}━━━  $*  ━━━${NC}"; }
die()     { error "$*"; exit 1; }

ask() {
  # ask <var_name> <prompt> [default]
  local var="$1" prompt="$2" default="${3:-}"
  if [[ -n "$default" ]]; then
    echo -en "  ${WHT}${prompt}${NC} ${DIM}[${default}]${NC}: "
  else
    echo -en "  ${WHT}${prompt}${NC}: "
  fi
  local reply; read -r reply
  printf -v "$var" '%s' "${reply:-$default}"
}

ask_secret() {
  # ask_secret <var_name> <prompt> [auto-gen description]
  local var="$1" prompt="$2" gen="${3:-}"
  if [[ -n "$gen" ]]; then
    echo -en "  ${WHT}${prompt}${NC} ${DIM}[auto-generate ${gen} — press Enter]${NC}: "
  else
    echo -en "  ${WHT}${prompt}${NC}: "
  fi
  local reply; read -rs reply; echo
  if [[ -z "$reply" && -n "$gen" ]]; then
    reply="$(openssl rand -hex 32)"
    info "Generated: ${DIM}${reply:0:12}…${NC}"
  fi
  printf -v "$var" '%s' "$reply"
}

check_cmd() {
  command -v "$1" &>/dev/null || die "Required command not found: ${1}. Install it first."
}

# Build compose file list based on mode (evaluated after arg parsing)
_build_dc_args() {
  DC_COMPOSE_ARGS=(-f "$COMPOSE_FILE")
  if [[ "$PORTABLE_MODE" == "true" ]]; then
    DC_COMPOSE_ARGS+=(-f "$SCRIPT_DIR/docker/docker-compose.portable.yml")
    [[ "$PORTABLE_CPU" == "true" ]] && DC_COMPOSE_ARGS+=(-f "$SCRIPT_DIR/docker/docker-compose.portable-cpu.yml")
    DC_COMPOSE_ARGS+=(-f "$SCRIPT_DIR/docker/docker-compose.usb.yml")
  fi
}

dc() {
  # Wrapper that supports both 'docker compose' (v2) and 'docker-compose' (v1)
  if docker compose version &>/dev/null 2>&1; then
    docker compose "${DC_COMPOSE_ARGS[@]}" --env-file "$ENV_FILE" "$@"
  else
    docker-compose "${DC_COMPOSE_ARGS[@]}" --env-file "$ENV_FILE" "$@"
  fi
}

wait_for_http() {
  local name="$1" url="$2" retries="${3:-30}"
  echo -en "  Waiting for ${name}"
  until curl -sf --max-time 3 "$url" &>/dev/null; do
    retries=$((retries - 1))
    [[ $retries -le 0 ]] && echo && die "${name} did not become ready in time."
    echo -n "."
    sleep 3
  done
  echo
  success "${name} ready"
}

# ── Parse arguments ───────────────────────────────────────────────────────────
INSTALL_MODE="docker"
NON_INTERACTIVE=false
PORTABLE_MODE=false
PORTABLE_CPU=false

while [[ $# -gt 0 ]]; do
  case "$1" in
    --mode)       INSTALL_MODE="$2"; shift 2 ;;
    --mode=*)     INSTALL_MODE="${1#*=}"; shift ;;
    --yes|-y)     NON_INTERACTIVE=true; shift ;;
    --portable|-p) PORTABLE_MODE=true; shift ;;
    --portable-cpu) PORTABLE_MODE=true; PORTABLE_CPU=true; shift ;;
    --help|-h)
      echo "Usage: $0 [--mode docker|ansible] [--yes]"
      echo "  --mode docker   Docker Compose directly on this machine (default, Unraid)"
      echo "  --mode ansible  Ansible remote deploy (DGX Spark or fresh Linux)"
      echo "  --yes           Non-interactive — accept all auto-generated values"
      echo "  --portable      USB-NVMe portable mode (Ollama runs in container, no host install)"
      echo "  --portable-cpu  Portable mode without GPU (CPU inference — no NVIDIA required)"
      exit 0 ;;
    *) die "Unknown argument: $1" ;;
  esac
done

[[ "$INSTALL_MODE" == "docker" || "$INSTALL_MODE" == "ansible" ]] \
  || die "Invalid mode '${INSTALL_MODE}'. Use 'docker' or 'ansible'."
_build_dc_args   # Finalise compose file list based on --portable flags

# ── Banner ────────────────────────────────────────────────────────────────────
clear
echo
echo -e "${GRN}"
cat << 'BANNER'
  ██╗    ██╗██╗██╗     ██╗      ██████╗ ██╗    ██╗
  ██║    ██║██║██║     ██║     ██╔═══██╗██║    ██║
  ██║ █╗ ██║██║██║     ██║     ██║   ██║██║ █╗ ██║
  ██║███╗██║██║██║     ██║     ██║   ██║██║███╗██║
  ╚███╔███╔╝██║███████╗███████╗╚██████╔╝╚███╔███╔╝
   ╚══╝╚══╝ ╚═╝╚══════╝╚══════╝ ╚═════╝  ╚══╝╚══╝
BANNER
echo -e "${NC}"
echo -e "  ${WHT}Privacy-First AI Bookkeeping Appliance${NC}"
PORTABLE_SUFFIX=""
[[ "$PORTABLE_MODE" == "true" ]] && PORTABLE_SUFFIX=" | portable"
[[ "$PORTABLE_CPU" == "true" ]]  && PORTABLE_SUFFIX=" | portable-cpu"
echo -e "  ${DIM}Engineered Data Systems — v1.1  |  mode: ${INSTALL_MODE}${PORTABLE_SUFFIX}${NC}"
echo

# ── Pre-flight ────────────────────────────────────────────────────────────────
header "Pre-flight Checks"

check_cmd docker
check_cmd openssl
check_cmd git

if [[ "$INSTALL_MODE" == "ansible" ]]; then
  check_cmd ansible-playbook
  check_cmd ssh
fi

docker info &>/dev/null || die "Docker daemon is not running. Start Docker first."
success "Docker daemon running"

# Auto-detect GPU (sets GPU_TYPE, GPU_NAME, COMPOSE_TARGET globals for later use)
GPU_TYPE=""; GPU_NAME=""; COMPOSE_TARGET="up-portable-cpu"
if [[ -x "$SCRIPT_DIR/scripts/detect-gpu.sh" ]]; then
  GPU_TYPE="$(bash "$SCRIPT_DIR/scripts/detect-gpu.sh" --quiet 2>/dev/null || echo "cpu")"
  # Write .env.gpu fragment for reference
  bash "$SCRIPT_DIR/scripts/detect-gpu.sh" --env 2>/dev/null || true
fi
case "$GPU_TYPE" in
  nvidia)
    GPU_NAME="$(nvidia-smi --query-gpu=name --format=csv,noheader | head -1 | xargs 2>/dev/null || echo "NVIDIA GPU")"
    success "GPU: ${GPU_NAME} (NVIDIA CUDA)"
    COMPOSE_TARGET="up-portable"
    ;;
  amd)
    GPU_NAME="$(lspci 2>/dev/null | grep -i "amd\|radeon" | head -1 | sed 's/.*: //' || echo "AMD GPU")"
    success "GPU: ${GPU_NAME} (AMD ROCm)"
    COMPOSE_TARGET="up-portable-amd"
    ;;
  intel)
    GPU_NAME="$(lspci 2>/dev/null | grep -i "intel.*arc\|intel.*xe" | head -1 | sed 's/.*: //' || echo "Intel Arc GPU")"
    success "GPU: ${GPU_NAME} (Intel SYCL)"
    COMPOSE_TARGET="up-portable-intel"
    ;;
  *)
    warn "No GPU detected — CPU-only mode (expect 1-5 tok/s)"
    COMPOSE_TARGET="up-portable-cpu"
    ;;
esac

if [[ "$PORTABLE_MODE" == "true" ]]; then
  info "Portable mode: Ollama will run in container (no host installation required)."
elif curl -sf --max-time 3 http://localhost:11434/api/tags &>/dev/null; then
  success "Ollama running on localhost:11434"
else
  warn "Ollama not detected. Install it (https://ollama.ai) and start before pulling models."
fi

# ── Check for existing .env ───────────────────────────────────────────────────
RECONFIGURE=true
if [[ -f "$ENV_FILE" && "$NON_INTERACTIVE" == false ]]; then
  header "Existing Config Found"
  warn "docker/.env already exists."
  ask CHOICE "Reconfigure? (yes = overwrite, no = redeploy with existing config)" "no"
  [[ "$CHOICE" =~ ^[Yy] ]] || RECONFIGURE=false
fi

# ── Config Wizard ─────────────────────────────────────────────────────────────
if [[ "$RECONFIGURE" == true ]]; then

  header "1 of 5 — Network"
  ask LAN_IP        "Host machine LAN IP (the box running Docker + Ollama)" "192.168.0.50"
  ask N8N_DOMAIN    "n8n public hostname  (LAN IP is fine for local-only)" "$LAN_IP"
  ask WEBUI_DOMAIN  "Willow dashboard hostname (LAN IP is fine for local-only)" "$LAN_IP"

  header "2 of 5 — Database & Security"
  if [[ "$NON_INTERACTIVE" == true ]]; then
    POSTGRES_PASSWORD="$(openssl rand -hex 18)"
    N8N_ENCRYPTION_KEY="$(openssl rand -hex 32)"
    OPEN_WEBUI_N8N_API_KEY="$(openssl rand -hex 24)"
    info "Auto-generated DB password, n8n key, and API key."
  else
    ask_secret POSTGRES_PASSWORD      "PostgreSQL password"            "strong random"
    ask_secret N8N_ENCRYPTION_KEY     "n8n encryption key (32+ chars)" "32-char hex"
    ask_secret OPEN_WEBUI_N8N_API_KEY "Open WebUI ↔ n8n shared key"   "24-char hex"
  fi
  OPEN_WEBUI_SECRET_KEY="$(openssl rand -hex 32)"
  KANBOARD_API_TOKEN="$(openssl rand -hex 24)"

  header "3 of 5 — LLM & Speech Models"
  ask OLLAMA_MODEL       "Primary LLM (RTX 2070 default)" "qwen2.5:7b-instruct-q4_K_M"
  ask OLLAMA_EMBED_MODEL "Embedding model for Mem0"        "nomic-embed-text"
  ask WHISPER_MODEL      "Whisper model size (tiny→large-v3; medium recommended for RTX 2070)" "medium"
  ask PIPER_VOICE        "Piper TTS voice"                 "en_AU-karen-medium"

  header "4 of 5 — Email"
  ask FIRM_EMAIL_PROVIDER "Firm email provider (gmail or outlook)" "gmail"
  ask FIRM_EMAIL_ADDRESS  "Firm central inbox address"             "invoices@yourfirm.com.au"

  header "5 of 5 — Cloudflare Tunnels (optional — press Enter to skip)"
  info "Tunnels are only needed for OAuth2 callbacks (Xero, Gmail) and remote access."
  info "Skip now and add tokens to docker/.env later if working LAN-only."
  ask CF_PROD_TOKEN "Production tunnel token" ""
  ask CF_DEV_TOKEN  "Dev tunnel token"        ""

  # ── Write docker/.env ──────────────────────────────────────────────────────
  header "Writing docker/.env"

  cat > "$ENV_FILE" << ENVEOF
# =============================================================================
# WILLOW AI — Runtime Configuration
# Generated: $(date -u '+%Y-%m-%dT%H:%M:%SZ')
# DO NOT commit this file. It is in .gitignore.
# =============================================================================

# ---------------------------------------------------------------------------
# HOST
# ---------------------------------------------------------------------------
UNRAID_LAN_IP=${LAN_IP}

# ---------------------------------------------------------------------------
# POSTGRESQL
# ---------------------------------------------------------------------------
POSTGRES_USER=willow
POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
POSTGRES_DB=willow

# ---------------------------------------------------------------------------
# N8N
# ---------------------------------------------------------------------------
N8N_HOST=${N8N_DOMAIN}
N8N_WEBHOOK_URL=https://${N8N_DOMAIN}/
N8N_ENCRYPTION_KEY=${N8N_ENCRYPTION_KEY}
OPEN_WEBUI_N8N_API_KEY=${OPEN_WEBUI_N8N_API_KEY}

# ---------------------------------------------------------------------------
# OPEN WEBUI
# ---------------------------------------------------------------------------
OPEN_WEBUI_URL=https://${WEBUI_DOMAIN}
OPEN_WEBUI_SECRET_KEY=${OPEN_WEBUI_SECRET_KEY}

# ---------------------------------------------------------------------------
# OLLAMA (host-level — containers reach via host.docker.internal:11434)
# ---------------------------------------------------------------------------
OLLAMA_MODEL=${OLLAMA_MODEL}
OLLAMA_EMBED_MODEL=${OLLAMA_EMBED_MODEL}
# DGX Spark upgrade: set OLLAMA_MODEL=qwen2.5:72b-instruct OLLAMA_EMBED_MODEL=mxbai-embed-large

# ---------------------------------------------------------------------------
# SPEECH
# ---------------------------------------------------------------------------
WHISPER_MODEL=${WHISPER_MODEL}
PIPER_VOICE=${PIPER_VOICE}

# ---------------------------------------------------------------------------
# CLOUDFLARE TUNNELS
# ---------------------------------------------------------------------------
CLOUDFLARE_TUNNEL_TOKEN=${CF_PROD_TOKEN:-CHANGE_ME_IF_USING_TUNNEL}
CLOUDFLARE_DEV_TUNNEL_TOKEN=${CF_DEV_TOKEN:-CHANGE_ME_IF_USING_TUNNEL}

# ---------------------------------------------------------------------------
# XERO  (configure inside n8n → Credentials, or add here for env injection)
# ---------------------------------------------------------------------------
XERO_CLIENT_ID=CHANGE_ME
XERO_CLIENT_SECRET=CHANGE_ME

# ---------------------------------------------------------------------------
# GMAIL
# ---------------------------------------------------------------------------
FIRM_GMAIL_ADDRESS=${FIRM_EMAIL_ADDRESS}
GMAIL_CLIENT_ID=CHANGE_ME
GMAIL_CLIENT_SECRET=CHANGE_ME

# ---------------------------------------------------------------------------
# OUTLOOK / MICROSOFT 365
# ---------------------------------------------------------------------------
FIRM_OUTLOOK_ADDRESS=${FIRM_EMAIL_ADDRESS}
OUTLOOK_CLIENT_ID=CHANGE_ME
OUTLOOK_CLIENT_SECRET=CHANGE_ME
OUTLOOK_TENANT_ID=CHANGE_ME

# ---------------------------------------------------------------------------
# KANBOARD
# ---------------------------------------------------------------------------
KANBOARD_API_TOKEN=${KANBOARD_API_TOKEN}
KANBOARD_URL=http://kanboard:8081

# ---------------------------------------------------------------------------
# MEM0
# ---------------------------------------------------------------------------
MEM0_URL=http://mem0:8070

# ---------------------------------------------------------------------------
# FIRM
# ---------------------------------------------------------------------------
FIRM_EMAIL_PROVIDER=${FIRM_EMAIL_PROVIDER}
TZ=Australia/Brisbane
ENVEOF

  chmod 600 "$ENV_FILE"
  success "docker/.env written (mode 600 — owner-read-only)"
fi

# ── Ansible inventory (ansible mode only) ─────────────────────────────────────
if [[ "$INSTALL_MODE" == "ansible" ]]; then
  header "Ansible Inventory"

  SKIP_INVENTORY=false
  if [[ -f "$INVENTORY_FILE" ]]; then
    warn "ansible/inventory.yml already exists."
    if [[ "$NON_INTERACTIVE" == false ]]; then
      ask SKIP_INV_CHOICE "Skip inventory generation? (yes/no)" "yes"
      [[ "$SKIP_INV_CHOICE" =~ ^[Yy] ]] && SKIP_INVENTORY=true || SKIP_INVENTORY=false
    else
      SKIP_INVENTORY=true
    fi
  fi

  if [[ "$SKIP_INVENTORY" == false ]]; then
    ask ANS_HOST    "Target host IP or hostname" "192.168.0.50"
    ask ANS_USER    "SSH user"                   "root"
    ask ANS_PORT    "SSH port"                   "22"
    ask ANS_ROOT    "Deploy path on target"      "/mnt/user/appdata/willow"
    ask ANS_DOCKER  "Skip Docker install? (true for Unraid, false for fresh Linux)" "true"
    ask ANS_PROFILE "Compose profile (development / production)"                    "development"

    cat > "$INVENTORY_FILE" << INVEOF
---
# Generated by install.sh on $(date -u '+%Y-%m-%dT%H:%M:%SZ')
all:
  vars:
    ansible_user: ${ANS_USER}
    ansible_ssh_private_key_file: ~/.ssh/id_ed25519
    ansible_python_interpreter: /usr/bin/python3

  children:
    willow_host:
      hosts:
        primary:
          ansible_host: ${ANS_HOST}
          ansible_port: ${ANS_PORT}
          compose_profile: ${ANS_PROFILE}
          willow_root: ${ANS_ROOT}
          gpu_driver: nvidia
          skip_docker_install: ${ANS_DOCKER}
INVEOF
    success "ansible/inventory.yml written"
  fi
fi

# ── Deploy ────────────────────────────────────────────────────────────────────
header "Deploying"

if [[ "$INSTALL_MODE" == "ansible" ]]; then
  step() { echo -e "${CYN}  $*${NC}"; }
  step "Running Ansible playbook — this will take a few minutes..."
  ansible-playbook -i "$INVENTORY_FILE" "$SCRIPT_DIR/ansible/deploy.yml"

else
  # ── Docker Compose (Unraid / local) ──────────────────────────────────────
  info "Pulling Docker images (this may take a while on first run)..."
  dc pull --quiet

  info "Starting services..."
  dc up -d --remove-orphans

  wait_for_http "PostgreSQL" "http://localhost:5432" 20  || true  # not HTTP but try
  # Use pg_isready instead
  echo -en "  Waiting for PostgreSQL"
  RETRIES=30
  until dc exec -T willow-db pg_isready -U willow &>/dev/null; do
    RETRIES=$((RETRIES - 1))
    [[ $RETRIES -le 0 ]] && echo && die "PostgreSQL did not start in time."
    echo -n "."; sleep 2
  done
  echo; success "PostgreSQL ready"

  wait_for_http "n8n" "http://localhost:5678/healthz"

  info "Running database migrations..."
  for sql in "$SCRIPT_DIR"/database/migrations/*.sql; do
    [[ -f "$sql" ]] || continue
    if dc exec -T willow-db psql -U willow -d willow < "$sql" &>/dev/null; then
      success "Migration applied: $(basename "$sql")"
    else
      warn "Migration skipped (may already exist): $(basename "$sql")"
    fi
  done

  info "Importing n8n workflows..."
  N8N_CONTAINER="$(dc ps -q n8n 2>/dev/null || true)"
  if [[ -n "$N8N_CONTAINER" ]]; then
    for wf in "$SCRIPT_DIR"/n8n/workflows/*.json; do
      [[ -f "$wf" ]] || continue
      WF_NAME="$(basename "$wf")"
      docker cp "$wf" "${N8N_CONTAINER}:/tmp/${WF_NAME}" 2>/dev/null || true
      docker exec "$N8N_CONTAINER" n8n import:workflow \
        --input="/tmp/${WF_NAME}" &>/dev/null \
        && success "Imported: ${WF_NAME}" \
        || warn "Could not import: ${WF_NAME} (import manually in n8n UI)"
    done

    # Activate all workflows EXCEPT follow-up-executor (requires approval gate
    # to be confirmed working in the dashboard before enabling).
    info "Activating workflows..."
    SKIP_ACTIVATE="willow-follow-up-executor"
    for wf in "$SCRIPT_DIR"/n8n/workflows/*.json; do
      [[ -f "$wf" ]] || continue
      WF_BASE="$(basename "$wf" .json)"
      if [[ "$WF_BASE" == *"$SKIP_ACTIVATE"* ]]; then
        warn "Skipped activation: ${WF_BASE} (enable manually after confirming Approvals dashboard works)"
        continue
      fi
      # Read the id field from the JSON
      WF_ID="$(python3 -c "import json,sys; d=json.load(open('$wf')); print(d.get('id',''))" 2>/dev/null || true)"
      if [[ -n "$WF_ID" ]]; then
        docker exec "$N8N_CONTAINER" n8n update:workflow --id="$WF_ID" --active=true &>/dev/null \
          && success "Activated: ${WF_BASE}" \
          || warn "Could not activate: ${WF_BASE} (activate manually in n8n UI)"
      fi
    done
  else
    warn "n8n container not found — import workflows manually via n8n UI."
  fi
fi

# ── Ollama models ─────────────────────────────────────────────────────────────
header "Ollama Models"

# Re-source .env to pick up OLLAMA_MODEL values
set -a; source "$ENV_FILE"; set +a

if [[ "$PORTABLE_MODE" == "true" ]]; then
  # Portable mode: Ollama runs inside willow-ollama container
  info "Checking willow-ollama container..."
  if docker exec willow-ollama curl -sf http://localhost:11434/api/tags &>/dev/null 2>&1; then
    info "Pulling ${OLLAMA_MODEL} into willow-ollama container (this may take several minutes)..."
    docker exec willow-ollama ollama pull "${OLLAMA_MODEL}"       && success "${OLLAMA_MODEL} ready"       || warn "Pull failed — run manually: make models-portable"

    info "Pulling ${OLLAMA_EMBED_MODEL}..."
    docker exec willow-ollama ollama pull "${OLLAMA_EMBED_MODEL}"       && success "${OLLAMA_EMBED_MODEL} ready"       || warn "Pull failed — run manually: make models-portable"
  else
    warn "willow-ollama container not ready yet — skipping model pull."
    info "After the stack is healthy, run:  make models-portable"
  fi
elif curl -sf --max-time 3 http://localhost:11434/api/tags &>/dev/null; then
  info "Pulling ${OLLAMA_MODEL} (this may take several minutes)..."
  ollama pull "${OLLAMA_MODEL}"   && success "${OLLAMA_MODEL} ready" \
    || warn "Pull failed — run manually: ollama pull ${OLLAMA_MODEL}"

  info "Pulling ${OLLAMA_EMBED_MODEL}..."
  ollama pull "${OLLAMA_EMBED_MODEL}" && success "${OLLAMA_EMBED_MODEL} ready" \
    || warn "Pull failed — run manually: ollama pull ${OLLAMA_EMBED_MODEL}"
else
  warn "Ollama not running — skipping model pull."
  info "After starting Ollama, run:"
  info "  ollama pull ${OLLAMA_MODEL:-qwen2.5:7b-instruct-q4_K_M}"
  info "  ollama pull ${OLLAMA_EMBED_MODEL:-nomic-embed-text}"
fi

# ── Verify ────────────────────────────────────────────────────────────────────
header "Service Check"

check_http() {
  local name="$1" url="$2" required="${3:-warn}"
  if curl -sf --max-time 5 "$url" &>/dev/null; then
    success "${name}"
  elif [[ "$required" == "error" ]]; then
    error "${name} — not responding at ${url}"
  else
    warn "${name} — not responding at ${url} (check logs: make logs)"
  fi
}

IP="${UNRAID_LAN_IP:-localhost}"
check_http "n8n"            "http://${IP}:5678/healthz"  error
check_http "Open WebUI"     "http://${IP}:3000"
check_http "Kanboard"       "http://${IP}:8081"
check_http "faster-whisper" "http://${IP}:9000/health"

# ── Seed first admin staff member ────────────────────────────────────────────
header "First Admin User"

WILLOW_DB_CONTAINER="$(dc ps -q willow-db 2>/dev/null || true)"
if [[ -n "$WILLOW_DB_CONTAINER" ]]; then
  EXISTING_STAFF="$(docker exec "$WILLOW_DB_CONTAINER" \
    psql -U willow -d willow -tAc "SELECT COUNT(*) FROM staff_registry" 2>/dev/null || echo '0')"
  EXISTING_STAFF="$(echo "$EXISTING_STAFF" | tr -d '[:space:]')"

  if [[ "$EXISTING_STAFF" -eq 0 ]]; then
    info "No staff found. Creating the first admin account."
    if [[ "$NON_INTERACTIVE" == "1" ]]; then
      ADMIN_NAME="Admin"
      ADMIN_EMAIL="admin@willow.local"
    else
      printf "  Admin name  (e.g. Jane Smith): "
      read -r ADMIN_NAME
      printf "  Admin email (e.g. jane@yourfirm.com.au): "
      read -r ADMIN_EMAIL
    fi
    ADMIN_ID="staff_$(openssl rand -hex 6)"
    docker exec "$WILLOW_DB_CONTAINER" psql -U willow -d willow -c \
      "INSERT INTO staff_registry (user_id, name, role, email, approval_limit, active) \
       VALUES ('${ADMIN_ID}', '${ADMIN_NAME}', 'admin', '${ADMIN_EMAIL}', 999999, TRUE) \
       ON CONFLICT (email) DO NOTHING;" &>/dev/null \
      && success "Admin created: ${ADMIN_NAME} (${ADMIN_EMAIL}) — user_id: ${ADMIN_ID}" \
      || warn "Could not seed admin (may already exist). Add via Staff page in the dashboard."
  else
    info "Staff already exist (${EXISTING_STAFF} records) — skipping seed."
  fi
else
  warn "Database container not found — add staff via the Staff page in the dashboard after startup."
fi

# ── Done ──────────────────────────────────────────────────────────────────────
echo
echo -e "${GRN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GRN}  Willow is installed!${NC}"
echo -e "${GRN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo
echo -e "  ${WHT}Services${NC}"
echo -e "  ${CYN}http://${IP}:5678${NC}   n8n workflow editor"
echo -e "  ${CYN}http://${IP}:3000${NC}   Open WebUI chat"
echo -e "  ${CYN}http://${IP}:8081${NC}   Kanboard tasks"
echo -e "  ${CYN}http://${IP}:8080${NC}   Willow dashboard"
echo
echo -e "  ${WHT}Two manual steps remain${NC}"
echo -e "  1. Open n8n → Credentials → add ${WHT}Xero OAuth2${NC} + ${WHT}Gmail OAuth2${NC}"
echo -e "     (These require a browser auth flow — cannot be automated)"
echo -e "  2. Enable ${WHT}willow-follow-up-executor${NC} in n8n AFTER confirming"
echo -e "     the Approvals page in the dashboard is working"
echo
echo -e "  Everything else is running. Add more staff via the ${WHT}Staff${NC} page."
echo
echo -e "  ${WHT}Day-to-day${NC}"
if [[ "$PORTABLE_MODE" == "true" ]]; then
  echo -e "  ${DIM}make ${COMPOSE_TARGET}${NC}   start   ${DIM}make down${NC}   stop"
  echo -e "  ${DIM}make models-portable${NC} pull models  ${DIM}make backup${NC}  dump DB"
  echo -e "  ${DIM}make up-auto${NC}    auto-detect GPU on next run"
else
  echo -e "  ${DIM}make up${NC}      start   ${DIM}make down${NC}     stop"
  echo -e "  ${DIM}make logs${NC}    logs    ${DIM}make backup${NC}   dump DB"
fi
echo -e "  ${DIM}make update${NC}  update  ${DIM}make status${NC}   health check"
echo
