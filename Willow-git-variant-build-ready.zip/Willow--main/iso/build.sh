#!/usr/bin/env bash
# =============================================================================
# WILLOW AI — ISO Build Script
# Engineered Data Systems
# =============================================================================
# Remasters the official Ubuntu 22.04 LTS Server ISO with a cloud-init
# autoinstall config that installs Docker, Ollama, and the Willow stack.
#
# Does NOT use live-build — avoids all grub-legacy / syslinux / gfxboot
# package compatibility issues with modern Ubuntu runners.
#
# Usage:
#   ./iso/build.sh [output.iso]
#
# Requirements:
#   apt-get install -y p7zip-full xorriso syslinux-utils
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

ISO_OUTPUT="${1:-willow-install-amd64.iso}"
WORK_DIR="$(mktemp -d /tmp/willow-iso-XXXXXX)"
trap 'rm -rf "$WORK_DIR"' EXIT

GREEN=$'\e[32m'; YELLOW=$'\e[33m'; CYAN=$'\e[36m'; BOLD=$'\e[1m'; RESET=$'\e[0m'
info()    { echo "  ${GREEN}✓${RESET}  $*"; }
warn()    { echo "  ${YELLOW}⚠${RESET}  $*"; }
heading() { echo ""; echo "${BOLD}${CYAN}$*${RESET}"; echo ""; }

SOURCE_ISO="${WORK_DIR}/ubuntu-base.iso"
SOURCE_DIR="${WORK_DIR}/iso-source"
EFI_IMG="${WORK_DIR}/efi.img"
MBR_IMG="${WORK_DIR}/mbr.img"

UBUNTU_ISO_URL="https://releases.ubuntu.com/22.04.5/ubuntu-22.04.5-live-server-amd64.iso"
UBUNTU_ISO_SHA256="9bc6028870aef3f74f4e16b900008179e78b130e6b0b9a140635434a46aa98b0"

# ── 1: Download ───────────────────────────────────────────────────────────────
heading "1/7  Downloading Ubuntu 22.04 Server ISO"

CACHE="/tmp/ubuntu-22.04.5-live-server-amd64.iso"
if [[ -f "$CACHE" ]]; then
  info "Using cached ISO"
  cp "$CACHE" "$SOURCE_ISO"
else
  wget -q --show-progress -O "$SOURCE_ISO" "$UBUNTU_ISO_URL"
  cp "$SOURCE_ISO" "$CACHE" 2>/dev/null || true
fi

echo "  Verifying checksum..."
echo "${UBUNTU_ISO_SHA256}  ${SOURCE_ISO}" | sha256sum -c --quiet
info "Checksum verified"

# ── 2: Extract ────────────────────────────────────────────────────────────────
heading "2/7  Extracting ISO"
mkdir -p "$SOURCE_DIR"
# 7z does not preserve executable bits — that's fine for an ISO filesystem
7z x "$SOURCE_ISO" -o"$SOURCE_DIR" -bsp0 -bso0
info "Extracted to $SOURCE_DIR"

# ── 3: Extract boot images ────────────────────────────────────────────────────
heading "3/7  Extracting boot images"

# BIOS bootstrap: first 446 bytes (MBR boot code, not the partition table)
dd if="$SOURCE_ISO" bs=1 count=446 of="$MBR_IMG" 2>/dev/null
info "MBR boot code extracted"

# EFI system partition — find its sector range in the ISO's GPT/MBR table
EFI_LINE=$(fdisk -l "$SOURCE_ISO" 2>/dev/null | grep -i "EFI System" || true)
if [[ -z "$EFI_LINE" ]]; then
  # Some Ubuntu ISO versions label it differently
  EFI_LINE=$(fdisk -l "$SOURCE_ISO" 2>/dev/null | grep -E "\.iso2" || true)
fi
if [[ -z "$EFI_LINE" ]]; then
  echo "  WARNING: could not find EFI partition via fdisk" >&2
  fdisk -l "$SOURCE_ISO" >&2
  # Fall back: extract from xorriso system area report
  EFI_START=$(xorriso -indev "$SOURCE_ISO" -report_system_area plain 2>/dev/null \
    | grep -i "EFI" | grep -oP '(?<=sector )\d+' | head -1 || echo "")
  EFI_SIZE=2880   # standard Ubuntu EFI partition size in sectors
else
  EFI_START=$(echo "$EFI_LINE" | awk '{print $2}')
  EFI_END=$(echo "$EFI_LINE"   | awk '{print $3}')
  EFI_SIZE=$(( EFI_END - EFI_START + 1 ))
fi

if [[ -z "$EFI_START" ]]; then
  warn "EFI partition not found — ISO will be BIOS-only"
  touch "$EFI_IMG"   # empty placeholder so xorriso command still works
else
  dd if="$SOURCE_ISO" bs=512 skip="$EFI_START" count="$EFI_SIZE" \
     of="$EFI_IMG" 2>/dev/null
  info "EFI partition extracted (start sector ${EFI_START}, ${EFI_SIZE} sectors)"
fi

# ── 4: Stage Willow repo ──────────────────────────────────────────────────────
heading "4/7  Staging Willow repo into ISO"

mkdir -p "$SOURCE_DIR/willow-src"
rsync -a \
  --exclude='.git' \
  --exclude='audit-exports/' \
  --exclude='offboard-exports/' \
  --exclude='iso/' \
  --exclude='*.log' \
  "$REPO_ROOT"/ "$SOURCE_DIR/willow-src/"

# Also include the firstboot systemd service from iso/includes
if [[ -f "$SCRIPT_DIR/includes/systemd/willow-firstboot.service" ]]; then
  mkdir -p "$SOURCE_DIR/willow-src/iso/includes/systemd"
  cp "$SCRIPT_DIR/includes/systemd/willow-firstboot.service" \
     "$SOURCE_DIR/willow-src/iso/includes/systemd/"
fi
info "Willow repo staged at /willow-src inside ISO"

# ── 5: Inject autoinstall config ─────────────────────────────────────────────
heading "5/7  Injecting autoinstall config"

mkdir -p "$SOURCE_DIR/autoinstall"
cp "$SCRIPT_DIR/autoinstall/user-data" "$SOURCE_DIR/autoinstall/user-data"
touch "$SOURCE_DIR/autoinstall/meta-data"

# Stamp a default password hash ("willow" — force-changed on first login)
DEFAULT_HASH=$(openssl passwd -6 -salt "eds-willow-salt" "willow")
sed -i "s|WILLOW_PASSWORD_HASH|${DEFAULT_HASH}|g" \
  "$SOURCE_DIR/autoinstall/user-data"
info "Autoinstall config injected (password hash stamped)"

# Patch grub.cfg files to add autoinstall + nocloud kernel parameters
for cfg in \
  "$SOURCE_DIR/boot/grub/grub.cfg" \
  "$SOURCE_DIR/EFI/boot/grub.cfg" \
  "$SOURCE_DIR/boot/grub/loopback.cfg"
do
  [[ -f "$cfg" ]] || continue
  sed -i \
    's|\(linux.*casper/vmlinuz.*\)---|\1autoinstall quiet ds=nocloud;s=/cdrom/autoinstall/ ---|g' \
    "$cfg"
  info "Patched grub: $(dirname "$cfg" | xargs basename)/$(basename "$cfg")"
done

# ── 6: Rebuild MD5 manifest ───────────────────────────────────────────────────
heading "6/7  Rebuilding MD5 manifest"

( cd "$SOURCE_DIR"
  rm -f md5sum.txt
  find . -type f ! -name 'md5sum.txt' -print0 \
    | xargs -0 md5sum \
    | sed 's|  \./|  |' \
    > md5sum.txt
)
info "md5sum.txt regenerated ($(wc -l < "$SOURCE_DIR/md5sum.txt") files)"

# ── 7: Build hybrid ISO ───────────────────────────────────────────────────────
heading "7/7  Building hybrid ISO (BIOS + UEFI)"

# xorriso -as mkisofs generates a temporary binary.sh and execs it after
# writing the ISO.  That script calls isohybrid, which is redundant here
# because --grub2-mbr already wrote the hybrid MBR natively inside xorriso.
# Strategy: (a) stamp a no-op shim so binary.sh succeeds cleanly, and
# (b) tolerate a non-zero exit from xorriso if the ISO was written correctly.

info "Stamping isohybrid no-op shim at all standard bin paths"
_shim_tmp=$(mktemp)
printf '#!/bin/sh\nexit 0\n' > "$_shim_tmp"
chmod 755 "$_shim_tmp"
for _dir in /usr/bin /usr/local/bin /usr/sbin /usr/local/sbin /bin /sbin; do
  [[ -d "$_dir" ]] || continue
  cp "$_shim_tmp" "$_dir/isohybrid" 2>/dev/null && chmod 755 "$_dir/isohybrid" \
    && echo "  shim → $_dir/isohybrid" || true
done
rm -f "$_shim_tmp"
_ih=$(command -v isohybrid 2>/dev/null || echo "NOT IN PATH")
echo "  isohybrid in PATH: $_ih"
[[ "$_ih" != "NOT IN PATH" ]] && { isohybrid && echo "  shim test: PASS" || echo "  shim test: exit $?"; }

# Build with xorriso in mkisofs-compatibility mode.
# --grub2-mbr injects the MBR bootstrap code for BIOS boot.
# -append_partition + GPT flags embed the EFI partition for UEFI boot.
set +e
xorriso -as mkisofs \
  -r \
  -V "Willow AI Install" \
  -J -joliet-long \
  --grub2-mbr      "$MBR_IMG" \
  --mbr-force-bootable \
  -partition_offset 16 \
  -append_partition 2 28732ac11ff8d211ba4b00a0c93ec93b "$EFI_IMG" \
  -appended_part_as_gpt \
  -iso_mbr_part_type a2a0d0ebe5b9334487c068b6b72699c7 \
  -c  boot.catalog \
  -b  boot/grub/i386-pc/eltorito.img \
  -no-emul-boot -boot-load-size 4 -boot-info-table --grub2-boot-info \
  -eltorito-alt-boot \
  -e  '--interval:appended_partition_2:::' \
  -no-emul-boot \
  "$SOURCE_DIR" \
  -o  "$ISO_OUTPUT" \
  2>&1 | tail -10
XORRISO_RC=${PIPESTATUS[0]}
set -e

# The ISO content is written before xorriso calls binary.sh/isohybrid.
# If xorriso exits non-zero but the output file is a valid-sized ISO
# (>500 MB), the failure was from the redundant isohybrid post-call only.
if [[ $XORRISO_RC -ne 0 ]]; then
  _iso_bytes=$(stat -c%s "$ISO_OUTPUT" 2>/dev/null || echo 0)
  if [[ $_iso_bytes -gt 524288000 ]]; then
    warn "xorriso exited $XORRISO_RC — isohybrid post-call failed (redundant; MBR already written)"
    warn "ISO is $(du -sh "$ISO_OUTPUT" | cut -f1) — content correct, continuing."
  else
    echo "ERROR: xorriso exited $XORRISO_RC with no valid ISO (${_iso_bytes} bytes)" >&2
    exit $XORRISO_RC
  fi
fi

info "ISO written: $ISO_OUTPUT  ($(du -sh "$ISO_OUTPUT" | cut -f1))"
echo ""
echo "  SHA256: $(sha256sum "$ISO_OUTPUT" | cut -d' ' -f1)"
echo ""
echo "  Flash to USB:"
echo "    sudo dd if=$ISO_OUTPUT of=/dev/sdX bs=4M status=progress && sync"
echo ""
