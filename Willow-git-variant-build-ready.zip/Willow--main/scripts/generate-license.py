#!/usr/bin/env python3
"""
Willow License Generator — PRIVATE TOOL
Engineered Data Systems

SECURITY:
  - Requires the PRIVATE key. Never share or commit the private key.
  - Run this tool only on your own secure machine (not on client hardware).
  - The private key file should be stored offline (encrypted USB, password manager, etc.).
  - The generated .key file is safe to email to the client.

Requirements:
  pip install cryptography

Usage:
  # Get client's hardware ID first — SSH to their Willow machine and run:
  #   bash /opt/willow/scripts/hardware-id.sh

  python3 scripts/generate-license.py \\
      --private-key /path/to/willow-private.pem \\
      --firm "Smith & Associates Bookkeeping" \\
      --email admin@smithbooks.com.au \\
      --tier professional \\
      --seats 8 \\
      --hardware-id a3f9c2b1d4e5f6a7 \\
      --days 365 \\
      --output smith-associates.key

  # No hardware binding (testing, demo units):
  #   --hardware-id any

  # Renewal (same arguments, new --days):
  #   python3 scripts/generate-license.py ... --days 365

  # Optional paid support SKU:
  #   --support-plan priority --support-days 365

Tiers:
  starter       1–3 staff    AUD $3,600/year
  professional  4–10 staff   AUD $7,200/year
  studio        11–25 staff  AUD $13,200/year
  enterprise    25+ staff    Negotiated
"""

import argparse
import json
import base64
import datetime
import sys
from pathlib import Path

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.serialization import load_pem_private_key
except ImportError:
    print("ERROR: cryptography package required.\n  pip install cryptography")
    sys.exit(1)

TIERS = {
    "starter":      (3,    3_600),
    "professional": (10,   7_200),
    "studio":       (25,  13_200),
    "enterprise":   (9999, 0),    # negotiated
}

TIER_SEAT_LIMITS = {k: v[0] for k, v in TIERS.items()}


def slugify(text: str) -> str:
    slug = text.lower().replace(" & ", "-and-").replace(" ", "-")
    return "".join(c for c in slug if c.isalnum() or c == "-")


def main():
    parser = argparse.ArgumentParser(
        description="Willow License Generator — Engineered Data Systems"
    )
    parser.add_argument("--private-key",  required=True,
                        help="Path to willow-private.pem (keep offline)")
    parser.add_argument("--firm",         required=True,
                        help="Firm legal name e.g. 'Smith & Associates Bookkeeping'")
    parser.add_argument("--email",        required=True,
                        help="Billing contact email")
    parser.add_argument("--tier",         required=True, choices=list(TIERS.keys()),
                        help="License tier")
    parser.add_argument("--seats",        type=int, required=True,
                        help="Number of staff seats licensed")
    parser.add_argument("--hardware-id",  required=True,
                        help="Hardware fingerprint from hardware-id.sh, or 'any' to skip binding")
    parser.add_argument("--days",         type=int, default=365,
                        help="Updates/licence validity in days (default: 365). After expiry, Willow keeps running but updates pause.")
    parser.add_argument("--support-plan", choices=["none", "priority"], default="none",
                        help="Optional support SKU attached to the licence")
    parser.add_argument("--support-days", type=int, default=0,
                        help="Support validity in days. Use with --support-plan priority.")
    parser.add_argument("--output",       help="Output filename (default: <firm-slug>.key)")
    args = parser.parse_args()

    # Validate seat count against tier
    max_seats = TIER_SEAT_LIMITS[args.tier]
    if args.seats > max_seats and args.tier != "enterprise":
        print(f"WARNING: {args.seats} seats exceeds {args.tier} tier limit ({max_seats}). "
              f"Consider upgrading to the next tier.")

    # Load private key
    pk_path = Path(args.private_key)
    if not pk_path.exists():
        print(f"ERROR: Private key not found: {pk_path}")
        sys.exit(1)
    try:
        private_key = load_pem_private_key(pk_path.read_bytes(), password=None)
        if not isinstance(private_key, Ed25519PrivateKey):
            print("ERROR: Key is not an Ed25519 private key")
            sys.exit(1)
    except Exception as e:
        print(f"ERROR loading private key: {e}")
        sys.exit(1)

    # Build payload
    today   = datetime.date.today()
    expires = today + datetime.timedelta(days=args.days)

    payload = {
        "version":     1,
        "firm":        args.firm,
        "email":       args.email,
        "tier":        args.tier,
        "seats":       args.seats,
        "hardware_id": args.hardware_id,
        "issued":      today.isoformat(),
        "expires":     expires.isoformat(),  # updates/support entitlement period; not a dead-man lock
        "fallback":    "perpetual",
    }

    if args.support_plan != "none":
        support_days = args.support_days or args.days
        payload["support_plan"] = args.support_plan
        payload["support_expires"] = (today + datetime.timedelta(days=support_days)).isoformat()

    # Sort keys for deterministic output — signature must be over the exact same bytes
    payload_json  = json.dumps(payload, separators=(",", ":"), sort_keys=True)
    payload_bytes = payload_json.encode()
    payload_b64   = base64.b64encode(payload_bytes).decode()

    # Sign with Ed25519 private key
    signature = private_key.sign(payload_bytes)
    sig_b64   = base64.b64encode(signature).decode()

    # License file format
    license_content = f"WILLOW_LICENSE_V1\n{payload_b64}\n{sig_b64}\n"

    # Output path
    out_path = Path(args.output) if args.output else Path(f"{slugify(args.firm)}.key")
    out_path.write_text(license_content)

    annual_price = TIERS[args.tier][1]
    price_str    = f"AUD ${annual_price:,}/year" if annual_price else "Negotiated"

    print(f"""
  ╔══════════════════════════════════════════════════════════╗
  ║              Willow License Generated                    ║
  ╚══════════════════════════════════════════════════════════╝

  File:     {out_path}
  Firm:     {args.firm}
  Email:    {args.email}
  Tier:     {args.tier.title()}  ({price_str})
  Seats:    {args.seats}
  HW ID:    {args.hardware_id}
  Issued:   {today.isoformat()}
  Updates:  active until {expires.isoformat()}  ({args.days} days)
  Fallback: perpetual — writes continue after expiry, updates pause
  Support:  {args.support_plan if args.support_plan != "none" else "none"}

  ── Client instructions ───────────────────────────────────
  1. Email {out_path} to {args.email}
  2. SSH into the Willow machine (ssh willow@<ip>)
  3. Copy the file:
       cp /path/to/{out_path.name} /opt/willow/license.key
  4. Apply the license:
       cd /opt/willow && make license-apply FILE=license.key
  ─────────────────────────────────────────────────────────
""")


if __name__ == "__main__":
    main()
