#!/usr/bin/env bash
# =============================================================================
# WILLOW AI — Offboarding / Data Exit Script
# Engineered Data Systems
# =============================================================================
# Produces a complete, self-contained data exit package for the firm.
# Run this when either party disengages — EDS retains no copy of firm data,
# and the firm leaves with everything they need.
#
# Output:
#   offboard-exports/willow-offboard-YYYYMMDD-HHMMSS/
#     00_README.txt              Plain-English guide for the firm
#     01_full_database.sql.gz    Complete pg_dump (all firm data)
#     02_audit_log.csv           Audit trail (ATO records)
#     03_invoice_records.csv     Invoice fingerprints + Xero links
#     04_client_register.csv     Client list + ABNs
#     05_staff_register.csv      Staff list + roles
#     06_n8n_workflows.json      All n8n workflow definitions
#     07_credentials_notice.txt  Instructions for Xero/Gmail re-auth
#     MANIFEST.sha256            SHA256 of every file for integrity checking
#
# Usage:
#   ./scripts/offboard.sh
#   make offboard
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
ENV_FILE="$REPO_ROOT/docker/.env"
COMPOSE_FILE="$REPO_ROOT/docker/docker-compose.yml"

RED=$'\e[31m'; GREEN=$'\e[32m'; YELLOW=$'\e[33m'; CYAN=$'\e[36m'; BOLD=$'\e[1m'; RESET=$'\e[0m'
info()    { echo "  ${GREEN}✓${RESET}  $*"; }
warn()    { echo "  ${YELLOW}⚠${RESET}  $*"; }
heading() { echo ""; echo "${BOLD}${CYAN}$*${RESET}"; echo ""; }

# ---------------------------------------------------------------------------
if [[ ! -f "$ENV_FILE" ]]; then
  echo "  ${RED}✗${RESET}  docker/.env not found. Run 'make install' first." >&2
  exit 1
fi

# shellcheck disable=SC1090
set -a; source "$ENV_FILE"; set +a

DOCKER_COMPOSE=$(docker compose version >/dev/null 2>&1 && echo "docker compose" || echo "docker-compose")
DC() { $DOCKER_COMPOSE -f "$COMPOSE_FILE" --env-file "$ENV_FILE" "$@"; }

TIMESTAMP=$(date +%Y%m%d-%H%M%S)
OUT_DIR="$REPO_ROOT/offboard-exports/willow-offboard-$TIMESTAMP"
mkdir -p "$OUT_DIR"

echo ""
echo "${BOLD}${CYAN}═══════════════════════════════════════════════════════${RESET}"
echo "${BOLD}${CYAN}  Willow — Offboarding / Data Exit Package${RESET}"
echo "${BOLD}${CYAN}═══════════════════════════════════════════════════════${RESET}"
echo ""
echo "  Output:  $OUT_DIR"
echo ""
echo "  ${YELLOW}This script exports all firm data.${RESET}"
echo "  ${YELLOW}It does NOT delete or modify anything.${RESET}"
echo ""
read -rp "  Continue? [y/N]: " CONFIRM
[[ "${CONFIRM,,}" == "y" ]] || { echo "  Aborted."; exit 0; }

# ── 1. Full database dump ────────────────────────────────────────────────────
heading "01 — Full database dump"

DC exec -T willow-db pg_dump \
  -U "${POSTGRES_USER:-willow}" \
  --no-owner --no-acl \
  "${POSTGRES_DB:-willow}" \
  | gzip > "$OUT_DIR/01_full_database.sql.gz"

info "01_full_database.sql.gz  ($(du -sh "$OUT_DIR/01_full_database.sql.gz" | cut -f1))"

# ── 2. Audit log CSV ─────────────────────────────────────────────────────────
heading "02 — Audit log"

DC exec -T willow-db psql \
  -U "${POSTGRES_USER:-willow}" \
  -d "${POSTGRES_DB:-willow}" \
  --csv -q \
  -c "SELECT
        id,
        (timestamp AT TIME ZONE 'Australia/Brisbane')::TEXT AS timestamp_aest,
        staff_name,
        staff_user_id,
        action,
        agent,
        client_id,
        details,
        result,
        error_message,
        row_hash
      FROM audit_log
      ORDER BY id ASC" \
  > "$OUT_DIR/02_audit_log.csv"

ROWS=$(tail -n +2 "$OUT_DIR/02_audit_log.csv" | wc -l | tr -d ' ')
info "02_audit_log.csv  ($ROWS rows)"

# ── 3. Invoice fingerprints ──────────────────────────────────────────────────
heading "03 — Invoice records"

DC exec -T willow-db psql \
  -U "${POSTGRES_USER:-willow}" \
  -d "${POSTGRES_DB:-willow}" \
  --csv -q \
  -c "SELECT
        f.sha256_hash,
        f.client_id,
        cr.business_name AS client_name,
        f.supplier_name,
        f.invoice_number,
        f.amount,
        f.gst_amount,
        f.xero_bill_id,
        f.source_message_id,
        f.source_type,
        f.processed_by,
        (f.processed_at AT TIME ZONE 'Australia/Brisbane')::TEXT AS processed_at_aest,
        f.status
      FROM invoice_fingerprints f
      LEFT JOIN client_registry cr USING (client_id)
      ORDER BY f.processed_at ASC" \
  > "$OUT_DIR/03_invoice_records.csv"

ROWS=$(tail -n +2 "$OUT_DIR/03_invoice_records.csv" | wc -l | tr -d ' ')
info "03_invoice_records.csv  ($ROWS rows)"

# ── 4. Client register ───────────────────────────────────────────────────────
heading "04 — Client register"

DC exec -T willow-db psql \
  -U "${POSTGRES_USER:-willow}" \
  -d "${POSTGRES_DB:-willow}" \
  --csv -q \
  -c "SELECT
        client_id,
        business_name,
        abn,
        xero_tenant_id,
        xero_org_name,
        primary_contact,
        contact_email,
        contact_domain,
        bas_frequency,
        payroll_frequency,
        assigned_staff,
        email_provider,
        notes,
        active,
        (created_at AT TIME ZONE 'Australia/Brisbane')::TEXT AS created_at_aest
      FROM client_registry
      ORDER BY business_name ASC" \
  > "$OUT_DIR/04_client_register.csv"

ROWS=$(tail -n +2 "$OUT_DIR/04_client_register.csv" | wc -l | tr -d ' ')
info "04_client_register.csv  ($ROWS rows — $(grep -c ',true,' "$OUT_DIR/04_client_register.csv" 2>/dev/null || echo '?') active)"

# ── 5. Staff register ────────────────────────────────────────────────────────
heading "05 — Staff register"

DC exec -T willow-db psql \
  -U "${POSTGRES_USER:-willow}" \
  -d "${POSTGRES_DB:-willow}" \
  --csv -q \
  -c "SELECT
        user_id,
        name,
        role,
        email,
        approval_limit,
        timezone,
        active,
        (created_at AT TIME ZONE 'Australia/Brisbane')::TEXT AS created_at_aest
      FROM staff_registry
      ORDER BY name ASC" \
  > "$OUT_DIR/05_staff_register.csv"

info "05_staff_register.csv  ($(tail -n +2 "$OUT_DIR/05_staff_register.csv" | wc -l | tr -d ' ') rows)"

# ── 6. n8n workflow definitions ──────────────────────────────────────────────
heading "06 — n8n workflow definitions"

N8N_CONTAINER=$(DC ps -q n8n 2>/dev/null || true)
if [[ -n "$N8N_CONTAINER" ]]; then
  docker exec "$N8N_CONTAINER" \
    n8n export:workflow --all --output=/tmp/all-workflows.json 2>/dev/null \
    && docker cp "$N8N_CONTAINER:/tmp/all-workflows.json" \
        "$OUT_DIR/06_n8n_workflows.json" \
    && info "06_n8n_workflows.json  (exported from running n8n)" \
    || warn "Could not export from n8n — copying source files instead"
else
  warn "n8n not running — copying workflow source files"
fi

# Always include the source workflow files as a fallback
cp -r "$REPO_ROOT/n8n/workflows" "$OUT_DIR/06_n8n_workflow_sources"
info "06_n8n_workflow_sources/  (source JSON files)"

# ── 7. Credentials notice ────────────────────────────────────────────────────
heading "07 — Credentials notice"

ENCRYPTION_KEY="${N8N_ENCRYPTION_KEY:-NOT_FOUND}"

cat > "$OUT_DIR/07_credentials_notice.txt" << NOTICE
WILLOW — CREDENTIAL HANDOVER NOTICE
Generated: $(date '+%d %B %Y %H:%M AEST')
================================================================================

YOUR N8N ENCRYPTION KEY
-----------------------
n8n stores all OAuth credentials (Xero, Gmail, Outlook) encrypted at rest
using this key. You must keep it to retain access to your credentials.

  N8N_ENCRYPTION_KEY: ${ENCRYPTION_KEY}

  Store this in a password manager immediately.

YOUR ACTIVE CREDENTIALS
-----------------------
The following third-party connections were configured in Willow:

  • Xero OAuth2     — connected as: ${XERO_CLIENT_ID:-not configured}
  • Gmail OAuth2    — inbox: ${FIRM_GMAIL_ADDRESS:-not configured}
  • Outlook OAuth2  — inbox: ${FIRM_OUTLOOK_ADDRESS:-not configured}
  • Cloudflare      — tunnel: ${CLOUDFLARE_TUNNEL_TOKEN:0:8}... (production)

WHAT TO DO AFTER OFFBOARDING
-----------------------------
Option A — Shut Willow down completely:
  1. Run: docker compose down -v   (from docker/ directory)
  2. Revoke Xero app access: developer.xero.com → My Apps → Revoke
  3. Revoke Gmail access: myaccount.google.com → Security → Third-party apps
  4. Archive the export files (this directory) for your 5-year ATO obligation
  5. Store 01_full_database.sql.gz offsite (encrypted)

Option B — Continue running Willow independently:
  1. Keep docker/.env and the N8N_ENCRYPTION_KEY above
  2. Willow is fully self-contained — no EDS licence or connection required
  3. For support, the codebase is in the repo you already have

WHAT EDS RETAINS
----------------
  • Nothing. Willow is self-hosted. EDS has never had access to your data,
    credentials, client list, or audit trail.
  • EDS retains the software IP (the code, workflows, and architecture).
  • You retain all firm data and the right to run the software indefinitely
    under the terms of your service agreement.

ATO RECORD-KEEPING REMINDER
----------------------------
Under s262A ITAA 1997, you must retain tax records for 5 years.
The files 02_audit_log.csv and 03_invoice_records.csv in this export,
combined with your Xero records, satisfy that requirement.
Store them alongside your Xero exports offsite.
================================================================================
NOTICE

info "07_credentials_notice.txt"

# ── Manifest ─────────────────────────────────────────────────────────────────
heading "Generating manifest"

cd "$OUT_DIR"
find . -type f ! -name "MANIFEST.sha256" -exec sha256sum {} \; \
  | sort > MANIFEST.sha256

info "MANIFEST.sha256  ($(wc -l < MANIFEST.sha256) files)"

# ── README ───────────────────────────────────────────────────────────────────

cat > "$OUT_DIR/00_README.txt" << README
WILLOW OFFBOARDING PACKAGE
Generated: $(date '+%d %B %Y %H:%M AEST')
================================================================================

This package contains everything the firm needs to retain after disengaging
from the Willow AI bookkeeping system.

FILES IN THIS PACKAGE
---------------------
  00_README.txt               This file
  01_full_database.sql.gz     Complete database backup — all firm data
  02_audit_log.csv            Every action Willow took (ATO audit trail)
  03_invoice_records.csv      Every invoice processed + Xero bill IDs
  04_client_register.csv      Your full client list with ABNs
  05_staff_register.csv       Staff members and their roles
  06_n8n_workflows.json       Workflow definitions (if n8n was running)
  06_n8n_workflow_sources/    Source workflow JSON files
  07_credentials_notice.txt   Your encryption key + what to do next
  MANIFEST.sha256             Integrity check — run: sha256sum -c MANIFEST.sha256

WHAT THIS IS NOT
----------------
  • This is NOT a replacement for Xero. Financial records live in Xero.
  • This is NOT tax advice. Consult your registered tax agent.
  • Willow does not lodge BAS. BAS is lodged through Xero or your agent.

INTEGRITY VERIFICATION
----------------------
  sha256sum -c MANIFEST.sha256

ATO RETENTION REQUIREMENTS
---------------------------
  Retain 02_audit_log.csv and 03_invoice_records.csv for 5 years
  from the date each transaction was lodged (s262A ITAA 1997).
  Store this package offsite alongside your Xero exports.

================================================================================
README

info "00_README.txt"

# ── Summary ───────────────────────────────────────────────────────────────────
echo ""
echo "  ${BOLD}${GREEN}Offboarding package complete.${RESET}"
echo ""
echo "  Location: ${BOLD}$OUT_DIR${RESET}"
echo "  Size:     $(du -sh "$OUT_DIR" | cut -f1)"
echo ""
echo "  ${BOLD}Next steps:${RESET}"
echo "  1. Read $OUT_DIR/07_credentials_notice.txt"
echo "  2. Store 01_full_database.sql.gz offsite (encrypted)"
echo "  3. Archive the full directory for 5 years (ATO obligation)"
echo ""
echo "  ${YELLOW}This script did not delete or modify any Willow data.${RESET}"
echo "  ${YELLOW}Shutdown is a separate step — see 07_credentials_notice.txt.${RESET}"
echo ""
