#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo "== Willow preflight build check =="

echo "[1/6] Python syntax check"
python -m compileall backend/app voice/app >/dev/null

echo "[2/6] n8n workflow JSON + connection check"
python - <<'PY'
import json
from pathlib import Path
roots = [Path('n8n/workflows'), Path('n8n/workflows-product')]
files = []
for r in roots:
    if r.exists():
        files += list(r.glob('*.json'))
if not files:
    print('No workflow json files found')
for f in files:
    data = json.loads(f.read_text())
    names = {n.get('name') for n in data.get('nodes', [])}
    missing = []
    for src, outputs in data.get('connections', {}).items():
        if src not in names:
            missing.append(f'connection source missing: {src}')
        for group in outputs.get('main', []) if isinstance(outputs, dict) else []:
            for edge in group:
                if edge.get('node') not in names:
                    missing.append(f"{src} -> missing target: {edge.get('node')}")
    if missing:
        raise SystemExit(f'{f}: ' + '; '.join(missing))
    print(f'OK {f}')
PY

echo "[3/6] Frontend dependency/build check"
cd frontend
npm ci --legacy-peer-deps
npm run type-check
npm run build
cd "$ROOT"

echo "[4/6] Dashboard dependency smoke check"
python -m pip install -q -r dashboard/requirements.txt
python -m py_compile dashboard/app.py

echo "[5/6] Docker compose config check"
if command -v docker >/dev/null 2>&1; then
  cp -n docker/.env.example docker/.env || true
  docker compose -f docker/docker-compose.yml --env-file docker/.env config >/dev/null
else
  echo "docker not found; skipping compose config"
fi

echo "[6/6] Done"
echo "Preflight passed."
