#!/bin/bash
# =============================================================================
# WILLOW AI — First Boot Setup
# Runs once via systemd on the first boot after ISO installation.
# =============================================================================
# This script:
#   1. Runs the interactive Willow installer (./install.sh)
#   2. Pulls Ollama models
#   3. Starts the stack
#   4. Marks first boot as complete so it never runs again
# =============================================================================
set -euo pipefail

LOG=/var/log/willow-firstboot.log
exec > >(tee -a "$LOG") 2>&1

WILLOW_DIR=/opt/willow

echo "========================================================="
echo "  Willow AI — First Boot  $(date)"
echo "========================================================="
echo ""

# ── Wait for Docker ──────────────────────────────────────────────────────────
echo "Waiting for Docker..."
for i in $(seq 1 30); do
  docker info &>/dev/null && break
  sleep 2
done
docker info &>/dev/null || { echo "Docker not ready after 60s — aborting"; exit 1; }

# ── Wait for network ─────────────────────────────────────────────────────────
echo "Waiting for internet..."
for i in $(seq 1 15); do
  curl -sf https://archive.ubuntu.com &>/dev/null && break
  sleep 4
done

# ── Run installer ────────────────────────────────────────────────────────────
echo ""
echo "Starting Willow installer..."
echo "(This is interactive — answer the prompts on the console)"
echo ""

cd "$WILLOW_DIR"
bash install.sh

# ── Pull Ollama models ───────────────────────────────────────────────────────
# shellcheck disable=SC1091
set -a; source docker/.env 2>/dev/null; set +a

if [[ -n "${OLLAMA_MODEL:-}" ]]; then
  echo ""
  echo "Pulling Ollama model: $OLLAMA_MODEL"
  ollama pull "$OLLAMA_MODEL" || echo "Warning: model pull failed — run 'make models' later"
fi
if [[ -n "${OLLAMA_EMBED_MODEL:-}" ]]; then
  echo "Pulling embedding model: $OLLAMA_EMBED_MODEL"
  ollama pull "$OLLAMA_EMBED_MODEL" || echo "Warning: embed model pull failed — run 'make models' later"
fi

# ── Mark complete ────────────────────────────────────────────────────────────
touch "$WILLOW_DIR/.firstboot-complete"

echo ""
echo "========================================================="
echo "  Willow first-boot setup complete."
echo "  Log saved to: $LOG"
echo ""
echo "  Open WebUI → http://localhost:3000"
echo "  n8n        → http://localhost:5678"
echo "========================================================="
