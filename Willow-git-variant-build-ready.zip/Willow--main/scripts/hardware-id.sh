#!/usr/bin/env bash
# =============================================================================
# WILLOW — Hardware Fingerprint
# Generates a stable 16-character hex ID for license binding.
# Combines DMI product UUID + first physical MAC address + SHA256 truncated.
#
# Usage:
#   bash scripts/hardware-id.sh           # prints fingerprint only
#   bash scripts/hardware-id.sh --full    # prints full details + purchase info
# =============================================================================

FULL="${1:-}"

# DMI UUID — stable across OS reinstalls on the same physical hardware
UUID=""
UUID=$(cat /sys/class/dmi/id/product_uuid 2>/dev/null | tr '[:upper:]' '[:lower:]' | tr -d '[:space:]') \
  || UUID=$(dmidecode -s system-uuid 2>/dev/null | tr '[:upper:]' '[:lower:]') \
  || UUID=$(cat /etc/machine-id 2>/dev/null) \
  || UUID="no-dmi-uuid"

# First physical (non-loopback) MAC address
MAC=$(ip link show 2>/dev/null | awk '/ether/ {print $2; exit}' | tr -d ':') \
  || MAC="000000000000"

# 16-character fingerprint (SHA256 of UUID:MAC, truncated to 64 bits)
FINGERPRINT=$(printf '%s:%s' "${UUID}" "${MAC}" | sha256sum | cut -c1-16)

if [[ "${FULL}" == "--full" ]]; then
  BOLD=$'\e[1m'; CYAN=$'\e[36m'; RESET=$'\e[0m'
  echo ""
  echo -e "${BOLD}  Willow Hardware Fingerprint${RESET}"
  echo "  ─────────────────────────────────────────"
  echo "  DMI UUID : ${UUID}"
  echo "  MAC addr : ${MAC}"
  echo ""
  echo -e "  ${BOLD}${CYAN}Hardware ID : ${FINGERPRINT}${RESET}"
  echo ""
  echo "  Provide this ID when purchasing a Willow license:"
  echo "  sales@engineereddatasystems.com.au"
  echo ""
else
  echo "${FINGERPRINT}"
fi
