#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="${ROOT_DIR}/docker/.env"
if [[ -f "${ENV_FILE}" ]]; then
  set -a
  # shellcheck disable=SC1090
  source "${ENV_FILE}"
  set +a
fi

API_BASE="${WILLOW_API_BASE:-http://localhost:8080/api/v1/product}"
KEY="${WILLOW_API_KEY:-change-me-local-dev}"

hdr=(-H "Content-Type: application/json" -H "X-Willow-API-Key: ${KEY}")

echo "== Willow product health =="
curl -fsS "${API_BASE}/health" -H "X-Willow-API-Key: ${KEY}" | python3 -m json.tool

echo "== Willow email triage =="
curl -fsS -X POST "${API_BASE}/email/triage" "${hdr[@]}" -d '{
  "message_id":"smoke-email-001",
  "from":"supplier@example.com",
  "subject":"Invoice attached for testing",
  "snippet":"Please see attached invoice for $121.00 including GST.",
  "body":"Please see attached invoice for $121.00 including GST.",
  "attachments":[{"filename":"test-invoice.pdf","mime_type":"application/pdf"}]
}' | tee /tmp/willow_triage.json | python3 -m json.tool

echo "== Grace extract =="
curl -fsS -X POST "${API_BASE}/grace/extract" "${hdr[@]}" -d '{
  "source_id":"smoke-email-001",
  "filename":"test-invoice.pdf",
  "mime_type":"application/pdf",
  "sender":"supplier@example.com",
  "email_subject":"Invoice attached for testing",
  "text":"Tax Invoice INV-1001 Supplier Pty Ltd Amount $121.00 GST $11.00 Due 2026-05-15"
}' | tee /tmp/willow_grace.json | python3 -m json.tool

DOC_ID="$(python3 - <<'PY'
import json
try:
    print(json.load(open('/tmp/willow_grace.json')).get('document_id',''))
except Exception:
    print('')
PY
)"
EXTRACTION="$(python3 - <<'PY'
import json
try:
    print(json.dumps(json.load(open('/tmp/willow_grace.json')).get('extraction',{})))
except Exception:
    print('{}')
PY
)"

echo "== Hayley reconcile =="
python3 - <<PY | curl -fsS -X POST "${API_BASE}/hayley/reconcile" "${hdr[@]}" -d @- | python3 -m json.tool
import json
payload = {
  "source_id": "smoke-email-001",
  "document_id": "${DOC_ID}",
  "invoice": json.loads('''${EXTRACTION}'''),
  "transactions": [{"id":"txn-1","description":"Supplier Pty Ltd","amount":121.00,"date":"2026-05-01"}]
}
print(json.dumps(payload))
PY

echo "Smoke test complete."
