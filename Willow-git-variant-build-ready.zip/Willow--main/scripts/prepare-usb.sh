#!/usr/bin/env bash
# =============================================================================
# WILLOW AI — USB / Portable Mode Preparation
# Engineered Data Systems
# =============================================================================
# Creates the directory structure Willow needs on a USB drive (or any
# external path) and migrates any existing Docker named-volume data there.
#
# Usage:
#   ./scripts/prepare-usb.sh /mnt/willow-usb
#
# What it does:
#   1. Validates the target path is writable
#   2. Creates the eleven data subdirectories
#   3. Optionally migrates existing Docker named-volume data
#   4. Updates docker/.env to set WILLOW_DATA_ROOT
#   5. Prints next steps
# =============================================================================
set -euo pipefail

# ---------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
ENV_FILE="$REPO_ROOT/docker/.env"

RED=$'\e[31m'; GREEN=$'\e[32m'; YELLOW=$'\e[33m'; CYAN=$'\e[36m'; BOLD=$'\e[1m'; RESET=$'\e[0m'

info()    { echo "  ${GREEN}✓${RESET}  $*"; }
warn()    { echo "  ${YELLOW}⚠${RESET}  $*"; }
error()   { echo "  ${RED}✗${RESET}  $*" >&2; }
heading() { echo ""; echo "${BOLD}${CYAN}$*${RESET}"; echo ""; }

# ---------------------------------------------------------------------------
TARGET_PATH="${1:-}"

if [[ -z "$TARGET_PATH" ]]; then
  echo ""
  echo "${BOLD}Usage:${RESET}  $0 <target-path>"
  echo ""
  echo "  <target-path>   Directory on the USB drive (or any external path)"
  echo "                  where Willow data should live."
  echo ""
  echo "  Examples:"
  echo "    $0 /mnt/willow-usb"
  echo "    $0 /media/usb/willow"
  echo "    $0 /mnt/user/willow-data   # Unraid NAS share"
  echo ""
  exit 1
fi

# ---------------------------------------------------------------------------
heading "Willow USB / Portable Mode Setup"

# ── Step 1: Validate target ──────────────────────────────────────────────────
echo "  Target path: ${BOLD}$TARGET_PATH${RESET}"
echo ""

if [[ ! -d "$TARGET_PATH" ]]; then
  echo "  Path does not exist yet. Creating it..."
  mkdir -p "$TARGET_PATH" || {
    error "Could not create $TARGET_PATH — check permissions or mount the drive first."
    exit 1
  }
  info "Created $TARGET_PATH"
fi

if [[ ! -w "$TARGET_PATH" ]]; then
  error "$TARGET_PATH is not writable. Check permissions."
  exit 1
fi

# ── Step 2: Check USB speed (rough heuristic) ────────────────────────────────
DEVICE=$(df "$TARGET_PATH" | tail -1 | awk '{print $1}')
if [[ "$DEVICE" == /dev/sd* ]]; then
  # Try to detect USB 2.0 (480 Mbps bus speed) vs USB 3.x
  SPEED=$(lsusb -t 2>/dev/null | grep -i "480M" | head -1 || true)
  if [[ -n "$SPEED" ]]; then
    warn "USB 2.0 detected (480 Mbit/s). Willow will work but may be slow."
    warn "PostgreSQL requires sustained random I/O. USB 3.x / USB-C NVMe enclosure strongly recommended."
    echo ""
  fi
fi

# ── Step 3: Create data directories ─────────────────────────────────────────
heading "Creating data directories"

DIRS=(
  "postgres"
  "n8n"
  "mem0"
  "kanboard"
  "open-webui"
  "piper"
  "redis"
  "uploads"
  "voice/recordings"
  "voice/tts"
  "ollama"
)

for d in "${DIRS[@]}"; do
  DIR_PATH="$TARGET_PATH/$d"
  if [[ -d "$DIR_PATH" ]]; then
    info "$d  (already exists)"
  else
    mkdir -p "$DIR_PATH"
    info "$d"
  fi
done

# Fix permissions for postgres — must be owned by uid 999 (postgres in container)
chown -R 999:999 "$TARGET_PATH/postgres" 2>/dev/null \
  || warn "Could not chown $TARGET_PATH/postgres to uid 999 — you may need to run as root."

# ── Step 4: Optional data migration ─────────────────────────────────────────
heading "Migrate existing data from Docker named volumes?"

DOCKER_VOLUMES=(postgres_data n8n_data mem0_data kanboard_data open_webui_data piper_data redis_data uploads_data voice_recordings voice_tts ollama_models)
DIR_NAMES=(postgres n8n mem0 kanboard open-webui piper redis uploads voice/recordings voice/tts ollama)

ANY_EXISTING=false
for vol in "${DOCKER_VOLUMES[@]}"; do
  if docker volume inspect "$vol" &>/dev/null 2>&1; then
    ANY_EXISTING=true
    break
  fi
done

if [[ "$ANY_EXISTING" == true ]]; then
  echo "  Existing Docker named volumes detected:"
  for i in "${!DOCKER_VOLUMES[@]}"; do
    VOL="${DOCKER_VOLUMES[$i]}"
    if docker volume inspect "$VOL" &>/dev/null 2>&1; then
      echo "    • $VOL"
    fi
  done
  echo ""
  read -rp "  Copy data from Docker named volumes to $TARGET_PATH? [y/N]: " MIGRATE
  echo ""

  if [[ "${MIGRATE,,}" == "y" ]]; then
    echo "  Copying data (this may take a few minutes)..."
    for i in "${!DOCKER_VOLUMES[@]}"; do
      VOL="${DOCKER_VOLUMES[$i]}"
      DEST="${DIR_NAMES[$i]}"
      if docker volume inspect "$VOL" &>/dev/null 2>&1; then
        echo "    Copying $VOL → $TARGET_PATH/$DEST ..."
        docker run --rm \
          -v "${VOL}:/source:ro" \
          -v "${TARGET_PATH}/${DEST}:/dest" \
          alpine sh -c "cp -a /source/. /dest/" \
          && info "$VOL → $DEST" \
          || warn "Failed to copy $VOL — continuing"
      fi
    done
  else
    info "Skipped — starting fresh on USB (existing Docker volumes untouched)"
  fi
else
  info "No existing named volumes found — starting fresh on USB"
fi

# ── Step 5: Update docker/.env ───────────────────────────────────────────────
heading "Updating docker/.env"

DATA_ROOT="$TARGET_PATH"

if [[ -f "$ENV_FILE" ]]; then
  if grep -q "^WILLOW_DATA_ROOT=" "$ENV_FILE"; then
    # Update existing entry
    sed -i "s|^WILLOW_DATA_ROOT=.*|WILLOW_DATA_ROOT=$DATA_ROOT|" "$ENV_FILE"
    info "Updated WILLOW_DATA_ROOT in docker/.env"
  else
    # Append
    echo "" >> "$ENV_FILE"
    echo "# ---------------------------------------------------------------------------" >> "$ENV_FILE"
    echo "# USB / PORTABLE MODE" >> "$ENV_FILE"
    echo "# ---------------------------------------------------------------------------" >> "$ENV_FILE"
    echo "WILLOW_DATA_ROOT=$DATA_ROOT" >> "$ENV_FILE"
    info "Added WILLOW_DATA_ROOT to docker/.env"
  fi
else
  warn "docker/.env not found — run 'make install' first, then re-run this script."
  warn "Set WILLOW_DATA_ROOT=$DATA_ROOT manually in docker/.env afterwards."
fi

# ── Step 6: Next steps ───────────────────────────────────────────────────────
echo ""
echo "  ${BOLD}${GREEN}Setup complete.${RESET}"
echo ""
echo "  ${BOLD}Next steps:${RESET}"
echo ""
echo "    1.  Start Willow in portable mode (GPU + containerised Ollama):"
echo ""
echo "          make up-portable"
echo ""
echo "        Or standard USB mode (Ollama stays on host):"
echo ""
echo "          make up-usb"
echo ""
echo "    2.  Pull Ollama models into the container (portable mode only):"
echo ""
echo "          make models-portable"
echo ""
echo "    3.  On first run, migrate database schema:"
echo ""
echo "          make migrate"
echo ""
echo "    4.  To copy the repo to the USB drive as well:"
echo ""
echo "          rsync -av --exclude='audit-exports/' \\"
echo "            $(pwd)/ $TARGET_PATH/../repo/"
echo ""
echo "  ${BOLD}Performance notes:${RESET}"
echo "    • USB 3.x / USB-C NVMe enclosure:  good performance"
echo "    • USB 2.0 thumb drive:              works, but Postgres will be slow"
echo "    • Portable mode:  Ollama models stored on USB under ollama/"
echo "    • Standard mode:  Ollama stays on the host (USB ollama/ path ignored)"
echo ""
