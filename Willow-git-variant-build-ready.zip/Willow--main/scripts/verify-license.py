#!/usr/bin/env python3
"""
Willow License Verifier — offline Ed25519 cryptographic verification.
Called by verify-license.sh. Outputs a JSON blob to stdout.

Exit codes:
  0  full        — valid, >30 days remaining
  1  trial       — no licence, trial period active
  2  expiring    — valid, ≤30 days remaining
  3  readonly    — never-paid trial expired only
  4  invalid     — bad signature or wrong hardware
  5  expired     — paid licence lapsed; writes continue, updates paused
"""

import json
import sys
import os
import base64
import datetime
import subprocess
from pathlib import Path
import socket
import struct

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    from cryptography.exceptions import InvalidSignature
    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False

# ── Embedded public key ───────────────────────────────────────────────────────
# Raw 32-byte Ed25519 public key, base64-encoded.
# The matching private key is held offline by Engineered Data Systems.
# DO NOT commit the private key. This public key is safe to distribute.
WILLOW_PUBLIC_KEY_B64 = "eTseg3Uqy8qSeoRmH9iylTg2/urr2ILatEBMRiGvUnk="

# ── Paths ─────────────────────────────────────────────────────────────────────
WILLOW_DIR      = Path(os.getenv("WILLOW_DIR", "/opt/willow"))
LICENSE_FILE    = WILLOW_DIR / "license.key"
FIRST_BOOT_FILE = WILLOW_DIR / ".first-boot"
PAID_MARKER_FILE = WILLOW_DIR / ".paid-license-installed"
TRIAL_DAYS      = 30

LAST_VERIFIED_FILE = WILLOW_DIR / ".last-verified"

EXIT_CODES = {"full": 0, "trial": 1, "expiring": 2, "readonly": 3, "invalid": 4, "expired": 5}



# =============================================================================
# Clock Integrity — anti-rollback protection
# =============================================================================

def _ntp_offset_seconds() -> float | None:
    """
    Query NTP using raw UDP (no external library needed).
    Returns offset in seconds, or None if unreachable/offline.
    """
    ntp_servers = ["pool.ntp.org", "time.cloudflare.com", "time.apple.com"]
    for server in ntp_servers:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.settimeout(3)
            # NTP request packet
            packet = b"\x1b" + 47 * b"\x00"
            sock.sendto(packet, (server, 123))
            data, _ = sock.recvfrom(1024)
            sock.close()
            if len(data) >= 48:
                # Transmit timestamp is at bytes 40-47 (unsigned 64-bit, NTP epoch)
                t = struct.unpack("!I", data[40:44])[0]
                ntp_unix = t - 2_208_988_800  # NTP epoch → Unix epoch
                import time
                return abs(time.time() - ntp_unix)
        except Exception:
            continue
    return None


def check_clock_integrity() -> tuple:
    """
    Three-layer clock manipulation detection.
    Returns (ok: bool, reason: str).

    Layer 1 — monotonic last-verified file:
        Records the Unix timestamp of every successful check.
        If the current time is more than 26 hours behind the last stored
        value, the clock has been rolled back.

    Layer 2 — NTP soft-check (non-blocking):
        Queries public NTP servers.  If the system clock is more than 24
        hours off and internet is reachable, flag as manipulated.
        Skipped silently when offline.
    """
    import time
    now_ts = time.time()
    today_str = datetime.date.today().isoformat()

    # ── Layer 1: monotonic last-verified ────────────────────────────────────
    if LAST_VERIFIED_FILE.exists():
        try:
            stored_ts = float(LAST_VERIFIED_FILE.read_text().strip())
            # 26-hour window covers DST transitions + minor drift
            if now_ts < stored_ts - 93_600:
                stored_date = datetime.datetime.fromtimestamp(stored_ts).date().isoformat()
                return False, (
                    f"System clock integrity check failed. "
                    f"Last verified: {stored_date} — current system date: {today_str}. "
                    f"The clock appears to have been moved backward. "
                    f"Contact sales@engineereddatasystems.com.au if this is in error."
                )
        except Exception:
            pass  # Corrupt file — recreate below

    # Update the last-verified file (always, even if NTP fails)
    try:
        LAST_VERIFIED_FILE.parent.mkdir(parents=True, exist_ok=True)
        LAST_VERIFIED_FILE.write_text(str(now_ts))
    except Exception:
        pass

    # ── Layer 2: NTP soft-check ──────────────────────────────────────────────
    offset = _ntp_offset_seconds()
    if offset is not None and offset > 86_400:  # 24-hour tolerance
        return False, (
            f"System clock is {int(offset // 3600)} hours off from network time. "
            f"License verification requires an accurate system clock. "
            f"Run: sudo timedatectl set-ntp true"
        )

    return True, ""

def get_hardware_id() -> str:
    """Return stable hardware fingerprint (runs hardware-id.sh)."""
    script = WILLOW_DIR / "scripts" / "hardware-id.sh"
    if script.exists():
        try:
            result = subprocess.run(
                ["bash", str(script)],
                capture_output=True, text=True, timeout=10
            )
            hw_id = result.stdout.strip()
            if hw_id and len(hw_id) == 16:
                return hw_id
        except Exception:
            pass
    # Fallback: SHA256 of /etc/machine-id
    try:
        import hashlib
        machine_id = Path("/etc/machine-id").read_text().strip()
        return hashlib.sha256(machine_id.encode()).hexdigest()[:16]
    except Exception:
        return "unknown-hardware"


def trial_status() -> dict:
    """Compute trial status. Read-only is only for never-paid trial expiry."""
    today = datetime.date.today()
    previously_paid = PAID_MARKER_FILE.exists()

    if not FIRST_BOOT_FILE.exists():
        try:
            FIRST_BOOT_FILE.parent.mkdir(parents=True, exist_ok=True)
            FIRST_BOOT_FILE.write_text(today.isoformat())
        except Exception:
            pass
        first_boot = today
    else:
        try:
            first_boot = datetime.date.fromisoformat(FIRST_BOOT_FILE.read_text().strip())
        except Exception:
            first_boot = today

    days_used      = (today - first_boot).days
    days_remaining = max(0, TRIAL_DAYS - days_used)
    trial_expires  = first_boot + datetime.timedelta(days=TRIAL_DAYS)

    if days_remaining > 0:
        return {
            "mode": "trial",
            "firm": "Unlicensed",
            "tier": "trial",
            "seats": 999,
            "expires": trial_expires.isoformat(),
            "days_remaining": days_remaining,
            "readonly": False,
            "writes_allowed": True,
            "updates_enabled": False,
            "paid_license_installed": previously_paid,
            "support_active": False,
            "support_plan": None,
            "support_expires": None,
            "message": (
                f"Trial mode — {days_remaining} of {TRIAL_DAYS} days remaining. "
                "Install a paid licence to unlock perpetual fallback."
            ),
        }

    if previously_paid:
        return {
            "mode": "expired",
            "firm": "Previously Licensed",
            "tier": "unknown",
            "seats": 0,
            "expires": trial_expires.isoformat(),
            "days_remaining": 0,
            "readonly": False,
            "writes_allowed": True,
            "updates_enabled": False,
            "paid_license_installed": True,
            "support_active": False,
            "support_plan": None,
            "support_expires": None,
            "message": (
                "Paid licence previously installed. Willow continues operating; "
                "updates and new premium features are paused until renewal."
            ),
        }

    return {
        "mode": "readonly",
        "firm": "Trial Expired",
        "tier": "expired",
        "seats": 0,
        "expires": trial_expires.isoformat(),
        "days_remaining": 0,
        "readonly": True,
        "writes_allowed": False,
        "updates_enabled": False,
        "paid_license_installed": False,
        "support_active": False,
        "support_plan": None,
        "support_expires": None,
        "message": (
            "Trial period has ended. Willow is read-only because no paid licence has ever been installed. "
            "Existing data remains accessible. Install a paid licence to continue processing."
        ),
    }


def mark_paid_license_installed() -> None:
    try:
        PAID_MARKER_FILE.parent.mkdir(parents=True, exist_ok=True)
        if not PAID_MARKER_FILE.exists():
            PAID_MARKER_FILE.write_text(datetime.date.today().isoformat())
    except Exception:
        pass


def support_state(data: dict, today: datetime.date) -> dict:
    support_plan = data.get("support_plan") or data.get("support") or None
    support_expires_str = data.get("support_expires") or data.get("support_until") or None
    support_active = False
    if support_expires_str:
        try:
            support_active = datetime.date.fromisoformat(str(support_expires_str)) >= today
        except Exception:
            support_active = False
    else:
        support_expires_str = None
    return {
        "support_active": bool(support_active),
        "support_plan": support_plan if support_active else None,
        "support_expires": support_expires_str,
    }


def invalid_or_fallback(reason: str, firm: str = "Invalid", tier: str = "invalid", seats: int = 0, expires: str = "") -> dict:
    """Invalid keys do not create a customer lockout.

    If a paid licence was previously installed, continue under perpetual
    fallback. If not, ignore the bad key and apply normal trial rules.
    A never-paid expired trial is still read-only.
    """
    if PAID_MARKER_FILE.exists():
        return {
            "mode": "expired",
            "firm": firm,
            "tier": tier,
            "seats": seats,
            "expires": expires,
            "days_remaining": 0,
            "readonly": False,
            "writes_allowed": True,
            "updates_enabled": False,
            "paid_license_installed": True,
            "support_active": False,
            "support_plan": None,
            "support_expires": None,
            "message": f"Licence needs attention: {reason} Willow continues operating under perpetual fallback; updates are paused.",
        }

    state = trial_status()
    state["message"] = f"Licence file ignored: {reason} " + state.get("message", "")
    return state

def parse_license_file(content: str):
    """Return (payload_bytes, sig_bytes) from license file content."""
    lines = [l.strip() for l in content.strip().splitlines() if l.strip()]
    if len(lines) < 3 or lines[0] != "WILLOW_LICENSE_V1":
        raise ValueError("Not a Willow license file (expected WILLOW_LICENSE_V1 header)")
    payload_bytes = base64.b64decode(lines[1])
    sig_bytes     = base64.b64decode(lines[2])
    return payload_bytes, sig_bytes


def verify() -> dict:
    """Full verification: signature → hardware binding → expiry."""

    # ── Clock integrity check (runs before any license logic) ─────────────
    clock_ok, clock_reason = check_clock_integrity()
    # Clock warnings should not dead-man-lock a paid customer. They are reported
    # in logs by callers but do not alter licence state.
    _clock_warning = clock_reason if not clock_ok else ""

    # No license file → trial
    if not LICENSE_FILE.exists():
        return trial_status()

    # Read license file
    try:
        content = LICENSE_FILE.read_text().strip()
    except Exception as e:
        return {**trial_status(), "message": f"Cannot read license.key: {e}"}

    # Parse
    try:
        payload_bytes, sig_bytes = parse_license_file(content)
    except Exception as e:
        return invalid_or_fallback(f"License file is malformed: {e}")

    # Crypto library check
    if not CRYPTO_AVAILABLE:
        return {
            "mode": "trial", "firm": "Unlicensed", "tier": "trial",
            "seats": 999, "expires": "", "days_remaining": TRIAL_DAYS,
            "message": "python3-cryptography not installed — running in trial mode. "
                       "Run: sudo apt-get install python3-cryptography",
        }

    # Verify Ed25519 signature
    try:
        pub_raw = base64.b64decode(WILLOW_PUBLIC_KEY_B64)
        pub_key = Ed25519PublicKey.from_public_bytes(pub_raw)
        pub_key.verify(sig_bytes, payload_bytes)
    except InvalidSignature:
        return invalid_or_fallback("License signature is invalid. The file may be corrupted or tampered.")
    except Exception as e:
        return invalid_or_fallback(f"Signature verification error: {e}")

    # Parse payload JSON
    try:
        data = json.loads(payload_bytes.decode())
    except Exception:
        return invalid_or_fallback("License payload is not valid JSON.")

    firm  = data.get("firm",  "Unknown")
    tier  = data.get("tier",  "unknown")
    seats = data.get("seats", 0)

    # Hardware binding
    expected_hw = data.get("hardware_id", "")
    if expected_hw and expected_hw != "any":
        actual_hw = get_hardware_id()
        if actual_hw != expected_hw:
            return invalid_or_fallback(
                f"License is bound to hardware {expected_hw} — this machine reports {actual_hw}.",
                firm=firm, tier=tier, seats=seats, expires=data.get("expires", "")
            )

    # Expiry
    today = datetime.date.today()
    try:
        expires = datetime.date.fromisoformat(data["expires"])
    except Exception:
        expires = today

    days_remaining = (expires - today).days

    support = support_state(data, today)
    mark_paid_license_installed()

    if days_remaining < 0:
        return {
            "mode": "expired",
            "firm": firm,
            "tier": tier,
            "seats": seats,
            "expires": data["expires"],
            "days_remaining": 0,
            "readonly": False,
            "writes_allowed": True,
            "updates_enabled": False,
            "paid_license_installed": True,
            **support,
            "message": (
                f"Paid licence expired {abs(days_remaining)} days ago. "
                "Perpetual fallback is active: writes and daily operations continue. "
                "Updates, new premium features and non-included support are paused until renewal."
            ),
        }

    mode = "expiring" if days_remaining <= 30 else "full"

    return {
        "mode": mode,
        "firm": firm,
        "tier": tier,
        "seats": seats,
        "expires": data["expires"],
        "days_remaining": days_remaining,
        "readonly": False,
        "writes_allowed": True,
        "updates_enabled": True,
        "paid_license_installed": True,
        **support,
        "message": f"Licensed to {firm} — {tier.title()} tier — {days_remaining} days remaining.",
    }


if __name__ == "__main__":
    result = verify()
    print(json.dumps(result))
    sys.exit(EXIT_CODES.get(result["mode"], 4))
