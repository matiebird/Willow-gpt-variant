#!/usr/bin/env bash
# =============================================================================
# WILLOW AI — Audit Export Package Generator
# Engineered Data Systems
# =============================================================================
# Produces a self-contained, dated ZIP of every record relevant to an ATO
# or other regulatory review covering a specified date range.
#
# Usage:
#   ./scripts/export-audit-package.sh                      # current FY to today
#   ./scripts/export-audit-package.sh 2025-07-01 2026-06-30  # specific FY
#   ./scripts/export-audit-package.sh 2024-01-01 2024-12-31  # calendar year
#
# Output:
#   audit-exports/willow-audit-YYYYMMDD-HHMMSS.zip
#   (directory also left on disk for inspection)
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="$SCRIPT_DIR/docker/.env"
COMPOSE_FILE="$SCRIPT_DIR/docker/docker-compose.yml"

# ── Colours ───────────────────────────────────────────────────────────────────
GRN='\033[0;32m'; YLW='\033[0;33m'; CYN='\033[0;36m'; WHT='\033[1;37m'; NC='\033[0m'
info()    { echo -e "${CYN}  ➜${NC}  $*"; }
success() { echo -e "${GRN}  ✓${NC}  $*"; }
warn()    { echo -e "${YLW}  ⚠${NC}  $*"; }
die()     { echo -e "\033[0;31m  ✗${NC}  $*" >&2; exit 1; }

# ── Australian financial year helpers ─────────────────────────────────────────
current_fy_start() {
  local month year
  month=$(date +%-m)
  year=$(date +%Y)
  if [[ $month -ge 7 ]]; then
    echo "${year}-07-01"
  else
    echo "$((year - 1))-07-01"
  fi
}

# ── Parse arguments ───────────────────────────────────────────────────────────
DATE_FROM="${1:-$(current_fy_start)}"
DATE_TO="${2:-$(date +%Y-%m-%d)}"

# Validate dates
date -d "$DATE_FROM" &>/dev/null 2>&1 || date -j -f "%Y-%m-%d" "$DATE_FROM" >/dev/null 2>&1 \
  || die "Invalid DATE_FROM: $DATE_FROM  (use YYYY-MM-DD)"
date -d "$DATE_TO"   &>/dev/null 2>&1 || date -j -f "%Y-%m-%d" "$DATE_TO"   >/dev/null 2>&1 \
  || die "Invalid DATE_TO: $DATE_TO  (use YYYY-MM-DD)"

# ── Setup ─────────────────────────────────────────────────────────────────────
[[ -f "$ENV_FILE" ]] || die "docker/.env not found. Run 'make install' first."

set -a; source "$ENV_FILE"; set +a

TIMESTAMP="$(date +%Y%m%d-%H%M%S)"
EXPORT_DIR="$SCRIPT_DIR/audit-exports/willow-audit-${TIMESTAMP}"
ZIP_FILE="${EXPORT_DIR}.zip"

mkdir -p "$EXPORT_DIR"

dc() {
  if docker compose version &>/dev/null 2>&1; then
    docker compose -f "$COMPOSE_FILE" --env-file "$ENV_FILE" "$@"
  else
    docker-compose -f "$COMPOSE_FILE" --env-file "$ENV_FILE" "$@"
  fi
}

psql_csv() {
  # Run a SQL query and write output as CSV
  local outfile="$1"; shift
  dc exec -T willow-db psql -U willow -d willow \
    --csv -t -c "$*" > "$EXPORT_DIR/$outfile"
}

echo
echo -e "  ${WHT}Willow Audit Package Generator${NC}"
echo -e "  Period: ${CYN}${DATE_FROM}${NC} → ${CYN}${DATE_TO}${NC}"
echo -e "  Output: ${CYN}${ZIP_FILE}${NC}"
echo

# ── 1. Full audit log ─────────────────────────────────────────────────────────
info "Exporting audit log..."
dc exec -T willow-db psql -U willow -d willow --csv -c "
SELECT
  id,
  timestamp AT TIME ZONE 'Australia/Brisbane'     AS timestamp_aest,
  staff_user_id,
  staff_name,
  action,
  agent,
  client_id,
  result,
  details,
  error_message
FROM audit_log
WHERE timestamp BETWEEN '${DATE_FROM}' AND '${DATE_TO} 23:59:59'
ORDER BY timestamp ASC
" > "$EXPORT_DIR/01_audit_log.csv"
success "01_audit_log.csv"

# ── 2. Invoice fingerprints (processed invoices) ──────────────────────────────
info "Exporting invoice records..."
dc exec -T willow-db psql -U willow -d willow --csv -c "
SELECT
  f.sha256_hash,
  f.processed_at AT TIME ZONE 'Australia/Brisbane'  AS processed_at_aest,
  cr.business_name                                   AS client,
  cr.abn                                             AS client_abn,
  f.supplier_name,
  f.invoice_number,
  f.amount,
  f.gst_amount,
  f.xero_bill_id,
  f.source_type,
  sr.name                                            AS processed_by,
  f.status
FROM invoice_fingerprints f
LEFT JOIN client_registry  cr ON f.client_id  = cr.client_id
LEFT JOIN staff_registry   sr ON f.processed_by = sr.user_id
WHERE f.processed_at BETWEEN '${DATE_FROM}' AND '${DATE_TO} 23:59:59'
ORDER BY f.processed_at ASC
" > "$EXPORT_DIR/02_invoice_records.csv"
success "02_invoice_records.csv"

# ── 3. Client register ────────────────────────────────────────────────────────
info "Exporting client register..."
dc exec -T willow-db psql -U willow -d willow --csv -c "
SELECT
  client_id,
  business_name,
  abn,
  xero_org_name,
  xero_tenant_id,
  contact_email,
  bas_frequency,
  payroll_frequency,
  assigned_staff,
  active,
  created_at AT TIME ZONE 'Australia/Brisbane'  AS created_at_aest
FROM client_registry
ORDER BY business_name ASC
" > "$EXPORT_DIR/03_client_register.csv"
success "03_client_register.csv"

# ── 4. Staff access register ──────────────────────────────────────────────────
info "Exporting staff access register..."
dc exec -T willow-db psql -U willow -d willow --csv -c "
SELECT
  user_id,
  name,
  role,
  email,
  approval_limit,
  active,
  created_at AT TIME ZONE 'Australia/Brisbane'   AS created_at_aest,
  updated_at AT TIME ZONE 'Australia/Brisbane'   AS updated_at_aest
FROM staff_registry
ORDER BY name ASC
" > "$EXPORT_DIR/04_staff_access_register.csv"
success "04_staff_access_register.csv"

# ── 5. Follow-up communications ───────────────────────────────────────────────
info "Exporting follow-up communication records..."
dc exec -T willow-db psql -U willow -d willow --csv -c "
SELECT
  fs.id,
  cr.business_name                                     AS client,
  cr.abn                                               AS client_abn,
  cr.contact_email                                     AS client_email,
  sr.name                                              AS assigned_staff,
  fs.subject,
  fs.cadence_days,
  fs.current_step,
  fs.status,
  fs.created_at AT TIME ZONE 'Australia/Brisbane'     AS created_at_aest,
  fs.last_action_at AT TIME ZONE 'Australia/Brisbane' AS last_action_aest,
  fs.next_action_at AT TIME ZONE 'Australia/Brisbane' AS next_action_aest
FROM follow_up_sequences fs
LEFT JOIN client_registry cr ON fs.client_id    = cr.client_id
LEFT JOIN staff_registry  sr ON fs.assigned_staff = sr.user_id
WHERE fs.created_at BETWEEN '${DATE_FROM}' AND '${DATE_TO} 23:59:59'
ORDER BY fs.created_at ASC
" > "$EXPORT_DIR/05_follow_up_communications.csv"
success "05_follow_up_communications.csv"

# ── 6. Actions by client (summary) ───────────────────────────────────────────
info "Building per-client action summary..."
dc exec -T willow-db psql -U willow -d willow --csv -c "
SELECT
  cr.business_name                            AS client,
  cr.abn,
  al.action,
  al.agent,
  COUNT(*)                                    AS action_count,
  MIN(al.timestamp)::DATE                     AS first_occurrence,
  MAX(al.timestamp)::DATE                     AS last_occurrence,
  SUM(CASE WHEN al.result = 'success'          THEN 1 ELSE 0 END) AS successes,
  SUM(CASE WHEN al.result = 'failed'           THEN 1 ELSE 0 END) AS failures,
  SUM(CASE WHEN al.result = 'pending_approval' THEN 1 ELSE 0 END) AS pending_approval
FROM audit_log al
LEFT JOIN client_registry cr ON al.client_id = cr.client_id
WHERE al.timestamp BETWEEN '${DATE_FROM}' AND '${DATE_TO} 23:59:59'
GROUP BY cr.business_name, cr.abn, al.action, al.agent
ORDER BY cr.business_name ASC, al.action ASC
" > "$EXPORT_DIR/06_client_activity_summary.csv"
success "06_client_activity_summary.csv"

# ── 7. Invoice value summary (for cross-checking with Xero GST reports) ───────
info "Building invoice value summary..."
dc exec -T willow-db psql -U willow -d willow --csv -c "
SELECT
  cr.business_name                     AS client,
  cr.abn,
  DATE_TRUNC('month', f.processed_at)::DATE AS month,
  COUNT(*)                             AS invoice_count,
  SUM(f.amount)                        AS total_ex_gst,
  SUM(f.gst_amount)                    AS total_gst,
  SUM(f.amount + COALESCE(f.gst_amount, 0)) AS total_inc_gst
FROM invoice_fingerprints f
LEFT JOIN client_registry cr ON f.client_id = cr.client_id
WHERE f.processed_at BETWEEN '${DATE_FROM}' AND '${DATE_TO} 23:59:59'
  AND f.status != 'rejected'
GROUP BY cr.business_name, cr.abn, DATE_TRUNC('month', f.processed_at)
ORDER BY cr.business_name ASC, month ASC
" > "$EXPORT_DIR/07_invoice_value_summary.csv"
success "07_invoice_value_summary.csv"

# ── 8. Package metadata / README ──────────────────────────────────────────────
info "Writing audit manifest..."

ROW_COUNT_AUDIT=$(dc exec -T willow-db psql -U willow -d willow -t -c \
  "SELECT COUNT(*) FROM audit_log WHERE timestamp BETWEEN '${DATE_FROM}' AND '${DATE_TO} 23:59:59'" \
  | tr -d ' ')
ROW_COUNT_INVOICES=$(dc exec -T willow-db psql -U willow -d willow -t -c \
  "SELECT COUNT(*) FROM invoice_fingerprints WHERE processed_at BETWEEN '${DATE_FROM}' AND '${DATE_TO} 23:59:59'" \
  | tr -d ' ')

cat > "$EXPORT_DIR/00_README.txt" << READMEEOF
================================================================================
WILLOW AI — AUDIT PACKAGE
Engineered Data Systems
================================================================================

Generated:      $(date -u '+%Y-%m-%d %H:%M:%S UTC') / $(date '+%Y-%m-%d %H:%M:%S %Z')
Period:         ${DATE_FROM} to ${DATE_TO} (AEST timestamps throughout)
System:         Willow AI v1.1 — Local AI Bookkeeping Appliance
System host:    ${UNRAID_LAN_IP:-[not set]}

AUDIT LOG RECORDS:  ${ROW_COUNT_AUDIT}
INVOICE RECORDS:    ${ROW_COUNT_INVOICES}

--------------------------------------------------------------------------------
ABOUT THIS SYSTEM
--------------------------------------------------------------------------------
Willow is a self-hosted AI processing appliance used to automate bookkeeping
tasks for an Australian professional services firm. It processes supplier
invoices, triages emails, and generates client follow-up communications.

Willow is a PROCESSING LAYER — it does not store financial ledger data.
The authoritative financial records (bills, bank reconciliation, GST reports,
BAS history) are held in Xero for each client entity.

This audit package documents HOW financial records were created and by whom.

PRIMARY FINANCIAL RECORDS (request separately from Xero):
  - Supplier bills and purchase invoices
  - GST/BAS reports per quarter
  - Bank reconciliation
  - P&L and balance sheet

--------------------------------------------------------------------------------
FILES IN THIS PACKAGE
--------------------------------------------------------------------------------
01_audit_log.csv
  Every action taken by Willow during the period. Columns:
  - id, timestamp_aest, staff_user_id, staff_name
  - action (e.g. invoice_processed, email_classified, client_onboarded)
  - agent (willow_manager | grace | hayley | email_triage | workflow)
  - client_id, result (success | failed | pending_approval | escalated)
  - details (JSON — contains invoice amounts, email metadata, etc.)
  This is the primary tamper-evident action trail.

02_invoice_records.csv
  Every supplier invoice processed during the period. Columns:
  - sha256_hash — cryptographic fingerprint of the original document
  - processed_at_aest — when Willow processed this invoice
  - client, client_abn — which firm's books this was processed into
  - supplier_name, invoice_number, amount (ex-GST), gst_amount
  - xero_bill_id — the corresponding DRAFT bill ID in Xero
  - source_type — how the invoice arrived (email_attachment, voice_dictation, etc.)
  - processed_by, status
  Cross-reference: match xero_bill_id against Xero bill records to verify
  all processed invoices appear as bills in Xero.

03_client_register.csv
  All clients on the system. Includes ABN, Xero organisation ID, assigned
  staff member, and BAS/payroll frequency.

04_staff_access_register.csv
  All staff who had access during the period. Includes role, approval limit
  (the dollar threshold below which staff could auto-submit to Xero without
  additional review), and active status.

05_follow_up_communications.csv
  Automated client follow-up sequences initiated during the period. Shows
  client contacted, subject, sequence step reached, and last action date.
  This documents the communication trail for outstanding invoices.

06_client_activity_summary.csv
  Aggregated count of all actions per client, by action type and agent.
  Useful for a high-level overview of activity volume per entity.

07_invoice_value_summary.csv
  Monthly invoice totals per client — total ex-GST, total GST, total inc-GST.
  Cross-reference against Xero GST reports to verify completeness.

--------------------------------------------------------------------------------
DATA INTEGRITY
--------------------------------------------------------------------------------
- The audit_log table is append-only. UPDATE and DELETE operations are blocked
  by database triggers (see database/migrations/002_audit_hardening.sql).
- Each invoice has a SHA256 hash of the original document, stored before
  any processing occurs. This hash can be used to verify the original invoice
  was not modified after receipt.
- All Willow-created Xero bills are initially DRAFT status. Authorisation
  to AUTHORISED status requires separate explicit staff approval in Xero.
  This means no financial commitment is made without a human decision.
- All timestamps are stored in UTC and converted to AEST (UTC+10) in exports.

--------------------------------------------------------------------------------
RECORD RETENTION
--------------------------------------------------------------------------------
These records are retained for a minimum of 5 years from the end of the
relevant financial year, in accordance with s262A of the Income Tax
Assessment Act 1997 and s 36-35 of the A New Tax System (GST) Act 1999.

--------------------------------------------------------------------------------
SYSTEM OPERATOR CONTACT
--------------------------------------------------------------------------------
Entity:   Engineered Data Systems
System:   Willow AI v1.1
================================================================================
READMEEOF

success "00_README.txt"

# ── 9. Row counts and hash manifest ──────────────────────────────────────────
info "Generating file manifest with row counts..."
{
  echo "filename,rows,size_bytes,sha256"
  for f in "$EXPORT_DIR"/*.csv "$EXPORT_DIR"/*.txt; do
    [[ -f "$f" ]] || continue
    ROWS=$(wc -l < "$f" || echo "?")
    SIZE=$(wc -c < "$f" || echo "?")
    HASH=$(sha256sum "$f" 2>/dev/null | cut -d' ' -f1 \
          || shasum -a 256 "$f" 2>/dev/null | cut -d' ' -f1 \
          || echo "unavailable")
    echo "$(basename "$f"),$ROWS,$SIZE,$HASH"
  done
} > "$EXPORT_DIR/MANIFEST.csv"
success "MANIFEST.csv"

# ── 10. Create ZIP ────────────────────────────────────────────────────────────
info "Creating ZIP archive..."
if command -v zip &>/dev/null; then
  (cd "$(dirname "$EXPORT_DIR")" && zip -rq "$(basename "$ZIP_FILE")" "$(basename "$EXPORT_DIR")")
  success "$(basename "$ZIP_FILE")  ($(du -sh "$ZIP_FILE" | cut -f1))"
else
  tar -czf "${ZIP_FILE%.zip}.tar.gz" -C "$(dirname "$EXPORT_DIR")" "$(basename "$EXPORT_DIR")"
  ZIP_FILE="${ZIP_FILE%.zip}.tar.gz"
  success "$(basename "$ZIP_FILE")  ($(du -sh "$ZIP_FILE" | cut -f1))"
fi

# ── Done ──────────────────────────────────────────────────────────────────────
echo
echo -e "  ${GRN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "  ${GRN}  ✓  Audit package ready${NC}"
echo -e "  ${GRN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo
echo -e "  Archive:  ${CYN}${ZIP_FILE}${NC}"
echo -e "  Contents: ${CYN}${EXPORT_DIR}/${NC}"
echo
echo -e "  ${WHT}What to do next:${NC}"
echo -e "  1. Export Xero reports (P&L, GST, BAS history) for the same period"
echo -e "  2. Match 02_invoice_records.csv xero_bill_id against Xero bills"
echo -e "  3. Keep original emails in Gmail/Outlook archive for source documents"
echo -e "  4. Retain this ZIP for minimum 5 years (ATO record-keeping requirement)"
echo
