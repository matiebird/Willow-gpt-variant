#!/usr/bin/env bash
# =============================================================================
# WILLOW — License Verification
# Runs offline Ed25519 cryptographic verification + hardware binding + expiry.
#
# Called by:
#   • willow-autostart.service  (every boot, before stack start)
#   • willow-first-run.sh       (first boot setup)
#   • Makefile (license-check, up-auto, up targets)
#
# Writes:  docker/.license.env   (read by docker compose for WILLOW_MODE)
# Exports: WILLOW_MODE  WILLOW_FIRM  WILLOW_TIER  WILLOW_SEATS
#          WILLOW_EXPIRES  WILLOW_DAYS_REMAINING
# =============================================================================
set -euo pipefail

WILLOW_DIR="${WILLOW_DIR:-/opt/willow}"
LICENSE_ENV="${WILLOW_DIR}/docker/.license.env"

CYAN=$'\e[36m'; GREEN=$'\e[32m'; YELLOW=$'\e[33m'; RED=$'\e[31m'
BOLD=$'\e[1m'; RESET=$'\e[0m'

# ── Run Python verifier ───────────────────────────────────────────────────────
VERIFY_JSON=$(python3 "${WILLOW_DIR}/scripts/verify-license.py" 2>/dev/null) || \
VERIFY_JSON='{"mode":"trial","firm":"Unlicensed","tier":"trial","seats":999,"expires":"","days_remaining":30,"message":"Verification unavailable — trial mode"}'

# ── Parse JSON fields ─────────────────────────────────────────────────────────
_field() {
  echo "${VERIFY_JSON}" \
    | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('$1',''))" 2>/dev/null \
    || echo ""
}

WILLOW_MODE=$(_field mode)
WILLOW_FIRM=$(_field firm)
WILLOW_TIER=$(_field tier)
WILLOW_SEATS=$(_field seats)
WILLOW_EXPIRES=$(_field expires)
WILLOW_DAYS_REMAINING=$(_field days_remaining)
WILLOW_SUPPORT_ACTIVE=$(_field support_active)
WILLOW_SUPPORT_PLAN=$(_field support_plan)
WILLOW_SUPPORT_EXPIRES=$(_field support_expires)
LICENSE_MSG=$(_field message)

# Default to trial if parsing failed
WILLOW_MODE="${WILLOW_MODE:-trial}"

# ── Write docker/.license.env ─────────────────────────────────────────────────
mkdir -p "$(dirname "${LICENSE_ENV}")"
cat > "${LICENSE_ENV}" << ENVEOF
WILLOW_MODE=${WILLOW_MODE}
WILLOW_FIRM=${WILLOW_FIRM}
WILLOW_TIER=${WILLOW_TIER}
WILLOW_SEATS=${WILLOW_SEATS}
WILLOW_EXPIRES=${WILLOW_EXPIRES}
WILLOW_DAYS_REMAINING=${WILLOW_DAYS_REMAINING}
WILLOW_SUPPORT_ACTIVE=${WILLOW_SUPPORT_ACTIVE}
WILLOW_SUPPORT_PLAN=${WILLOW_SUPPORT_PLAN}
WILLOW_SUPPORT_EXPIRES=${WILLOW_SUPPORT_EXPIRES}
ENVEOF

# ── Export for calling shell ──────────────────────────────────────────────────
export WILLOW_MODE WILLOW_FIRM WILLOW_TIER WILLOW_SEATS WILLOW_EXPIRES WILLOW_DAYS_REMAINING WILLOW_SUPPORT_ACTIVE WILLOW_SUPPORT_PLAN WILLOW_SUPPORT_EXPIRES

# ── Display status ────────────────────────────────────────────────────────────
echo ""
case "${WILLOW_MODE}" in
  full)
    echo -e "  ${GREEN}✓${RESET}  ${BOLD}Licensed${RESET} — ${WILLOW_FIRM} · ${WILLOW_TIER^} tier · ${WILLOW_DAYS_REMAINING} days remaining"
    ;;
  expiring)
    echo -e "  ${YELLOW}⚠${RESET}  ${BOLD}License expiring in ${WILLOW_DAYS_REMAINING} days${RESET} — ${WILLOW_FIRM}"
    echo -e "     Renew at ${CYAN}sales@engineereddatasystems.com.au${RESET}"
    ;;
  trial)
    echo -e "  ${CYAN}➜${RESET}  ${BOLD}Trial mode${RESET} — ${WILLOW_DAYS_REMAINING} days remaining"
    echo -e "     Contact ${CYAN}sales@engineereddatasystems.com.au${RESET} to license Willow"
    ;;
  expired)
    echo -e "  ${YELLOW}⚠${RESET}  ${BOLD}Paid licence expired — perpetual fallback active${RESET}"
    echo -e "     Willow continues operating. Writes are allowed; updates are paused."
    echo -e "     Renew updates/support at ${CYAN}sales@engineereddatasystems.com.au${RESET}"
    ;;
  readonly)
    echo -e "  ${RED}✗${RESET}  ${BOLD}${RED}Trial expired — READ-ONLY MODE active${RESET}"
    echo -e "     Existing data is safe. This state only applies when no paid licence has ever been installed."
    echo -e "     Install a paid licence from ${CYAN}sales@engineereddatasystems.com.au${RESET}"
    ;;
  invalid)
    echo -e "  ${RED}✗${RESET}  ${BOLD}${RED}Invalid license${RESET}"
    echo -e "     ${LICENSE_MSG}"
    echo -e "     Contact ${CYAN}sales@engineereddatasystems.com.au${RESET}"
    ;;
  *)
    echo -e "  ${YELLOW}⚠${RESET}  Unknown license state: ${WILLOW_MODE} — defaulting to trial"
    WILLOW_MODE=trial
    ;;
esac
echo ""

# Exit code reflects mode (used by callers that want to branch on license state)
exit_map() {
  case "$1" in
    full)     echo 0 ;;
    trial)    echo 1 ;;
    expiring) echo 2 ;;
    readonly) echo 3 ;;
    invalid)  echo 4 ;;
    expired)  echo 5 ;;
    *)        echo 1 ;;
  esac
}

exit "$(exit_map "${WILLOW_MODE}")" 2>/dev/null || true
