#!/usr/bin/env bash
# =============================================================================
# WILLOW AI — GPU Auto-Detection
# Engineered Data Systems
# =============================================================================
# Detects the best available GPU and reports the correct Willow portable-mode
# stack to use.  Works with NVIDIA (CUDA), AMD (ROCm), Intel (Arc/Xe/SYCL),
# and falls back to CPU-only mode.
#
# Usage:
#   ./scripts/detect-gpu.sh              # Detect and print a full report
#   ./scripts/detect-gpu.sh --quiet      # Print GPU type only: nvidia|amd|intel|cpu
#   ./scripts/detect-gpu.sh --env        # Write GPU_TYPE= line to docker/.env.gpu
#   ./scripts/detect-gpu.sh --start      # Detect + start the right portable stack
#
# Exit codes:
#   0  success
#   1  error (Docker not running, missing tool, etc.)
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
ENV_FILE="$REPO_ROOT/docker/.env"
GPU_ENV_FILE="$REPO_ROOT/docker/.env.gpu"

RED=$'\e[31m'; GREEN=$'\e[32m'; YELLOW=$'\e[33m'
CYAN=$'\e[36m'; BOLD=$'\e[1m'; DIM=$'\e[2m'; RESET=$'\e[0m'

ok()      { echo "  ${GREEN}✓${RESET}  $*"; }
warn()    { echo "  ${YELLOW}⚠${RESET}  $*"; }
info()    { echo "  ${CYAN}➜${RESET}  $*"; }
heading() { echo ""; echo "${BOLD}${CYAN}$*${RESET}"; echo ""; }

MODE="${1:-}"

# =============================================================================
# Detection
# =============================================================================

GPU_TYPE=""
GPU_NAME=""
GPU_VRAM=""
GPU_COUNT=0
RECOMMENDED_MODEL=""
RECOMMENDED_EMBED=""
RECOMMENDED_WHISPER=""
COMPOSE_TARGET=""

# NPU state (detected separately — can coexist with GPU)
NPU_TYPE=""
NPU_NAME=""
NPU_WHISPER_HINT=""

# ── NVIDIA ───────────────────────────────────────────────────────────────────
detect_nvidia() {
  if ! command -v nvidia-smi &>/dev/null; then return 1; fi
  if ! nvidia-smi --query-gpu=name --format=csv,noheader &>/dev/null 2>&1; then return 1; fi

  GPU_TYPE="nvidia"
  GPU_NAME="$(nvidia-smi --query-gpu=name --format=csv,noheader | head -1 | xargs)"
  GPU_VRAM="$(nvidia-smi --query-gpu=memory.total --format=csv,noheader | head -1 | xargs)"
  GPU_COUNT="$(nvidia-smi --query-gpu=name --format=csv,noheader | wc -l | xargs)"

  # Parse VRAM MiB → choose model
  local vram_mib
  vram_mib="$(nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits | head -1 | xargs)"

  # ── DGX Spark / Blackwell ────────────────────────────────────────────────────
  # Grace Blackwell (GB10) uses NVLink-C2C unified memory — check name first,
  # then fall back to pool size ≥ 80 000 MiB as the discriminator.
  if echo "$GPU_NAME" | grep -qiE "blackwell|gb10|gb20|b100|b200|dgx spark|dgx-spark"; then
    GPU_TYPE="dgx-spark"
    RECOMMENDED_MODEL="qwen2.5:72b-instruct-q4_K_M"
    RECOMMENDED_WHISPER="large-v3"
    RECOMMENDED_EMBED="nomic-embed-text"
    COMPOSE_TARGET="up-dgx-spark"
    return 0
  fi
  # Fallback: ≥ 80 GB reported VRAM is characteristic of DGX / HGX class hardware
  if [[ "$vram_mib" -ge 80000 ]]; then
    GPU_TYPE="dgx-spark"
    RECOMMENDED_MODEL="qwen2.5:72b-instruct-q4_K_M"
    RECOMMENDED_WHISPER="large-v3"
    RECOMMENDED_EMBED="nomic-embed-text"
    COMPOSE_TARGET="up-dgx-spark"
    return 0
  fi

  if   [[ "$vram_mib" -ge 20000 ]]; then
    RECOMMENDED_MODEL="qwen2.5:14b-instruct-q4_K_M"
    RECOMMENDED_WHISPER="large-v3"
  elif [[ "$vram_mib" -ge 10000 ]]; then
    RECOMMENDED_MODEL="qwen2.5:7b-instruct-q4_K_M"
    RECOMMENDED_WHISPER="medium"
  elif [[ "$vram_mib" -ge 6000 ]]; then
    RECOMMENDED_MODEL="qwen2.5:7b-instruct-q4_K_M"
    RECOMMENDED_WHISPER="small"
  else
    RECOMMENDED_MODEL="qwen2.5:3b-instruct-q4_K_M"
    RECOMMENDED_WHISPER="tiny"
  fi
  RECOMMENDED_EMBED="nomic-embed-text"
  COMPOSE_TARGET="up-portable"
  return 0
}

# ── AMD ROCm ─────────────────────────────────────────────────────────────────
detect_amd() {
  # Check for ROCm device or rocm-smi
  if [[ ! -e /dev/kfd ]] && ! command -v rocm-smi &>/dev/null; then return 1; fi
  # Confirm at least one GPU shows in lspci
  if ! lspci 2>/dev/null | grep -qi "amd\|radeon\|vega\|navi\|polaris\|gfx"; then return 1; fi

  GPU_TYPE="amd"
  if command -v rocm-smi &>/dev/null; then
    GPU_NAME="$(rocm-smi --showproductname 2>/dev/null \
      | grep -oP '(?<=Card series:\s{0,10})\S.*' | head -1 || true)"
  fi
  [[ -z "$GPU_NAME" ]] && \
    GPU_NAME="$(lspci 2>/dev/null | grep -i "amd\|radeon\|vega\|navi" | head -1 | sed 's/.*: //' || echo "AMD GPU")"

  if command -v rocm-smi &>/dev/null; then
    GPU_VRAM="$(rocm-smi --showmeminfo vram 2>/dev/null \
      | grep -oP '\d+ bytes' | head -1 \
      | awk '{printf "%.0f MiB", $1/1048576}' || echo "unknown")"
  fi
  GPU_COUNT=1

  # AMD VRAM detection less reliable — default to 7b safe model
  RECOMMENDED_MODEL="qwen2.5:7b-instruct-q4_K_M"
  RECOMMENDED_EMBED="nomic-embed-text"
  RECOMMENDED_WHISPER="medium"
  COMPOSE_TARGET="up-portable-amd"
  return 0
}

# ── Intel Arc / Xe ───────────────────────────────────────────────────────────
detect_intel() {
  # Need at least a DRI render node
  if [[ ! -e /dev/dri/renderD128 ]]; then return 1; fi
  # Must be Intel discrete Arc or Xe (not just integrated UHD)
  if ! lspci 2>/dev/null | grep -qi "intel.*arc\|intel.*xe\|intel.*a770\|intel.*a750\|intel.*a380"; then
    # Integrated Intel — not worth GPU inference, fall through to CPU
    return 1
  fi

  GPU_TYPE="intel"
  GPU_NAME="$(lspci 2>/dev/null | grep -i "intel.*arc\|intel.*xe\|intel.*a770\|intel.*a750\|intel.*a380" \
    | head -1 | sed 's/.*: //' || echo "Intel Arc GPU")"
  GPU_VRAM="see lspci"   # Intel doesn't expose VRAM via standard tools easily
  GPU_COUNT=1

  RECOMMENDED_MODEL="qwen2.5:7b-instruct-q4_K_M"
  RECOMMENDED_EMBED="nomic-embed-text"
  RECOMMENDED_WHISPER="small"   # Intel SYCL whisper support is newer — be conservative
  COMPOSE_TARGET="up-portable-intel"
  return 0
}

# ── CPU fallback ─────────────────────────────────────────────────────────────
detect_cpu() {
  GPU_TYPE="cpu"
  GPU_NAME="$(grep 'model name' /proc/cpuinfo 2>/dev/null | head -1 | cut -d: -f2 | xargs || echo "Unknown CPU")"
  local cores
  cores="$(nproc 2>/dev/null || echo '?')"
  GPU_VRAM="${cores} cores"
  GPU_COUNT=0

  RECOMMENDED_MODEL="qwen2.5:7b-instruct-q4_K_M"
  RECOMMENDED_EMBED="nomic-embed-text"
  RECOMMENDED_WHISPER="tiny"   # CPU whisper is slow; keep it small
  COMPOSE_TARGET="up-portable-cpu"
}

# ── NPU detection (Intel Core Ultra / AMD Ryzen AI) ──────────────────────────
# NPU is detected independently — it can coexist with any GPU type.
# Current use: offload Whisper speech recognition, freeing the GPU for LLM.
detect_npu() {
  # Intel NPU — Core Ultra (Meteor Lake, Arrow Lake, Lunar Lake)
  # Kernel exposes it as /dev/accel/accel0 via the intel_vpu driver (kernel 6.3+)
  if ls /dev/accel/accel* &>/dev/null 2>&1; then
    if lspci 2>/dev/null | grep -qi "intel.*npu\|intel.*vpu\|intel.*image processing\|8086:7d1d\|8086:643e"; then
      NPU_TYPE="intel"
      NPU_NAME="$(lspci 2>/dev/null | grep -i "intel.*npu\|intel.*vpu\|8086:7d1d\|8086:643e"         | head -1 | sed 's/.*: //' || echo "Intel NPU")"
      NPU_WHISPER_HINT="openvino"
      return 0
    fi
    # /dev/accel exists but lspci didn't match Intel pattern — still report it
    NPU_TYPE="intel"
    NPU_NAME="Intel NPU (Core Ultra)"
    NPU_WHISPER_HINT="openvino"
    return 0
  fi

  # AMD Ryzen AI (XDNA / XDNA2) — Ryzen 7040, 8040, 9000 series
  # Kernel 6.8+ exposes AMD NPU under /sys/class/accel/ or via amdxdna driver
  if ls /sys/bus/platform/drivers/amdxdna/*/drm/accel* &>/dev/null 2>&1 ||      lsmod 2>/dev/null | grep -q "amdxdna"; then
    NPU_TYPE="amd"
    NPU_NAME="AMD Ryzen AI (XDNA)"
    NPU_WHISPER_HINT="onnxruntime"
    return 0
  fi

  # Check lspci for AMD signal processing controller (Ryzen AI on older kernels)
  if lspci 2>/dev/null | grep -qi "AMD.*signal processing\|AMD.*NPU"; then
    NPU_TYPE="amd"
    NPU_NAME="AMD Ryzen AI (XDNA)"
    NPU_WHISPER_HINT="onnxruntime"
    return 0
  fi

  return 1
}

# Run detectors in priority order
detect_nvidia || detect_amd || detect_intel || detect_cpu

# Run NPU detection (independent of GPU)
detect_npu || true   # non-fatal — most machines have no NPU

# =============================================================================
# --quiet mode: just print the type and exit
# =============================================================================
if [[ "$MODE" == "--quiet" ]]; then
  echo "$GPU_TYPE"
  exit 0
fi

# --quiet-npu: output NPU type only (none if not found)
if [[ "$MODE" == "--quiet-npu" ]]; then
  echo "${NPU_TYPE:-none}"
  exit 0
fi

# =============================================================================
# --env mode: write .env.gpu fragment
# =============================================================================
if [[ "$MODE" == "--env" ]]; then
  cat > "$GPU_ENV_FILE" << ENVEOF
# Auto-generated by scripts/detect-gpu.sh — do not edit manually
GPU_TYPE=${GPU_TYPE}
GPU_NAME=${GPU_NAME}
RECOMMENDED_MODEL=${RECOMMENDED_MODEL}
RECOMMENDED_EMBED=${RECOMMENDED_EMBED}
RECOMMENDED_WHISPER=${RECOMMENDED_WHISPER}
NPU_TYPE=${NPU_TYPE}
NPU_NAME=${NPU_NAME}
NPU_WHISPER_HINT=${NPU_WHISPER_HINT}
ENVEOF
  echo "  Written: $GPU_ENV_FILE"
  exit 0
fi

# =============================================================================
# Full report (default + --start mode)
# =============================================================================
heading "Willow — GPU Detection"

case "$GPU_TYPE" in
  dgx-spark)
    ok  "GPU type:    NVIDIA DGX Spark — Grace Blackwell Superchip (GB10)"
    ok  "GPU name:    $GPU_NAME"
    ok  "Memory:      $GPU_VRAM (unified NVLink-C2C — CPU + GPU share the pool)"
    info "Platform:    linux/arm64 (aarch64) — ARM Neoverse N2 cores"
    info "Capability:  72B parameter models + simultaneous embed loaded in memory"
    ;;
  nvidia)
    ok  "GPU type:    NVIDIA (CUDA)"
    ok  "GPU name:    $GPU_NAME"
    ok  "VRAM:        $GPU_VRAM"
    [[ "$GPU_COUNT" -gt 1 ]] && info "GPU count:   $GPU_COUNT (Willow uses first GPU)"
    ;;
  amd)
    ok  "GPU type:    AMD (ROCm)"
    ok  "GPU name:    $GPU_NAME"
    [[ -n "$GPU_VRAM" ]] && ok "VRAM:        $GPU_VRAM"
    warn "ROCm note:   If inference fails, set HSA_OVERRIDE_GFX_VERSION in docker/.env"
    ;;
  intel)
    ok  "GPU type:    Intel Arc / Xe (SYCL)"
    ok  "GPU name:    $GPU_NAME"
    warn "Intel note:  SYCL support requires intel-compute-runtime on host"
    warn "             Install: apt install intel-opencl-icd intel-level-zero-gpu"
    ;;
  cpu)
    warn "No GPU detected — CPU-only mode"
    ok  "CPU:         $GPU_NAME"
    warn "Performance: expect 1–5 tok/s. Whisper set to tiny for speed."
    ;;
esac

echo ""
info "Recommended model:         ${BOLD}$RECOMMENDED_MODEL${RESET}"
info "Recommended embed model:   ${BOLD}$RECOMMENDED_EMBED${RESET}"
info "Recommended Whisper model: ${BOLD}$RECOMMENDED_WHISPER${RESET}"
echo ""
ok  "Correct make target:  ${BOLD}make $COMPOSE_TARGET${RESET}"

# NPU report
if [[ -n "$NPU_TYPE" ]]; then
  echo ""
  echo "  ${BOLD}${CYAN}NPU Detected${RESET}"
  ok  "NPU:           $NPU_NAME"
  case "$NPU_TYPE" in
    intel)
      info "NPU use:       Whisper speech recognition (OpenVINO) — frees GPU for LLM"
      info "Enable with:   add docker-compose.portable-npu.yml to your compose stack"
      info "               Or: ${BOLD}make up-portable-npu${RESET} (GPU) / ${BOLD}make up-auto-npu${RESET} (auto-detect)"
      ;;
    amd)
      info "NPU use:       Whisper via ONNX Runtime (experimental)"
      info "               AMD XDNA driver support is kernel 6.8+ — check: lsmod | grep amdxdna"
      ;;
  esac
fi
echo ""

# =============================================================================
# --start mode: start the stack
# =============================================================================
if [[ "$MODE" == "--start" ]]; then
  heading "Starting Willow in $GPU_TYPE mode"

  # Validate .env and WILLOW_DATA_ROOT exist
  if [[ ! -f "$ENV_FILE" ]]; then
    echo "  ${RED}✗${RESET}  docker/.env not found. Run 'make install' first." >&2
    exit 1
  fi

  # DGX Spark uses local NVMe (named Docker volumes) — no USB / data-root required
  if [[ "$GPU_TYPE" == "dgx-spark" ]]; then
    info "DGX Spark mode — local NVMe storage, skipping USB check"
    if docker compose version &>/dev/null 2>&1; then DC_CMD="docker compose"; else DC_CMD="docker-compose"; fi
    $DC_CMD \
      -f "$REPO_ROOT/docker/docker-compose.yml" \
      -f "$REPO_ROOT/docker/docker-compose.dgx-spark.yml" \
      --env-file "$ENV_FILE" \
      up -d --remove-orphans
    echo ""
    ok  "Stack started in ${BOLD}DGX Spark (Blackwell)${RESET} mode."
    info "Pull 72B model suite:  make models-dgx-spark"
    echo ""
    exit 0
  fi

  DATA_ROOT="$(grep -E '^WILLOW_DATA_ROOT=' "$ENV_FILE" 2>/dev/null | cut -d= -f2 || true)"
  if [[ -z "$DATA_ROOT" ]]; then
    echo "  ${RED}✗${RESET}  WILLOW_DATA_ROOT not set in docker/.env." >&2
    echo "         Run: make prepare-portable TARGET=/mnt/willow-usb" >&2
    exit 1
  fi
  if [[ ! -d "$DATA_ROOT" ]]; then
    echo "  ${RED}✗${RESET}  WILLOW_DATA_ROOT=$DATA_ROOT does not exist. Mount the drive first." >&2
    exit 1
  fi

  # Detect docker compose v1 vs v2
  if docker compose version &>/dev/null 2>&1; then
    DC="docker compose"
  else
    DC="docker-compose"
  fi

  BASE_F="-f $REPO_ROOT/docker/docker-compose.yml"
  USB_F="-f $REPO_ROOT/docker/docker-compose.usb.yml"

  case "$GPU_TYPE" in
    nvidia) STACK_FILES="$BASE_F -f $REPO_ROOT/docker/docker-compose.portable.yml $USB_F" ;;
    amd)    STACK_FILES="$BASE_F -f $REPO_ROOT/docker/docker-compose.portable-amd.yml $USB_F" ;;
    intel)  STACK_FILES="$BASE_F -f $REPO_ROOT/docker/docker-compose.portable-intel.yml $USB_F" ;;
    cpu)    STACK_FILES="$BASE_F -f $REPO_ROOT/docker/docker-compose.portable.yml -f $REPO_ROOT/docker/docker-compose.portable-cpu.yml $USB_F" ;;
    # dgx-spark is handled above (exits early) — this branch is a safety net
    dgx-spark) STACK_FILES="$BASE_F -f $REPO_ROOT/docker/docker-compose.dgx-spark.yml" ;;
  esac

  info "Running: $DC $STACK_FILES --env-file $ENV_FILE up -d --remove-orphans"
  echo ""
  # shellcheck disable=SC2086
  $DC $STACK_FILES --env-file "$ENV_FILE" up -d --remove-orphans

  echo ""
  ok  "Stack started in ${BOLD}$GPU_TYPE${RESET} mode."
  IP="$(grep -E '^UNRAID_LAN_IP=' "$ENV_FILE" | cut -d= -f2 || echo localhost)"
  echo "  n8n       → http://${IP}:5678"
  echo "  Open WebUI → http://${IP}:3000"
  echo "  Kanboard  → http://${IP}:8081"
  echo ""
  info "First run? Pull models with:  make models-portable"
  echo ""
fi
