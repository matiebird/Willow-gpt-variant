# Willow AI — Ansible Deployment

## Quick Start

```bash
# 1. Install Ansible collections
ansible-galaxy collection install -r requirements.yml

# 2. Copy and fill in inventory
cp inventory.example.yml inventory.yml
# Edit inventory.yml — set your server IP and paths

# 3. Ensure docker/.env exists
cp ../docker/.env.example ../docker/.env
# Edit .env — fill in all secrets

# 4. Deploy (development — Unraid)
ansible-playbook -i inventory.yml deploy.yml --limit unraid

# 5. Deploy (production — DGX Spark)
ansible-playbook -i inventory.yml deploy.yml --limit dgx_spark
```

## Tags

| Tag | What it does |
|---|---|
| `install` | Install Docker, NVIDIA drivers, base packages |
| `deploy` | Sync files, pull images, start stack, import workflows |
| `migrate` | Run SQL migrations only |
| `models` | Pull Ollama models only |
| `verify` | Smoke-test all services |
| `workflows` | Import n8n workflows only |

## Upgrading to DGX Spark

The `inventory.yml` for `dgx_spark` sets:
```yaml
ollama_model: qwen2.5:72b-instruct
ollama_embed_model: mxbai-embed-large
```

No workflow changes are needed — the model upgrade is purely an Ollama
configuration change, exactly as designed in the spec.

```bash
ansible-playbook -i inventory.yml deploy.yml --limit dgx_spark --tags models
ansible-playbook -i inventory.yml deploy.yml --limit dgx_spark --tags deploy
```
