# Willow

**Your books. Your server. Your rules.**

Privacy-first AI bookkeeping appliance for professional services firms.
All financial data stays on your hardware. Zero cloud APIs. Zero telemetry.

---

## What Willow Does

Willow is a force multiplier for a bookkeeping firm. It handles the mechanical
work — reading documents, reconciling transactions, chasing clients, drafting
emails — so the team handles judgement calls.

| Capability | Detail |
|---|---|
| **Document intelligence** | Reads receipts, invoices, PDFs, voice notes. Extracts vendor, date, amount, GST, line items via local LLM. |
| **Reconciliation** | Validates extracted data against bank feed. SHA256 deduplication prevents double-submission. |
| **Xero integration** | Pushes reconciled entries as **draft bills only** — never publishes automatically. |
| **Email triage** | Monitors shared inbox, labels, routes to staff, drafts responses. Never auto-sends. |
| **Approval gate** | Every email above a staff member's approval limit stages in the dashboard before sending. |
| **Voice interface** | Staff dictate via M5Stack Echo or browser. Whisper transcribes locally. |
| **Memory** | Mem0 maintains per-client and firm-wide context across all sessions. |
| **Task management** | Kanboard tracks open items. Agents create and update tasks automatically. |
| **Audit trail** | Immutable PostgreSQL audit log with pgcrypto row hashing. Tamper-evident. |

---

## Deployment Modes

Willow runs in three modes. Pick the one that fits.

### Mode 1 — Unraid / Home Server (production)

Standard mode. Ollama runs on the host with full GPU access.
Everything else is Docker. This is the permanent installation.

```bash
git clone https://github.com/matiebird/Willow-.git && cd Willow-
make install        # interactive setup wizard
make up             # start the full stack
```

### Mode 2 — Portable USB-NVMe (testing / demo)

The entire stack including Ollama runs in Docker. No host modifications.
Plug into any PC, run, unplug — the machine is untouched.

```bash
make prepare-portable TARGET=/mnt/willow-usb   # set up USB directories
./install.sh --portable                         # configure + bring up stack
make up-auto                                    # auto-detects GPU, starts right stack
make models-portable                            # pull AI models into container
```

### Mode 3 — Willow OS (bootable image)

A full bootable Ubuntu 24.04 image. Boot from the USB-NVMe and Willow
starts automatically — no OS on the host required. Two variants are built
automatically by GitHub Actions on every push:

| ISO | Use case |
|-----|----------|
| **Desktop** `willow-os-<ver>-desktop.iso` | Boots to XFCE4 — Chromium opens Willow dashboard automatically. Firm apps pre-installed: LibreOffice, KeePassXC, Remmina, CUPS printing. |
| **Server** `willow-os-<ver>-server.iso` | Headless — no desktop. One server machine runs Willow; all staff open `http://willow.local` in Chrome, Edge, or Firefox from their own PCs. |

**Download the latest ISOs from [Releases](../../releases).**

Flash with [Rufus](https://rufus.ie) (Windows, DD mode) or
[Balena Etcher](https://etcher.balena.io) (macOS/Linux).
First boot runs setup automatically. See [`os/README.md`](os/README.md).

**Server mode — staff access URLs** (any browser, any PC on the same network):

| Service | URL |
|---------|-----|
| Willow dashboard | `http://willow.local:8080` |
| n8n workflow editor | `http://willow.local:5678` |
| Open WebUI chat | `http://willow.local:3000` |
| Kanboard tasks | `http://willow.local:8081` |

---

## Hardware Support

### GPU — LLM Inference (Ollama)

| GPU | Mode | Compose | Performance |
|---|---|---|---|
| **NVIDIA** RTX / GTX | `make up-auto` | `docker-compose.portable.yml` | ⚡ Best — CUDA |
| **AMD** RX 6000/7000 | `make up-auto` | `docker-compose.portable-amd.yml` | ✅ Good — ROCm 6.3 |
| **Intel Arc** A/B series | `make up-auto` | `docker-compose.portable-intel.yml` | ✅ Good — SYCL/Level Zero |
| **CPU only** | `make up-auto` | `docker-compose.portable-cpu.yml` | 🐢 Slow — 1–5 tok/s |

`make up-auto` calls `scripts/detect-gpu.sh` and picks the right stack automatically.

**Model recommendations by VRAM:**

| Memory Pool | LLM | Whisper |
|---|---|---|
| **128 GB unified** (DGX Spark — GB10 Blackwell) | `qwen2.5:72b-instruct-q4_K_M` | `large-v3` |
| ≥ 20 GB VRAM (RTX 4090 / RX 7900 XTX) | `qwen2.5:14b-instruct-q4_K_M` | `large-v3` |
| 10–20 GB VRAM (RTX 3080 / Arc A770) | `qwen2.5:7b-instruct-q4_K_M` | `medium` |
| 6–10 GB VRAM (RTX 2070 / Arc A750) | `qwen2.5:7b-instruct-q4_K_M` | `small` |
| CPU only | `qwen2.5:7b-instruct-q4_K_M` | `tiny` |

### NPU — Whisper Speech Recognition

Modern CPUs include a dedicated Neural Processing Unit (NPU) designed
for transformer models. Willow uses it to offload Whisper, freeing the
GPU entirely for LLM inference.

| NPU | Hardware | Support |
|---|---|---|
| **Intel NPU** | Core Ultra 100/200 (Meteor Lake, Arrow Lake, Lunar Lake) | ✅ OpenVINO via `/dev/accel/accel0` |
| **AMD Ryzen AI** | Ryzen 7040 / 8040 / 9000 (XDNA / XDNA2) | 🧪 Experimental — ONNX Runtime, kernel 6.8+ |

**Why this matters on an 8 GB GPU:**
Without the NPU overlay, Whisper and Ollama compete for VRAM.
With it, Ollama gets the full 8 GB and you can run `large-v3` Whisper
without touching GPU memory.

```bash
make up-auto-npu          # auto-detect GPU + add NPU Whisper overlay if NPU found
make up-portable-npu      # NVIDIA GPU + Intel NPU Whisper (explicit)
```

Add the overlay manually:
```bash
docker compose \
  -f docker/docker-compose.yml \
  -f docker/docker-compose.portable.yml \
  -f docker/docker-compose.portable-npu.yml \
  -f docker/docker-compose.usb.yml \
  --env-file docker/.env up -d
```

**Check if your CPU has an NPU:**
```bash
bash scripts/detect-gpu.sh      # full report including NPU
ls /dev/accel/                  # Intel NPU device node (kernel 6.3+)
lsmod | grep amdxdna            # AMD Ryzen AI driver (kernel 6.8+)
```

---

## Architecture

```
                    ┌──────────────────────────────────────────────┐
                    │             WILLOW STACK (Docker)            │
                    │                                              │
  Staff Browser ───►│  Nginx :8080                                │
                    │    ├── /          → Next.js 14 dashboard     │
                    │    └── /api/**    → FastAPI backend          │
                    │                                              │
  Voice device ────►│  faster-whisper :9000   (STT)               │
                    │  Piper          :5002   (TTS)               │
                    │                                              │
                    │  n8n :5678   (14 agent workflows)            │
                    │    ├── Willow Manager   (routing + memory)   │
                    │    ├── Grace           (document extraction) │
                    │    ├── Hayley          (reconciliation)      │
                    │    ├── Email Triage    (inbox management)    │
                    │    └── + 10 supporting workflows             │
                    │                                              │
                    │  PostgreSQL 16 + pgvector  (willow-db)       │
                    │  Redis       (Celery broker + cache)         │
                    │  Mem0        (persistent AI memory)          │
                    │  Kanboard    (task management)               │
                    │  Open WebUI  (alternative chat)             │
                    │                                              │
                    │  Ollama — LLM inference                      │
                    │    Unraid mode:   host GPU (direct)          │
                    │    Portable mode: willow-ollama container    │
                    │    NPU mode:      Whisper → NPU, LLM → GPU  │
                    │    DGX Spark:     72B model, 128 GB unified  │
                    └──────────────────────────────────────────────┘
                                          │
                                Cloudflare Tunnel
                                          │
                       Gmail webhooks · Xero callbacks · remote access
```

### Named Agents

| Agent | Role |
|---|---|
| **Willow** (Manager) | Conversational core. Routes requests, maintains context via Mem0, enforces approval limits. |
| **Grace** (Extraction) | Transforms receipts, photos, PDFs, voice notes → structured JSON. Computes SHA256 fingerprint. |
| **Hayley** (Reconciliation) | Validates Grace's JSON against bank feed. Deduplicates. Pushes draft bills to Xero — never publishes. |
| **Email Triage** | Monitors inbox, labels, routes, drafts responses. Human approval required before sending. |

---

## Repository Structure

```
Willow-/
├── docker/
│   ├── docker-compose.yml              # Base 15-service stack
│   ├── docker-compose.usb.yml          # USB/portable data overlay (all 11 volumes)
│   ├── docker-compose.portable.yml     # Containerised Ollama — NVIDIA GPU
│   ├── docker-compose.portable-cpu.yml # CPU-only (no GPU reservations)
│   ├── docker-compose.portable-amd.yml # AMD ROCm GPU
│   ├── docker-compose.portable-intel.yml  # Intel Arc / Xe SYCL
│   └── docker-compose.portable-npu.yml # Intel/AMD NPU Whisper overlay
├── scripts/
│   ├── detect-gpu.sh                   # Auto-detect GPU + NPU, recommend stack
│   ├── prepare-usb.sh                  # Create USB directory structure (11 dirs)
│   └── export-audit-package.sh         # ATO audit export
├── os/
│   ├── build.sh                        # Ubuntu 24.04 bootable ISO builder
│   ├── config/                         # systemd services, first-run script
│   └── README.md                       # Flash instructions
├── .github/workflows/
│   └── build-iso.yml                   # GitHub Actions — desktop + server ISOs in parallel → one Release
├── database/migrations/                # SQL migrations (000→003)
├── backend/                            # FastAPI REST API + Celery
├── frontend/                           # Next.js 14 dashboard
├── n8n/workflows/                      # 14 agent workflow JSON exports
├── ansible/                            # Unraid remote provisioning playbook
├── install.sh                          # Interactive installer (all modes)
└── Makefile                            # All operational targets
```

---

## Quick Reference — Make Targets

```
make install            First-time interactive setup
make up                 Start stack (Unraid/host Ollama mode)
make down               Stop stack
make status             Health check + Ollama model list
make logs               Follow all logs  (make logs s=n8n for one service)
make backup             Dump PostgreSQL to ./backups/
make migrate            Run pending SQL migrations

# Portable / USB-NVMe
make up-auto            Auto-detect GPU, start the right portable stack
make up-auto-npu        Same + add NPU Whisper overlay if NPU detected
make up-portable        NVIDIA GPU explicit
make up-portable-amd    AMD ROCm explicit
make up-portable-intel  Intel Arc explicit
make up-portable-cpu    CPU-only
make up-portable-npu    NVIDIA GPU + Intel NPU Whisper
make models-portable    Pull Ollama models into container (first run)
make prepare-portable   Set up USB drive: make prepare-portable TARGET=/mnt/usb

# DGX Spark (Grace Blackwell — no USB required)
make up-dgx-spark       Blackwell ARM64, 72B models, 128 GB unified memory
make models-dgx-spark   Pull 72B model suite into container (first run, ~41 GB)

# Detection
make detect-gpu         Show detected GPU/NPU + model recommendations

# Willow OS
# → See Releases tab for latest ISOs (desktop + server variants)
```

---

## Licensing

Willow uses offline Ed25519 cryptographic licensing. Each licence is bound to the hardware fingerprint of one server — no phone-home, no cloud activation dependency, and no dead-man switch.

### Perpetual fallback promise

Paid Willow customers keep operating even if their update/licence period lapses.

If a paid licence expires, Willow enters **expired mode**:

- writes continue
- email triage, receptionist workflows, tasks and approvals continue
- data remains accessible and exportable
- updates and new premium features pause until renewal
- optional support is available only while the Support SKU is active

Read-only mode is reserved for one case only: **the initial trial expired and no paid licence has ever been installed**.

### Trial Period

Willow runs in full trial mode for **30 days** from first boot with no licence applied. After expiry, a never-paid trial enters read-only mode. Existing data is preserved and accessible; new ingestion/writes are paused until a paid licence is installed.

### Pricing (AUD, annual)

| Tier | Staff capacity | Annual |
|---|---|---:|
| **Starter** | 1–3 staff | $3,600 |
| **Professional** | 4–10 staff | $7,200 |
| **Studio** | 11–25 staff | $13,200 |
| **Enterprise** | 25+ | Contact us |

Optional support add-on:

| Add-on | Price | Includes |
|---|---:|---|
| **Priority Support** | $99/month | response-SLA support tickets, guided upgrades, configuration help, scheduled remote support |

One licence covers one Willow OS server instance.

### Getting Your Hardware ID

```bash
make license-info
```

This prints a 16-character hardware fingerprint (SHA256 of DMI UUID + primary MAC). Send this to `sales@engineereddatasystems.com.au` when purchasing.

### Applying a Licence

Once you receive your `firm.key` licence file:

```bash
make license-apply FILE=/path/to/firm.key
```

The licence is validated offline and the stack is ready to start.

### Licence Modes

| Mode | Behaviour |
|---|---|
| `trial` | Full operation during initial 30-day evaluation |
| `readonly` | Trial expired and no paid licence was ever installed — data preserved, writes paused |
| `full` | Paid licence active — writes and updates enabled |
| `expiring` | Paid licence active, renewal due within 30 days |
| `expired` | Paid licence lapsed — writes continue, updates/support paused |
| `invalid` | Wrong hardware or bad signature — contact support for replacement |

Detailed policy: see [`docs/licensing.md`](docs/licensing.md).

Contact: `sales@engineereddatasystems.com.au`

---

## Security Model

| Control | Implementation |
|---|---|
| **Local-only inference** | Ollama on host or container — zero external API calls |
| **Xero** | Draft-only — no automatic publishing |
| **Email** | Human approval gate for all outbound — `willow-follow-up-executor` disabled until manually confirmed |
| **Audit log** | Immutable PostgreSQL rows with pgcrypto SHA256 hashing |
| **Approval limits** | Per-staff `approval_limit` field — amounts above limit route to dashboard |
| **Memory isolation** | Mem0 enforces strict personal vs. firm scopes |
| **Deduplication** | SHA256 fingerprint on every document — no double-Xero-submission |
| **DB constraints** | Journal balance enforced by PostgreSQL trigger (debits = credits) |
| **Soft deletes** | Financial records are never hard-deleted |

---

## First-Time Setup Checklist

After `make install` or first Willow OS boot, two steps require a browser:

1. **Xero OAuth2** — n8n → Credentials → New → Xero OAuth2 API
2. **Gmail OAuth2** — n8n → Credentials → New → Gmail OAuth2 API
3. Enable **willow-follow-up-executor** in n8n after confirming the Approvals dashboard is working

Everything else is automated by the installer.

---

*Engineered Data Systems · Queensland · v2.1*
