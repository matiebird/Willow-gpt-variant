-- =============================================================================
-- WILLOW AI — Migration 006: Policy RAG Knowledge Base
-- Adds: policies table, policy_chunks table (pgvector embeddings)
--
-- Embedding model: nomic-embed-text (768 dimensions, CPU, ~270MB)
-- Similarity: cosine distance via pgvector <=> operator
-- =============================================================================

-- pgvector already enabled in migration 001 — ensure it's present
CREATE EXTENSION IF NOT EXISTS vector;

-- ---------------------------------------------------------------------------
-- 1. POLICIES — Master policy document registry
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS policies (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    title           TEXT        NOT NULL,
    category        TEXT        NOT NULL CHECK (category IN (
                        'engagement',       -- Client onboarding & engagement rules
                        'disengagement',    -- Client offboarding rules
                        'xero',             -- Xero/accounting rules
                        'staff',            -- Staff procedures & HR
                        'compliance',       -- ATO, GST, legal compliance
                        'billing',          -- Fee structures & invoicing
                        'communication',    -- Client communication standards
                        'general'           -- Catch-all
                    )),
    original_filename   TEXT,
    raw_text            TEXT NOT NULL,      -- Full extracted text (searchable)
    version             INTEGER DEFAULT 1,
    active              BOOLEAN DEFAULT TRUE,
    created_by          TEXT REFERENCES staff_registry(user_id),
    created_at          TIMESTAMPTZ DEFAULT now(),
    updated_at          TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_policies_category ON policies(category) WHERE active = TRUE;
CREATE INDEX IF NOT EXISTS idx_policies_active    ON policies(active, created_at DESC);

-- Full-text search on raw_text (fallback to keyword search)
CREATE INDEX IF NOT EXISTS idx_policies_fts ON policies
    USING GIN (to_tsvector('english', title || ' ' || raw_text));

CREATE TRIGGER trg_policies_updated_at
    BEFORE UPDATE ON policies
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------------
-- 2. POLICY CHUNKS — Vectorised chunks for semantic retrieval
--    Each policy is split into ~400 word overlapping chunks.
--    nomic-embed-text produces 768-dimensional embeddings.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS policy_chunks (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    policy_id       UUID        NOT NULL REFERENCES policies(id) ON DELETE CASCADE,
    chunk_index     INTEGER     NOT NULL,       -- Order within parent document
    chunk_text      TEXT        NOT NULL,       -- The actual text chunk
    embedding       vector(768) NOT NULL,       -- nomic-embed-text vector
    created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_policy_chunks_policy  ON policy_chunks(policy_id);

-- IVFFlat index for fast approximate nearest-neighbour cosine search
-- lists=50 is appropriate for up to ~5000 chunks (1 list per 100 vectors)
CREATE INDEX IF NOT EXISTS idx_policy_chunks_embedding
    ON policy_chunks USING ivfflat (embedding vector_cosine_ops) WITH (lists = 50);

-- ---------------------------------------------------------------------------
-- 3. POLICY ACCESS LOG — Track which policies were surfaced and when
--    Used to tune retrieval quality over time.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS policy_access_log (
    id              BIGSERIAL   PRIMARY KEY,
    query_text      TEXT        NOT NULL,
    chunks_returned INTEGER     NOT NULL,
    policy_ids      JSONB       DEFAULT '[]'::jsonb,
    context         TEXT,       -- 'main_assistant' | 'receptionist' | 'api'
    staff_user_id   TEXT        REFERENCES staff_registry(user_id),
    accessed_at     TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_policy_access_log_date ON policy_access_log(accessed_at DESC);

-- ---------------------------------------------------------------------------
-- 4. Schema version
-- ---------------------------------------------------------------------------
INSERT INTO schema_migrations (version, description)
VALUES ('006', 'Policy RAG knowledge base: policies, policy_chunks (pgvector 768-dim), access log')
ON CONFLICT (version) DO NOTHING;
