-- =============================================================================
-- WILLOW AI — Migration 005: Staff & Client Lifecycle Management
-- Adds: phone columns, deactivated_at, updated_at on client_registry,
--       staff_disengagement_log, client_disengagement_log
-- =============================================================================

-- ---------------------------------------------------------------------------
-- 1. Add missing columns to staff_registry
-- ---------------------------------------------------------------------------
ALTER TABLE staff_registry
    ADD COLUMN IF NOT EXISTS phone          TEXT,
    ADD COLUMN IF NOT EXISTS deactivated_at TIMESTAMPTZ;

-- ---------------------------------------------------------------------------
-- 2. Add missing columns to client_registry
-- ---------------------------------------------------------------------------
ALTER TABLE client_registry
    ADD COLUMN IF NOT EXISTS phone      TEXT,
    ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT now();

-- Backfill updated_at for existing rows
UPDATE client_registry SET updated_at = created_at WHERE updated_at IS NULL;

-- Auto-update trigger for client_registry
CREATE TRIGGER trg_client_registry_updated_at
    BEFORE UPDATE ON client_registry
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------------
-- 3. STAFF DISENGAGEMENT LOG
-- Immutable record of every staff offboarding event.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS staff_disengagement_log (
    id                  BIGSERIAL       PRIMARY KEY,
    staff_user_id       TEXT            NOT NULL REFERENCES staff_registry(user_id),
    staff_name          TEXT            NOT NULL,
    deactivated_by      TEXT            NOT NULL REFERENCES staff_registry(user_id),
    reassigned_to       TEXT            REFERENCES staff_registry(user_id),
    clients_reassigned  JSONB           DEFAULT '[]'::jsonb,
    tasks_reassigned    JSONB           DEFAULT '[]'::jsonb,
    reason              TEXT            NOT NULL,
    disengaged_at       TIMESTAMPTZ     DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_staff_diseng_staff ON staff_disengagement_log(staff_user_id);
CREATE INDEX IF NOT EXISTS idx_staff_diseng_by    ON staff_disengagement_log(deactivated_by);

-- ---------------------------------------------------------------------------
-- 4. CLIENT DISENGAGEMENT LOG
-- Immutable record of every client offboarding event with Xero closure details.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS client_disengagement_log (
    id                      BIGSERIAL       PRIMARY KEY,
    client_id               TEXT            NOT NULL REFERENCES client_registry(client_id),
    business_name           TEXT            NOT NULL,
    abn                     TEXT,
    disengaged_by           TEXT            NOT NULL REFERENCES staff_registry(user_id),
    disengaged_by_name      TEXT            NOT NULL,
    reason                  TEXT            NOT NULL,
    -- Handover details
    final_report_path       TEXT,
    xero_connection_removed BOOLEAN         DEFAULT FALSE,
    open_tasks_cancelled    INTEGER         DEFAULT 0,
    open_tasks_completed    INTEGER         DEFAULT 0,
    -- Notification trail
    notification_sent_to    JSONB           DEFAULT '[]'::jsonb,  -- list of emails/channels notified
    -- Timestamps
    disengaged_at           TIMESTAMPTZ     DEFAULT now(),
    notes                   TEXT
);

CREATE INDEX IF NOT EXISTS idx_client_diseng_client ON client_disengagement_log(client_id);
CREATE INDEX IF NOT EXISTS idx_client_diseng_by     ON client_disengagement_log(disengaged_by);
CREATE INDEX IF NOT EXISTS idx_client_diseng_date   ON client_disengagement_log(disengaged_at DESC);

-- ---------------------------------------------------------------------------
-- 5. Add disengagement_reason and disengaged_at to client_registry
--    (so we can see why a client is inactive without joining the log)
-- ---------------------------------------------------------------------------
ALTER TABLE client_registry
    ADD COLUMN IF NOT EXISTS disengaged_at     TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS disengagement_reason TEXT;

-- ---------------------------------------------------------------------------
-- 6. Schema version
-- ---------------------------------------------------------------------------
INSERT INTO schema_migrations (version, description)
VALUES ('005', 'Staff & client lifecycle: phone, deactivated_at, disengagement logs, client_registry updated_at')
ON CONFLICT (version) DO NOTHING;
