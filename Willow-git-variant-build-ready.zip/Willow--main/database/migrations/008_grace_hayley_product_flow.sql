-- =============================================================================
-- WILLOW AI — Migration 008: Productised Grace/Hayley Flow
-- Adds document extraction, reconciliation and approval-safe product tables.
-- Safe to run repeatedly on fresh installs or upgrades.
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

-- A default single-firm row makes first boot and demos easier while still
-- supporting real multi-tenant firm_id scoping later.
INSERT INTO firms (name, slug)
VALUES ('Default Willow Firm', 'default')
ON CONFLICT (slug) DO NOTHING;

CREATE TABLE IF NOT EXISTS product_documents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_id UUID REFERENCES firms(id) ON DELETE RESTRICT,
    source TEXT NOT NULL DEFAULT 'grace',
    source_id TEXT,
    filename TEXT,
    mime_type TEXT,
    extraction JSONB NOT NULL DEFAULT '{}'::jsonb,
    confidence NUMERIC(5,4) NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'review_needed',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_product_documents_firm_status
  ON product_documents(firm_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_product_documents_source
  ON product_documents(source, source_id);

CREATE TABLE IF NOT EXISTS product_reconciliations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_id UUID REFERENCES firms(id) ON DELETE RESTRICT,
    document_id TEXT,
    source_id TEXT,
    result JSONB NOT NULL DEFAULT '{}'::jsonb,
    confidence NUMERIC(5,4) NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'review_needed',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_product_reconciliations_firm_status
  ON product_reconciliations(firm_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_product_reconciliations_document
  ON product_reconciliations(document_id);

CREATE TABLE IF NOT EXISTS product_approval_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_id UUID REFERENCES firms(id) ON DELETE RESTRICT,
    task_id UUID REFERENCES product_tasks(id) ON DELETE SET NULL,
    actor TEXT NOT NULL DEFAULT 'system',
    decision TEXT NOT NULL CHECK (decision IN ('approved','rejected','requested_changes','commented')),
    notes TEXT,
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_product_approval_task
  ON product_approval_events(task_id, created_at DESC);

-- First-boot routing rule. Operators should edit this in production, but it
-- prevents urgent/document tasks from having no destination during testing.
INSERT INTO staff_routing_rules
  (firm_id, rule_name, document_type, urgency, assigned_staff_id, fallback_email, extension, active)
SELECT id, 'Default urgent fallback', NULL, 'urgent', NULL, NULL, '101', TRUE
FROM firms WHERE slug = 'default'
ON CONFLICT DO NOTHING;

INSERT INTO staff_routing_rules
  (firm_id, rule_name, document_type, urgency, assigned_staff_id, fallback_email, extension, active)
SELECT id, 'Default document review', 'invoice', NULL, NULL, NULL, '101', TRUE
FROM firms WHERE slug = 'default'
ON CONFLICT DO NOTHING;

-- Ensure updated_at triggers exist for the new product tables.
DROP TRIGGER IF EXISTS trg_product_documents_updated_at ON product_documents;
CREATE TRIGGER trg_product_documents_updated_at
  BEFORE UPDATE ON product_documents
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

DROP TRIGGER IF EXISTS trg_product_reconciliations_updated_at ON product_reconciliations;
CREATE TRIGGER trg_product_reconciliations_updated_at
  BEFORE UPDATE ON product_reconciliations
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
