-- =============================================================================
-- Migration 002 — Pending Approvals
-- =============================================================================
-- Creates the pending_approvals table required by the follow-up executor
-- approval gate pattern (audit finding 1.3).
--
-- Emails composed by willow-follow-up-executor are staged here for staff
-- review before sending. Staff approve or reject via the dashboard webhook.
-- =============================================================================

CREATE TABLE IF NOT EXISTS pending_approvals (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    approval_type   TEXT NOT NULL DEFAULT 'follow_up_email',
    client_id       TEXT REFERENCES client_registry(client_id) ON DELETE SET NULL,
    sequence_id     TEXT,
    to_email        TEXT NOT NULL,
    subject         TEXT NOT NULL,
    body            TEXT NOT NULL,
    created_by      TEXT NOT NULL DEFAULT 'willow_system',
    status          TEXT NOT NULL DEFAULT 'pending'
                        CHECK (status IN ('pending', 'sent', 'rejected', 'expired')),
    approved_by     TEXT REFERENCES staff_registry(user_id) ON DELETE SET NULL,
    approved_at     TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Index for dashboard queries (pending approvals list)
CREATE INDEX IF NOT EXISTS idx_pending_approvals_status
    ON pending_approvals (status, created_at DESC);

-- Index for client filtering
CREATE INDEX IF NOT EXISTS idx_pending_approvals_client
    ON pending_approvals (client_id, status);

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_pending_approvals_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_pending_approvals_updated_at ON pending_approvals;
CREATE TRIGGER trg_pending_approvals_updated_at
    BEFORE UPDATE ON pending_approvals
    FOR EACH ROW EXECUTE FUNCTION update_pending_approvals_updated_at();

COMMENT ON TABLE pending_approvals IS
    'Outbound communications staged for human review before sending. '
    'Created by automated workflows (e.g. follow-up executor). '
    'Staff approve/reject via dashboard. Nothing sends without approval.';
