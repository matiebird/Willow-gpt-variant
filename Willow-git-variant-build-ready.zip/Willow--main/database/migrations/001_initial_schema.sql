-- =============================================================================
-- WILLOW AI — Unified Database Schema v2.0
-- Engineered Data Systems — Architecture v2.0
-- Migration: 001_initial_schema.sql
-- Database: PostgreSQL 16 + pgvector
--
-- Combines:
--   • Willow agent infrastructure (staff/client registry, audit log, Hayley/Grace tables)
--   • Full double-entry bookkeeping engine (accounts, transactions, invoices)
--   • Receipt OCR/AI pipeline tracking
-- =============================================================================

-- ---------------------------------------------------------------------------
-- EXTENSIONS
-- ---------------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS vector;           -- Mem0 semantic memory (pgvector)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";      -- uuid_generate_v4() compatibility
CREATE EXTENSION IF NOT EXISTS "pgcrypto";       -- gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS "pg_trgm";        -- Fuzzy vendor/description search

-- ---------------------------------------------------------------------------
-- SHARED updated_at TRIGGER FUNCTION
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

-- Alias for backward compatibility with existing workflows
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

-- =============================================================================
-- PART 1 — WILLOW AGENT INFRASTRUCTURE
-- Staff registry, client registry, audit log, Grace/Hayley state tables.
-- These are the operational tables used by n8n workflows.
-- =============================================================================

-- ---------------------------------------------------------------------------
-- 1. STAFF REGISTRY
-- Every person who can interact with Willow must have a row here.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS staff_registry (
    user_id           TEXT PRIMARY KEY,
    name              TEXT NOT NULL,
    role              TEXT NOT NULL CHECK (role IN (
                        'bookkeeper', 'senior_bookkeeper', 'manager', 'admin'
                      )),
    email             TEXT NOT NULL,
    client_ids        JSONB DEFAULT '[]'::jsonb,
    approval_limit    NUMERIC(10,2) DEFAULT 500.00,
    timezone          TEXT DEFAULT 'Australia/Brisbane',
    active            BOOLEAN DEFAULT true,
    created_at        TIMESTAMPTZ DEFAULT now(),
    updated_at        TIMESTAMPTZ DEFAULT now()
);

DROP TRIGGER IF EXISTS trg_staff_registry_updated_at ON staff_registry;
CREATE TRIGGER trg_staff_registry_updated_at
  BEFORE UPDATE ON staff_registry
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------------
-- 2. CLIENT REGISTRY
-- Central source of truth for all client metadata and Xero tenancy.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS client_registry (
    client_id           TEXT PRIMARY KEY,
    business_name       TEXT NOT NULL,
    abn                 TEXT,
    xero_tenant_id      TEXT,
    xero_org_name       TEXT,
    primary_contact     TEXT,
    contact_email       TEXT,
    contact_domain      TEXT,
    bas_frequency       TEXT CHECK (bas_frequency IN ('monthly', 'quarterly', 'annual')),
    payroll_frequency   TEXT CHECK (payroll_frequency IN ('weekly', 'fortnightly', 'monthly', 'none')),
    assigned_staff      TEXT REFERENCES staff_registry(user_id),
    email_provider      TEXT DEFAULT 'gmail' CHECK (email_provider IN ('gmail', 'outlook')),
    notes               TEXT,
    active              BOOLEAN DEFAULT true,
    created_at          TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_client_email  ON client_registry(contact_email);
CREATE INDEX IF NOT EXISTS idx_client_domain ON client_registry(contact_domain);

-- ---------------------------------------------------------------------------
-- 3. AUDIT LOG — Immutable. Never UPDATE or DELETE rows here.
-- Every action that touches financial data writes a record here.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_log (
    id                BIGSERIAL PRIMARY KEY,
    timestamp         TIMESTAMPTZ DEFAULT now(),
    staff_user_id     TEXT REFERENCES staff_registry(user_id),
    staff_name        TEXT NOT NULL,
    action            TEXT NOT NULL,
    -- Agent: willow_manager | grace | hayley | email_triage | task_agent | api
    agent             TEXT NOT NULL,
    client_id         TEXT REFERENCES client_registry(client_id),
    details           JSONB,
    result            TEXT CHECK (result IN ('success', 'failed', 'pending_approval', 'escalated')),
    error_message     TEXT
);

CREATE INDEX IF NOT EXISTS idx_audit_staff   ON audit_log(staff_user_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_client  ON audit_log(client_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_action  ON audit_log(action, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_agent   ON audit_log(agent, timestamp DESC);

-- ---------------------------------------------------------------------------
-- 4. INVOICE FINGERPRINTS — SHA256 dedup (Grace computes, Hayley checks)
-- Prevents any invoice being submitted to Xero more than once.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS invoice_fingerprints (
    sha256_hash         TEXT PRIMARY KEY,
    client_id           TEXT REFERENCES client_registry(client_id),
    supplier_name       TEXT,
    invoice_number      TEXT,
    amount              NUMERIC(12,2),
    gst_amount          NUMERIC(12,2),
    xero_bill_id        TEXT,
    source_message_id   TEXT,
    source_type         TEXT,  -- email_attachment | email_html_body | voice_dictation | dashboard_upload
    processed_by        TEXT REFERENCES staff_registry(user_id),
    processed_at        TIMESTAMPTZ DEFAULT now(),
    status              TEXT CHECK (status IN (
                          'pending', 'submitted', 'approved',
                          'rejected', 'duplicate', 'flagged_for_review'
                        ))
);

CREATE INDEX IF NOT EXISTS idx_fingerprint_client ON invoice_fingerprints(client_id, processed_at DESC);
CREATE INDEX IF NOT EXISTS idx_fingerprint_xero   ON invoice_fingerprints(xero_bill_id);

-- ---------------------------------------------------------------------------
-- 5. FOLLOW-UP SEQUENCES — 3-5-7 day automated client chase cadences
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS follow_up_sequences (
    id                BIGSERIAL PRIMARY KEY,
    client_id         TEXT REFERENCES client_registry(client_id),
    assigned_staff    TEXT REFERENCES staff_registry(user_id),
    subject           TEXT NOT NULL,
    cadence_days      INTEGER[] DEFAULT '{3,5,7}',
    current_step      INTEGER DEFAULT 0,
    status            TEXT CHECK (status IN ('active', 'completed', 'escalated', 'cancelled')) DEFAULT 'active',
    created_at        TIMESTAMPTZ DEFAULT now(),
    next_action_at    TIMESTAMPTZ,
    last_action_at    TIMESTAMPTZ,
    notes             TEXT
);

CREATE INDEX IF NOT EXISTS idx_followup_due   ON follow_up_sequences(next_action_at) WHERE status = 'active';
CREATE INDEX IF NOT EXISTS idx_followup_staff ON follow_up_sequences(assigned_staff, status);

-- ---------------------------------------------------------------------------
-- 6. CHAT SESSIONS (n8n memoryPostgresChat node)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS chat_sessions (
    id          BIGSERIAL PRIMARY KEY,
    session_id  TEXT NOT NULL,
    type        TEXT NOT NULL,   -- human | ai | system
    content     TEXT NOT NULL,
    metadata    JSONB DEFAULT '{}'::jsonb,
    created_at  TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_chat_session ON chat_sessions(session_id, created_at DESC);

-- ---------------------------------------------------------------------------
-- 7. KANBOARD PROJECTS — Maps client_ids to Kanboard project IDs
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS kanboard_projects (
    client_id            TEXT PRIMARY KEY REFERENCES client_registry(client_id),
    kanboard_project_id  INTEGER NOT NULL,
    review_column_id     INTEGER,
    created_at           TIMESTAMPTZ DEFAULT now()
);

-- =============================================================================
-- PART 2 — BOOKKEEPING ENGINE
-- Full double-entry accounting: Chart of Accounts, Categories, Transactions,
-- Journal Entries, Invoices, Receipt pipeline tracking.
-- =============================================================================

-- ---------------------------------------------------------------------------
-- ENUMERATIONS
-- ---------------------------------------------------------------------------
DO $$ BEGIN
  CREATE TYPE account_type_enum      AS ENUM ('asset', 'liability', 'equity', 'revenue', 'expense');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;
DO $$ BEGIN
  CREATE TYPE account_subtype_enum   AS ENUM (
    'cash', 'bank', 'accounts_receivable', 'inventory', 'fixed_asset', 'other_asset',
    'accounts_payable', 'credit_card', 'loan', 'tax_payable', 'other_liability',
    'retained_earnings', 'owners_equity',
    'operating_revenue', 'other_income',
    'operating_expense', 'cost_of_goods', 'tax_expense', 'other_expense'
);
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;
DO $$ BEGIN
  CREATE TYPE transaction_type_enum   AS ENUM ('income', 'expense', 'transfer', 'journal', 'opening_balance');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;
DO $$ BEGIN
  CREATE TYPE transaction_status_enum AS ENUM ('draft', 'pending', 'cleared', 'reconciled', 'voided');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;
DO $$ BEGIN
  CREATE TYPE entry_type_enum         AS ENUM ('debit', 'credit');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;
DO $$ BEGIN
  CREATE TYPE invoice_type_enum       AS ENUM ('receivable', 'payable');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;
DO $$ BEGIN
  CREATE TYPE invoice_status_enum     AS ENUM ('draft', 'sent', 'partial', 'paid', 'overdue', 'voided', 'written_off');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;
DO $$ BEGIN
  CREATE TYPE receipt_status_enum     AS ENUM (
    'uploaded', 'ocr_processing', 'ocr_complete',
    'ai_processing', 'ai_complete', 'review_needed',
    'linked', 'failed', 'duplicate'
);
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- ---------------------------------------------------------------------------
-- TAX RATES — Australian defaults (GST 10%, GST-Free, Input-Taxed, BAS Excluded)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tax_rates (
    id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    name        VARCHAR(50) NOT NULL,
    code        VARCHAR(15) NOT NULL UNIQUE,
    rate        NUMERIC(5,4) NOT NULL CHECK (rate >= 0 AND rate <= 1),
    is_active   BOOLEAN     NOT NULL DEFAULT TRUE,
    is_default  BOOLEAN     NOT NULL DEFAULT FALSE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO tax_rates (name, code, rate, is_active, is_default) VALUES
    ('GST (10%)',          'GST',        0.10, TRUE, TRUE),
    ('GST-Free (0%)',      'GST-FREE',   0.00, TRUE, FALSE),
    ('Input-Taxed (0%)',   'INPUT-TAXED',0.00, TRUE, FALSE),
    ('BAS Excluded',       'BAS-EX',     0.00, TRUE, FALSE);

-- ---------------------------------------------------------------------------
-- CHART OF ACCOUNTS — Hierarchical, double-entry aware
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS accounts (
    id               UUID                 PRIMARY KEY DEFAULT gen_random_uuid(),
    code             VARCHAR(20)          NOT NULL UNIQUE,
    name             VARCHAR(200)         NOT NULL,
    description      TEXT,
    account_type     account_type_enum    NOT NULL,
    account_subtype  account_subtype_enum,
    parent_id        UUID                 REFERENCES accounts(id) ON DELETE SET NULL,
    balance          NUMERIC(15,2)        NOT NULL DEFAULT 0.00,
    currency         CHAR(3)              NOT NULL DEFAULT 'AUD',
    is_active        BOOLEAN              NOT NULL DEFAULT TRUE,
    is_bank_account  BOOLEAN              NOT NULL DEFAULT FALSE,
    is_system        BOOLEAN              NOT NULL DEFAULT FALSE,
    is_deleted       BOOLEAN              NOT NULL DEFAULT FALSE,
    tax_code         VARCHAR(20),
    -- Xero account code for Hayley reconciliation
    xero_account_code VARCHAR(10),
    created_at       TIMESTAMPTZ          NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ          NOT NULL DEFAULT NOW(),
    deleted_at       TIMESTAMPTZ
);

CREATE INDEX ix_accounts_type   ON accounts(account_type);
CREATE INDEX ix_accounts_code   ON accounts(code);
CREATE INDEX ix_accounts_active ON accounts(is_active) WHERE is_deleted = FALSE;

-- Australian Chart of Accounts seed data
INSERT INTO accounts (code, name, account_type, account_subtype, is_system, is_bank_account, xero_account_code) VALUES
    -- Assets
    ('1000', 'Cash on Hand',             'asset', 'cash',                TRUE, TRUE,  '090'),
    ('1010', 'Business Cheque Account',  'asset', 'bank',                TRUE, TRUE,  '091'),
    ('1020', 'Savings Account',          'asset', 'bank',                TRUE, TRUE,  '092'),
    ('1100', 'Accounts Receivable',      'asset', 'accounts_receivable', TRUE, FALSE, '200'),
    ('1200', 'Inventory',                'asset', 'inventory',           TRUE, FALSE, '310'),
    ('1500', 'Equipment',                'asset', 'fixed_asset',         TRUE, FALSE, '720'),
    ('1510', 'Accumulated Depreciation', 'asset', 'fixed_asset',         TRUE, FALSE, '721'),
    -- Liabilities
    ('2000', 'Accounts Payable',         'liability', 'accounts_payable', TRUE, FALSE, '800'),
    ('2100', 'GST Collected',            'liability', 'tax_payable',      TRUE, FALSE, '820'),
    ('2110', 'GST Paid',                 'liability', 'tax_payable',      TRUE, FALSE, '821'),
    ('2200', 'PAYG Withholding',         'liability', 'tax_payable',      TRUE, FALSE, '825'),
    ('2300', 'Business Credit Card',     'liability', 'credit_card',      TRUE, FALSE, '803'),
    ('2400', 'Loan Payable',             'liability', 'loan',             FALSE,FALSE, NULL),
    -- Equity
    ('3000', 'Owner''s Equity',          'equity', 'owners_equity',      TRUE, FALSE, '970'),
    ('3100', 'Retained Earnings',        'equity', 'retained_earnings',  TRUE, FALSE, '960'),
    ('3200', 'Owner''s Draw',            'equity', 'owners_equity',      FALSE,FALSE, NULL),
    -- Revenue
    ('4000', 'Sales Revenue',            'revenue', 'operating_revenue', TRUE, FALSE, '200'),
    ('4100', 'Service Revenue',          'revenue', 'operating_revenue', TRUE, FALSE, '201'),
    ('4900', 'Other Income',             'revenue', 'other_income',      FALSE,FALSE, '260'),
    -- Expenses
    ('5000', 'Cost of Goods Sold',       'expense', 'cost_of_goods',     TRUE, FALSE, '500'),
    ('6000', 'Advertising & Marketing',  'expense', 'operating_expense', FALSE,FALSE, '400'),
    ('6010', 'Bank Charges',             'expense', 'operating_expense', FALSE,FALSE, '404'),
    ('6020', 'Depreciation',             'expense', 'operating_expense', FALSE,FALSE, '711'),
    ('6030', 'Insurance',                'expense', 'operating_expense', FALSE,FALSE, '408'),
    ('6040', 'Motor Vehicle Expenses',   'expense', 'operating_expense', FALSE,FALSE, '489'),
    ('6050', 'Office Supplies',          'expense', 'operating_expense', FALSE,FALSE, '412'),
    ('6060', 'Postage & Printing',       'expense', 'operating_expense', FALSE,FALSE, '413'),
    ('6070', 'Professional Services',    'expense', 'operating_expense', FALSE,FALSE, '414'),
    ('6080', 'Rent & Occupancy',         'expense', 'operating_expense', FALSE,FALSE, '415'),
    ('6090', 'Repairs & Maintenance',    'expense', 'operating_expense', FALSE,FALSE, '416'),
    ('6100', 'Software & Subscriptions', 'expense', 'operating_expense', FALSE,FALSE, '453'),
    ('6110', 'Superannuation',           'expense', 'operating_expense', FALSE,FALSE, '476'),
    ('6120', 'Travel & Transport',       'expense', 'operating_expense', FALSE,FALSE, '493'),
    ('6130', 'Utilities',                'expense', 'operating_expense', FALSE,FALSE, '420'),
    ('6140', 'Wages & Salaries',         'expense', 'operating_expense', FALSE,FALSE, '477'),
    ('6200', 'Meals & Entertainment',    'expense', 'operating_expense', FALSE,FALSE, '410'),
    ('6900', 'Other Expenses',           'expense', 'other_expense',     FALSE,FALSE, '499'),
    ('7000', 'Income Tax Expense',       'expense', 'tax_expense',       FALSE,FALSE, '505');

-- ---------------------------------------------------------------------------
-- CATEGORIES — AI-suggested labels, mapped to accounts (Grace output)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS categories (
    id                  UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    name                VARCHAR(100) NOT NULL UNIQUE,
    description         TEXT,
    colour              VARCHAR(7),
    icon                VARCHAR(50),
    default_account_id  UUID        REFERENCES accounts(id) ON DELETE SET NULL,
    tax_rate_id         UUID        REFERENCES tax_rates(id) ON DELETE SET NULL,
    is_active           BOOLEAN     NOT NULL DEFAULT TRUE,
    is_system           BOOLEAN     NOT NULL DEFAULT FALSE,
    ai_keywords         TEXT,
    -- Xero account code used by Hayley when pushing to Xero
    xero_account_code   VARCHAR(10),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX ix_categories_name ON categories(name);

INSERT INTO categories (name, colour, icon, is_system, ai_keywords, xero_account_code)
SELECT c.name, c.colour, c.icon, TRUE, c.kw, c.xero
FROM (VALUES
    ('Office Supplies',          '#4CAF50', 'printer',       'stationery,paper,ink,office,supplies',                    '412'),
    ('Travel & Transport',       '#2196F3', 'car',           'taxi,uber,fuel,petrol,flight,train,bus,transport',        '493'),
    ('Meals & Entertainment',    '#FF9800', 'utensils',      'restaurant,cafe,coffee,lunch,dinner,food,meal',           '410'),
    ('Utilities',                '#9C27B0', 'zap',           'electricity,water,gas,internet,phone,utility',            '420'),
    ('Software & Subscriptions', '#00BCD4', 'monitor',       'saas,app,subscription,software,licence,adobe,microsoft', '453'),
    ('Professional Services',    '#607D8B', 'briefcase',     'accountant,lawyer,consultant,legal,advisory',             '414'),
    ('Equipment & Hardware',     '#795548', 'cpu',           'computer,laptop,phone,hardware,equipment,server',         NULL),
    ('Marketing & Advertising',  '#E91E63', 'megaphone',     'ad,ads,facebook,google ads,marketing,social media',       '400'),
    ('Rent & Occupancy',         '#FF5722', 'home',          'rent,lease,office space,storage',                         '415'),
    ('Motor Vehicle',            '#8BC34A', 'truck',         'car,vehicle,fuel,rego,registration,service',              '489'),
    ('Insurance',                '#FFC107', 'shield',        'insurance,premium,policy,cover',                          '408'),
    ('Bank Charges',             '#9E9E9E', 'credit-card',   'bank fee,merchant fee,transaction fee,interest',          '404'),
    ('Wages & Salaries',         '#3F51B5', 'users',         'wages,salary,payroll,staff,employee',                     '477'),
    ('Inventory',                '#009688', 'package',       'stock,inventory,goods,product,purchase',                  '500'),
    ('Repairs & Maintenance',    '#FF6F00', 'tool',          'repair,maintenance,fix,service',                          '416'),
    ('Other',                    '#757575', 'more-horizontal','miscellaneous,other,general',                             '499')
) AS c(name, colour, icon, kw, xero)
ON CONFLICT (name) DO NOTHING;

-- ---------------------------------------------------------------------------
-- RECEIPTS — Grace pipeline tracking (uploaded file → OCR → AI → Xero)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS receipts (
    id                  UUID                 PRIMARY KEY DEFAULT gen_random_uuid(),
    original_filename   VARCHAR(500)         NOT NULL,
    stored_filename     VARCHAR(500)         NOT NULL UNIQUE,
    file_path           VARCHAR(1000)        NOT NULL,
    mime_type           VARCHAR(100)         NOT NULL,
    file_size_bytes     INTEGER              NOT NULL,
    -- SHA256 for duplicate detection (checked against invoice_fingerprints)
    file_hash           VARCHAR(64)          NOT NULL,
    status              receipt_status_enum  NOT NULL DEFAULT 'uploaded',
    processing_error    TEXT,
    processing_attempts SMALLINT             NOT NULL DEFAULT 0,
    -- OCR output
    ocr_text            TEXT,
    ocr_confidence      REAL,
    -- AI extraction (Grace) output
    ai_extracted_data   JSONB,
    ai_confidence       REAL,
    ai_model_used       VARCHAR(100),
    -- Human review
    reviewed_by_human   BOOLEAN              NOT NULL DEFAULT FALSE,
    human_corrections   JSONB,
    -- Agent / source tracking
    source_type         TEXT DEFAULT 'dashboard_upload',
    client_id           TEXT REFERENCES client_registry(client_id),
    processed_by        TEXT REFERENCES staff_registry(user_id),
    created_at          TIMESTAMPTZ          NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ          NOT NULL DEFAULT NOW()
);

CREATE INDEX ix_receipts_hash   ON receipts(file_hash);
CREATE INDEX ix_receipts_status ON receipts(status);

-- ---------------------------------------------------------------------------
-- INVOICES (Willow-internal ledger — separate from Xero drafts)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS invoices (
    id                   UUID                  PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_number       VARCHAR(50)           NOT NULL UNIQUE,
    po_number            VARCHAR(50),
    invoice_type         invoice_type_enum     NOT NULL,
    status               invoice_status_enum   NOT NULL DEFAULT 'draft',
    counterparty_name    VARCHAR(200)          NOT NULL,
    counterparty_email   VARCHAR(200),
    counterparty_address TEXT,
    counterparty_abn     VARCHAR(20),
    issue_date           DATE                  NOT NULL,
    due_date             DATE,
    paid_date            DATE,
    subtotal             NUMERIC(15,2)         NOT NULL DEFAULT 0.00 CHECK (subtotal >= 0),
    tax_total            NUMERIC(15,2)         NOT NULL DEFAULT 0.00 CHECK (tax_total >= 0),
    total                NUMERIC(15,2)         NOT NULL DEFAULT 0.00 CHECK (total >= 0),
    amount_paid          NUMERIC(15,2)         NOT NULL DEFAULT 0.00 CHECK (amount_paid >= 0),
    currency             CHAR(3)               NOT NULL DEFAULT 'AUD',
    notes                TEXT,
    terms                TEXT,
    -- Xero tracking
    xero_invoice_id      TEXT,
    xero_tenant_id       TEXT,
    client_id            TEXT REFERENCES client_registry(client_id),
    is_deleted           BOOLEAN               NOT NULL DEFAULT FALSE,
    deleted_at           TIMESTAMPTZ,
    created_at           TIMESTAMPTZ           NOT NULL DEFAULT NOW(),
    updated_at           TIMESTAMPTZ           NOT NULL DEFAULT NOW()
);

CREATE INDEX ix_invoices_type_status  ON invoices(invoice_type, status);
CREATE INDEX ix_invoices_due          ON invoices(due_date) WHERE is_deleted = FALSE;
CREATE INDEX ix_invoices_client       ON invoices(client_id);
CREATE INDEX ix_invoices_xero         ON invoices(xero_invoice_id);

-- ---------------------------------------------------------------------------
-- INVOICE LINE ITEMS
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS invoice_items (
    id               UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_id       UUID            NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
    sort_order       SMALLINT        NOT NULL DEFAULT 0,
    description      VARCHAR(500)    NOT NULL,
    quantity         NUMERIC(10,4)   NOT NULL DEFAULT 1.0000 CHECK (quantity > 0),
    unit_price       NUMERIC(15,4)   NOT NULL CHECK (unit_price >= 0),
    discount_percent NUMERIC(5,2)    NOT NULL DEFAULT 0.00,
    tax_rate_id      UUID            REFERENCES tax_rates(id) ON DELETE SET NULL,
    tax_amount       NUMERIC(15,2)   NOT NULL DEFAULT 0.00,
    line_total       NUMERIC(15,2)   NOT NULL CHECK (line_total >= 0),
    account_id       UUID            REFERENCES accounts(id) ON DELETE SET NULL,
    created_at       TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

CREATE INDEX ix_invoice_items_invoice ON invoice_items(invoice_id);

-- ---------------------------------------------------------------------------
-- TRANSACTIONS — Double-entry header
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS transactions (
    id                   UUID                    PRIMARY KEY DEFAULT gen_random_uuid(),
    date                 DATE                    NOT NULL,
    description          VARCHAR(500)            NOT NULL,
    reference            VARCHAR(100),
    notes                TEXT,
    transaction_type     transaction_type_enum   NOT NULL DEFAULT 'expense',
    status               transaction_status_enum NOT NULL DEFAULT 'pending',
    amount               NUMERIC(15,2)           NOT NULL CHECK (amount >= 0),
    tax_amount           NUMERIC(15,2)           NOT NULL DEFAULT 0.00 CHECK (tax_amount >= 0),
    currency             CHAR(3)                 NOT NULL DEFAULT 'AUD',
    category_id          UUID                    REFERENCES categories(id) ON DELETE SET NULL,
    receipt_id           UUID                    REFERENCES receipts(id) ON DELETE SET NULL,
    invoice_id           UUID                    REFERENCES invoices(id) ON DELETE SET NULL,
    ai_categorised       BOOLEAN                 NOT NULL DEFAULT FALSE,
    ai_confidence        REAL,
    ai_raw_response      TEXT,
    vendor_name          VARCHAR(200),
    bank_transaction_id  VARCHAR(100)            UNIQUE,
    -- Client linkage (for multi-client firms)
    client_id            TEXT REFERENCES client_registry(client_id),
    -- Xero reconciliation (Hayley)
    xero_transaction_id  TEXT,
    is_deleted           BOOLEAN                 NOT NULL DEFAULT FALSE,
    deleted_at           TIMESTAMPTZ,
    created_at           TIMESTAMPTZ             NOT NULL DEFAULT NOW(),
    updated_at           TIMESTAMPTZ             NOT NULL DEFAULT NOW()
);

CREATE INDEX ix_transactions_date        ON transactions(date);
CREATE INDEX ix_transactions_type        ON transactions(transaction_type);
CREATE INDEX ix_transactions_status      ON transactions(status);
CREATE INDEX ix_transactions_client      ON transactions(client_id);
CREATE INDEX ix_transactions_date_type   ON transactions(date, transaction_type);
CREATE INDEX ix_transactions_desc_trgm   ON transactions USING GIN (description gin_trgm_ops);
CREATE INDEX ix_transactions_vendor_trgm ON transactions USING GIN (vendor_name gin_trgm_ops);

-- ---------------------------------------------------------------------------
-- TRANSACTION JOURNAL ENTRIES — Double-entry lines
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS transaction_entries (
    id             UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    transaction_id UUID            NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
    account_id     UUID            NOT NULL REFERENCES accounts(id) ON DELETE RESTRICT,
    entry_type     entry_type_enum NOT NULL,
    amount         NUMERIC(15,2)   NOT NULL CHECK (amount > 0),
    description    VARCHAR(200),
    created_at     TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at     TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

CREATE INDEX ix_entries_transaction ON transaction_entries(transaction_id);
CREATE INDEX ix_entries_account     ON transaction_entries(account_id);

-- ---------------------------------------------------------------------------
-- JOURNAL BALANCE ENFORCEMENT TRIGGER
-- Debits must equal credits within each transaction.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION check_journal_balance()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE
    v_debit_sum  NUMERIC;
    v_credit_sum NUMERIC;
BEGIN
    SELECT
        COALESCE(SUM(amount) FILTER (WHERE entry_type = 'debit'),  0),
        COALESCE(SUM(amount) FILTER (WHERE entry_type = 'credit'), 0)
    INTO v_debit_sum, v_credit_sum
    FROM transaction_entries
    WHERE transaction_id = NEW.transaction_id;

    IF v_debit_sum > 0 AND v_credit_sum > 0 AND v_debit_sum != v_credit_sum THEN
        RAISE EXCEPTION 'Journal entries must balance: debits=% credits=%',
            v_debit_sum, v_credit_sum;
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_journal_balance ON transaction_entries;
CREATE CONSTRAINT TRIGGER trg_journal_balance
    AFTER INSERT OR UPDATE ON transaction_entries
    DEFERRABLE INITIALLY DEFERRED
    FOR EACH ROW EXECUTE FUNCTION check_journal_balance();

-- ---------------------------------------------------------------------------
-- AUTO updated_at TRIGGERS — All bookkeeping tables
-- ---------------------------------------------------------------------------
DO $$
DECLARE t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY[
        'accounts', 'categories', 'tax_rates', 'transactions',
        'transaction_entries', 'invoices', 'invoice_items', 'receipts'
    ]
    LOOP
        EXECUTE format(
            'DROP TRIGGER IF EXISTS trg_%s_updated_at ON %s',
            t, t
        );
        EXECUTE format(
            'CREATE TRIGGER trg_%s_updated_at
             BEFORE UPDATE ON %s
             FOR EACH ROW EXECUTE FUNCTION set_updated_at()',
            t, t, t, t
        );
    END LOOP;
END;
$$;

-- =============================================================================
-- REPORTING VIEWS
-- =============================================================================

CREATE OR REPLACE VIEW v_profit_loss AS
SELECT
    a.account_type, a.code, a.name,
    COALESCE(SUM(
        CASE
            WHEN te.entry_type = 'credit' AND a.account_type = 'revenue' THEN  te.amount
            WHEN te.entry_type = 'debit'  AND a.account_type = 'revenue' THEN -te.amount
            WHEN te.entry_type = 'debit'  AND a.account_type = 'expense' THEN  te.amount
            WHEN te.entry_type = 'credit' AND a.account_type = 'expense' THEN -te.amount
            ELSE 0
        END
    ), 0) AS balance
FROM accounts a
LEFT JOIN transaction_entries te ON te.account_id = a.id
LEFT JOIN transactions t ON t.id = te.transaction_id
    AND t.status NOT IN ('voided', 'draft') AND t.is_deleted = FALSE
WHERE a.account_type IN ('revenue', 'expense') AND a.is_deleted = FALSE
GROUP BY a.account_type, a.code, a.name
ORDER BY a.account_type, a.code;

CREATE OR REPLACE VIEW v_balance_sheet AS
SELECT a.account_type, a.code, a.name, a.balance
FROM accounts a
WHERE a.account_type IN ('asset', 'liability', 'equity')
  AND a.is_active = TRUE AND a.is_deleted = FALSE
ORDER BY a.account_type, a.code;

CREATE OR REPLACE VIEW v_overdue_invoices AS
SELECT i.id, i.invoice_number, i.counterparty_name, i.client_id,
       i.due_date, i.total - i.amount_paid AS balance_due,
       i.currency, CURRENT_DATE - i.due_date AS days_overdue
FROM invoices i
WHERE i.due_date < CURRENT_DATE
  AND i.status NOT IN ('paid', 'voided', 'written_off')
  AND i.is_deleted = FALSE
ORDER BY i.due_date ASC;

-- Australian tax calendar deadlines (used by Deadline Warning workflow)
CREATE OR REPLACE VIEW v_upcoming_deadlines AS
SELECT
    cr.client_id, cr.business_name, cr.bas_frequency,
    cr.assigned_staff,
    CASE cr.bas_frequency
        WHEN 'quarterly' THEN
            CASE
                WHEN CURRENT_DATE <= (DATE_TRUNC('year', CURRENT_DATE) + INTERVAL '10 months 28 days')::DATE THEN (DATE_TRUNC('year', CURRENT_DATE) + INTERVAL '10 months 28 days')::DATE
                ELSE (DATE_TRUNC('year', CURRENT_DATE) + INTERVAL '1 year 1 month 28 days')::DATE
            END
        WHEN 'monthly' THEN (DATE_TRUNC('month', CURRENT_DATE) + INTERVAL '1 month 21 days')::DATE
        ELSE NULL
    END AS next_bas_due
FROM client_registry cr
WHERE cr.active = TRUE AND cr.bas_frequency IS NOT NULL;

-- =============================================================================
-- SCHEMA VERSION TRACKING
-- =============================================================================
CREATE TABLE IF NOT EXISTS schema_migrations (
    version     VARCHAR(50) PRIMARY KEY,
    applied_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    description TEXT
);

INSERT INTO schema_migrations (version, description)
VALUES ('002', 'Unified schema v2.0: double-entry bookkeeping + Willow agent infrastructure + pgvector');
