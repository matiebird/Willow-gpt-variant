-- Willow product layer: multi-tenant-safe task and audit spine.
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS firms (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    slug TEXT UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS product_tasks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_id UUID REFERENCES firms(id) ON DELETE RESTRICT,
    title TEXT NOT NULL,
    task_type TEXT NOT NULL,
    priority INTEGER NOT NULL DEFAULT 1,
    status TEXT NOT NULL DEFAULT 'pending',
    source TEXT NOT NULL,
    source_id TEXT,
    assigned_staff_id TEXT,
    payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_product_tasks_firm_status ON product_tasks(firm_id, status, priority DESC, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_product_tasks_source ON product_tasks(source, source_id);

CREATE TABLE IF NOT EXISTS product_audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_id UUID REFERENCES firms(id) ON DELETE RESTRICT,
    agent TEXT NOT NULL,
    action TEXT NOT NULL,
    source TEXT NOT NULL,
    source_id TEXT,
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_product_audit_firm_created ON product_audit_log(firm_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_product_audit_source ON product_audit_log(source, source_id);

CREATE TABLE IF NOT EXISTS staff_routing_rules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    firm_id UUID REFERENCES firms(id) ON DELETE CASCADE,
    rule_name TEXT NOT NULL,
    document_type TEXT,
    urgency TEXT,
    assigned_staff_id TEXT,
    fallback_email TEXT,
    extension TEXT,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Add firm_id to common existing tables where possible. These are nullable for upgrade safety.
ALTER TABLE IF EXISTS client_registry ADD COLUMN IF NOT EXISTS firm_id UUID REFERENCES firms(id) ON DELETE RESTRICT;
ALTER TABLE IF EXISTS staff_registry ADD COLUMN IF NOT EXISTS firm_id UUID REFERENCES firms(id) ON DELETE RESTRICT;
ALTER TABLE IF EXISTS calls ADD COLUMN IF NOT EXISTS firm_id UUID REFERENCES firms(id) ON DELETE RESTRICT;
ALTER TABLE IF EXISTS call_turns ADD COLUMN IF NOT EXISTS firm_id UUID REFERENCES firms(id) ON DELETE RESTRICT;
ALTER TABLE IF EXISTS audit_log ADD COLUMN IF NOT EXISTS firm_id UUID REFERENCES firms(id) ON DELETE RESTRICT;
