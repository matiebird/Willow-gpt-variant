-- =============================================================================
-- MIGRATION 003: Voice Calls + Task Queue + Staff Capacity
-- Willow Voice Receptionist & Scale Architecture
-- =============================================================================

-- ── Inbound/Outbound call log ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS calls (
    id                  UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    call_id             VARCHAR(100) UNIQUE NOT NULL,   -- Asterisk UniqueID
    caller_number       VARCHAR(30),
    client_id           TEXT        REFERENCES client_registry(client_id) ON DELETE SET NULL,
    direction           VARCHAR(10) NOT NULL DEFAULT 'inbound',  -- inbound | outbound
    status              VARCHAR(25) NOT NULL DEFAULT 'active',
    -- active | completed | transferred | voicemail | callback_requested | failed
    intent              VARCHAR(60),
    -- invoice_query | payment | new_client | general | complaint | after_hours
    transcript          TEXT,                           -- full call transcript
    willow_handled      BOOLEAN     NOT NULL DEFAULT TRUE,
    transferred_to      VARCHAR(50),                    -- 3CX extension number
    duration_seconds    INTEGER,
    recording_path      TEXT,
    task_created_id     UUID,                           -- FK to task_queue.id
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at        TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_calls_caller    ON calls(caller_number);
CREATE INDEX IF NOT EXISTS idx_calls_client    ON calls(client_id);
CREATE INDEX IF NOT EXISTS idx_calls_status    ON calls(status);
CREATE INDEX IF NOT EXISTS idx_calls_created   ON calls(created_at DESC);

-- ── Per-turn conversation log ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS call_turns (
    id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    call_id     UUID        NOT NULL REFERENCES calls(id) ON DELETE CASCADE,
    turn_number INTEGER     NOT NULL,
    speaker     VARCHAR(10) NOT NULL,   -- caller | willow
    audio_path  TEXT,
    transcript  TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_call_turns_call ON call_turns(call_id, turn_number);

-- ── Staff availability (updated by 3CX presence webhook via n8n) ───────────────
CREATE TABLE IF NOT EXISTS staff_capacity (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    staff_id        VARCHAR(50) UNIQUE NOT NULL,  -- 3CX extension e.g. "101"
    staff_name      VARCHAR(100),
    status          VARCHAR(20) NOT NULL DEFAULT 'available',
    -- available | busy | dnd | offline
    active_call_id  VARCHAR(100),
    task_count      INTEGER     NOT NULL DEFAULT 0,
    max_tasks       INTEGER     NOT NULL DEFAULT 20,   -- override per staff
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Seed default staff (update to match real 3CX extensions)
INSERT INTO staff_capacity (staff_id, staff_name, status)
VALUES ('101', 'Bookkeeper', 'available')
ON CONFLICT (staff_id) DO NOTHING;

-- ── Task queue — overflow & autonomous work items ─────────────────────────────
CREATE TABLE IF NOT EXISTS task_queue (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    priority        INTEGER     NOT NULL DEFAULT 5,    -- 1 = urgent, 10 = low
    task_type       VARCHAR(60) NOT NULL,
    -- call_callback | receipt_review | transaction_review |
    -- invoice_approval | client_intake | bas_review | reconciliation_exception
    title           VARCHAR(250) NOT NULL,
    description     TEXT,
    source          VARCHAR(30),                       -- voice_call | email | receipt | system
    source_id       UUID,                              -- calls.id / transactions.id / etc
    client_id       TEXT        REFERENCES client_registry(client_id) ON DELETE SET NULL,
    assigned_to     VARCHAR(50),                       -- staff_id or NULL (unassigned)
    status          VARCHAR(20) NOT NULL DEFAULT 'pending',
    -- pending | in_progress | completed | cancelled | escalated
    due_at          TIMESTAMPTZ,
    kanboard_task_id INTEGER,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at    TIMESTAMPTZ,
    escalated_at    TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_task_queue_status   ON task_queue(status, priority ASC, created_at ASC);
CREATE INDEX IF NOT EXISTS idx_task_queue_assigned ON task_queue(assigned_to, status);
CREATE INDEX IF NOT EXISTS idx_task_queue_client   ON task_queue(client_id);
CREATE INDEX IF NOT EXISTS idx_task_queue_due      ON task_queue(due_at) WHERE due_at IS NOT NULL;

-- ── Useful view: active workload per staff member ─────────────────────────────
CREATE OR REPLACE VIEW v_staff_workload AS
SELECT
    sc.staff_id,
    sc.staff_name,
    sc.status,
    sc.task_count,
    sc.max_tasks,
    COUNT(tq.id) FILTER (WHERE tq.status = 'pending')     AS pending_tasks,
    COUNT(tq.id) FILTER (WHERE tq.status = 'in_progress') AS active_tasks,
    COUNT(tq.id) FILTER (WHERE tq.priority = 1)           AS urgent_tasks,
    MAX(tq.due_at) FILTER (WHERE tq.status != 'completed') AS next_due
FROM staff_capacity sc
LEFT JOIN task_queue tq ON tq.assigned_to = sc.staff_id
    AND tq.status NOT IN ('completed', 'cancelled')
GROUP BY sc.staff_id, sc.staff_name, sc.status, sc.task_count, sc.max_tasks;

-- ── Useful view: today's call summary ────────────────────────────────────────
CREATE OR REPLACE VIEW v_call_summary_today AS
SELECT
    COUNT(*)                                                AS total_calls,
    COUNT(*) FILTER (WHERE willow_handled = TRUE)           AS willow_handled,
    COUNT(*) FILTER (WHERE status = 'transferred')          AS transferred,
    COUNT(*) FILTER (WHERE status = 'voicemail')            AS voicemails,
    COUNT(*) FILTER (WHERE status = 'callback_requested')   AS callbacks,
    ROUND(AVG(duration_seconds))                            AS avg_duration_sec,
    COUNT(DISTINCT client_id)                               AS unique_clients
FROM calls
WHERE created_at >= CURRENT_DATE
  AND direction = 'inbound';

-- ── Schema version ────────────────────────────────────────────────────────────
INSERT INTO schema_migrations (version, description)
VALUES ('003', 'Voice calls, call_turns, staff_capacity, task_queue — receptionist & scale architecture')
ON CONFLICT (version) DO NOTHING;
