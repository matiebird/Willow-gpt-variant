-- =============================================================================
-- Migration 000 — Create Additional Databases
-- Runs first (000_ prefix) via docker-entrypoint-initdb.d on a fresh container.
-- PostgreSQL only executes initdb scripts when the data directory is empty
-- (i.e. the very first container start). This script is idempotent.
--
-- The `willow` database is created automatically by the POSTGRES_DB env var.
-- Kanboard needs its own separate database or it will crash on startup.
-- =============================================================================

SELECT 'CREATE DATABASE kanboard OWNER ' || current_user
    WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'kanboard')
\gexec
