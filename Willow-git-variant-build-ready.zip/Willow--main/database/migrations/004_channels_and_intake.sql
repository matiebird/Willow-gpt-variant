-- =============================================================================
-- MIGRATION 004: Multi-Channel Document Intake + Channel Contacts
-- Supports: Email, SMS, Telegram, Web Upload
-- =============================================================================

-- ── Document intake — every document received from any channel ────────────────
CREATE TABLE IF NOT EXISTS document_intake (
    id                  UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    source              VARCHAR(20) NOT NULL,   -- 'email'|'sms'|'telegram'|'web'|'voice'
    client_id           TEXT        REFERENCES client_registry(client_id) ON DELETE SET NULL,
    original_filename   VARCHAR(250) NOT NULL,
    pdf_path            TEXT,                   -- local path to PDF version
    mime_type           VARCHAR(100),
    original_message    TEXT,                   -- accompanying text from sender
    sender_identifier   VARCHAR(200),           -- email addr / phone / telegram chat_id
    channel_contact_id  UUID,                   -- FK to channel_contacts
    status              VARCHAR(30) NOT NULL DEFAULT 'processing',
    -- processing | draft_created | review_needed | completed | failed | archived
    xero_draft_id       VARCHAR(100),           -- Xero InvoiceID of the DRAFT created
    xero_draft_type     VARCHAR(10),            -- 'invoice' | 'bill'
    task_queue_id       UUID        REFERENCES task_queue(id) ON DELETE SET NULL,
    extraction_result   JSONB,                  -- Grace extraction output
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_document_intake_client  ON document_intake(client_id);
CREATE INDEX IF NOT EXISTS idx_document_intake_source  ON document_intake(source);
CREATE INDEX IF NOT EXISTS idx_document_intake_status  ON document_intake(status);
CREATE INDEX IF NOT EXISTS idx_document_intake_created ON document_intake(created_at DESC);

-- ── Channel contacts — maps phone/email/Telegram IDs to clients ───────────────
CREATE TABLE IF NOT EXISTS channel_contacts (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    channel         VARCHAR(20) NOT NULL,   -- 'telegram' | 'sms' | 'email' | 'whatsapp'
    identifier      VARCHAR(200) NOT NULL,  -- chat_id / phone number / email address
    display_name    VARCHAR(200),
    client_id       TEXT        REFERENCES client_registry(client_id) ON DELETE SET NULL,
    notes           TEXT,
    last_seen       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (channel, identifier)
);

CREATE INDEX IF NOT EXISTS idx_channel_contacts_client ON channel_contacts(client_id);
CREATE INDEX IF NOT EXISTS idx_channel_contacts_ident  ON channel_contacts(channel, identifier);

-- ── Channel interaction log — every inbound/outbound message ─────────────────
CREATE TABLE IF NOT EXISTS channel_contacts_log (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    channel         VARCHAR(20) NOT NULL,
    contact_id      UUID        REFERENCES channel_contacts(id) ON DELETE SET NULL,
    client_id       TEXT        REFERENCES client_registry(client_id) ON DELETE SET NULL,
    direction       VARCHAR(10) NOT NULL DEFAULT 'inbound',  -- inbound | outbound
    content         TEXT,
    file_id         TEXT,                   -- Telegram file_id or media URL
    intake_id       UUID        REFERENCES document_intake(id) ON DELETE SET NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_cclog_contact   ON channel_contacts_log(contact_id);
CREATE INDEX IF NOT EXISTS idx_cclog_client    ON channel_contacts_log(client_id);
CREATE INDEX IF NOT EXISTS idx_cclog_created   ON channel_contacts_log(created_at DESC);

-- ── Xero tokens — OAuth2 access/refresh tokens ───────────────────────────────
-- Populated by Xero OAuth callback flow in n8n.
CREATE TABLE IF NOT EXISTS xero_tokens (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       VARCHAR(100) NOT NULL,
    tenant_name     VARCHAR(200),
    access_token    TEXT        NOT NULL,
    refresh_token   TEXT,
    expires_at      TIMESTAMPTZ NOT NULL,
    scope           TEXT,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Policy audit log — every Xero API call made by Willow ────────────────────
-- Provides an immutable trail showing Willow NEVER published a document.
CREATE TABLE IF NOT EXISTS xero_audit_log (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    action          VARCHAR(50) NOT NULL,   -- 'create_draft_invoice'|'create_draft_bill'|'attach_pdf'|'read'
    resource_type   VARCHAR(30),            -- 'invoice'|'bill'|'contact'|'report'
    resource_id     VARCHAR(100),           -- Xero resource ID
    xero_status     VARCHAR(20),            -- always 'DRAFT' for writes
    intake_id       UUID        REFERENCES document_intake(id) ON DELETE SET NULL,
    client_id       TEXT        REFERENCES client_registry(client_id) ON DELETE SET NULL,
    payload_summary TEXT,                   -- non-sensitive summary of what was sent
    success         BOOLEAN     NOT NULL DEFAULT TRUE,
    error_message   TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE xero_audit_log IS
    'Immutable audit trail. Every Xero write must have xero_status=DRAFT. '
    'If any row shows xero_status != DRAFT for a write action, that is a policy violation.';

CREATE INDEX IF NOT EXISTS idx_xero_audit_client  ON xero_audit_log(client_id);
CREATE INDEX IF NOT EXISTS idx_xero_audit_created ON xero_audit_log(created_at DESC);

-- ── View: pending review queue (dashboard widget) ─────────────────────────────
CREATE OR REPLACE VIEW v_pending_review AS
SELECT
    di.id,
    di.source,
    di.original_filename,
    di.status,
    di.xero_draft_type,
    di.created_at,
    cr.business_name,
    tq.title       AS task_title,
    tq.priority    AS task_priority,
    tq.assigned_to
FROM document_intake di
LEFT JOIN client_registry cr ON di.client_id = cr.client_id
LEFT JOIN task_queue tq ON di.task_queue_id = tq.id
WHERE di.status NOT IN ('completed', 'archived', 'failed')
ORDER BY tq.priority ASC, di.created_at ASC;

-- ── Schema version ────────────────────────────────────────────────────────────
INSERT INTO schema_migrations (version, description)
VALUES ('004', 'Multi-channel document intake, channel contacts, Xero audit log, xero_tokens')
ON CONFLICT (version) DO NOTHING;
