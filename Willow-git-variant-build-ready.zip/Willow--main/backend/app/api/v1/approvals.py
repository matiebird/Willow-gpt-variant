"""
Willow — Pending Approvals API
Serves the approvals queue to the frontend and proxies approve/reject
actions to the n8n Staff Approval Webhook.
"""

import httpx
import structlog
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from typing import Literal, Optional
from datetime import datetime

from app.database import get_db
from app.config import get_settings

log = structlog.get_logger(__name__)
router = APIRouter(prefix="/approvals", tags=["Approvals"])
settings = get_settings()

# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------

class PendingApproval(BaseModel):
    id: str
    approval_type: str
    client_id: Optional[str]
    sequence_id: Optional[str]
    to_email: str
    subject: str
    body: str
    created_by: str
    status: str
    approved_by: Optional[str]
    approved_at: Optional[datetime]
    created_at: datetime


class ApprovalAction(BaseModel):
    approval_id: str
    staff_id: str
    action: Literal["approve", "reject"]


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@router.get("", response_model=list[PendingApproval])
async def list_approvals(
    status: str = Query("pending", description="Filter by status: pending, sent, rejected, expired"),
    limit: int = Query(50, le=200),
    db=Depends(get_db),
):
    """Return pending approval records for the frontend queue."""
    rows = await db.fetch(
        """
        SELECT id, approval_type, client_id, sequence_id, to_email, subject, body,
               created_by, status, approved_by, approved_at, created_at
        FROM pending_approvals
        WHERE status = $1
        ORDER BY created_at DESC
        LIMIT $2
        """,
        status,
        limit,
    )
    return [dict(r) for r in rows]


@router.post("/action")
async def process_action(body: ApprovalAction, db=Depends(get_db)):
    """
    Forward approve/reject to the n8n Staff Approval Webhook.
    n8n handles the actual Gmail send and DB status update.
    """
    # Verify the approval exists and is still pending
    row = await db.fetchrow(
        "SELECT id, status, to_email, subject FROM pending_approvals WHERE id = $1",
        body.approval_id,
    )
    if not row:
        raise HTTPException(status_code=404, detail="Approval not found")
    if row["status"] != "pending":
        raise HTTPException(
            status_code=409,
            detail=f"Approval already {row['status']} — cannot action again",
        )

    # Forward to n8n webhook
    n8n_url = f"{settings.n8n_base_url}/webhook/willow-approve-followup"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(
                n8n_url,
                json={
                    "approval_id": body.approval_id,
                    "staff_id": body.staff_id,
                    "action": body.action,
                },
            )
            resp.raise_for_status()
    except httpx.HTTPStatusError as e:
        log.error("n8n_approval_webhook_error", status=e.response.status_code, detail=str(e))
        raise HTTPException(
            status_code=502,
            detail=f"n8n approval webhook returned {e.response.status_code}",
        )
    except httpx.RequestError as e:
        log.error("n8n_approval_webhook_unreachable", error=str(e))
        raise HTTPException(
            status_code=503,
            detail="Could not reach n8n approval webhook — is n8n running?",
        )

    log.info(
        "approval.actioned",
        approval_id=body.approval_id,
        staff_id=body.staff_id,
        action=body.action,
    )
    return {"ok": True, "action": body.action, "approval_id": body.approval_id}
