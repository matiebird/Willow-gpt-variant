"""
Willows AI — Transactions API Endpoints
"""

import math
import uuid
from datetime import date

import structlog
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models.transaction import Transaction, TransactionStatus, TransactionType
from app.schemas.transaction import (
    TransactionCreate,
    TransactionListResponse,
    TransactionRead,
    TransactionSummary,
    TransactionUpdate,
)

logger = structlog.get_logger(__name__)
router = APIRouter()


@router.get("", response_model=TransactionListResponse)
async def list_transactions(
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=50, ge=1, le=200),
    status_filter: TransactionStatus | None = Query(default=None, alias="status"),
    type_filter: TransactionType | None = Query(default=None, alias="type"),
    date_from: date | None = Query(default=None),
    date_to: date | None = Query(default=None),
    vendor: str | None = Query(default=None),
    db: AsyncSession = Depends(get_db),
) -> TransactionListResponse:
    """List transactions with filtering and pagination."""
    query = select(Transaction).where(Transaction.is_deleted == False)

    if status_filter:
        query = query.where(Transaction.status == status_filter)
    if type_filter:
        query = query.where(Transaction.transaction_type == type_filter)
    if date_from:
        query = query.where(Transaction.date >= date_from)
    if date_to:
        query = query.where(Transaction.date <= date_to)
    if vendor:
        query = query.where(Transaction.vendor_name.ilike(f"%{vendor}%"))

    # Count total
    count_q = select(func.count()).select_from(query.subquery())
    total = (await db.execute(count_q)).scalar_one()

    # Paginate and order
    offset = (page - 1) * page_size
    query = query.order_by(Transaction.date.desc()).offset(offset).limit(page_size)
    result = await db.execute(query)
    transactions = result.scalars().all()

    return TransactionListResponse(
        items=[TransactionRead.model_validate(t) for t in transactions],
        total=total,
        page=page,
        page_size=page_size,
        total_pages=math.ceil(total / page_size) if total else 1,
    )


@router.post("", response_model=TransactionRead, status_code=status.HTTP_201_CREATED)
async def create_transaction(
    data: TransactionCreate,
    db: AsyncSession = Depends(get_db),
) -> TransactionRead:
    """Create a new transaction with optional double-entry journal entries."""
    txn = Transaction(
        date=data.date,
        description=data.description,
        reference=data.reference,
        notes=data.notes,
        transaction_type=data.transaction_type,
        status=TransactionStatus.PENDING,
        amount=data.amount,
        tax_amount=data.tax_amount,
        currency=data.currency,
        vendor_name=data.vendor_name,
        category_id=data.category_id,
    )
    db.add(txn)
    await db.flush()

    # Add journal entries if provided
    from app.models.transaction import TransactionEntry, EntryType
    for entry_data in data.entries:
        entry = TransactionEntry(
            transaction_id=txn.id,
            account_id=entry_data.account_id,
            entry_type=entry_data.entry_type,
            amount=entry_data.amount,
            description=entry_data.description,
        )
        db.add(entry)

    await db.flush()
    await db.refresh(txn)
    return TransactionRead.model_validate(txn)


@router.get("/summary", response_model=TransactionSummary)
async def get_summary(
    date_from: date = Query(default_factory=lambda: date.today().replace(day=1)),
    date_to: date = Query(default_factory=date.today),
    db: AsyncSession = Depends(get_db),
) -> TransactionSummary:
    """Financial summary for a date range (defaults to current month)."""
    from sqlalchemy import and_
    from app.models.transaction import TransactionType

    base = and_(
        Transaction.is_deleted == False,
        Transaction.date >= date_from,
        Transaction.date <= date_to,
        Transaction.status.notin_([TransactionStatus.VOIDED]),
    )

    income_q = select(func.coalesce(func.sum(Transaction.amount), 0)).where(
        and_(base, Transaction.transaction_type == TransactionType.INCOME)
    )
    expense_q = select(func.coalesce(func.sum(Transaction.amount), 0)).where(
        and_(base, Transaction.transaction_type == TransactionType.EXPENSE)
    )
    count_q = select(func.count(Transaction.id)).where(base)
    pending_q = select(func.count(Transaction.id)).where(
        and_(base, Transaction.status == TransactionStatus.PENDING)
    )

    income = (await db.execute(income_q)).scalar_one()
    expenses = (await db.execute(expense_q)).scalar_one()
    count = (await db.execute(count_q)).scalar_one()
    pending = (await db.execute(pending_q)).scalar_one()

    return TransactionSummary(
        period_start=date_from,
        period_end=date_to,
        total_income=income,
        total_expenses=expenses,
        net_profit=income - expenses,
        transaction_count=count,
        pending_count=pending,
    )


@router.get("/{transaction_id}", response_model=TransactionRead)
async def get_transaction(
    transaction_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
) -> TransactionRead:
    result = await db.execute(
        select(Transaction).where(
            Transaction.id == transaction_id,
            Transaction.is_deleted == False,
        )
    )
    txn = result.scalar_one_or_none()
    if not txn:
        raise HTTPException(status_code=404, detail="Transaction not found")
    return TransactionRead.model_validate(txn)


@router.patch("/{transaction_id}", response_model=TransactionRead)
async def update_transaction(
    transaction_id: uuid.UUID,
    data: TransactionUpdate,
    db: AsyncSession = Depends(get_db),
) -> TransactionRead:
    result = await db.execute(
        select(Transaction).where(Transaction.id == transaction_id, Transaction.is_deleted == False)
    )
    txn = result.scalar_one_or_none()
    if not txn:
        raise HTTPException(status_code=404, detail="Transaction not found")

    update_data = data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(txn, field, value)

    await db.flush()
    await db.refresh(txn)
    return TransactionRead.model_validate(txn)


@router.delete("/{transaction_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_transaction(
    transaction_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
) -> None:
    """Soft-delete a transaction (financial records are never hard-deleted)."""
    from datetime import datetime, timezone
    result = await db.execute(
        select(Transaction).where(Transaction.id == transaction_id, Transaction.is_deleted == False)
    )
    txn = result.scalar_one_or_none()
    if not txn:
        raise HTTPException(status_code=404, detail="Transaction not found")

    txn.is_deleted = True
    txn.deleted_at = datetime.now(timezone.utc)
    await db.flush()
