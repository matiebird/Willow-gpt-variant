"""
Voice & Queue endpoints — exposed via the main Willow backend API.
Provides the frontend dashboard with call history, queue status, and
staff workload data. Also receives 3CX presence webhooks.
"""
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Header
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from pydantic import BaseModel

from app.database import get_db
from app.config import settings

router = APIRouter(prefix="/voice", tags=["voice"])


def verify_key(x_api_key: str = Header(...)):
    if x_api_key != settings.willow_api_key:
        raise HTTPException(status_code=403, detail="Forbidden")
    return x_api_key


# ── Call dashboard data ───────────────────────────────────────────────────────

@router.get("/calls/summary")
async def call_summary(db: AsyncSession = Depends(get_db)):
    """Today's call KPIs for the dashboard."""
    result = await db.execute(text("SELECT * FROM v_call_summary_today"))
    row = result.mappings().first()
    return dict(row) if row else {}


@router.get("/calls")
async def list_calls(
    limit: int = 50,
    status: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
):
    q = """
        SELECT c.*, cr.business_name
        FROM calls c
        LEFT JOIN client_registry cr ON c.client_id = cr.client_id
        {where}
        ORDER BY c.created_at DESC
        LIMIT :limit
    """
    where = "WHERE c.status = :status" if status else ""
    result = await db.execute(text(q.format(where=where)),
                               {"limit": limit, "status": status})
    return [dict(r) for r in result.mappings()]


@router.get("/calls/{call_id}/turns")
async def call_turns(call_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        text("SELECT * FROM call_turns WHERE call_id = (SELECT id FROM calls WHERE call_id=:cid) ORDER BY turn_number"),
        {"cid": call_id}
    )
    return [dict(r) for r in result.mappings()]


# ── Task queue ────────────────────────────────────────────────────────────────

@router.get("/queue")
async def get_queue(
    status: str = "pending",
    limit: int = 50,
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        text("""
            SELECT tq.*, cr.business_name
            FROM task_queue tq
            LEFT JOIN client_registry cr ON tq.client_id = cr.client_id
            WHERE tq.status = :status
            ORDER BY tq.priority ASC, tq.created_at ASC
            LIMIT :limit
        """),
        {"status": status, "limit": limit}
    )
    return [dict(r) for r in result.mappings()]


@router.patch("/queue/{task_id}")
async def update_task(task_id: str, body: dict, db: AsyncSession = Depends(get_db)):
    allowed = {"status", "assigned_to", "priority", "kanboard_task_id"}
    updates = {k: v for k, v in body.items() if k in allowed}
    if not updates:
        raise HTTPException(status_code=400, detail="Nothing to update")
    set_clause = ", ".join(f"{k} = :{k}" for k in updates)
    updates["task_id"] = task_id
    await db.execute(
        text(f"UPDATE task_queue SET {set_clause} WHERE id = :task_id::uuid"),
        updates
    )
    await db.commit()
    return {"updated": True}


# ── Queue status (called by willow-task-queue n8n workflow) ─────────────────

class QueueStatusUpdate(BaseModel):
    """Payload shape sent by the willow-task-queue n8n workflow every 5 min."""
    pending_count:   int = 0
    assigned_count:  int = 0
    escalated_count: int = 0
    overdue_count:   int = 0
    escalated_tasks: list = []
    timestamp:       Optional[str] = None


@router.post("/queue-status")
async def receive_queue_status(
    payload: QueueStatusUpdate,
    db: AsyncSession = Depends(get_db),
    api_key: str = Depends(verify_key),
):
    """
    Receives queue statistics from the willow-task-queue n8n workflow.
    Writes a summary row to the audit log so the dashboard can surface
    queue health without hitting the task_queue table directly.
    """
    await db.execute(
        text("""
            INSERT INTO audit_log
              (staff_user_id, staff_name, action, agent, client_id, details, result)
            VALUES
              (NULL, 'Willow System', 'queue_status_update', 'task_queue', NULL,
               jsonb_build_object(
                 'pending_count',   :pending,
                 'assigned_count',  :assigned,
                 'escalated_count', :escalated,
                 'overdue_count',   :overdue,
                 'escalated_tasks', :tasks::jsonb
               ),
               'success')
        """),
        {
            "pending":   payload.pending_count,
            "assigned":  payload.assigned_count,
            "escalated": payload.escalated_count,
            "overdue":   payload.overdue_count,
            "tasks":     __import__('json').dumps(payload.escalated_tasks),
        }
    )
    await db.commit()
    return {
        "received": True,
        "pending_count":   payload.pending_count,
        "assigned_count":  payload.assigned_count,
        "escalated_count": payload.escalated_count,
    }


# ── Staff capacity ────────────────────────────────────────────────────────────

@router.get("/staff")
async def get_staff(db: AsyncSession = Depends(get_db)):
    result = await db.execute(text("SELECT * FROM v_staff_workload"))
    return [dict(r) for r in result.mappings()]


class PresenceWebhook(BaseModel):
    """3CX sends this when a staff member's presence changes."""
    extension: str
    display_name: str
    status: str          # Available | Busy | DoNotDisturb | Away | Offline
    active_call_id: Optional[str] = None


@router.post("/staff/presence")
async def three_cx_presence_webhook(payload: PresenceWebhook, db: AsyncSession = Depends(get_db)):
    """
    3CX Presence webhook endpoint.
    Configure in 3CX: Admin → Integrations → Webhooks → Presence Events
    URL: http://<server>:8080/api/v1/voice/staff/presence
    """
    status_map = {
        "Available": "available",
        "Busy": "busy",
        "DoNotDisturb": "dnd",
        "Away": "dnd",
        "Offline": "offline",
    }
    normalised_status = status_map.get(payload.status, "offline")

    await db.execute(
        text("""
            INSERT INTO staff_capacity (staff_id, staff_name, status, active_call_id, updated_at)
            VALUES (:sid, :name, :status, :call_id, NOW())
            ON CONFLICT (staff_id) DO UPDATE SET
                staff_name     = EXCLUDED.staff_name,
                status         = EXCLUDED.status,
                active_call_id = EXCLUDED.active_call_id,
                updated_at     = NOW()
        """),
        {
            "sid": payload.extension,
            "name": payload.display_name,
            "status": normalised_status,
            "call_id": payload.active_call_id,
        }
    )
    await db.commit()
    return {"received": True, "status": normalised_status}
