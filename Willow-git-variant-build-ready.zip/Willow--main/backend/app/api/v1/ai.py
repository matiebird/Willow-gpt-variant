"""
Willows AI — AI Processing API Endpoints

Endpoints:
  POST /ai/upload          — Upload a receipt image or PDF for AI extraction
  POST /ai/classify        — Classify a raw transaction description string
  GET  /ai/health          — Check Ollama availability and model status
"""

import structlog
from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.schemas.ai import (
    AIHealthResponse,
    ClassifyTransactionRequest,
    ExtractedReceiptData,
    ReceiptUploadResponse,
    TransactionClassification,
)
from app.services.ai_service import AIService, get_ai_service
from app.services.receipt_processor import ReceiptProcessor, ReceiptProcessingError, get_receipt_processor

logger = structlog.get_logger(__name__)
router = APIRouter()


# ---------------------------------------------------------------------------
# Receipt Upload & Extraction
# ---------------------------------------------------------------------------

@router.post(
    "/upload",
    response_model=ReceiptUploadResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Upload receipt for AI extraction",
    description=(
        "Accepts a receipt image (JPEG, PNG, WEBP, TIFF) or PDF invoice. "
        "The file is processed entirely locally: OCR extracts text, the local "
        "LLM extracts structured financial data. Zero data leaves the network."
    ),
)
async def upload_receipt(
    file: UploadFile = File(..., description="Receipt image or PDF (max 20MB)"),
    auto_create_transaction: bool = Query(
        default=False,
        description="Automatically create a Draft transaction if confidence >= 0.8"
    ),
    db: AsyncSession = Depends(get_db),
    processor: ReceiptProcessor = Depends(get_receipt_processor),
) -> ReceiptUploadResponse:
    """
    Full receipt processing pipeline:
    1. Validate file type and size
    2. SHA-256 duplicate detection
    3. OCR (Tesseract for images, pypdf for PDFs)
    4. LLM extraction via local Ollama (mistral/llama3.2)
    5. Persist Receipt record
    6. Optionally auto-create a Draft Transaction
    """
    log = logger.bind(filename=file.filename, content_type=file.content_type)
    log.info("Receipt upload received")

    # Read file data
    try:
        file_data = await file.read()
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Could not read uploaded file: {e}",
        )

    if not file_data:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Uploaded file is empty.",
        )

    # Run the pipeline
    try:
        receipt = await processor.process_upload(
            db=db,
            file_data=file_data,
            original_filename=file.filename or "upload",
            mime_type=file.content_type or "application/octet-stream",
            auto_create_transaction=auto_create_transaction,
        )
    except ReceiptProcessingError as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(e),
        )
    except Exception as e:
        log.error("Unexpected receipt processing error", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Receipt processing failed. Check server logs.",
        )

    # Build response
    extracted_data: ExtractedReceiptData | None = None
    if receipt.ai_extracted_data:
        try:
            extracted_data = ExtractedReceiptData(**receipt.ai_extracted_data)
        except Exception:
            pass  # Return without extracted data if deserialization fails

    message_parts = []
    if receipt.status.value == "duplicate":
        message_parts.append("Duplicate receipt detected.")
    elif receipt.status.value == "review_needed":
        message_parts.append("Low confidence — human review recommended.")
    elif receipt.status.value == "linked":
        message_parts.append("Transaction auto-created from receipt.")
    elif receipt.status.value == "ai_complete":
        message_parts.append("Extraction complete. Review and confirm to create transaction.")

    return ReceiptUploadResponse(
        receipt_id=str(receipt.id),
        status=receipt.status.value,
        confidence=receipt.ai_confidence,
        extracted_data=extracted_data,
        requires_human_review=receipt.status.value in ("review_needed", "failed"),
        message=" ".join(message_parts),
    )


# ---------------------------------------------------------------------------
# Transaction Classification
# ---------------------------------------------------------------------------

@router.post(
    "/classify",
    response_model=TransactionClassification,
    summary="Classify a transaction description",
    description=(
        "Sends a bank transaction description to the local LLM for category "
        "and vendor classification. Useful for bulk CSV import flows."
    ),
)
async def classify_transaction(
    request: ClassifyTransactionRequest,
    ai_service: AIService = Depends(get_ai_service),
) -> TransactionClassification:
    """
    Classify a single transaction description using the local LLM.
    Typically called during bank CSV import to suggest categories.
    """
    result = await ai_service.classify_transaction(
        description=request.description,
        amount=request.amount,
        currency=request.currency,
        transaction_date=request.date,
    )
    return result


# ---------------------------------------------------------------------------
# Health Check
# ---------------------------------------------------------------------------

@router.get(
    "/health",
    response_model=AIHealthResponse,
    summary="Check local AI engine status",
)
async def ai_health(
    ai_service: AIService = Depends(get_ai_service),
) -> AIHealthResponse:
    """
    Verifies the local Ollama instance is reachable and the configured model
    is loaded. Use this to diagnose LLM availability issues.
    """
    result = await ai_service.health_check()
    return AIHealthResponse(
        status=result.get("status", "unknown"),
        configured_model=result.get("configured_model", ""),
        model_available=result.get("model_available", False),
        available_models=result.get("available_models", []),
        detail=result.get("detail"),
    )
