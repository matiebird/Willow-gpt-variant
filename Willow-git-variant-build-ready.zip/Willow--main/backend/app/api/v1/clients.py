"""
Client Status API
==================
"Where are we with [client]?" — the single most important question
a bookkeeper needs answered instantly.

Returns a complete portfolio snapshot: financials, open tasks, deadlines,
recent contacts, draft Xero documents, and pending documents.
"""

from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from datetime import date

from app.database import get_db

router = APIRouter(prefix="/clients", tags=["Client Status"])


@router.get("/search")
async def search_clients(
    q: str = Query(..., min_length=2),
    db: AsyncSession = Depends(get_db),
):
    """Fuzzy search clients by business name or contact name."""
    result = await db.execute(
        text("""
            SELECT client_id, business_name, primary_contact AS contact_name,
                   contact_email AS email, phone, assigned_staff, bas_frequency, abn
            FROM client_registry
            WHERE active = TRUE
              AND (
                business_name ILIKE :q
                OR primary_contact ILIKE :q
                OR contact_email ILIKE :q
                OR abn ILIKE :q
              )
            ORDER BY business_name ASC
            LIMIT 10
        """),
        {"q": f"%{q}%"}
    )
    return [dict(r) for r in result.mappings()]


@router.get("/{client_id}/status")
async def client_status(client_id: str, db: AsyncSession = Depends(get_db)):
    """
    Full portfolio status for a client.
    Called by the main assistant, receptionist, and dashboard.
    """
    # ── Client profile ─────────────────────────────────────────────────────
    client_result = await db.execute(
        text("SELECT * FROM client_registry WHERE client_id = :id AND active = TRUE"),
        {"id": client_id}
    )
    client = client_result.mappings().first()
    if not client:
        raise HTTPException(status_code=404, detail="Client not found")
    client = dict(client)

    # ── Financial summary ──────────────────────────────────────────────────
    fin_result = await db.execute(text("""
        SELECT
            COUNT(*)                                                      AS total_invoices,
            COUNT(*) FILTER (WHERE status = 'draft')                   AS draft_invoices,
            COUNT(*) FILTER (WHERE status IN ('sent','partial')
                             AND due_date >= CURRENT_DATE)               AS outstanding_invoices,
            COUNT(*) FILTER (WHERE status = 'overdue'
                             OR (status IN ('sent','partial') AND due_date < CURRENT_DATE)) AS overdue_invoices,
            COALESCE(SUM(total) FILTER (
                WHERE status IN ('sent','partial') AND due_date >= CURRENT_DATE), 0) AS outstanding_amount,
            COALESCE(SUM(total) FILTER (
                WHERE status = 'overdue' OR (status IN ('sent','partial') AND due_date < CURRENT_DATE)), 0) AS overdue_amount,
            MAX(created_at) FILTER (WHERE status = 'paid')              AS last_payment_date,
            COALESCE(SUM(total) FILTER (
                WHERE status = 'paid'
                AND created_at >= DATE_TRUNC('year', CURRENT_DATE)), 0)  AS ytd_billed
        FROM invoices
        WHERE client_id = :cid
    """), {"cid": client_id})
    financials = dict(fin_result.mappings().first() or {})

    # ── Recent transactions ────────────────────────────────────────────────
    tx_result = await db.execute(text("""
        SELECT t.date, t.description, t.vendor_name AS vendor, t.amount, t.status, c.name AS category
        FROM transactions t
        LEFT JOIN categories c ON t.category_id = c.id
        WHERE t.client_id = :cid
        ORDER BY t.date DESC
        LIMIT 5
    """), {"cid": client_id})
    recent_transactions = [dict(r) for r in tx_result.mappings()]

    # ── Open tasks ────────────────────────────────────────────────────────
    task_result = await db.execute(text("""
        SELECT id, priority, task_type, title, assigned_to, status, due_at, created_at
        FROM task_queue
        WHERE client_id = :cid
          AND status NOT IN ('completed', 'cancelled')
        ORDER BY priority ASC, created_at ASC
        LIMIT 10
    """), {"cid": client_id})
    open_tasks = [dict(r) for r in task_result.mappings()]

    # ── ATO deadlines ──────────────────────────────────────────────────────
    deadline_result = await db.execute(text("""
        SELECT client_id, business_name, bas_frequency,
               assigned_staff, next_bas_due
        FROM v_upcoming_deadlines
        WHERE client_id = :cid
    """), {"cid": client_id})
    deadline = dict(deadline_result.mappings().first() or {})

    # ── Recent calls ──────────────────────────────────────────────────────
    call_result = await db.execute(text("""
        SELECT call_id, status, intent, transcript,
               willow_handled, transferred_to, duration_seconds, created_at
        FROM calls
        WHERE client_id = :cid
        ORDER BY created_at DESC
        LIMIT 3
    """), {"cid": client_id})
    recent_calls = [dict(r) for r in call_result.mappings()]

    # ── Pending documents ─────────────────────────────────────────────────
    doc_result = await db.execute(text("""
        SELECT id, source, original_filename, status,
               xero_draft_id, xero_draft_type, created_at
        FROM document_intake
        WHERE client_id = :cid
          AND status != 'archived'
        ORDER BY created_at DESC
        LIMIT 5
    """), {"cid": client_id})
    pending_docs = [dict(r) for r in doc_result.mappings()]

    # ── Build plain-English summary ───────────────────────────────────────
    today_str = date.today().strftime("%-d %B %Y")
    summary_parts = [f"{client['business_name']} — Status as at {today_str}", ""]

    # Financials
    if financials.get("overdue_invoices", 0) > 0:
        summary_parts.append(
            f"OVERDUE: {financials['overdue_invoices']} invoice(s) — "
            f"${financials['overdue_amount']:,.2f} outstanding"
        )
    if financials.get("outstanding_invoices", 0) > 0:
        summary_parts.append(
            f"OUTSTANDING: {financials['outstanding_invoices']} invoice(s) — "
            f"${financials['outstanding_amount']:,.2f} not yet due"
        )
    if financials.get("draft_invoices", 0) > 0:
        summary_parts.append(
            f"DRAFTS: {financials['draft_invoices']} draft invoice(s) awaiting bookkeeper review"
        )

    # Recent activity
    if recent_transactions:
        tx = recent_transactions[0]
        summary_parts.append(
            f"LAST TRANSACTION: {tx.get('date', '')} — {tx.get('description', '')} "
            f"${abs(tx.get('amount', 0)):,.2f} ({tx.get('status', '')})"
        )

    # Tasks
    if open_tasks:
        task_titles = ", ".join(f"\"{t['title']}\"" for t in open_tasks[:3])
        summary_parts.append(f"OPEN TASKS: {len(open_tasks)} — {task_titles}")

    # Deadlines
    if deadline.get("next_bas_due"):
        summary_parts.append(f"BAS DUE: {deadline['next_bas_due']}")

    # Last call
    if recent_calls:
        c = recent_calls[0]
        handled = "Willow handled" if c.get("willow_handled") else "Staff handled"
        summary_parts.append(
            f"LAST CALL: {c['created_at'].strftime('%-d %b') if hasattr(c.get('created_at'), 'strftime') else c.get('created_at', '')} "
            f"— {handled}"
            + (f", transferred to ext {c['transferred_to']}" if c.get("transferred_to") else "")
        )

    # Pending docs
    if pending_docs:
        summary_parts.append(
            f"PENDING DOCUMENTS: {len(pending_docs)} document(s) in review"
        )

    summary_text = "\n".join(summary_parts)

    return {
        "client": client,
        "financials": financials,
        "recent_transactions": recent_transactions,
        "open_tasks": open_tasks,
        "deadlines": deadline,
        "recent_calls": recent_calls,
        "pending_documents": pending_docs,
        "summary_text": summary_text,
    }


@router.get("/{client_id}/timeline")
async def client_timeline(
    client_id: str,
    days: int = 30,
    db: AsyncSession = Depends(get_db),
):
    """Chronological timeline of all interactions for a client."""
    result = await db.execute(text("""
        SELECT 'call'        AS event_type, call_id AS ref, intent AS detail,
               created_at,
               CASE WHEN willow_handled THEN 'Willow' ELSE 'Staff' END AS actor
        FROM calls WHERE client_id = :cid
          AND created_at >= NOW() - (:days * INTERVAL '1 day')
        UNION ALL
        SELECT 'document'    AS event_type, id::text AS ref,
               source || ': ' || original_filename AS detail,
               created_at, 'Willow' AS actor
        FROM document_intake WHERE client_id = :cid
          AND created_at >= NOW() - (:days * INTERVAL '1 day')
        UNION ALL
        SELECT 'task'        AS event_type, id::text AS ref,
               title AS detail, created_at, assigned_to AS actor
        FROM task_queue WHERE client_id = :cid
          AND created_at >= NOW() - (:days * INTERVAL '1 day')
        ORDER BY created_at DESC
        LIMIT 50
    """), {"cid": client_id, "days": days})
    return [dict(r) for r in result.mappings()]
