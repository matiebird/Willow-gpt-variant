"""
Willows AI — Chart of Accounts API Endpoints
"""

import uuid
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models.account import Account, AccountType, AccountSubtype

router = APIRouter()


class AccountRead(BaseModel):
    id: uuid.UUID
    code: str
    name: str
    description: str | None
    account_type: AccountType
    account_subtype: AccountSubtype | None
    parent_id: uuid.UUID | None
    balance: float
    currency: str
    is_active: bool
    is_bank_account: bool
    is_system: bool
    model_config = {"from_attributes": True}


class AccountCreate(BaseModel):
    code: str = Field(max_length=20)
    name: str = Field(max_length=200)
    description: str | None = None
    account_type: AccountType
    account_subtype: AccountSubtype | None = None
    parent_id: uuid.UUID | None = None
    currency: str = Field(default="AUD", max_length=3)
    is_bank_account: bool = False
    tax_code: str | None = None


@router.get("", response_model=list[AccountRead])
async def list_accounts(
    account_type: AccountType | None = None,
    active_only: bool = True,
    db: AsyncSession = Depends(get_db),
) -> list[AccountRead]:
    query = select(Account).where(Account.is_deleted == False)
    if account_type:
        query = query.where(Account.account_type == account_type)
    if active_only:
        query = query.where(Account.is_active == True)
    query = query.order_by(Account.code)
    result = await db.execute(query)
    return [AccountRead.model_validate(a) for a in result.scalars().all()]


@router.post("", response_model=AccountRead, status_code=status.HTTP_201_CREATED)
async def create_account(
    data: AccountCreate,
    db: AsyncSession = Depends(get_db),
) -> AccountRead:
    # Check code uniqueness
    existing = await db.execute(select(Account).where(Account.code == data.code))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=409, detail=f"Account code '{data.code}' already exists.")

    account = Account(**data.model_dump())
    db.add(account)
    await db.flush()
    await db.refresh(account)
    return AccountRead.model_validate(account)


@router.get("/{account_id}", response_model=AccountRead)
async def get_account(
    account_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
) -> AccountRead:
    result = await db.execute(
        select(Account).where(Account.id == account_id, Account.is_deleted == False)
    )
    account = result.scalar_one_or_none()
    if not account:
        raise HTTPException(status_code=404, detail="Account not found")
    return AccountRead.model_validate(account)
