"""
Policies API
============
Manage Willow's internal knowledge base — company policies uploaded as
PDF or plain text documents.

Endpoints:
  POST   /v1/policies              — Upload & ingest a new policy document
  GET    /v1/policies              — List all policies (with optional filters)
  GET    /v1/policies/{id}         — Get single policy (full text + chunk count)
  PATCH  /v1/policies/{id}         — Update title, category, or active status
  DELETE /v1/policies/{id}         — Soft-delete (sets active = FALSE)
  GET    /v1/policies/search       — Semantic search (called by n8n before LLM)
  POST   /v1/policies/{id}/reindex — Re-embed a policy after text edit
"""

import json
from typing import Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.services.policy_service import (
    extract_text,
    format_policy_context,
    ingest_policy,
    search_policies,
)

router = APIRouter(prefix="/policies", tags=["Policy Knowledge Base"])

VALID_CATEGORIES = {
    "engagement", "disengagement", "xero", "staff",
    "compliance", "billing", "communication", "general",
}
MAX_FILE_MB = 10


# ── Pydantic ──────────────────────────────────────────────────────────────────

class PolicyUpdate(BaseModel):
    title: Optional[str] = None
    category: Optional[str] = None
    active: Optional[bool] = None


# ── POST /v1/policies — Upload + ingest ───────────────────────────────────────

@router.post("", status_code=201)
async def upload_policy(
    title: str = Form(..., min_length=3, max_length=200),
    category: str = Form(...),
    created_by: str = Form(..., description="user_id of the staff member uploading"),
    file: UploadFile = File(..., description="PDF or plain text file (max 10MB)"),
    db: AsyncSession = Depends(get_db),
):
    """
    Upload a policy document. Willow will:
    1. Extract all text from the file
    2. Split it into overlapping chunks (~400 words each)
    3. Embed each chunk locally via nomic-embed-text (Ollama)
    4. Store the vectors in pgvector for semantic retrieval

    Supported formats: PDF, TXT, MD
    After upload, the policy is immediately available to all Willow queries.
    """
    if category not in VALID_CATEGORIES:
        raise HTTPException(
            status_code=422,
            detail=f"Invalid category. Must be one of: {', '.join(sorted(VALID_CATEGORIES))}",
        )

    # Check file size
    file_bytes = await file.read()
    size_mb = len(file_bytes) / (1024 * 1024)
    if size_mb > MAX_FILE_MB:
        raise HTTPException(
            status_code=413,
            detail=f"File too large ({size_mb:.1f}MB). Maximum is {MAX_FILE_MB}MB.",
        )

    if not file_bytes:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")

    # Extract text
    try:
        raw_text = extract_text(file_bytes, file.filename or "", file.content_type or "")
    except Exception as e:
        raise HTTPException(
            status_code=422,
            detail=f"Could not extract text from file: {e}. Upload a PDF or plain text file.",
        )

    if len(raw_text.strip()) < 50:
        raise HTTPException(
            status_code=422,
            detail="Extracted text is too short. Check the file contains readable content.",
        )

    # Ingest (chunk + embed + store)
    try:
        policy_id = await ingest_policy(
            db=db,
            title=title,
            category=category,
            raw_text=raw_text,
            original_filename=file.filename,
            created_by=created_by,
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Policy ingestion failed: {e}. Ensure Ollama is running with nomic-embed-text.",
        )

    # Count chunks stored
    chunk_count = await db.execute(
        text("SELECT COUNT(*) FROM policy_chunks WHERE policy_id = :pid"),
        {"pid": policy_id},
    )
    n_chunks = chunk_count.scalar()

    return {
        "policy_id": policy_id,
        "title": title,
        "category": category,
        "chunks_stored": n_chunks,
        "message": (
            f"Policy '{title}' ingested successfully. "
            f"{n_chunks} chunks embedded and indexed. "
            f"Willow will reference this policy immediately."
        ),
    }


# ── GET /v1/policies — List all ───────────────────────────────────────────────

@router.get("")
async def list_policies(
    active_only: bool = Query(default=True),
    category: Optional[str] = Query(default=None),
    db: AsyncSession = Depends(get_db),
):
    """List all stored policies with metadata and chunk counts."""
    base = """
        SELECT p.id, p.title, p.category, p.original_filename,
               p.version, p.active, p.created_by, p.created_at,
               COUNT(pc.id) AS chunk_count
        FROM policies p
        LEFT JOIN policy_chunks pc ON pc.policy_id = p.id
        WHERE 1=1
    """
    params = {}

    if active_only:
        base += " AND p.active = TRUE"
    if category:
        base += " AND p.category = :cat"
        params["cat"] = category

    base += " GROUP BY p.id ORDER BY p.category, p.title"

    result = await db.execute(text(base), params)
    rows = [dict(r) for r in result.mappings()]

    return {"policies": rows, "total": len(rows)}


# ── GET /v1/policies/search — Semantic search (used by n8n) ──────────────────

@router.get("/search")
async def search_policy_knowledge(
    q: str = Query(..., min_length=3, description="Natural language query"),
    top_k: int = Query(default=4, ge=1, le=10),
    category: Optional[str] = Query(default=None),
    context: str = Query(default="api", description="Caller: main_assistant | receptionist | api"),
    staff_user_id: Optional[str] = Query(default=None),
    format: str = Query(default="chunks", description="chunks | prompt_block"),
    db: AsyncSession = Depends(get_db),
):
    """
    Semantic search across all active policy chunks.
    Called by n8n workflows before every LLM call to retrieve relevant policies.

    - format=chunks  → returns raw chunk list (for custom prompt building)
    - format=prompt_block → returns pre-formatted text block ready to inject
    """
    chunks = await search_policies(
        db=db,
        query=q,
        top_k=top_k,
        category=category if category in VALID_CATEGORIES else None,
        context=context,
        staff_user_id=staff_user_id,
    )

    if format == "prompt_block":
        block = format_policy_context(chunks)
        return {
            "query": q,
            "chunks_found": len(chunks),
            "prompt_block": block,
        }

    return {
        "query": q,
        "chunks_found": len(chunks),
        "chunks": [
            {
                "chunk_text": c["chunk_text"],
                "policy_title": c["policy_title"],
                "category": c["category"],
                "similarity": round(float(c["similarity"]), 4),
            }
            for c in chunks
        ],
    }


# ── GET /v1/policies/{id} — Single policy ─────────────────────────────────────

@router.get("/{policy_id}")
async def get_policy(policy_id: str, db: AsyncSession = Depends(get_db)):
    """Full policy detail including raw text and chunk count."""
    result = await db.execute(
        text("SELECT * FROM policies WHERE id = :id::uuid"),
        {"id": policy_id},
    )
    policy = result.mappings().first()
    if not policy:
        raise HTTPException(status_code=404, detail="Policy not found.")

    chunk_count = await db.execute(
        text("SELECT COUNT(*) FROM policy_chunks WHERE policy_id = :pid::uuid"),
        {"pid": policy_id},
    )

    return {
        **dict(policy),
        "chunk_count": chunk_count.scalar(),
    }


# ── PATCH /v1/policies/{id} — Update metadata ────────────────────────────────

@router.patch("/{policy_id}")
async def update_policy(
    policy_id: str,
    payload: PolicyUpdate,
    requested_by: str = Query(...),
    db: AsyncSession = Depends(get_db),
):
    """
    Update policy title, category, or active status.
    To replace the document content, use the reindex endpoint.
    """
    existing = await db.execute(
        text("SELECT id, title FROM policies WHERE id = :id::uuid"),
        {"id": policy_id},
    )
    row = existing.mappings().first()
    if not row:
        raise HTTPException(status_code=404, detail="Policy not found.")

    updates = {}
    if payload.title is not None:
        updates["title"] = payload.title
    if payload.category is not None:
        if payload.category not in VALID_CATEGORIES:
            raise HTTPException(status_code=422, detail="Invalid category.")
        updates["category"] = payload.category
    if payload.active is not None:
        updates["active"] = payload.active

    if not updates:
        return {"message": "No changes made.", "policy_id": policy_id}

    set_clause = ", ".join(f"{k} = :{k}" for k in updates)
    params = {**updates, "pid": policy_id}

    await db.execute(
        text(f"UPDATE policies SET {set_clause}, updated_at = now() WHERE id = :pid::uuid"),
        params,
    )
    await db.commit()

    return {
        "policy_id": policy_id,
        "changes": updates,
        "message": f"Policy '{row['title']}' updated.",
    }


# ── DELETE /v1/policies/{id} — Soft delete ────────────────────────────────────

@router.delete("/{policy_id}")
async def delete_policy(
    policy_id: str,
    requested_by: str = Query(...),
    db: AsyncSession = Depends(get_db),
):
    """
    Soft-delete a policy (sets active = FALSE).
    The document and its chunks remain in the database for audit purposes.
    Use PATCH active=true to reactivate.
    """
    existing = await db.execute(
        text("SELECT id, title FROM policies WHERE id = :id::uuid"),
        {"id": policy_id},
    )
    row = existing.mappings().first()
    if not row:
        raise HTTPException(status_code=404, detail="Policy not found.")

    await db.execute(
        text("UPDATE policies SET active = FALSE, updated_at = now() WHERE id = :id::uuid"),
        {"id": policy_id},
    )
    await db.commit()

    return {
        "policy_id": policy_id,
        "message": f"Policy '{row['title']}' deactivated. Willow will no longer reference it.",
    }


# ── POST /v1/policies/{id}/reindex — Re-embed after edit ─────────────────────

@router.post("/{policy_id}/reindex", status_code=202)
async def reindex_policy(
    policy_id: str,
    requested_by: str = Query(...),
    db: AsyncSession = Depends(get_db),
):
    """
    Delete all existing chunks for this policy and re-embed from the stored raw_text.
    Use this after editing a policy's content manually via the database.
    """
    existing = await db.execute(
        text("SELECT id, title, category, raw_text, original_filename, created_by FROM policies WHERE id = :id::uuid"),
        {"id": policy_id},
    )
    row = existing.mappings().first()
    if not row:
        raise HTTPException(status_code=404, detail="Policy not found.")

    # Delete old chunks
    await db.execute(
        text("DELETE FROM policy_chunks WHERE policy_id = :pid::uuid"),
        {"pid": policy_id},
    )
    await db.commit()

    # Re-ingest (this commits internally)
    from app.services.policy_service import chunk_text, embed_text, _vec_to_pg

    chunks = chunk_text(row["raw_text"])
    reindexed = 0
    for idx, chunk in enumerate(chunks):
        try:
            vec = await embed_text(chunk)
            await db.execute(
                text("""
                    INSERT INTO policy_chunks (policy_id, chunk_index, chunk_text, embedding)
                    VALUES (:pid::uuid, :idx, :text, :vec::vector)
                """),
                {"pid": policy_id, "idx": idx, "text": chunk, "vec": _vec_to_pg(vec)},
            )
            reindexed += 1
        except Exception as e:
            pass  # Log but continue

    # Bump version
    await db.execute(
        text("UPDATE policies SET version = version + 1, updated_at = now() WHERE id = :id::uuid"),
        {"id": policy_id},
    )
    await db.commit()

    return {
        "policy_id": policy_id,
        "chunks_reindexed": reindexed,
        "message": f"Policy '{row['title']}' reindexed with {reindexed} chunks.",
    }
