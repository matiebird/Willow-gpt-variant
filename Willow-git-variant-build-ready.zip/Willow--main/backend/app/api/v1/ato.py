"""
ATO Reference API
==================
Exposes Willow's ATO knowledge base to n8n workflows and the dashboard.

Endpoints:
  POST /v1/ato/suggest-coding   — Suggest account code + GST for a supplier
  POST /v1/ato/ask              — Answer a plain-English ATO / coding question
  GET  /v1/ato/health           — Check if ATO KB is loaded and embed model is up
"""

from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.services.ato_service import (
    answer_ato_question,
    is_ato_question,
    suggest_account_coding,
)

router = APIRouter(prefix="/ato", tags=["ATO Reference"])


# ── Pydantic models ───────────────────────────────────────────────────────────

class CodingSuggestionRequest(BaseModel):
    supplier_name: str
    description: str
    amount: Optional[float] = None
    staff_user_id: Optional[str] = None


class ATOQuestionRequest(BaseModel):
    question: str
    staff_user_id: Optional[str] = None
    context: Optional[str] = "main_assistant"


# ── POST /v1/ato/suggest-coding ───────────────────────────────────────────────

@router.post("/suggest-coding")
async def suggest_coding(
    payload: CodingSuggestionRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Suggest the correct Xero account code and GST treatment for a new supplier.

    Called automatically by:
    - Grace extraction workflow when no prior invoices from supplier exist
    - The bookkeeper review task description (adds ATO note to draft)

    Returns account_code, gst_type, bookkeeper_note, confidence, requires_review.
    If confidence < 0.55, the Xero draft is flagged for mandatory review.
    """
    if not payload.supplier_name.strip() and not payload.description.strip():
        raise HTTPException(
            status_code=422,
            detail="At least one of supplier_name or description must be provided.",
        )

    result = await suggest_account_coding(
        db=db,
        supplier_name=payload.supplier_name,
        description=payload.description,
        amount=payload.amount,
        staff_user_id=payload.staff_user_id,
    )

    return {
        "supplier": payload.supplier_name,
        "description": payload.description,
        **result,
        "gst_label": {
            "INPUT2":  "GST on Expenses (10%)",
            "FRE":     "GST-Free",
            "NOINPUT": "BAS Excluded",
            "GSTNEXUS":"GST on Expenses — verify type",
        }.get(result["gst_type"], result["gst_type"]),
    }


# ── POST /v1/ato/ask ─────────────────────────────────────────────────────────

@router.post("/ask")
async def ask_ato(
    payload: ATOQuestionRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Answer a plain-English ATO or coding question using Willow's policy KB.

    Called by:
    - Main assistant (n8n) when is_ato_question() returns True
    - Receptionist when a call involves a compliance question
    - Telegram/SMS when a staff member sends a coding question

    Returns answer, policy_references, confidence, suggest_review.
    """
    if not payload.question.strip():
        raise HTTPException(status_code=422, detail="Question cannot be empty.")

    result = await answer_ato_question(
        db=db,
        question=payload.question,
        staff_user_id=payload.staff_user_id,
    )

    return {
        "question": payload.question,
        **result,
        "is_ato_question": is_ato_question(payload.question),
    }


# ── GET /v1/ato/health ────────────────────────────────────────────────────────

@router.get("/health")
async def ato_health(db: AsyncSession = Depends(get_db)):
    """
    Verify the ATO knowledge base is loaded and the embedding model is available.
    """
    import httpx
    from app.services.ato_service import OLLAMA_BASE_URL, EMBED_MODEL

    # Count loaded policies
    policy_count = await db.execute(
        text("SELECT COUNT(*) FROM policies WHERE category = 'compliance' AND active = TRUE")
    )
    chunk_count = await db.execute(
        text("""
            SELECT COUNT(*) FROM policy_chunks pc
            JOIN policies p ON p.id = pc.policy_id
            WHERE p.category = 'compliance' AND p.active = TRUE
        """)
    )

    n_policies = policy_count.scalar() or 0
    n_chunks = chunk_count.scalar() or 0

    # Check embedding model
    embed_ok = False
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.get(f"{OLLAMA_BASE_URL}/api/tags")
            tags = resp.json().get("models", [])
            embed_ok = any(EMBED_MODEL in m.get("name", "") for m in tags)
    except Exception:
        pass

    return {
        "compliance_policies_loaded": n_policies,
        "compliance_chunks_indexed": n_chunks,
        "embed_model": EMBED_MODEL,
        "embed_model_available": embed_ok,
        "status": "ready" if (n_policies > 0 and embed_ok) else "degraded",
        "message": (
            "ATO knowledge base ready."
            if n_policies > 0 and embed_ok
            else (
                "No ATO policies loaded — run ingest_ato_resources.py"
                if n_policies == 0
                else f"Embed model '{EMBED_MODEL}' not found in Ollama"
            )
        ),
    }
