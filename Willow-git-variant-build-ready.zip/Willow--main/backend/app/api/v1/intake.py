"""
Document Intake API
====================
Receives documents from n8n channel workflows (Telegram, SMS, email, web).
Runs the full intake pipeline: PDF → Xero draft → attachment → task.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from pydantic import BaseModel
from typing import Optional

from app.database import get_db
from app.services.document_intake import DocumentIntakeService, IntakeDocument

router = APIRouter(prefix="/intake", tags=["Document Intake"])


class IntakeRequest(BaseModel):
    source: str               # 'email' | 'sms' | 'telegram' | 'web'
    client_id: Optional[str] = None
    file_data: str            # base64-encoded file
    filename: str
    mime_type: str = "application/octet-stream"
    original_message: Optional[str] = None
    sender_identifier: Optional[str] = None
    channel_contact_id: Optional[str] = None


class SMSRequest(BaseModel):
    """For outbound SMS confirmation replies."""
    to: str
    body: str


@router.post("/document")
async def intake_document(req: IntakeRequest, db: AsyncSession = Depends(get_db)):
    """
    Main intake endpoint. Called by n8n Telegram, SMS, and email workflows.
    Returns immediately with intake_id; processing continues asynchronously.
    """
    doc = IntakeDocument(**req.model_dump())
    service = DocumentIntakeService(db)
    result = await service.process(doc)
    return result.model_dump()


@router.get("/documents")
async def list_documents(
    source: Optional[str] = None,
    status: Optional[str] = None,
    limit: int = 50,
    db: AsyncSession = Depends(get_db),
):
    """List recent intake documents — for the dashboard."""
    conditions = []
    params = {"limit": limit}
    if source:
        conditions.append("source = :source")
        params["source"] = source
    if status:
        conditions.append("status = :status")
        params["status"] = status

    where = ("WHERE " + " AND ".join(conditions)) if conditions else ""
    result = await db.execute(
        text(f"""
            SELECT di.*, cr.business_name
            FROM document_intake di
            LEFT JOIN client_registry cr ON di.client_id = cr.client_id
            {where}
            ORDER BY di.created_at DESC
            LIMIT :limit
        """),
        params
    )
    return [dict(r) for r in result.mappings()]


@router.get("/documents/{intake_id}")
async def get_document(intake_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        text("SELECT * FROM document_intake WHERE id = :id::uuid"),
        {"id": intake_id}
    )
    row = result.mappings().first()
    if not row:
        raise HTTPException(status_code=404, detail="Document not found")
    return dict(row)


@router.post("/sms/send")
async def send_sms(req: SMSRequest, db: AsyncSession = Depends(get_db)):
    """
    Outbound SMS — routes via 3CX SMS API (local, no cloud).
    3CX handles SMS delivery; we just POST to its API.
    """
    import httpx, os
    three_cx_host = os.getenv("THREE_CX_HOST", "localhost")
    api_key = os.getenv("THREE_CX_SMS_API_KEY", "")

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(
                f"http://{three_cx_host}/api/v1/sms/send",
                json={"to": req.to, "body": req.body},
                headers={"Authorization": f"Bearer {api_key}"},
            )
            return {"sent": resp.status_code < 300, "status_code": resp.status_code}
    except Exception as e:
        # Log but don't fail — SMS delivery is best-effort
        return {"sent": False, "error": str(e)}


@router.get("/channels/contacts")
async def list_channel_contacts(db: AsyncSession = Depends(get_db)):
    """List all known channel contacts (Telegram, SMS, email)."""
    result = await db.execute(
        text("""
            SELECT cc.*, cr.business_name
            FROM channel_contacts cc
            LEFT JOIN client_registry cr ON cc.client_id = cr.client_id
            ORDER BY cc.last_seen DESC
        """)
    )
    return [dict(r) for r in result.mappings()]


@router.post("/channels/contacts")
async def upsert_channel_contact(body: dict, db: AsyncSession = Depends(get_db)):
    """Register or update a channel contact (called by n8n when new contact seen)."""
    await db.execute(text("""
        INSERT INTO channel_contacts
            (id, channel, identifier, display_name, client_id, last_seen)
        VALUES
            (gen_random_uuid(), :channel, :identifier, :display_name,
             :client_id::uuid, NOW())
        ON CONFLICT (channel, identifier) DO UPDATE SET
            display_name = EXCLUDED.display_name,
            client_id    = COALESCE(EXCLUDED.client_id, channel_contacts.client_id),
            last_seen    = NOW()
    """), {
        "channel": body.get("channel"),
        "identifier": body.get("identifier"),
        "display_name": body.get("display_name", ""),
        "client_id": body.get("client_id"),
    })
    await db.commit()
    return {"saved": True}
