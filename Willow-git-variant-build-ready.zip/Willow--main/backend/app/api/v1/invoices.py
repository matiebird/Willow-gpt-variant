"""
Willows AI — Invoices API Endpoints
"""

import uuid
from datetime import date, datetime, timezone
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models.invoice import Invoice, InvoiceItem, InvoiceStatus, InvoiceType

router = APIRouter()


# ── Schemas (inline for brevity — extract to schemas/invoice.py in production) ──

class InvoiceItemCreate(BaseModel):
    description: str = Field(max_length=500)
    quantity: Decimal = Field(default=Decimal("1"), gt=0)
    unit_price: Decimal = Field(ge=0)
    discount_percent: Decimal = Field(default=Decimal("0"), ge=0, le=100)
    tax_rate_id: uuid.UUID | None = None
    account_id: uuid.UUID | None = None
    sort_order: int = 0


class InvoiceCreate(BaseModel):
    invoice_type: InvoiceType
    counterparty_name: str = Field(max_length=200)
    counterparty_email: str | None = None
    counterparty_address: str | None = None
    counterparty_abn: str | None = None
    issue_date: date
    due_date: date | None = None
    po_number: str | None = None
    notes: str | None = None
    terms: str | None = None
    currency: str = Field(default="AUD", max_length=3)
    line_items: list[InvoiceItemCreate] = Field(min_length=1)


class InvoiceRead(BaseModel):
    id: uuid.UUID
    invoice_number: str
    invoice_type: InvoiceType
    status: InvoiceStatus
    counterparty_name: str
    counterparty_email: str | None
    issue_date: date
    due_date: date | None
    subtotal: Decimal
    tax_total: Decimal
    total: Decimal
    amount_paid: Decimal
    currency: str
    created_at: datetime
    model_config = {"from_attributes": True}


# ── Invoice Number Generator ─────────────────────────────────────────────────

async def _next_invoice_number(db: AsyncSession, invoice_type: InvoiceType) -> str:
    prefix = "INV" if invoice_type == InvoiceType.RECEIVABLE else "BILL"
    count_result = await db.execute(
        select(func.count(Invoice.id)).where(Invoice.invoice_type == invoice_type)
    )
    count = (count_result.scalar_one() or 0) + 1
    year = date.today().year
    return f"{prefix}-{year}-{count:04d}"


# ── Endpoints ────────────────────────────────────────────────────────────────

@router.get("", response_model=list[InvoiceRead])
async def list_invoices(
    invoice_type: InvoiceType | None = None,
    status_filter: InvoiceStatus | None = Query(default=None, alias="status"),
    db: AsyncSession = Depends(get_db),
) -> list[InvoiceRead]:
    query = select(Invoice).where(Invoice.is_deleted == False)
    if invoice_type:
        query = query.where(Invoice.invoice_type == invoice_type)
    if status_filter:
        query = query.where(Invoice.status == status_filter)
    query = query.order_by(Invoice.issue_date.desc())
    result = await db.execute(query)
    return [InvoiceRead.model_validate(i) for i in result.scalars().all()]


@router.post("", response_model=InvoiceRead, status_code=status.HTTP_201_CREATED)
async def create_invoice(
    data: InvoiceCreate,
    db: AsyncSession = Depends(get_db),
) -> InvoiceRead:
    invoice_number = await _next_invoice_number(db, data.invoice_type)

    # Compute totals from line items
    subtotal = Decimal("0")
    tax_total = Decimal("0")

    invoice = Invoice(
        invoice_number=invoice_number,
        invoice_type=data.invoice_type,
        status=InvoiceStatus.DRAFT,
        counterparty_name=data.counterparty_name,
        counterparty_email=data.counterparty_email,
        counterparty_address=data.counterparty_address,
        counterparty_abn=data.counterparty_abn,
        issue_date=data.issue_date,
        due_date=data.due_date,
        po_number=data.po_number,
        notes=data.notes,
        terms=data.terms,
        currency=data.currency,
    )
    db.add(invoice)
    await db.flush()

    for item_data in data.line_items:
        gross = item_data.quantity * item_data.unit_price
        discount_amount = gross * (item_data.discount_percent / 100)
        net = gross - discount_amount
        # Tax computed separately when tax_rate_id is resolved
        line_total = net
        subtotal += net

        item = InvoiceItem(
            invoice_id=invoice.id,
            description=item_data.description,
            quantity=item_data.quantity,
            unit_price=item_data.unit_price,
            discount_percent=item_data.discount_percent,
            tax_rate_id=item_data.tax_rate_id,
            tax_amount=Decimal("0"),  # Resolved via tax_rate lookup in production
            line_total=line_total,
            account_id=item_data.account_id,
            sort_order=item_data.sort_order,
        )
        db.add(item)

    invoice.subtotal = subtotal
    invoice.tax_total = tax_total
    invoice.total = subtotal + tax_total

    await db.flush()
    await db.refresh(invoice)
    return InvoiceRead.model_validate(invoice)


@router.get("/{invoice_id}", response_model=InvoiceRead)
async def get_invoice(
    invoice_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
) -> InvoiceRead:
    result = await db.execute(
        select(Invoice).where(Invoice.id == invoice_id, Invoice.is_deleted == False)
    )
    invoice = result.scalar_one_or_none()
    if not invoice:
        raise HTTPException(status_code=404, detail="Invoice not found")
    return InvoiceRead.model_validate(invoice)


@router.patch("/{invoice_id}/status", response_model=InvoiceRead)
async def update_invoice_status(
    invoice_id: uuid.UUID,
    new_status: InvoiceStatus,
    db: AsyncSession = Depends(get_db),
) -> InvoiceRead:
    result = await db.execute(
        select(Invoice).where(Invoice.id == invoice_id, Invoice.is_deleted == False)
    )
    invoice = result.scalar_one_or_none()
    if not invoice:
        raise HTTPException(status_code=404, detail="Invoice not found")

    invoice.status = new_status
    if new_status == InvoiceStatus.PAID:
        invoice.paid_date = date.today()
        invoice.amount_paid = invoice.total

    await db.flush()
    await db.refresh(invoice)
    return InvoiceRead.model_validate(invoice)
