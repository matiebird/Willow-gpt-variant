"""
SMS Send endpoint — receives outbound SMS dispatch requests from n8n workflows.

Architecture note: Willow is 100% local. This endpoint accepts a send request,
logs it to the audit table, and dispatches via the configured provider (env var).
Supported providers:
  - asterisk  →  uses Asterisk AMI SendText action (for SIP providers with SMS)
  - log_only  →  logs only, no dispatch (development / testing)

Set SMS_PROVIDER=asterisk in .env to enable real dispatch.
"""

import logging
from typing import Optional
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Header
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from pydantic import BaseModel

from app.database import get_db
from app.config import settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/sms", tags=["SMS"])


def verify_key(x_api_key: str = Header(...)):
    if x_api_key != settings.willow_api_key:
        raise HTTPException(status_code=403, detail="Forbidden")
    return x_api_key


class SmsSendRequest(BaseModel):
    to: str                          # Destination phone number (E.164)
    from_number: Optional[str] = None  # Sender number / alias (aliased from "from")
    body: str                        # Message body (max 480 chars)
    client_id: Optional[str] = None  # Optional — for audit log linkage
    staff_user_id: Optional[str] = None

    class Config:
        # Accept "from" as an alias since "from" is a Python keyword
        populate_by_name = True
        fields = {"from_number": {"alias": "from"}}


class SmsSendResponse(BaseModel):
    success: bool
    message_id: Optional[str] = None
    provider: str
    queued_at: str


@router.post("/send", response_model=SmsSendResponse)
async def send_sms(
    request: SmsSendRequest,
    db: AsyncSession = Depends(get_db),
    api_key: str = Depends(verify_key),
):
    """
    Dispatch an outbound SMS message.

    Called by n8n workflows (willow-sms, willow-receptionist) to send SMS
    replies to clients. Logs every dispatch to the audit table regardless
    of provider outcome.

    n8n payload shape:
        { "to": "+61412...", "from": "+61800...", "body": "Hi Jane..." }
    """
    if not request.body or not request.to:
        raise HTTPException(status_code=422, detail="to and body are required")

    # Truncate to 480 chars (3 SMS segments) — safety guard
    body_text = request.body[:480]

    provider = getattr(settings, "sms_provider", "log_only")
    message_id: Optional[str] = None
    queued_at = datetime.now(timezone.utc).isoformat()

    # ── Dispatch ──────────────────────────────────────────────────────────────
    if provider == "asterisk":
        # Asterisk AMI SendText action
        # Requires Asterisk AMI enabled in manager.conf and
        # ASTERISK_AMI_HOST / ASTERISK_AMI_PORT / ASTERISK_AMI_SECRET in settings.
        try:
            import socket
            ami_host = getattr(settings, "asterisk_ami_host", "willow-asterisk")
            ami_port = int(getattr(settings, "asterisk_ami_port", 5038))
            ami_secret = getattr(settings, "asterisk_ami_secret", "")

            ami_cmd = (
                "Action: SendText\r\n"
                f"Number: {request.to}\r\n"
                f"Message: {body_text}\r\n"
                "\r\n"
            )
            with socket.create_connection((ami_host, ami_port), timeout=5) as s:
                s.recv(1024)  # banner
                # Authenticate
                s.sendall(
                    f"Action: Login\r\nUsername: willow\r\nSecret: {ami_secret}\r\n\r\n".encode()
                )
                s.recv(1024)
                # Send
                s.sendall(ami_cmd.encode())
                resp = s.recv(1024).decode(errors="replace")
            message_id = f"ami-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}-{request.to[-4:]}"
            logger.info("SMS dispatched via Asterisk AMI to %s", request.to)
        except Exception as exc:
            logger.error("Asterisk AMI SMS dispatch failed: %s", exc)
            # Fall through — log the failure but don't 500
            provider = "asterisk_failed"
    else:
        # log_only — development mode
        logger.info(
            "SMS [log_only] to=%s from=%s body=%s",
            request.to,
            request.from_number,
            body_text[:80],
        )
        message_id = f"log-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"

    # ── Audit log ─────────────────────────────────────────────────────────────
    try:
        await db.execute(
            text("""
                INSERT INTO audit_log
                  (staff_user_id, staff_name, action, agent, client_id, details, result)
                VALUES
                  (:uid, 'Willow SMS', 'sms_sent', 'sms', :client_id,
                   jsonb_build_object(
                     'to',         :to,
                     'body_len',   :body_len,
                     'provider',   :provider,
                     'message_id', :message_id
                   ),
                   :result)
            """),
            {
                "uid": request.staff_user_id,
                "client_id": request.client_id,
                "to": request.to,
                "body_len": len(body_text),
                "provider": provider,
                "message_id": message_id,
                "result": "success" if "failed" not in provider else "failed",
            },
        )
        await db.commit()
    except Exception as exc:
        logger.warning("SMS audit log write failed: %s", exc)
        # Don't propagate — SMS was attempted

    return SmsSendResponse(
        success="failed" not in provider,
        message_id=message_id,
        provider=provider,
        queued_at=queued_at,
    )


@router.get("/status")
async def sms_status(api_key: str = Depends(verify_key)):
    """Health/config check — returns configured SMS provider."""
    provider = getattr(settings, "sms_provider", "log_only")
    return {"provider": provider, "status": "ok"}
