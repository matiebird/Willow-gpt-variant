"""Sellable Willow product API: secure coordinator endpoints for n8n/voice/workers.

Product boundary:
- n8n triggers and transports data only
- this API owns classification, routing, task creation, audit logging and safety rules
- all AI output becomes a reviewable task, not a direct financial action
"""

from __future__ import annotations

import json
from typing import Any
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.dependencies_security import firm_scope, require_internal_api_key
from app.services.ai_orchestrator import classify_email, grace_extract, hayley_reconcile, receptionist_turn

router = APIRouter(prefix="/product", dependencies=[Depends(require_internal_api_key)])


class EmailTriageRequest(BaseModel):
    message_id: str | None = None
    thread_id: str | None = None
    sender: str | None = Field(default=None, alias="from")
    subject: str | None = None
    snippet: str | None = None
    body: str | None = None
    attachments: list[dict[str, Any]] = Field(default_factory=list)


class GraceExtractRequest(BaseModel):
    source_id: str | None = None
    filename: str | None = None
    mime_type: str | None = None
    sender: str | None = None
    email_subject: str | None = None
    text: str | None = None
    ocr_text: str | None = None
    file_base64: str | None = None
    email: dict[str, Any] | None = None


class HayleyReconcileRequest(BaseModel):
    source_id: str | None = None
    document_id: str | None = None
    invoice: dict[str, Any] = Field(default_factory=dict)
    transactions: list[dict[str, Any]] = Field(default_factory=list)
    client_id: str | None = None
    context: dict[str, Any] = Field(default_factory=dict)


class VoiceTurnRequest(BaseModel):
    call_id: str
    caller_number: str | None = None
    transcript: str
    turn_number: int = 1
    session_history: list[dict[str, str]] = Field(default_factory=list)


class TaskUpdateRequest(BaseModel):
    status: str | None = None
    assigned_staff_id: str | None = None
    payload_patch: dict[str, Any] | None = None


async def audit_event(
    db: AsyncSession,
    *,
    firm_id: UUID | None,
    agent: str,
    action: str,
    source: str,
    source_id: str | None,
    details: dict[str, Any],
) -> None:
    await db.execute(
        text(
            """
            INSERT INTO product_audit_log
                (firm_id, agent, action, source, source_id, details)
            VALUES
                (:firm_id, :agent, :action, :source, :source_id, CAST(:details AS jsonb))
            """
        ),
        {
            "firm_id": firm_id,
            "agent": agent,
            "action": action,
            "source": source,
            "source_id": source_id,
            "details": json.dumps(details, default=str),
        },
    )


async def create_task(
    db: AsyncSession,
    *,
    firm_id: UUID | None,
    title: str,
    task_type: str,
    priority: int,
    source: str,
    source_id: str | None,
    payload: dict[str, Any],
    assigned_staff_id: str | None = None,
) -> str:
    inserted = await db.execute(
        text(
            """
            INSERT INTO product_tasks
                (firm_id, title, task_type, priority, status, source, source_id, assigned_staff_id, payload)
            VALUES
                (:firm_id, :title, :task_type, :priority, 'pending', :source, :source_id, :assigned_staff_id, CAST(:payload AS jsonb))
            RETURNING id
            """
        ),
        {
            "firm_id": firm_id,
            "title": title[:180],
            "task_type": task_type,
            "priority": priority,
            "source": source,
            "source_id": source_id,
            "assigned_staff_id": assigned_staff_id,
            "payload": json.dumps(payload, default=str),
        },
    )
    return str(inserted.scalar_one())


def priority_from_urgency(urgency: str | None) -> int:
    if urgency == "urgent":
        return 5
    if urgency == "time_sensitive":
        return 3
    return 1


async def lookup_route(
    db: AsyncSession,
    *,
    firm_id: UUID | None,
    document_type: str | None,
    urgency: str | None,
) -> dict[str, Any]:
    row = await db.execute(
        text(
            """
            SELECT assigned_staff_id, fallback_email, extension
            FROM staff_routing_rules
            WHERE active = TRUE
              AND (:firm_id IS NULL OR firm_id = :firm_id OR firm_id IS NULL)
              AND (document_type IS NULL OR document_type = :document_type)
              AND (urgency IS NULL OR urgency = :urgency)
            ORDER BY
              CASE WHEN firm_id = :firm_id THEN 0 ELSE 1 END,
              CASE WHEN document_type = :document_type THEN 0 ELSE 1 END,
              CASE WHEN urgency = :urgency THEN 0 ELSE 1 END,
              created_at ASC
            LIMIT 1
            """
        ),
        {"firm_id": firm_id, "document_type": document_type, "urgency": urgency},
    )
    found = row.mappings().first()
    return dict(found) if found else {"assigned_staff_id": None, "fallback_email": None, "extension": None}


@router.get("/health")
async def product_health(db: AsyncSession = Depends(get_db)):
    db_ok = False
    try:
        await db.execute(text("SELECT 1"))
        db_ok = True
    except Exception:
        db_ok = False
    return {"ok": True, "product_api": "ready", "database": db_ok}


@router.post("/email/triage")
async def triage_email(
    payload: EmailTriageRequest,
    db: AsyncSession = Depends(get_db),
    firm_id: UUID | None = Depends(firm_scope),
):
    """Classify an email, create an auditable task, and return n8n routing instructions."""
    data = payload.model_dump(by_alias=True)
    result = await classify_email(data)

    confidence = float(result.get("confidence") or 0)
    document_type = result.get("document_type") or "general_query"
    urgency = result.get("urgency") or "routine"
    recommended_action = result.get("recommended_action") or "create_task"
    if recommended_action in {"spam", "ignore"} or document_type in {"spam", "newsletter", "irrelevant"}:
        route = "ignore"
    else:
        route = recommended_action

    needs_review = bool(result.get("needs_human_review", True)) or confidence < 0.8
    route_info = await lookup_route(db, firm_id=firm_id, document_type=document_type, urgency=urgency)

    await audit_event(
        db,
        firm_id=firm_id,
        agent="willow",
        action="email_triaged",
        source="email",
        source_id=payload.message_id,
        details={"input": data, "classification": result, "needs_review": needs_review},
    )

    task_id = None
    if route != "ignore":
        task_id = await create_task(
            db,
            firm_id=firm_id,
            title=f"{document_type}: {payload.subject or 'Untitled email'}",
            task_type="email_triage" if route == "create_task" else route,
            priority=priority_from_urgency(urgency),
            source="email",
            source_id=payload.message_id,
            assigned_staff_id=route_info.get("assigned_staff_id"),
            payload={"email": data, "classification": result, "route": route, "needs_review": needs_review},
        )

    return {
        "ok": True,
        "agent": "willow",
        "task_id": task_id,
        "needs_review": needs_review,
        "route": route,
        "classification": result,
        "assigned_staff_id": route_info.get("assigned_staff_id"),
        "fallback_email": route_info.get("fallback_email"),
        "extension": route_info.get("extension"),
    }


@router.post("/grace/extract")
async def grace_extract_endpoint(
    payload: GraceExtractRequest,
    db: AsyncSession = Depends(get_db),
    firm_id: UUID | None = Depends(firm_scope),
):
    """Grace document extraction. Always creates a reviewable extraction record/task."""
    data = payload.model_dump()
    result = await grace_extract(data)
    confidence = float(result.get("confidence") or 0)
    needs_review = bool(result.get("needs_review", True)) or confidence < 0.85

    inserted = await db.execute(
        text(
            """
            INSERT INTO product_documents
                (firm_id, source, source_id, filename, mime_type, extraction, confidence, status)
            VALUES
                (:firm_id, 'grace', :source_id, :filename, :mime_type, CAST(:extraction AS jsonb), :confidence, :status)
            RETURNING id
            """
        ),
        {
            "firm_id": firm_id,
            "source_id": payload.source_id,
            "filename": payload.filename,
            "mime_type": payload.mime_type,
            "extraction": json.dumps(result, default=str),
            "confidence": confidence,
            "status": "review_needed" if needs_review else "extracted",
        },
    )
    document_id = str(inserted.scalar_one())

    task_id = await create_task(
        db,
        firm_id=firm_id,
        title=f"Review {result.get('document_type', 'document')}: {result.get('vendor') or payload.filename or 'unknown'}",
        task_type="document_review" if needs_review else "send_to_hayley",
        priority=3 if needs_review else 2,
        source="document",
        source_id=document_id,
        payload={"document_id": document_id, "input": data, "extraction": result, "needs_review": needs_review},
    )

    await audit_event(
        db,
        firm_id=firm_id,
        agent="grace",
        action="document_extracted",
        source="document",
        source_id=document_id,
        details={"input_summary": {"filename": payload.filename, "source_id": payload.source_id}, "extraction": result},
    )

    return {
        "ok": True,
        "agent": "grace",
        "document_id": document_id,
        "task_id": task_id,
        "needs_review": needs_review,
        "extraction": result,
        "route": "manual_review" if needs_review else "send_to_hayley",
    }


@router.post("/hayley/reconcile")
async def hayley_reconcile_endpoint(
    payload: HayleyReconcileRequest,
    db: AsyncSession = Depends(get_db),
    firm_id: UUID | None = Depends(firm_scope),
):
    """Hayley reconciliation. Produces a recommendation only; no external writes."""
    data = payload.model_dump()
    result = await hayley_reconcile(data)
    confidence = float(result.get("confidence") or 0)
    needs_review = bool(result.get("needs_review", True)) or confidence < 0.9

    inserted = await db.execute(
        text(
            """
            INSERT INTO product_reconciliations
                (firm_id, document_id, source_id, result, confidence, status)
            VALUES
                (:firm_id, :document_id, :source_id, CAST(:result AS jsonb), :confidence, :status)
            RETURNING id
            """
        ),
        {
            "firm_id": firm_id,
            "document_id": payload.document_id,
            "source_id": payload.source_id,
            "result": json.dumps(result, default=str),
            "confidence": confidence,
            "status": "review_needed" if needs_review else "matched",
        },
    )
    reconciliation_id = str(inserted.scalar_one())

    task_id = await create_task(
        db,
        firm_id=firm_id,
        title=f"Review reconciliation: {result.get('match_status', 'unknown')}",
        task_type="reconciliation_review",
        priority=3 if needs_review else 2,
        source="reconciliation",
        source_id=reconciliation_id,
        payload={"reconciliation_id": reconciliation_id, "input": data, "result": result, "needs_review": needs_review},
    )

    await audit_event(
        db,
        firm_id=firm_id,
        agent="hayley",
        action="reconciliation_recommended",
        source="reconciliation",
        source_id=reconciliation_id,
        details={"input": data, "result": result, "needs_review": needs_review},
    )

    return {
        "ok": True,
        "agent": "hayley",
        "reconciliation_id": reconciliation_id,
        "task_id": task_id,
        "needs_review": needs_review,
        "result": result,
        "route": "manual_review" if needs_review else result.get("recommended_action", "manual_review"),
    }


@router.post("/voice/turn")
async def voice_turn(
    payload: VoiceTurnRequest,
    db: AsyncSession = Depends(get_db),
    firm_id: UUID | None = Depends(firm_scope),
):
    """Handle one receptionist turn and return a telephony-safe response envelope."""
    context: dict[str, Any] = {}
    if payload.caller_number:
        row = await db.execute(
            text(
                """
                SELECT client_id, business_name, assigned_staff, phone
                FROM client_registry
                WHERE (:firm_id IS NULL OR firm_id = :firm_id OR firm_id IS NULL)
                  AND phone = :phone
                LIMIT 1
                """
            ),
            {"firm_id": firm_id, "phone": payload.caller_number},
        )
        found = row.mappings().first()
        if found:
            context["client"] = dict(found)

    result = await receptionist_turn(payload.model_dump(), context=context)
    confidence = float(result.get("confidence") or 0)
    if confidence < 0.65 and result.get("action") == "transfer":
        result["action"] = "callback"
        result["reason"] = "Low-confidence transfer changed to callback for safety"

    await audit_event(
        db,
        firm_id=firm_id,
        agent="willow_receptionist",
        action="voice_turn",
        source="voice_call",
        source_id=payload.call_id,
        details={"input": payload.model_dump(), "context": context, "result": result},
    )

    task_id = None
    if result.get("action") in {"callback", "voicemail", "create_task"}:
        task_id = await create_task(
            db,
            firm_id=firm_id,
            title=f"Call follow-up: {payload.caller_number or payload.call_id}",
            task_type="call_callback",
            priority=5 if result.get("priority") == "urgent" else 2,
            source="voice_call",
            source_id=payload.call_id,
            payload={"call": payload.model_dump(), "ai": result, "context": context},
        )

    return {
        "ok": True,
        "task_id": task_id,
        "response_text": result.get("text") or "I can help with that. I’ll organise a callback for you.",
        "action": result.get("action") or "callback",
        "extension": result.get("extension"),
        "reason": result.get("reason"),
        "confidence": confidence,
        "call_id": payload.call_id,
    }


@router.get("/tasks")
async def list_tasks(
    db: AsyncSession = Depends(get_db),
    firm_id: UUID | None = Depends(firm_scope),
    status_filter: str = Query(default="pending", alias="status"),
    limit: int = Query(default=50, ge=1, le=200),
):
    rows = await db.execute(
        text(
            """
            SELECT id, title, task_type, priority, status, source, source_id, assigned_staff_id, payload, created_at, updated_at
            FROM product_tasks
            WHERE (:firm_id IS NULL OR firm_id = :firm_id OR firm_id IS NULL)
              AND (:status_filter = 'all' OR status = :status_filter)
            ORDER BY priority DESC, created_at ASC
            LIMIT :limit
            """
        ),
        {"firm_id": firm_id, "status_filter": status_filter, "limit": limit},
    )
    return {"ok": True, "tasks": [dict(r) for r in rows.mappings().all()]}


@router.patch("/tasks/{task_id}")
async def update_task(
    task_id: UUID,
    payload: TaskUpdateRequest,
    db: AsyncSession = Depends(get_db),
    firm_id: UUID | None = Depends(firm_scope),
):
    allowed_statuses = {"pending", "in_progress", "approved", "rejected", "completed", "failed", "archived"}
    if payload.status and payload.status not in allowed_statuses:
        raise HTTPException(400, f"Invalid status. Allowed: {sorted(allowed_statuses)}")

    current = await db.execute(
        text(
            """
            SELECT payload FROM product_tasks
            WHERE id = :task_id AND (:firm_id IS NULL OR firm_id = :firm_id OR firm_id IS NULL)
            """
        ),
        {"task_id": task_id, "firm_id": firm_id},
    )
    row = current.mappings().first()
    if not row:
        raise HTTPException(404, "Task not found")
    merged_payload = dict(row["payload"] or {})
    if payload.payload_patch:
        merged_payload.update(payload.payload_patch)

    await db.execute(
        text(
            """
            UPDATE product_tasks
            SET status = COALESCE(:status, status),
                assigned_staff_id = COALESCE(:assigned_staff_id, assigned_staff_id),
                payload = CAST(:payload AS jsonb),
                updated_at = NOW(),
                completed_at = CASE WHEN :status IN ('completed','approved','rejected','archived') THEN NOW() ELSE completed_at END
            WHERE id = :task_id
              AND (:firm_id IS NULL OR firm_id = :firm_id OR firm_id IS NULL)
            """
        ),
        {
            "task_id": task_id,
            "firm_id": firm_id,
            "status": payload.status,
            "assigned_staff_id": payload.assigned_staff_id,
            "payload": json.dumps(merged_payload, default=str),
        },
    )
    await audit_event(
        db,
        firm_id=firm_id,
        agent="willow_api",
        action="task_updated",
        source="task",
        source_id=str(task_id),
        details=payload.model_dump(exclude_none=True),
    )
    return {"ok": True, "task_id": str(task_id)}
