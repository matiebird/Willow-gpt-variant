"""
Willow License API
Endpoints for license status, hardware fingerprint, and key activation.
All cryptographic verification runs locally — no external calls.
"""

import base64
import datetime
import hashlib
import json
import os
import subprocess
from pathlib import Path

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from fastapi import APIRouter, Depends, HTTPException, Query
from app.dependencies import require_admin
from app.database import get_db
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel

router = APIRouter()

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

WILLOW_DIR        = Path(os.getenv("WILLOW_DIR", "/opt/willow"))
LICENSE_FILE      = WILLOW_DIR / "license.key"
FIRST_BOOT_FILE   = WILLOW_DIR / ".first-boot"
LAST_VERIFIED_FILE = WILLOW_DIR / ".last-verified"
TRIAL_DAYS        = 30

# Ed25519 public key — safe to distribute, private key is offline with EDS
WILLOW_PUBLIC_KEY_B64 = "eTseg3Uqy8qSeoRmH9iylTg2/urr2ILatEBMRiGvUnk="

# Modes that block write operations
READONLY_MODES = {"readonly"}
PAID_MARKER_FILE  = WILLOW_DIR / ".paid-license-installed"

# Licence modes:
# trial          = never paid, within trial, full writes allowed
# full           = paid, active, updates/support according to payload
# expiring       = paid, active but expires within 30 days
# expired        = paid licence has lapsed; writes continue, updates pause
# readonly       = never-paid trial expired only
# invalid        = invalid/tampered key; if previously paid, writes still continue but updates pause


# ---------------------------------------------------------------------------
# Hardware fingerprint
# ---------------------------------------------------------------------------

def compute_hardware_id() -> str:
    """
    Replicates hardware-id.sh: SHA256(dmi_uuid:mac)[:16].
    Reads /sys/class/dmi/id/product_uuid (accessible inside Docker via /sys)
    and the first non-loopback MAC from /sys/class/net/.
    Falls back to /etc/machine-id when DMI is unavailable.
    """
    # DMI UUID
    uuid = ""
    for path in ["/sys/class/dmi/id/product_uuid", "/etc/machine-id"]:
        try:
            uuid = Path(path).read_text().strip().lower()
            if uuid:
                break
        except Exception:
            continue
    if not uuid:
        uuid = "no-dmi-uuid"

    # First non-loopback MAC
    mac = "000000000000"
    try:
        net_path = Path("/sys/class/net")
        for iface in sorted(net_path.iterdir()):
            if iface.name == "lo":
                continue
            addr_file = iface / "address"
            if addr_file.exists():
                candidate = addr_file.read_text().strip().replace(":", "")
                if candidate and candidate != "000000000000":
                    mac = candidate
                    break
    except Exception:
        pass

    return hashlib.sha256(f"{uuid}:{mac}".encode()).hexdigest()[:16]


# ---------------------------------------------------------------------------
# License verification (inline — no shell subprocess required)
# ---------------------------------------------------------------------------

def _trial_status() -> dict:
    """Trial mode. Read-only is only used when no paid licence was ever installed."""
    today = datetime.date.today()
    previously_paid = PAID_MARKER_FILE.exists()

    if not FIRST_BOOT_FILE.exists():
        try:
            FIRST_BOOT_FILE.parent.mkdir(parents=True, exist_ok=True)
            FIRST_BOOT_FILE.write_text(today.isoformat())
        except Exception:
            pass
        first_boot = today
    else:
        try:
            first_boot = datetime.date.fromisoformat(FIRST_BOOT_FILE.read_text().strip())
        except Exception:
            first_boot = today

    days_used      = (today - first_boot).days
    days_remaining = max(0, TRIAL_DAYS - days_used)
    trial_expires  = (first_boot + datetime.timedelta(days=TRIAL_DAYS)).isoformat()

    base = {
        "firm": "Unlicensed",
        "tier": "trial",
        "seats": 999 if days_remaining > 0 else 0,
        "expires": trial_expires,
        "days_remaining": days_remaining,
        "paid_license_installed": previously_paid,
        "updates_enabled": False,
        "support_active": False,
        "support_plan": None,
        "support_expires": None,
    }

    if days_remaining > 0:
        return {
            **base,
            "mode": "trial",
            "readonly": False,
            "writes_allowed": True,
            "banner": f"Trial mode — {days_remaining} of {TRIAL_DAYS} days remaining.",
            "message": (
                f"Trial mode — {days_remaining} of {TRIAL_DAYS} days remaining. "
                "Install a paid licence to unlock perpetual fallback."
            ),
        }

    if previously_paid:
        # Defensive fallback: this should only happen if a licence file was removed
        # after activation. We do not punish the customer by blocking writes.
        return {
            **base,
            "mode": "expired",
            "readonly": False,
            "writes_allowed": True,
            "banner": "Paid licence previously installed. Updates paused — renew to resume.",
            "message": (
                "No active licence file found, but this appliance has previously had a paid licence. "
                "Willow continues operating; updates and new premium features are paused."
            ),
        }

    return {
        **base,
        "mode": "readonly",
        "readonly": True,
        "writes_allowed": False,
        "banner": "Trial expired — read-only until a paid licence is installed.",
        "message": (
            "Trial period has ended. Willow is read-only because no paid licence has ever been installed. "
            "Existing data remains accessible. Install a paid licence to continue processing."
        ),
    }


def _mark_paid_license_installed() -> None:
    try:
        PAID_MARKER_FILE.parent.mkdir(parents=True, exist_ok=True)
        if not PAID_MARKER_FILE.exists():
            PAID_MARKER_FILE.write_text(datetime.date.today().isoformat())
    except Exception:
        pass


def _support_state(data: dict, today: datetime.date) -> dict:
    support_plan = data.get("support_plan") or data.get("support") or None
    support_expires_str = data.get("support_expires") or data.get("support_until") or None
    support_active = False
    if support_expires_str:
        try:
            support_expires = datetime.date.fromisoformat(str(support_expires_str))
            support_active = support_expires >= today
        except Exception:
            support_active = False
    else:
        support_expires_str = None

    return {
        "support_active": bool(support_active),
        "support_plan": support_plan if support_active else None,
        "support_expires": support_expires_str,
    }

def _verify_key_content(content: str) -> dict:
    """Verify Ed25519 signature and return license state dict."""
    lines = [ln.strip() for ln in content.strip().splitlines() if ln.strip()]
    if len(lines) < 3 or lines[0] != "WILLOW_LICENSE_V1":
        return {
            "mode": "invalid", "firm": "Invalid", "tier": "invalid",
            "seats": 0, "expires": "", "days_remaining": 0, "readonly": True,
            "message": "License file format is invalid (expected WILLOW_LICENSE_V1 header).",
        }

    try:
        payload_bytes = base64.b64decode(lines[1])
        sig_bytes     = base64.b64decode(lines[2])
    except Exception as exc:
        return {
            "mode": "invalid", "firm": "Invalid", "tier": "invalid",
            "seats": 0, "expires": "", "days_remaining": 0, "readonly": True,
            "message": f"License file is corrupted: {exc}",
        }

    # Ed25519 signature verification
    try:
        pub_raw = base64.b64decode(WILLOW_PUBLIC_KEY_B64)
        pub_key = Ed25519PublicKey.from_public_bytes(pub_raw)
        pub_key.verify(sig_bytes, payload_bytes)
    except InvalidSignature:
        return {
            "mode": "invalid", "firm": "Invalid", "tier": "invalid",
            "seats": 0, "expires": "", "days_remaining": 0, "readonly": True,
            "message": (
                "License signature is invalid — the file may be corrupted or tampered with. "
                "Contact sales@engineereddatasystems.com.au for a replacement."
            ),
        }
    except Exception as exc:
        return {
            "mode": "invalid", "firm": "Invalid", "tier": "invalid",
            "seats": 0, "expires": "", "days_remaining": 0, "readonly": True,
            "message": f"Signature verification error: {exc}",
        }

    # Parse payload
    try:
        data = json.loads(payload_bytes.decode())
    except Exception:
        return {
            "mode": "invalid", "firm": "Invalid", "tier": "invalid",
            "seats": 0, "expires": "", "days_remaining": 0, "readonly": True,
            "message": "License payload is malformed.",
        }

    firm  = data.get("firm", "Unknown")
    tier  = data.get("tier", "unknown")
    seats = data.get("seats", 0)
    expires_str = data.get("expires", "")

    # Hardware binding
    expected_hw = data.get("hardware_id", "")
    if expected_hw and expected_hw != "any":
        actual_hw = compute_hardware_id()
        if actual_hw != expected_hw:
            return {
                "mode": "invalid", "firm": firm, "tier": tier,
                "seats": seats, "expires": expires_str, "days_remaining": 0,
                "readonly": True,
                "message": (
                    f"This license is bound to a different machine (ID: {expected_hw}). "
                    f"This server reports: {actual_hw}. "
                    "Contact sales@engineereddatasystems.com.au for a hardware transfer."
                ),
            }

    # Expiry
    today = datetime.date.today()
    try:
        expires = datetime.date.fromisoformat(expires_str)
    except Exception:
        expires = today

    days_remaining = (expires - today).days

    support = _support_state(data, today)
    _mark_paid_license_installed()

    if days_remaining < 0:
        return {
            "mode": "expired", "firm": firm, "tier": tier,
            "seats": seats, "expires": expires_str, "days_remaining": 0,
            "readonly": False,
            "writes_allowed": True,
            "paid_license_installed": True,
            "updates_enabled": False,
            **support,
            "banner": "Updates paused — renew to resume. Willow continues operating normally.",
            "message": (
                f"Paid licence expired {abs(days_remaining)} days ago. "
                "Perpetual fallback is active: writes and daily operations continue. "
                "Updates, new premium features and non-included support are paused until renewal."
            ),
        }

    mode = "expiring" if days_remaining <= 30 else "full"
    return {
        "mode": mode, "firm": firm, "tier": tier,
        "seats": seats, "expires": expires_str, "days_remaining": days_remaining,
        "readonly": False,
        "writes_allowed": True,
        "paid_license_installed": True,
        "updates_enabled": True,
        **support,
        "banner": f"Licensed to {firm} · {tier.title()} tier · {days_remaining} days remaining.",
        "message": f"Licensed to {firm} · {tier.title()} tier · {days_remaining} days remaining.",
    }


def get_license_state() -> dict:
    """
    Read live license state directly from the key file.
    Falls back to environment variables set at container startup if the
    key file is absent or /opt/willow is not mounted.
    """
    if LICENSE_FILE.exists():
        try:
            content = LICENSE_FILE.read_text().strip()
            state = _verify_key_content(content)
            if state.get("mode") == "invalid":
                if PAID_MARKER_FILE.exists():
                    # Previously paid appliances keep operating. Invalid/corrupt keys pause
                    # updates and require replacement, but do not lock customer data/workflows.
                    return {
                        **state,
                        "mode": "expired",
                        "readonly": False,
                        "writes_allowed": True,
                        "paid_license_installed": True,
                        "updates_enabled": False,
                        "support_active": False,
                        "support_plan": None,
                        "support_expires": None,
                        "banner": "Licence needs attention. Willow continues operating; updates paused.",
                        "message": state.get("message", "Licence could not be verified. Willow continues operating under perpetual fallback; updates are paused."),
                    }
                trial = _trial_status()
                trial["message"] = "Licence file ignored: " + state.get("message", "invalid licence") + " " + trial.get("message", "")
                trial["banner"] = trial.get("banner") or trial["message"]
                return trial
            return state
        except Exception:
            pass

    # Fall back to env vars (set by verify-license.sh at startup)
    mode = os.getenv("WILLOW_MODE", "trial")
    try:
        days = int(os.getenv("WILLOW_DAYS_REMAINING", "30") or 30)
    except ValueError:
        days = 30
    try:
        seats = int(os.getenv("WILLOW_SEATS", "0") or 0)
    except ValueError:
        seats = 0

    return {
        "mode":           mode,
        "firm":           os.getenv("WILLOW_FIRM", ""),
        "tier":           os.getenv("WILLOW_TIER", "trial"),
        "seats":          seats,
        "expires":        os.getenv("WILLOW_EXPIRES", ""),
        "days_remaining": days,
        "readonly":       mode in READONLY_MODES,
        "writes_allowed": mode not in READONLY_MODES,
        "paid_license_installed": mode in {"full", "expiring", "expired"},
        "updates_enabled": mode in {"full", "expiring"},
        "support_active": os.getenv("WILLOW_SUPPORT_ACTIVE", "false").lower() == "true",
        "support_plan": os.getenv("WILLOW_SUPPORT_PLAN") or None,
        "support_expires": os.getenv("WILLOW_SUPPORT_EXPIRES") or None,
        "banner":        _env_mode_message(mode, days, os.getenv("WILLOW_FIRM", "")),
        "message":        _env_mode_message(mode, days, os.getenv("WILLOW_FIRM", "")),
    }


def _env_mode_message(mode: str, days: int, firm: str) -> str:
    msgs = {
        "full":     f"Licensed to {firm}",
        "trial":    f"Trial mode — {days} days remaining.",
        "expiring": f"License expiring in {days} days. Renew at sales@engineereddatasystems.com.au.",
        "expired":  "Updates paused — renew to resume. Willow continues operating normally.",
        "readonly": "Trial expired — read-only until a paid licence is installed.",
        "invalid":  "License invalid. Contact sales@engineereddatasystems.com.au.",
    }
    return msgs.get(mode, "Unknown license state.")


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------

class LicenseActivateRequest(BaseModel):
    license_key: str


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@router.get("/license/status", tags=["System"])
async def license_status(db: AsyncSession = Depends(get_db)):
    """Current license state. Reads live from key file — no restart needed after activation."""
    state = get_license_state()

    # Count active staff so the admin can see seat usage
    try:
        count_result = await db.execute(
            text("SELECT COUNT(*) AS cnt FROM staff_registry WHERE active = TRUE")
        )
        seats_used = count_result.mappings().first()["cnt"]
    except Exception:
        seats_used = 0

    seats_total = state.get("seats", 0)
    # Trial = 999 seats; report as unlimited in the response
    if seats_total >= 999:
        return {**state, "seats_used": seats_used, "seats_available": None, "seats_unlimited": True}

    return {
        **state,
        "seats_used": seats_used,
        "seats_available": max(0, seats_total - seats_used),
        "seats_unlimited": False,
    }


@router.get("/license/hardware-id", tags=["System"])
async def hardware_id(_: str = Depends(require_admin)):
    """
    Return this machine's hardware fingerprint.
    Send this to sales@engineereddatasystems.com.au when requesting a license.
    """
    try:
        hw_id = compute_hardware_id()
        return {
            "hardware_id": hw_id,
            "contact": "sales@engineereddatasystems.com.au",
            "instructions": (
                "Copy the Hardware ID above and email it to us with your firm name. "
                "We will send back a license key within one business day."
            ),
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Could not compute hardware ID: {exc}")


@router.post("/license/activate", tags=["System"])
async def activate_license(
    payload: LicenseActivateRequest,
    _: str = Depends(require_admin),
):
    """
    Write and validate a license key.
    Returns the new license state immediately — no restart required.
    """
    key = payload.license_key.strip()
    if not key:
        raise HTTPException(status_code=400, detail="License key cannot be empty.")

    # Validate before writing
    state = _verify_key_content(key)
    if state["mode"] == "invalid":
        raise HTTPException(
            status_code=422,
            detail=state["message"],
        )

    # Write to disk
    try:
        LICENSE_FILE.parent.mkdir(parents=True, exist_ok=True)
        LICENSE_FILE.write_text(key + "\n")
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=(
                f"Could not write license file: {exc}. "
                "Ensure /opt/willow is mounted and writable in docker-compose.yml."
            ),
        )

    return {
        **state,
        "activated": True,
    }


@router.delete("/license/key", tags=["System"])
async def remove_license(_: str = Depends(require_admin)):
    """Remove a license key (revert to trial). Used when migrating to new hardware."""
    if LICENSE_FILE.exists():
        try:
            LICENSE_FILE.unlink()
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Could not remove license: {exc}")
    return {"removed": True, "message": "License removed. If a paid licence was previously installed, Willow remains writable under perpetual fallback; otherwise it returns to trial/read-only rules."}
