"""
Staff Management API
=====================
Full lifecycle management for staff members — add, view, edit, deactivate,
and offboard (with automatic client reassignment).

Roles: bookkeeper | senior_bookkeeper | manager | admin
Only manager/admin can create, edit, or offboard staff.
"""

import uuid
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from pydantic import BaseModel, EmailStr, Field
from datetime import datetime, timezone

from app.database import get_db
from app.api.v1.license import get_license_state

router = APIRouter(prefix="/staff", tags=["Staff Management"])

MANAGE_ROLES = {"manager", "admin"}


# ── Pydantic models ────────────────────────────────────────────────────────────

class StaffCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    role: str = Field(..., pattern="^(bookkeeper|senior_bookkeeper|manager|admin)$")
    email: EmailStr
    phone: Optional[str] = None
    approval_limit: float = Field(default=500.00, ge=0)
    timezone: str = Field(default="Australia/Brisbane")
    client_ids: List[str] = Field(default=[])


class StaffUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=2, max_length=100)
    role: Optional[str] = Field(None, pattern="^(bookkeeper|senior_bookkeeper|manager|admin)$")
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    approval_limit: Optional[float] = Field(None, ge=0)
    timezone: Optional[str] = None
    client_ids: Optional[List[str]] = None


class StaffOffboard(BaseModel):
    reassign_to: str = Field(..., description="user_id of staff member to receive all open clients and tasks")
    reason: str = Field(..., min_length=5, max_length=500)
    requested_by: str = Field(..., description="user_id of manager/admin authorising the offboard")


# ── Helper: verify requester role ─────────────────────────────────────────────

async def _require_manage_role(requester_id: str, db: AsyncSession):
    result = await db.execute(
        text("SELECT role FROM staff_registry WHERE user_id = :uid AND active = TRUE"),
        {"uid": requester_id},
    )
    row = result.mappings().first()
    if not row or row["role"] not in MANAGE_ROLES:
        raise HTTPException(
            status_code=403,
            detail="Only managers and admins can manage staff records.",
        )


# ── POST /v1/staff — Create new staff member ──────────────────────────────────

@router.post("", status_code=201)
async def create_staff(
    payload: StaffCreate,
    requested_by: str = Query(..., description="user_id of the manager/admin creating this record"),
    db: AsyncSession = Depends(get_db),
):
    """
    Onboard a new staff member.
    Generates a unique user_id and inserts into staff_registry.
    Writes an immutable audit log entry.
    """
    await _require_manage_role(requested_by, db)

    # ── Seat limit enforcement ─────────────────────────────────────────────────
    license_state = get_license_state()
    seats = license_state.get("seats", 0)
    # Trial mode uses seats=999 — skip enforcement
    if seats < 999:
        count_result = await db.execute(
            text("SELECT COUNT(*) AS cnt FROM staff_registry WHERE active = TRUE")
        )
        current_count = count_result.mappings().first()["cnt"]
        if current_count >= seats:
            raise HTTPException(
                status_code=403,
                detail=(
                    f"Seat limit reached — your licence allows {seats} staff "
                    f"and {current_count} {'is' if current_count == 1 else 'are'} currently active. "
                    "Offboard a staff member first, or contact "
                    "sales@engineereddatasystems.com.au to upgrade your licence."
                ),
            )

    # Check email uniqueness
    existing = await db.execute(
        text("SELECT user_id FROM staff_registry WHERE email = :email"),
        {"email": payload.email},
    )
    if existing.mappings().first():
        raise HTTPException(status_code=409, detail="A staff member with this email already exists.")

    new_id = f"staff_{uuid.uuid4().hex[:12]}"
    import json

    await db.execute(
        text("""
            INSERT INTO staff_registry
                (user_id, name, role, email, phone, client_ids, approval_limit, timezone, active)
            VALUES
                (:uid, :name, :role, :email, :phone, :client_ids::jsonb, :limit, :tz, TRUE)
        """),
        {
            "uid": new_id,
            "name": payload.name,
            "role": payload.role,
            "email": payload.email,
            "phone": payload.phone,
            "client_ids": json.dumps(payload.client_ids),
            "limit": payload.approval_limit,
            "tz": payload.timezone,
        },
    )

    # Audit
    requester = await db.execute(
        text("SELECT name FROM staff_registry WHERE user_id = :uid"),
        {"uid": requested_by},
    )
    req_row = requester.mappings().first()
    req_name = req_row["name"] if req_row else requested_by

    await db.execute(
        text("""
            INSERT INTO audit_log (staff_user_id, staff_name, action, agent, details, result)
            VALUES (:uid, :name, 'staff_created', 'api',
                    :details::jsonb, 'success')
        """),
        {
            "uid": requested_by,
            "name": req_name,
            "details": json.dumps({
                "new_staff_id": new_id,
                "new_staff_name": payload.name,
                "role": payload.role,
                "email": payload.email,
            }),
        },
    )

    await db.commit()

    return {
        "user_id": new_id,
        "name": payload.name,
        "role": payload.role,
        "email": payload.email,
        "message": f"Staff member {payload.name} created successfully.",
    }


# ── GET /v1/staff — List all staff ────────────────────────────────────────────

@router.get("")
async def list_staff(
    active_only: bool = Query(default=True),
    role: Optional[str] = Query(default=None),
    db: AsyncSession = Depends(get_db),
):
    """
    List all staff members. Optionally filter by active status or role.
    Returns name, role, email, phone, client count, approval_limit.
    """
    base_query = """
        SELECT sr.user_id, sr.name, sr.role, sr.email, sr.phone,
               sr.approval_limit, sr.timezone, sr.active, sr.created_at,
               COALESCE(jsonb_array_length(sr.client_ids), 0) AS assigned_client_count,
               sr.client_ids
        FROM staff_registry sr
        WHERE 1=1
    """
    params = {}
    if active_only:
        base_query += " AND sr.active = TRUE"
    if role:
        base_query += " AND sr.role = :role"
        params["role"] = role

    base_query += " ORDER BY sr.role DESC, sr.name ASC"

    result = await db.execute(text(base_query), params)
    rows = [dict(r) for r in result.mappings()]

    return {"staff": rows, "total": len(rows)}


# ── POST /v1/staff/bootstrap — First-run admin creation ───────────────────────
# NOTE: must be defined BEFORE /{user_id} to avoid being captured as user_id = "bootstrap"

class StaffBootstrap(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    email: EmailStr


@router.post("/bootstrap", status_code=201)
async def bootstrap_admin(
    payload: StaffBootstrap,
    db: AsyncSession = Depends(get_db),
):
    """
    Create the very first admin account on a fresh Willow installation.
    Automatically disabled once any staff record exists — returns 409.
    Requires no authentication (there is nobody to authenticate as yet).
    """
    import json

    # Block if already set up
    count_result = await db.execute(
        text("SELECT COUNT(*) AS cnt FROM staff_registry")
    )
    total = count_result.mappings().first()["cnt"]
    if total > 0:
        raise HTTPException(
            status_code=409,
            detail=(
                "Willow is already set up. "
                "Log in as an existing admin to manage staff accounts."
            ),
        )

    new_id = f"staff_{uuid.uuid4().hex[:12]}"

    await db.execute(
        text("""
            INSERT INTO staff_registry
                (user_id, name, role, email, client_ids, approval_limit, timezone, active)
            VALUES
                (:uid, :name, 'admin', :email, '[]'::jsonb, 500.00, 'Australia/Brisbane', TRUE)
        """),
        {"uid": new_id, "name": payload.name, "email": payload.email},
    )

    await db.execute(
        text("""
            INSERT INTO audit_log
                (staff_user_id, staff_name, action, agent, details, result)
            VALUES
                (:uid, :name, 'bootstrap_admin_created', 'setup', :details::jsonb, 'success')
        """),
        {
            "uid": new_id,
            "name": payload.name,
            "details": json.dumps({
                "email": payload.email,
                "note": "First admin account created via first-run setup",
            }),
        },
    )

    await db.commit()

    return {
        "user_id": new_id,
        "name": payload.name,
        "role": "admin",
        "email": payload.email,
        "message": f"Welcome to Willow, {payload.name}. Your admin account is ready.",
    }


# ── GET /v1/staff/me — Current user profile & role ───────────────────────────
# NOTE: must be defined BEFORE /{user_id} so FastAPI matches /me exactly
# rather than treating it as a user_id path parameter.

@router.get("/me")
async def get_my_profile(
    staff_id: str = Query(..., description="Your user_id (from local session)"),
    db: AsyncSession = Depends(get_db),
):
    """
    Return the current user's profile and role.
    Used by the frontend to gate admin-only UI (settings, license, integrations).
    """
    result = await db.execute(
        text("""
            SELECT user_id, name, role, email, active
            FROM staff_registry
            WHERE user_id = :uid
        """),
        {"uid": staff_id},
    )
    row = result.mappings().first()
    if not row:
        raise HTTPException(status_code=404, detail="Staff member not found.")

    # Return a structured deactivated response so the frontend can show
    # a proper "account deactivated" screen rather than silently breaking.
    if not row["active"]:
        return {
            "user_id":     row["user_id"],
            "name":        row["name"],
            "role":        row["role"],
            "email":       row["email"],
            "is_admin":    False,
            "active":      False,
            "deactivated": True,
        }

    return {
        "user_id":     row["user_id"],
        "name":        row["name"],
        "role":        row["role"],
        "email":       row["email"],
        "is_admin":    row["role"] == "admin",
        "active":      True,
        "deactivated": False,
    }


# ── GET /v1/staff/{user_id} — Single staff profile ────────────────────────────

@router.get("/{user_id}")
async def get_staff(user_id: str, db: AsyncSession = Depends(get_db)):
    """
    Full profile for one staff member, including their assigned clients
    and recent audit activity.
    """
    result = await db.execute(
        text("SELECT * FROM staff_registry WHERE user_id = :uid"),
        {"uid": user_id},
    )
    staff = result.mappings().first()
    if not staff:
        raise HTTPException(status_code=404, detail="Staff member not found.")
    staff = dict(staff)

    # Resolve assigned clients
    import json
    client_ids = staff.get("client_ids") or []
    if isinstance(client_ids, str):
        client_ids = json.loads(client_ids)

    clients = []
    if client_ids:
        cr = await db.execute(
            text("""
                SELECT client_id, business_name, bas_frequency, active
                FROM client_registry
                WHERE client_id = ANY(:ids)
                ORDER BY business_name ASC
            """),
            {"ids": client_ids},
        )
        clients = [dict(r) for r in cr.mappings()]

    # Recent audit activity (last 10)
    audit = await db.execute(
        text("""
            SELECT timestamp, action, agent, client_id, result
            FROM audit_log
            WHERE staff_user_id = :uid
            ORDER BY timestamp DESC
            LIMIT 10
        """),
        {"uid": user_id},
    )
    recent_audit = [dict(r) for r in audit.mappings()]

    return {
        "staff": staff,
        "assigned_clients": clients,
        "recent_activity": recent_audit,
    }


# ── PATCH /v1/staff/{user_id} — Update staff record ──────────────────────────

@router.patch("/{user_id}")
async def update_staff(
    user_id: str,
    payload: StaffUpdate,
    requested_by: str = Query(...),
    db: AsyncSession = Depends(get_db),
):
    """
    Update any field on a staff member's record.
    Change role, adjust approval limit, reassign clients, update contact details.
    Immutable audit entry written for every change.
    """
    await _require_manage_role(requested_by, db)

    existing = await db.execute(
        text("SELECT * FROM staff_registry WHERE user_id = :uid"),
        {"uid": user_id},
    )
    staff = existing.mappings().first()
    if not staff:
        raise HTTPException(status_code=404, detail="Staff member not found.")

    import json

    # Build dynamic SET clause
    updates = {}
    changes = {}

    if payload.name is not None and payload.name != staff["name"]:
        updates["name"] = payload.name
        changes["name"] = {"from": staff["name"], "to": payload.name}

    if payload.role is not None and payload.role != staff["role"]:
        updates["role"] = payload.role
        changes["role"] = {"from": staff["role"], "to": payload.role}

    if payload.email is not None and payload.email != staff["email"]:
        updates["email"] = payload.email
        changes["email"] = {"from": staff["email"], "to": payload.email}

    if payload.phone is not None and payload.phone != staff.get("phone"):
        updates["phone"] = payload.phone
        changes["phone"] = {"from": staff.get("phone"), "to": payload.phone}

    if payload.approval_limit is not None and payload.approval_limit != float(staff["approval_limit"]):
        updates["approval_limit"] = payload.approval_limit
        changes["approval_limit"] = {
            "from": float(staff["approval_limit"]),
            "to": payload.approval_limit,
        }

    if payload.timezone is not None and payload.timezone != staff["timezone"]:
        updates["timezone"] = payload.timezone
        changes["timezone"] = {"from": staff["timezone"], "to": payload.timezone}

    if payload.client_ids is not None:
        existing_ids = staff.get("client_ids") or []
        if isinstance(existing_ids, str):
            existing_ids = json.loads(existing_ids)
        if set(payload.client_ids) != set(existing_ids):
            updates["client_ids"] = json.dumps(payload.client_ids)
            changes["client_ids"] = {
                "from": existing_ids,
                "to": payload.client_ids,
            }

    if not updates:
        return {"message": "No changes detected.", "staff_id": user_id}

    set_parts = ", ".join(f"{k} = :{k}" for k in updates)
    update_params = {**updates, "uid": user_id}

    await db.execute(
        text(f"UPDATE staff_registry SET {set_parts}, updated_at = now() WHERE user_id = :uid"),
        update_params,
    )

    # Audit
    req_result = await db.execute(
        text("SELECT name FROM staff_registry WHERE user_id = :uid"),
        {"uid": requested_by},
    )
    req_row = req_result.mappings().first()
    req_name = req_row["name"] if req_row else requested_by

    await db.execute(
        text("""
            INSERT INTO audit_log (staff_user_id, staff_name, action, agent, details, result)
            VALUES (:uid, :name, 'staff_updated', 'api', :details::jsonb, 'success')
        """),
        {
            "uid": requested_by,
            "name": req_name,
            "details": json.dumps({
                "target_staff_id": user_id,
                "target_name": staff["name"],
                "changes": changes,
            }),
        },
    )

    await db.commit()

    return {
        "user_id": user_id,
        "changes_applied": changes,
        "message": f"{staff['name']}'s record updated successfully.",
    }


# ── POST /v1/staff/{user_id}/offboard — Deactivate + reassign ─────────────────

@router.post("/{user_id}/offboard")
async def offboard_staff(
    user_id: str,
    payload: StaffOffboard,
    db: AsyncSession = Depends(get_db),
):
    """
    Safely offboard a staff member:
    1. Verifies requester has manager/admin role
    2. Validates the reassignment target is active
    3. Reassigns all client_registry rows to the new assignee
    4. Reassigns all open task_queue rows to the new assignee
    5. Transfers client_ids JSONB to the new assignee's staff record
    6. Deactivates the departing staff member
    7. Writes full audit log + disengagement_log entry
    """
    import json

    await _require_manage_role(payload.requested_by, db)

    # Load departing staff
    dep_result = await db.execute(
        text("SELECT * FROM staff_registry WHERE user_id = :uid AND active = TRUE"),
        {"uid": user_id},
    )
    departing = dep_result.mappings().first()
    if not departing:
        raise HTTPException(status_code=404, detail="Staff member not found or already inactive.")

    if user_id == payload.reassign_to:
        raise HTTPException(status_code=400, detail="Cannot reassign to the same staff member.")

    # Validate reassignment target
    tgt_result = await db.execute(
        text("SELECT * FROM staff_registry WHERE user_id = :uid AND active = TRUE"),
        {"uid": payload.reassign_to},
    )
    target = tgt_result.mappings().first()
    if not target:
        raise HTTPException(status_code=404, detail="Reassignment target not found or inactive.")

    # ── 1. Reassign all client_registry rows ──────────────────────────────────
    reassigned_clients = await db.execute(
        text("""
            UPDATE client_registry
            SET assigned_staff = :new_staff
            WHERE assigned_staff = :old_staff AND active = TRUE
            RETURNING client_id, business_name
        """),
        {"new_staff": payload.reassign_to, "old_staff": user_id},
    )
    reassigned_client_rows = [dict(r) for r in reassigned_clients.mappings()]

    # ── 2. Reassign open task_queue rows ──────────────────────────────────────
    reassigned_tasks = await db.execute(
        text("""
            UPDATE task_queue
            SET assigned_to = :new_staff
            WHERE assigned_to = :old_staff AND status NOT IN ('completed', 'cancelled')
            RETURNING id, title
        """),
        {"new_staff": payload.reassign_to, "old_staff": user_id},
    )
    reassigned_task_rows = [dict(r) for r in reassigned_tasks.mappings()]

    # ── 3. Merge client_ids into target's JSONB ────────────────────────────────
    dep_client_ids = departing.get("client_ids") or []
    if isinstance(dep_client_ids, str):
        dep_client_ids = json.loads(dep_client_ids)

    tgt_client_ids = target.get("client_ids") or []
    if isinstance(tgt_client_ids, str):
        tgt_client_ids = json.loads(tgt_client_ids)

    merged_ids = list(set(tgt_client_ids + dep_client_ids))

    await db.execute(
        text("UPDATE staff_registry SET client_ids = :ids::jsonb, updated_at = now() WHERE user_id = :uid"),
        {"ids": json.dumps(merged_ids), "uid": payload.reassign_to},
    )

    # ── 4. Deactivate departing staff ─────────────────────────────────────────
    await db.execute(
        text("""
            UPDATE staff_registry
            SET active = FALSE, deactivated_at = now(), client_ids = '[]'::jsonb, updated_at = now()
            WHERE user_id = :uid
        """),
        {"uid": user_id},
    )

    # ── 5. Write disengagement_log ─────────────────────────────────────────────
    await db.execute(
        text("""
            INSERT INTO staff_disengagement_log
                (staff_user_id, staff_name, deactivated_by, reassigned_to,
                 clients_reassigned, tasks_reassigned, reason)
            VALUES
                (:uid, :name, :by, :to_uid,
                 :clients::jsonb, :tasks::jsonb, :reason)
        """),
        {
            "uid": user_id,
            "name": departing["name"],
            "by": payload.requested_by,
            "to_uid": payload.reassign_to,
            "clients": json.dumps([r["client_id"] for r in reassigned_client_rows]),
            "tasks": json.dumps([r["id"] for r in reassigned_task_rows]),
            "reason": payload.reason,
        },
    )

    # ── 6. Audit log ──────────────────────────────────────────────────────────
    req_result = await db.execute(
        text("SELECT name FROM staff_registry WHERE user_id = :uid"),
        {"uid": payload.requested_by},
    )
    req_name_row = req_result.mappings().first()
    req_name = req_name_row["name"] if req_name_row else payload.requested_by

    await db.execute(
        text("""
            INSERT INTO audit_log
                (staff_user_id, staff_name, action, agent, details, result)
            VALUES
                (:uid, :name, 'staff_offboarded', 'api', :details::jsonb, 'success')
        """),
        {
            "uid": payload.requested_by,
            "name": req_name,
            "details": json.dumps({
                "offboarded_id": user_id,
                "offboarded_name": departing["name"],
                "reassigned_to_id": payload.reassign_to,
                "reassigned_to_name": target["name"],
                "clients_reassigned": len(reassigned_client_rows),
                "tasks_reassigned": len(reassigned_task_rows),
                "reason": payload.reason,
            }),
        },
    )

    await db.commit()

    return {
        "offboarded": departing["name"],
        "reassigned_to": target["name"],
        "clients_reassigned": reassigned_client_rows,
        "tasks_reassigned": len(reassigned_task_rows),
        "message": (
            f"{departing['name']} has been deactivated. "
            f"{len(reassigned_client_rows)} client(s) and "
            f"{len(reassigned_task_rows)} task(s) reassigned to {target['name']}."
        ),
    }



