"""
Willow Integrations Settings API
Stores and retrieves OAuth2 credentials for Xero, Gmail, and Outlook.
Credentials are saved to /opt/willow/settings/integrations.json.
Secrets are never returned in GET responses — write-only once saved.
"""

import json
import os
import httpx
from pathlib import Path
from typing import Literal, Optional

from fastapi import APIRouter, Depends, HTTPException
from app.dependencies import require_admin
from pydantic import BaseModel, field_validator

router = APIRouter()

# ---------------------------------------------------------------------------
# Storage
# ---------------------------------------------------------------------------

SETTINGS_DIR  = Path(os.getenv("WILLOW_DIR", "/opt/willow")) / "settings"
SETTINGS_FILE = SETTINGS_DIR / "integrations.json"

REDACTED = "••••••••"


def _load() -> dict:
    if SETTINGS_FILE.exists():
        try:
            return json.loads(SETTINGS_FILE.read_text())
        except Exception:
            pass
    return {}


def _save(data: dict) -> None:
    SETTINGS_DIR.mkdir(parents=True, exist_ok=True)
    SETTINGS_FILE.write_text(json.dumps(data, indent=2))


def _mask(cfg: dict) -> dict:
    """Return config with secrets replaced by bullet string."""
    masked = dict(cfg)
    for key in ("client_secret", "tenant_id", "refresh_token", "access_token"):
        if masked.get(key):
            masked[key] = REDACTED
    return masked


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

EmailProvider = Literal["gmail", "outlook"]


class XeroConfig(BaseModel):
    client_id:     str
    client_secret: str  # write-only: never returned in GET

    @field_validator("client_id", "client_secret")
    @classmethod
    def not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("Cannot be empty")
        return v.strip()


class GmailConfig(BaseModel):
    client_id:     str
    client_secret: str

    @field_validator("client_id", "client_secret")
    @classmethod
    def not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("Cannot be empty")
        return v.strip()


class OutlookConfig(BaseModel):
    client_id:     str
    client_secret: str
    tenant_id:     str = "common"   # "common" for multi-tenant, or Azure tenant GUID

    @field_validator("client_id", "client_secret")
    @classmethod
    def not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("Cannot be empty")
        return v.strip()


class IntegrationsPayload(BaseModel):
    xero:           Optional[XeroConfig]    = None
    email_provider: Optional[EmailProvider] = None
    gmail:          Optional[GmailConfig]   = None
    outlook:        Optional[OutlookConfig] = None


# ---------------------------------------------------------------------------
# Connection testers
# ---------------------------------------------------------------------------

async def _test_xero(cfg: dict) -> dict:
    """Check Xero token endpoint reachability + stored refresh token validity."""
    client_id     = cfg.get("client_id", "")
    client_secret = cfg.get("client_secret", "")
    refresh_token = cfg.get("refresh_token", "")

    if not client_id or not client_secret:
        return {"connected": False, "reason": "Credentials not configured"}

    if not refresh_token:
        return {
            "connected": False,
            "reason": "No active session — click Reconnect to authorise Xero",
        }

    # Try refreshing the access token to confirm it is still valid
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.post(
                "https://identity.xero.com/connect/token",
                data={
                    "grant_type":    "refresh_token",
                    "refresh_token": refresh_token,
                    "client_id":     client_id,
                    "client_secret": client_secret,
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
        if resp.status_code == 200:
            tokens = resp.json()
            # Persist new tokens
            stored = _load()
            stored.setdefault("xero", {}).update({
                "access_token":  tokens.get("access_token", ""),
                "refresh_token": tokens.get("refresh_token", refresh_token),
            })
            _save(stored)
            return {"connected": True, "reason": "Xero connected and token refreshed"}
        elif resp.status_code in (400, 401):
            return {
                "connected": False,
                "reason": "Xero session expired — click Reconnect to re-authorise",
            }
        else:
            return {"connected": False, "reason": f"Xero returned HTTP {resp.status_code}"}
    except httpx.ConnectError:
        return {"connected": False, "reason": "Cannot reach Xero — check internet connection"}
    except Exception as exc:
        return {"connected": False, "reason": str(exc)}


async def _test_gmail(cfg: dict) -> dict:
    client_id     = cfg.get("client_id", "")
    refresh_token = cfg.get("refresh_token", "")

    if not client_id:
        return {"connected": False, "reason": "Gmail credentials not configured"}
    if not refresh_token:
        return {"connected": False, "reason": "No active session — click Reconnect to authorise Gmail"}

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.post(
                "https://oauth2.googleapis.com/token",
                data={
                    "grant_type":    "refresh_token",
                    "refresh_token": refresh_token,
                    "client_id":     cfg.get("client_id", ""),
                    "client_secret": cfg.get("client_secret", ""),
                },
            )
        if resp.status_code == 200:
            tokens = resp.json()
            stored = _load()
            stored.setdefault("gmail", {})["access_token"] = tokens.get("access_token", "")
            _save(stored)
            return {"connected": True, "reason": "Gmail connected"}
        elif resp.status_code in (400, 401):
            return {"connected": False, "reason": "Gmail session expired — click Reconnect"}
        else:
            return {"connected": False, "reason": f"Google returned HTTP {resp.status_code}"}
    except httpx.ConnectError:
        return {"connected": False, "reason": "Cannot reach Google — check internet connection"}
    except Exception as exc:
        return {"connected": False, "reason": str(exc)}


async def _test_outlook(cfg: dict) -> dict:
    client_id     = cfg.get("client_id", "")
    tenant_id     = cfg.get("tenant_id", "common")
    refresh_token = cfg.get("refresh_token", "")

    if not client_id:
        return {"connected": False, "reason": "Outlook credentials not configured"}
    if not refresh_token:
        return {"connected": False, "reason": "No active session — click Reconnect to authorise Outlook"}

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.post(
                f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token",
                data={
                    "grant_type":    "refresh_token",
                    "refresh_token": refresh_token,
                    "client_id":     client_id,
                    "client_secret": cfg.get("client_secret", ""),
                    "scope":         "https://graph.microsoft.com/.default offline_access",
                },
            )
        if resp.status_code == 200:
            tokens = resp.json()
            stored = _load()
            stored.setdefault("outlook", {}).update({
                "access_token":  tokens.get("access_token", ""),
                "refresh_token": tokens.get("refresh_token", refresh_token),
            })
            _save(stored)
            return {"connected": True, "reason": "Outlook / Microsoft 365 connected"}
        elif resp.status_code in (400, 401):
            return {"connected": False, "reason": "Outlook session expired — click Reconnect"}
        else:
            return {"connected": False, "reason": f"Microsoft returned HTTP {resp.status_code}"}
    except httpx.ConnectError:
        return {"connected": False, "reason": "Cannot reach Microsoft — check internet connection"}
    except Exception as exc:
        return {"connected": False, "reason": str(exc)}


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@router.get("/settings/integrations", tags=["Settings"])
async def get_integrations(_: str = Depends(require_admin)):
    """
    Return current integrations config with secrets redacted.
    Includes live connection status for each provider.
    """
    cfg = _load()

    xero_cfg    = cfg.get("xero", {})
    gmail_cfg   = cfg.get("gmail", {})
    outlook_cfg = cfg.get("outlook", {})

    return {
        "email_provider": cfg.get("email_provider", None),
        "xero": {
            **_mask(xero_cfg),
            "configured": bool(xero_cfg.get("client_id")),
            "has_session": bool(xero_cfg.get("refresh_token")),
        },
        "gmail": {
            **_mask(gmail_cfg),
            "configured": bool(gmail_cfg.get("client_id")),
            "has_session": bool(gmail_cfg.get("refresh_token")),
        },
        "outlook": {
            **_mask(outlook_cfg),
            "configured": bool(outlook_cfg.get("client_id")),
            "has_session": bool(outlook_cfg.get("refresh_token")),
        },
    }


@router.put("/settings/integrations", tags=["Settings"])
async def update_integrations(
    payload: IntegrationsPayload,
    _: str = Depends(require_admin),
):
    """
    Save credentials for one or more integrations.
    Only provided fields are updated — omitted fields are left unchanged.
    Secrets are stored as-is; redacted (••••) values are ignored.
    """
    cfg = _load()

    if payload.email_provider is not None:
        cfg["email_provider"] = payload.email_provider

    if payload.xero is not None:
        existing = cfg.get("xero", {})
        update = payload.xero.model_dump()
        # Never overwrite a real secret with the redacted placeholder
        for key in ("client_secret",):
            if update.get(key) == REDACTED:
                update[key] = existing.get(key, "")
        existing.update({k: v for k, v in update.items() if v})
        cfg["xero"] = existing

    if payload.gmail is not None:
        existing = cfg.get("gmail", {})
        update = payload.gmail.model_dump()
        for key in ("client_secret",):
            if update.get(key) == REDACTED:
                update[key] = existing.get(key, "")
        existing.update({k: v for k, v in update.items() if v})
        cfg["gmail"] = existing

    if payload.outlook is not None:
        existing = cfg.get("outlook", {})
        update = payload.outlook.model_dump()
        for key in ("client_secret", "tenant_id"):
            if update.get(key) == REDACTED:
                update[key] = existing.get(key, "")
        existing.update({k: v for k, v in update.items() if v})
        cfg["outlook"] = existing

    try:
        _save(cfg)
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=(
                f"Could not save settings: {exc}. "
                "Ensure /opt/willow is mounted and writable in docker-compose.yml."
            ),
        )

    return {"saved": True}


@router.post("/settings/integrations/test/{provider}", tags=["Settings"])
async def test_integration(provider: str, _: str = Depends(require_admin)):
    """Test the live connection for a given provider (xero | gmail | outlook)."""
    cfg = _load()

    if provider == "xero":
        result = await _test_xero(cfg.get("xero", {}))
    elif provider == "gmail":
        result = await _test_gmail(cfg.get("gmail", {}))
    elif provider == "outlook":
        result = await _test_outlook(cfg.get("outlook", {}))
    else:
        raise HTTPException(status_code=400, detail=f"Unknown provider: {provider}")

    return result


@router.delete("/settings/integrations/{provider}", tags=["Settings"])
async def disconnect_integration(provider: str, _: str = Depends(require_admin)):
    """Remove stored tokens for a provider, forcing re-authorisation."""
    cfg = _load()
    if provider not in ("xero", "gmail", "outlook"):
        raise HTTPException(status_code=400, detail=f"Unknown provider: {provider}")

    if provider in cfg:
        # Keep client_id / client_secret, clear tokens
        for key in ("access_token", "refresh_token"):
            cfg[provider].pop(key, None)
        _save(cfg)

    return {"disconnected": True, "provider": provider}
