"""
Willows AI — API v1 Router
Aggregates all endpoint routers into a single prefix.
"""

from fastapi import APIRouter

from app.api.v1 import transactions, accounts, invoices, ai, voice, intake, clients, policies, ato, staff, sms, approvals, license, settings, product

api_router = APIRouter()

api_router.include_router(
    transactions.router,
    prefix="/transactions",
    tags=["Transactions"],
)
api_router.include_router(
    accounts.router,
    prefix="/accounts",
    tags=["Accounts"],
)
api_router.include_router(
    invoices.router,
    prefix="/invoices",
    tags=["Invoices"],
)
api_router.include_router(
    ai.router,
    prefix="/ai",
    tags=["AI Processing"],
)
api_router.include_router(
    voice.router,
    tags=["Voice & Queue"],
)
api_router.include_router(
    intake.router,
    tags=["Document Intake"],
)
api_router.include_router(
    clients.router,
    tags=["Client Status"],
)
api_router.include_router(
    staff.router,
    tags=["Staff Management"],
)
api_router.include_router(
    policies.router,
    tags=["Policy Knowledge Base"],
)
api_router.include_router(
    ato.router,
    tags=["ATO Reference"],
)
api_router.include_router(
    sms.router,
    tags=["SMS"],
)
api_router.include_router(
    approvals.router,
    tags=["Approvals"],
)
api_router.include_router(
    license.router,
    tags=["System"],
)
api_router.include_router(
    settings.router,
    tags=["Settings"],
)

api_router.include_router(
    product.router,
    tags=["Product Coordinator"],
)
