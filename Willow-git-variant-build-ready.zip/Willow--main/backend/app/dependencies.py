"""
Willow — Shared FastAPI dependencies
"""

from fastapi import Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text

from app.database import get_db


async def require_admin(
    staff_id: str = Query(..., description="Administrator's user_id"),
    db: AsyncSession = Depends(get_db),
) -> str:
    """
    Dependency that enforces admin-only access.
    Pass ?staff_id=<user_id> on any protected request.
    Raises 403 if the user is not an active admin.
    """
    result = await db.execute(
        text(
            "SELECT role FROM staff_registry "
            "WHERE user_id = :uid AND active = TRUE"
        ),
        {"uid": staff_id},
    )
    row = result.mappings().first()
    if not row or row["role"] != "admin":
        raise HTTPException(
            status_code=403,
            detail="Administrator access required. Contact your Willow admin.",
        )
    return staff_id
