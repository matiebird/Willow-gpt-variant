"""
Willows AI — Application Configuration
All settings are loaded from environment variables / .env file.
"""

from functools import lru_cache
from typing import Literal

from pydantic import field_validator, computed_field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── Application ──────────────────────────────────────────────────────────
    app_name: str = "Willows AI"
    app_version: str = "1.0.0"
    environment: Literal["development", "production", "testing"] = "production"
    log_level: str = "info"
    debug: bool = False

    # ── Security ─────────────────────────────────────────────────────────────
    secret_key: str
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 1440  # 24 hours

    # ── Database ─────────────────────────────────────────────────────────────
    database_url: str                     # postgresql+asyncpg://...
    db_pool_size: int = 10
    db_max_overflow: int = 20
    db_pool_timeout: int = 30

    # ── Redis ─────────────────────────────────────────────────────────────────
    redis_url: str                        # redis://:password@redis:6379/0

    # ── Ollama (Local AI Inference) ───────────────────────────────────────────
    # Ollama runs on the Unraid HOST for GPU passthrough — not in Docker
    ollama_base_url: str = "http://host.docker.internal:11434"
    # RTX 2070 (8GB VRAM) — single model across all agents to avoid VRAM swap
    # Future DGX Spark: upgrade to qwen2.5:72b-instruct
    ollama_model: str = "qwen2.5:7b-instruct-q4_K_M"
    ollama_request_timeout: int = 120     # seconds — LLM inference can be slow
    ollama_max_retries: int = 3
    ollama_temperature: float = 0.0       # Deterministic output for data extraction

    # ── File Uploads ──────────────────────────────────────────────────────────
    upload_dir: str = "/app/uploads"
    max_upload_size_mb: int = 20
    allowed_upload_types: list[str] = [
        "image/jpeg", "image/png", "image/webp",
        "image/tiff", "application/pdf",
    ]

    # ── Internal service authentication ─────────────────────────────────────
    # Shared secret used by n8n/voice/SMS services when calling Willow API.
    willow_api_key: str = "change-me-local-dev"

    # ── SMS / Asterisk integration ──────────────────────────────────────────
    sms_provider: str = "log_only"
    asterisk_ami_host: str = "willow-asterisk"
    asterisk_ami_port: int = 5038
    asterisk_ami_secret: str = ""

    # ── n8n (internal service URL for webhook forwarding) ─────────────────────
    n8n_base_url: str = "http://n8n:5678"

    # ── Celery ────────────────────────────────────────────────────────────────
    celery_broker_url: str = ""
    celery_result_backend: str = ""

    @computed_field  # type: ignore[misc]
    @property
    def celery_broker(self) -> str:
        return self.celery_broker_url or self.redis_url

    @computed_field  # type: ignore[misc]
    @property
    def celery_backend(self) -> str:
        return self.celery_result_backend or self.redis_url

    @computed_field  # type: ignore[misc]
    @property
    def max_upload_size_bytes(self) -> int:
        return self.max_upload_size_mb * 1024 * 1024

    @field_validator("environment", mode="before")
    @classmethod
    def normalise_env(cls, v: str) -> str:
        return v.lower()


@lru_cache
def get_settings() -> Settings:
    """Cached settings singleton — instantiated once at startup."""
    return Settings()  # type: ignore[call-arg]


# Backwards-compatible module-level settings object.
# Some routes import `settings` directly. Keep this here so imports do not fail.
settings = get_settings()
