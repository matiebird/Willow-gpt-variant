"""
Willows AI — FastAPI Application Entry Point
"""

import logging
import os
import time
from contextlib import asynccontextmanager

import structlog
from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse

from app.api.v1.router import api_router
from app.config import get_settings
from app.database import AsyncSessionLocal
from app.api.v1.license import get_license_state
from sqlalchemy import text

# Paths exempt from active-staff check — always reachable even after deactivation
_DEACTIVATED_EXEMPT_PREFIXES = (
    "/v1/staff/me",   # must work so frontend can detect deactivation
    "/health",
    "/docs",
    "/redoc",
    "/openapi.json",
)

# Routes blocked in read-only/invalid license mode
_LICENSE_READONLY_PATHS = (
    "/v1/transactions",
    "/v1/invoices",
    "/v1/ai",
    "/v1/intake",
    "/v1/approvals",
    "/v1/clients",
)
_LICENSE_WRITE_METHODS = {"POST", "PUT", "PATCH", "DELETE"}

settings = get_settings()

# ---------------------------------------------------------------------------
# Structured logging setup
# ---------------------------------------------------------------------------
structlog.configure(
    wrapper_class=structlog.make_filtering_bound_logger(
        logging.getLevelName(settings.log_level.upper())
    ),
)
logger = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# Application Lifespan (startup / shutdown hooks)
# ---------------------------------------------------------------------------
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info(
        "Willows AI starting",
        version=settings.app_version,
        environment=settings.environment,
        ollama_model=settings.ollama_model,
    )
    yield
    logger.info("Willows AI shutting down")


# ---------------------------------------------------------------------------
# FastAPI application
# ---------------------------------------------------------------------------
app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description=(
        "Privacy-first, local AI bookkeeping. "
        "All data stays on your network — no cloud APIs used."
    ),
    docs_url="/docs" if settings.environment != "production" else None,
    redoc_url="/redoc" if settings.environment != "production" else None,
    openapi_url="/openapi.json" if settings.environment != "production" else None,
    lifespan=lifespan,
)

# ---------------------------------------------------------------------------
# Middleware
# ---------------------------------------------------------------------------
app.add_middleware(GZipMiddleware, minimum_size=1000)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:8080"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def active_staff_middleware(request: Request, call_next):
    """
    Block deactivated staff members from reaching any endpoint.
    Exempt paths (above) are always allowed so the frontend can
    determine deactivation status via GET /v1/staff/me.
    """
    staff_id = request.query_params.get("staff_id")
    if staff_id and not any(
        request.url.path.startswith(p) for p in _DEACTIVATED_EXEMPT_PREFIXES
    ):
        try:
            async with AsyncSessionLocal() as session:
                result = await session.execute(
                    text(
                        "SELECT active FROM staff_registry "
                        "WHERE user_id = :uid"
                    ),
                    {"uid": staff_id},
                )
                row = result.mappings().first()
                # Only block if the record exists AND active is explicitly False
                # (unknown staff_id falls through to normal endpoint handling)
                if row and not row["active"]:
                    return JSONResponse(
                        status_code=status.HTTP_403_FORBIDDEN,
                        content={
                            "detail": (
                                "Your account has been deactivated. "
                                "Contact your Willow administrator for assistance."
                            ),
                            "code": "STAFF_DEACTIVATED",
                        },
                    )
        except Exception:
            # Never block the request on a DB error — let the endpoint handle it
            pass

    return await call_next(request)


@app.middleware("http")
async def license_middleware(request: Request, call_next):
    """
    Enforce Willow's perpetual-fallback licence model.

    Only one customer-facing state blocks writes: a never-paid trial that has
    expired (mode=readonly). Paid licences that lapse enter mode=expired:
    writes continue, data remains usable, and updates/support are paused.
    """
    state = get_license_state()
    mode = state.get("mode", os.getenv("WILLOW_MODE", "trial"))
    readonly = bool(state.get("readonly", False))

    if readonly and request.method in _LICENSE_WRITE_METHODS:
        if any(request.url.path.startswith(p) for p in _LICENSE_READONLY_PATHS):
            return JSONResponse(
                status_code=status.HTTP_402_PAYMENT_REQUIRED,
                content={
                    "detail": state.get("message") or "Trial expired — read-only until a paid licence is installed.",
                    "license_mode": mode,
                    "writes_allowed": False,
                    "action": "Install a paid Willow licence to resume processing.",
                },
            )

    start    = time.perf_counter()
    response = await call_next(request)
    elapsed  = time.perf_counter() - start

    response.headers["X-Process-Time"] = f"{elapsed:.4f}s"
    response.headers["X-Willow-Mode"]  = str(mode)
    response.headers["X-Willow-Updates-Enabled"] = str(bool(state.get("updates_enabled", False))).lower()
    response.headers["X-Willow-Writes-Allowed"] = str(bool(state.get("writes_allowed", not readonly))).lower()
    return response


# ---------------------------------------------------------------------------
# Global exception handler
# ---------------------------------------------------------------------------
@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    logger.error("Unhandled exception", path=request.url.path, error=str(exc))
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "An internal server error occurred."},
    )


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
app.include_router(api_router, prefix="/v1")


@app.get("/health", tags=["System"])
async def health_check():
    return {"status": "ok", "version": settings.app_version}
