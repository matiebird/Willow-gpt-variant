"""
Willows AI — Celery Worker
Async task processing for the Grace receipt extraction pipeline
and Hayley reconciliation trigger.

Queues:
  receipts      → Grace OCR + LLM extraction tasks
  transactions  → Hayley Xero reconciliation trigger tasks

Run via docker-compose (celery-worker service):
  celery -A app.worker worker --loglevel=info --concurrency=2 -Q receipts,transactions
"""

from __future__ import annotations

import asyncio
import logging
import os
from typing import Any

from celery import Celery

from app.config import get_settings

logger = logging.getLogger(__name__)

settings = get_settings()

# =============================================================================
# Celery application
# =============================================================================

celery_app = Celery(
    "willow",
    broker=settings.celery_broker,
    backend=settings.celery_backend,
    include=["app.worker"],
)

celery_app.conf.update(
    # Serialisation
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    # Timezone
    timezone="Australia/Brisbane",
    enable_utc=True,
    # Routing
    task_routes={
        "app.worker.process_receipt": {"queue": "receipts"},
        "app.worker.reconcile_transactions": {"queue": "transactions"},
    },
    # Reliability — prevents VRAM contention when Ollama is processing
    worker_prefetch_multiplier=1,
    task_acks_late=True,
    task_reject_on_worker_lost=True,
    # Result expiry (24 hours)
    result_expires=86400,
)


# =============================================================================
# TASK: Receipt OCR + LLM extraction  (Grace pipeline)
# =============================================================================

@celery_app.task(
    name="app.worker.process_receipt",
    bind=True,
    max_retries=3,
    default_retry_delay=60,
)
def process_receipt(self, receipt_id: int) -> dict[str, Any]:
    """
    Process a receipt through the Grace extraction pipeline.

    Steps:
      1. Load receipt record from PostgreSQL
      2. Run Tesseract OCR on the stored image/PDF
      3. Send OCR text to Ollama (qwen2.5:7b) for structured extraction
      4. Persist extracted fields back to the receipts table

    Args:
        receipt_id: Primary key of the receipt row to process.

    Returns:
        dict with keys: receipt_id, status, extracted_data
    """
    from app.database import AsyncSessionLocal
    from app.services.receipt_processor import ReceiptProcessorService

    logger.info("[Grace] Processing receipt %d", receipt_id)

    async def _run() -> dict[str, Any]:
        async with AsyncSessionLocal() as session:
            service = ReceiptProcessorService(session)
            return await service.process(receipt_id)

    try:
        result = asyncio.run(_run())
        logger.info("[Grace] Receipt %d complete: status=%s", receipt_id, result.get("status"))
        return result
    except Exception as exc:
        logger.error("[Grace] Receipt %d failed: %s", receipt_id, exc)
        # Exponential back-off: 60 s, 120 s, 180 s
        countdown = 60 * (self.request.retries + 1)
        raise self.retry(exc=exc, countdown=countdown)


# =============================================================================
# TASK: Transaction reconciliation trigger  (Hayley pipeline)
# =============================================================================

@celery_app.task(
    name="app.worker.reconcile_transactions",
    bind=True,
    max_retries=3,
    default_retry_delay=120,
)
def reconcile_transactions(self, job_id: str) -> dict[str, Any]:
    """
    Trigger a Hayley reconciliation run via the n8n webhook.

    The n8n Hayley Reconciliation workflow handles the actual Xero API
    calls — this task is the async bridge from FastAPI to n8n.

    Args:
        job_id: Unique identifier for this reconciliation batch.

    Returns:
        dict with keys: job_id, status, n8n_response
    """
    import httpx

    n8n_base = os.getenv("N8N_INTERNAL_URL", "http://n8n:5678")
    webhook_path = "/webhook/willow-hayley-reconcile"
    api_key = os.getenv("WILLOW_API_KEY", "")

    logger.info("[Hayley] Starting reconciliation job %s", job_id)

    async def _run() -> dict[str, Any]:
        async with httpx.AsyncClient(timeout=300.0) as client:
            response = await client.post(
                f"{n8n_base}{webhook_path}",
                json={"job_id": job_id},
                headers={"X-API-Key": api_key},
            )
            response.raise_for_status()
            return {"job_id": job_id, "status": "triggered", "n8n_response": response.json()}

    try:
        result = asyncio.run(_run())
        logger.info("[Hayley] Job %s triggered successfully", job_id)
        return result
    except Exception as exc:
        logger.error("[Hayley] Job %s failed: %s", job_id, exc)
        countdown = 120 * (self.request.retries + 1)
        raise self.retry(exc=exc, countdown=countdown)
