"""
Willows AI — Chart of Accounts Model
Implements a standard double-entry bookkeeping chart of accounts.
"""

import enum
from decimal import Decimal
from typing import TYPE_CHECKING

from sqlalchemy import Enum, ForeignKey, Numeric, String, Text, Boolean
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDPrimaryKeyMixin, SoftDeleteMixin

if TYPE_CHECKING:
    from app.models.transaction import TransactionEntry


class AccountType(str, enum.Enum):
    """
    Standard accounting equation: Assets = Liabilities + Equity
    Normal balance: Assets/Expenses → Debit; Liabilities/Equity/Revenue → Credit
    """
    ASSET = "asset"
    LIABILITY = "liability"
    EQUITY = "equity"
    REVENUE = "revenue"
    EXPENSE = "expense"


class AccountSubtype(str, enum.Enum):
    # Assets
    CASH = "cash"
    BANK = "bank"
    ACCOUNTS_RECEIVABLE = "accounts_receivable"
    INVENTORY = "inventory"
    FIXED_ASSET = "fixed_asset"
    OTHER_ASSET = "other_asset"
    # Liabilities
    ACCOUNTS_PAYABLE = "accounts_payable"
    CREDIT_CARD = "credit_card"
    LOAN = "loan"
    TAX_PAYABLE = "tax_payable"
    OTHER_LIABILITY = "other_liability"
    # Equity
    RETAINED_EARNINGS = "retained_earnings"
    OWNERS_EQUITY = "owners_equity"
    # Revenue
    OPERATING_REVENUE = "operating_revenue"
    OTHER_INCOME = "other_income"
    # Expenses
    OPERATING_EXPENSE = "operating_expense"
    COST_OF_GOODS = "cost_of_goods"
    TAX_EXPENSE = "tax_expense"
    OTHER_EXPENSE = "other_expense"


class Account(Base, UUIDPrimaryKeyMixin, TimestampMixin, SoftDeleteMixin):
    """
    Represents an account in the chart of accounts.
    Supports hierarchical accounts (parent/child) for sub-account grouping.
    """
    __tablename__ = "accounts"

    # Identification
    code: Mapped[str] = mapped_column(String(20), unique=True, nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Classification
    account_type: Mapped[AccountType] = mapped_column(
        Enum(AccountType, name="account_type_enum", values_callable=lambda x: [e.value for e in x]), nullable=False, index=True
    )
    account_subtype: Mapped[AccountSubtype | None] = mapped_column(
        Enum(AccountSubtype, name="account_subtype_enum", values_callable=lambda x: [e.value for e in x]), nullable=True
    )

    # Hierarchy — self-referential for sub-accounts
    parent_id: Mapped[UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("accounts.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )

    # Current balance (denormalised for fast reads; recomputed from entries)
    balance: Mapped[Decimal] = mapped_column(
        Numeric(precision=15, scale=2), default=Decimal("0.00"), nullable=False
    )
    currency: Mapped[str] = mapped_column(String(3), default="AUD", nullable=False)

    # Flags
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_bank_account: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_system: Mapped[bool] = mapped_column(
        Boolean, default=False, nullable=False,
        comment="System accounts cannot be deleted or renamed"
    )

    # Tax settings
    tax_code: Mapped[str | None] = mapped_column(String(20), nullable=True)

    # Relationships
    parent: Mapped["Account | None"] = relationship(
        "Account", remote_side="Account.id", back_populates="children"
    )
    children: Mapped[list["Account"]] = relationship(
        "Account", back_populates="parent", cascade="all, delete-orphan"
    )
    entries: Mapped[list["TransactionEntry"]] = relationship(
        "TransactionEntry", back_populates="account"
    )

    def __repr__(self) -> str:
        return f"<Account {self.code}: {self.name} ({self.account_type})>"

    @property
    def normal_balance(self) -> str:
        """Returns 'debit' or 'credit' per standard accounting rules."""
        return "debit" if self.account_type in (
            AccountType.ASSET, AccountType.EXPENSE
        ) else "credit"
