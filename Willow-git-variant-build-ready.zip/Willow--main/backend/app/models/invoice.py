"""
Willows AI — Invoice & InvoiceItem Models
Supports both receivable (sales) and payable (purchase) invoices.
"""

import enum
from decimal import Decimal
from typing import TYPE_CHECKING

from sqlalchemy import (
    CheckConstraint, Date, Enum, ForeignKey, Numeric, String, Text, Boolean, Integer,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship, column_property
from sqlalchemy import select, func

from app.models.base import Base, TimestampMixin, UUIDPrimaryKeyMixin, SoftDeleteMixin

if TYPE_CHECKING:
    from app.models.transaction import Transaction
    from app.models.category import TaxRate


class InvoiceStatus(str, enum.Enum):
    DRAFT = "draft"
    SENT = "sent"
    PARTIAL = "partial"
    PAID = "paid"
    OVERDUE = "overdue"
    VOIDED = "voided"
    WRITTEN_OFF = "written_off"


class InvoiceType(str, enum.Enum):
    RECEIVABLE = "receivable"   # Sales invoice — we issue to clients
    PAYABLE = "payable"         # Purchase invoice — we receive from vendors


class Invoice(Base, UUIDPrimaryKeyMixin, TimestampMixin, SoftDeleteMixin):
    """
    Represents a sales or purchase invoice.
    Line items are stored in InvoiceItem rows.
    """
    __tablename__ = "invoices"

    # Identification
    invoice_number: Mapped[str] = mapped_column(String(50), unique=True, nullable=False, index=True)
    po_number: Mapped[str | None] = mapped_column(String(50), nullable=True)

    # Type & status
    invoice_type: Mapped[InvoiceType] = mapped_column(
        Enum(InvoiceType, name="invoice_type_enum", values_callable=lambda x: [e.value for e in x]), nullable=False, index=True
    )
    status: Mapped[InvoiceStatus] = mapped_column(
        Enum(InvoiceStatus, name="invoice_status_enum", values_callable=lambda x: [e.value for e in x]),
        nullable=False,
        default=InvoiceStatus.DRAFT,
        index=True,
    )

    # Counterparty (client or vendor)
    counterparty_name: Mapped[str] = mapped_column(String(200), nullable=False, index=True)
    counterparty_email: Mapped[str | None] = mapped_column(String(200), nullable=True)
    counterparty_address: Mapped[str | None] = mapped_column(Text, nullable=True)
    counterparty_abn: Mapped[str | None] = mapped_column(String(20), nullable=True, comment="Australian Business Number")

    # Dates
    issue_date: Mapped[Date] = mapped_column(Date, nullable=False, index=True)
    due_date: Mapped[Date | None] = mapped_column(Date, nullable=True, index=True)
    paid_date: Mapped[Date | None] = mapped_column(Date, nullable=True)

    # Amounts (computed from line items but cached here for performance)
    subtotal: Mapped[Decimal] = mapped_column(
        Numeric(precision=15, scale=2), nullable=False, default=Decimal("0.00")
    )
    tax_total: Mapped[Decimal] = mapped_column(
        Numeric(precision=15, scale=2), nullable=False, default=Decimal("0.00")
    )
    total: Mapped[Decimal] = mapped_column(
        Numeric(precision=15, scale=2), nullable=False, default=Decimal("0.00")
    )
    amount_paid: Mapped[Decimal] = mapped_column(
        Numeric(precision=15, scale=2), nullable=False, default=Decimal("0.00")
    )
    currency: Mapped[str] = mapped_column(String(3), default="AUD", nullable=False)

    # Content
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    terms: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Linked transaction (created when invoice is paid)
    transaction: Mapped["Transaction | None"] = relationship(
        "Transaction", back_populates="invoice", uselist=False
    )

    # Line items
    line_items: Mapped[list["InvoiceItem"]] = relationship(
        "InvoiceItem",
        back_populates="invoice",
        cascade="all, delete-orphan",
        order_by="InvoiceItem.sort_order",
        lazy="selectin",
    )

    __table_args__ = (
        CheckConstraint("subtotal >= 0", name="ck_invoice_subtotal_positive"),
        CheckConstraint("total >= 0", name="ck_invoice_total_positive"),
        CheckConstraint("amount_paid >= 0", name="ck_invoice_paid_positive"),
    )

    @property
    def balance_due(self) -> Decimal:
        return self.total - self.amount_paid

    @property
    def is_overdue(self) -> bool:
        from datetime import date
        return (
            self.due_date is not None
            and self.due_date < date.today()
            and self.status not in (InvoiceStatus.PAID, InvoiceStatus.VOIDED, InvoiceStatus.WRITTEN_OFF)
        )

    def __repr__(self) -> str:
        return f"<Invoice {self.invoice_number} {self.status} {self.total} {self.currency}>"


class InvoiceItem(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """A single line item on an invoice."""
    __tablename__ = "invoice_items"

    invoice_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("invoices.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    sort_order: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    description: Mapped[str] = mapped_column(String(500), nullable=False)
    quantity: Mapped[Decimal] = mapped_column(
        Numeric(precision=10, scale=4), nullable=False, default=Decimal("1.0000")
    )
    unit_price: Mapped[Decimal] = mapped_column(
        Numeric(precision=15, scale=4), nullable=False
    )
    discount_percent: Mapped[Decimal] = mapped_column(
        Numeric(precision=5, scale=2), nullable=False, default=Decimal("0.00"),
        comment="Percentage discount on this line, e.g. 10.00 for 10%"
    )

    # Tax
    tax_rate_id: Mapped[UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("tax_rates.id", ondelete="SET NULL"),
        nullable=True,
    )
    tax_amount: Mapped[Decimal] = mapped_column(
        Numeric(precision=15, scale=2), nullable=False, default=Decimal("0.00")
    )
    line_total: Mapped[Decimal] = mapped_column(
        Numeric(precision=15, scale=2), nullable=False
    )

    # Account mapping for this line item
    account_id: Mapped[UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("accounts.id", ondelete="SET NULL"),
        nullable=True,
    )

    # Relationships
    invoice: Mapped["Invoice"] = relationship("Invoice", back_populates="line_items")
    tax_rate: Mapped["TaxRate | None"] = relationship("TaxRate")

    __table_args__ = (
        CheckConstraint("quantity > 0", name="ck_item_quantity_positive"),
        CheckConstraint("line_total >= 0", name="ck_item_total_positive"),
    )

    def __repr__(self) -> str:
        return f"<InvoiceItem {self.description[:30]} × {self.quantity} @ {self.unit_price}>"
