"""
Willows AI — Model Registry
Import all models here so Alembic and SQLAlchemy can discover them via Base.metadata.
"""

from app.models.base import Base
from app.models.account import Account, AccountType, AccountSubtype
from app.models.category import Category, TaxRate
from app.models.transaction import Transaction, TransactionEntry, TransactionStatus, TransactionType, EntryType
from app.models.invoice import Invoice, InvoiceItem, InvoiceStatus, InvoiceType
from app.models.receipt import Receipt, ReceiptStatus

__all__ = [
    "Base",
    "Account", "AccountType", "AccountSubtype",
    "Category", "TaxRate",
    "Transaction", "TransactionEntry", "TransactionStatus", "TransactionType", "EntryType",
    "Invoice", "InvoiceItem", "InvoiceStatus", "InvoiceType",
    "Receipt", "ReceiptStatus",
]
