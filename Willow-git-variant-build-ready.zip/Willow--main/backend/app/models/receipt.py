"""
Willows AI — Receipt Upload & Processing Status Model
Tracks each uploaded receipt through the OCR → AI extraction pipeline.
"""

import enum
from typing import TYPE_CHECKING

from sqlalchemy import Enum, String, Text, Boolean, Integer, Float
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDPrimaryKeyMixin

if TYPE_CHECKING:
    from app.models.transaction import Transaction


class ReceiptStatus(str, enum.Enum):
    UPLOADED = "uploaded"           # File stored, awaiting processing
    OCR_PROCESSING = "ocr_processing"
    OCR_COMPLETE = "ocr_complete"
    AI_PROCESSING = "ai_processing"
    AI_COMPLETE = "ai_complete"
    REVIEW_NEEDED = "review_needed" # Low-confidence extraction — human check required
    LINKED = "linked"               # Successfully linked to a Transaction
    FAILED = "failed"
    DUPLICATE = "duplicate"         # Duplicate of an existing receipt


class Receipt(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """
    Tracks an uploaded receipt/document through the full AI extraction pipeline.
    Raw files are stored in the local upload volume; this model stores metadata only.
    """
    __tablename__ = "receipts"

    # File metadata
    original_filename: Mapped[str] = mapped_column(String(500), nullable=False)
    stored_filename: Mapped[str] = mapped_column(String(500), nullable=False, unique=True)
    file_path: Mapped[str] = mapped_column(String(1000), nullable=False)
    mime_type: Mapped[str] = mapped_column(String(100), nullable=False)
    file_size_bytes: Mapped[int] = mapped_column(Integer, nullable=False)
    file_hash: Mapped[str] = mapped_column(
        String(64), nullable=False, index=True,
        comment="SHA-256 hash for duplicate detection"
    )

    # Pipeline status
    status: Mapped[ReceiptStatus] = mapped_column(
        Enum(ReceiptStatus, name="receipt_status_enum", values_callable=lambda x: [e.value for e in x]),
        nullable=False,
        default=ReceiptStatus.UPLOADED,
        index=True,
    )
    processing_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    processing_attempts: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    # OCR output
    ocr_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    ocr_confidence: Mapped[float | None] = mapped_column(Float, nullable=True)

    # AI extraction output (raw JSON from LLM)
    ai_extracted_data: Mapped[dict | None] = mapped_column(
        JSONB, nullable=True,
        comment="Structured JSON extracted by the local LLM"
    )
    ai_confidence: Mapped[float | None] = mapped_column(Float, nullable=True)
    ai_model_used: Mapped[str | None] = mapped_column(String(100), nullable=True)

    # Human review
    reviewed_by_human: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    human_corrections: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    # Linked transaction (set once extraction is approved)
    transaction: Mapped["Transaction | None"] = relationship(
        "Transaction", back_populates="receipt", uselist=False
    )

    def __repr__(self) -> str:
        return f"<Receipt {self.original_filename} [{self.status}]>"
