"""
Willows AI — Transaction Category Model
Categories are AI-suggested labels mapped to accounts in the chart of accounts.
"""

from typing import TYPE_CHECKING

from sqlalchemy import ForeignKey, String, Text, Boolean
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDPrimaryKeyMixin

if TYPE_CHECKING:
    from app.models.account import Account
    from app.models.transaction import Transaction


class Category(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """
    User-defined or AI-suggested transaction categories.
    Each category maps to one or more accounts in the chart of accounts,
    enabling automatic journal entry creation.
    """
    __tablename__ = "categories"

    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False, index=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    colour: Mapped[str | None] = mapped_column(String(7), nullable=True, comment="Hex colour e.g. #4CAF50")
    icon: Mapped[str | None] = mapped_column(String(50), nullable=True, comment="Icon name from icon set")

    # Default account linkage (for automatic journal entries)
    default_account_id: Mapped[UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("accounts.id", ondelete="SET NULL"),
        nullable=True,
    )

    # GST / tax behaviour
    tax_rate_id: Mapped[UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("tax_rates.id", ondelete="SET NULL"),
        nullable=True,
    )

    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_system: Mapped[bool] = mapped_column(
        Boolean, default=False, nullable=False,
        comment="System categories seeded at startup"
    )

    # AI keyword hints (used to improve future classification)
    ai_keywords: Mapped[str | None] = mapped_column(
        Text, nullable=True,
        comment="Comma-separated keywords the LLM should associate with this category"
    )

    # Relationships
    default_account: Mapped["Account | None"] = relationship("Account", foreign_keys=[default_account_id])
    transactions: Mapped[list["Transaction"]] = relationship("Transaction", back_populates="category")

    def __repr__(self) -> str:
        return f"<Category {self.name}>"


class TaxRate(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """
    Tax rate definitions (e.g. GST 10%, GST-free 0%, Input-taxed).
    Linked to categories and invoice line items.
    """
    __tablename__ = "tax_rates"

    name: Mapped[str] = mapped_column(String(50), nullable=False)
    code: Mapped[str] = mapped_column(String(10), unique=True, nullable=False, index=True)
    rate: Mapped[float] = mapped_column(nullable=False, comment="As a decimal, e.g. 0.10 for 10%")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_default: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    categories: Mapped[list["Category"]] = relationship("Category", back_populates=None, foreign_keys=[Category.tax_rate_id])

    def __repr__(self) -> str:
        return f"<TaxRate {self.code}: {self.rate * 100:.1f}%>"
