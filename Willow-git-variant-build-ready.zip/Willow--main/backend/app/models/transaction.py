"""
Willows AI — Transaction & Journal Entry Models
Implements full double-entry bookkeeping: every transaction has two or more
journal entries (TransactionEntry rows) that balance to zero (debits = credits).
"""

import enum
from decimal import Decimal
from typing import TYPE_CHECKING

from sqlalchemy import (
    CheckConstraint, Enum, ForeignKey, Index, Numeric, String, Text, Boolean,
    Date, UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDPrimaryKeyMixin, SoftDeleteMixin

if TYPE_CHECKING:
    from app.models.account import Account
    from app.models.category import Category
    from app.models.receipt import Receipt
    from app.models.invoice import Invoice


class TransactionStatus(str, enum.Enum):
    DRAFT = "draft"
    PENDING = "pending"
    CLEARED = "cleared"
    RECONCILED = "reconciled"
    VOIDED = "voided"


class TransactionType(str, enum.Enum):
    INCOME = "income"
    EXPENSE = "expense"
    TRANSFER = "transfer"
    JOURNAL = "journal"         # Manual journal entry
    OPENING_BALANCE = "opening_balance"


class EntryType(str, enum.Enum):
    DEBIT = "debit"
    CREDIT = "credit"


class Transaction(Base, UUIDPrimaryKeyMixin, TimestampMixin, SoftDeleteMixin):
    """
    A financial transaction header. Paired with two or more TransactionEntry
    rows that represent the double-entry journal entries.
    """
    __tablename__ = "transactions"

    # Core fields
    date: Mapped[Date] = mapped_column(Date, nullable=False, index=True)
    description: Mapped[str] = mapped_column(String(500), nullable=False)
    reference: Mapped[str | None] = mapped_column(String(100), nullable=True, index=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Classification
    transaction_type: Mapped[TransactionType] = mapped_column(
        Enum(TransactionType, name="transaction_type_enum", values_callable=lambda x: [e.value for e in x]),
        nullable=False,
        default=TransactionType.EXPENSE,
        index=True,
    )
    status: Mapped[TransactionStatus] = mapped_column(
        Enum(TransactionStatus, name="transaction_status_enum", values_callable=lambda x: [e.value for e in x]),
        nullable=False,
        default=TransactionStatus.PENDING,
        index=True,
    )

    # Amount (gross total of the transaction)
    amount: Mapped[Decimal] = mapped_column(
        Numeric(precision=15, scale=2), nullable=False
    )
    tax_amount: Mapped[Decimal] = mapped_column(
        Numeric(precision=15, scale=2), nullable=False, default=Decimal("0.00")
    )
    currency: Mapped[str] = mapped_column(String(3), default="AUD", nullable=False)

    # Foreign keys
    category_id: Mapped[UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("categories.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )
    receipt_id: Mapped[UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("receipts.id", ondelete="SET NULL"),
        nullable=True,
    )
    invoice_id: Mapped[UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("invoices.id", ondelete="SET NULL"),
        nullable=True,
    )

    # AI metadata
    ai_categorised: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    ai_confidence: Mapped[float | None] = mapped_column(nullable=True)
    ai_raw_response: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Vendor / payee
    vendor_name: Mapped[str | None] = mapped_column(String(200), nullable=True, index=True)

    # Reconciliation
    bank_transaction_id: Mapped[str | None] = mapped_column(
        String(100), nullable=True, unique=True,
        comment="Unique ID from bank import — prevents duplicates"
    )

    # Relationships
    entries: Mapped[list["TransactionEntry"]] = relationship(
        "TransactionEntry",
        back_populates="transaction",
        cascade="all, delete-orphan",
        lazy="selectin",
    )
    category: Mapped["Category | None"] = relationship("Category", back_populates="transactions")
    receipt: Mapped["Receipt | None"] = relationship("Receipt", back_populates="transaction")
    invoice: Mapped["Invoice | None"] = relationship("Invoice", back_populates="transaction")

    __table_args__ = (
        CheckConstraint("amount >= 0", name="ck_transaction_amount_positive"),
        CheckConstraint("tax_amount >= 0", name="ck_transaction_tax_positive"),
        Index("ix_transactions_date_type", "date", "transaction_type"),
        Index("ix_transactions_vendor", "vendor_name"),
    )

    def __repr__(self) -> str:
        return f"<Transaction {self.date} {self.description} {self.amount} {self.currency}>"


class TransactionEntry(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """
    A single debit or credit journal entry within a Transaction.
    All entries for a transaction MUST balance: sum(debits) == sum(credits).
    """
    __tablename__ = "transaction_entries"

    transaction_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("transactions.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    account_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("accounts.id", ondelete="RESTRICT"),
        nullable=False,
        index=True,
    )
    entry_type: Mapped[EntryType] = mapped_column(
        Enum(EntryType, name="entry_type_enum", values_callable=lambda x: [e.value for e in x]), nullable=False
    )
    amount: Mapped[Decimal] = mapped_column(
        Numeric(precision=15, scale=2), nullable=False
    )
    description: Mapped[str | None] = mapped_column(String(200), nullable=True)

    # Relationships
    transaction: Mapped["Transaction"] = relationship("Transaction", back_populates="entries")
    account: Mapped["Account"] = relationship("Account", back_populates="entries")

    __table_args__ = (
        CheckConstraint("amount > 0", name="ck_entry_amount_positive"),
    )

    def __repr__(self) -> str:
        return f"<TransactionEntry {self.entry_type} {self.amount} → Account {self.account_id}>"
