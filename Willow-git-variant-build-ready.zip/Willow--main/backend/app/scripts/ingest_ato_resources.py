#!/usr/bin/env python3
"""
ATO Resource Pre-loader
========================
Run once at deployment to seed Willow's policy knowledge base with
key Australian Tax Office guidance.

This script embeds curated ATO content into the policy_chunks table
so Willow can reference it immediately without any manual uploads.

Usage:
  python -m app.scripts.ingest_ato_resources

The content here is curated from:
  - ATO Small Business Tax Time Toolkit
  - GST: How it works (ato.gov.au/gst)
  - Business deductions A-Z (ato.gov.au/business/income-and-deductions)
  - BAS lodgement guide
  - FBT guide for employers
  - Motor vehicle expenses for business
"""

import asyncio
import logging
import sys

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
log = logging.getLogger(__name__)


# =============================================================================
# ATO CONTENT LIBRARY
# Each entry: (title, category, content)
# =============================================================================

ATO_RESOURCES = [

    # ── GST FUNDAMENTALS ─────────────────────────────────────────────────────
    ("GST — How It Works for Australian Businesses", "compliance", """
GOODS AND SERVICES TAX (GST) — ATO GUIDE

GST is a 10% tax on most goods, services and other things sold or consumed in Australia.

If your business is registered for GST you must:
  • Include GST in the price you charge (for taxable supplies)
  • Issue tax invoices for sales over $82.50 including GST
  • Claim GST credits (input tax credits) on business purchases
  • Report and pay GST via your Business Activity Statement (BAS)

TAXABLE SUPPLIES (10% GST applies):
Most goods and services sold in Australia are taxable. You charge 10% GST on:
  - Sales of goods and services to Australian customers
  - Software subscriptions and digital services
  - Professional services (accounting, legal, consulting)
  - Repairs and maintenance
  - Office supplies, equipment and hardware
  - Advertising and marketing services
  - Motor vehicle expenses (fuel, servicing, tyres)
  - Rent on commercial premises
  - Travel and accommodation (domestic)
  - Meals and entertainment (10% GST, but may be limited deductible)

GST-FREE SUPPLIES (0% GST, still report on BAS):
You do not charge GST on:
  - Basic food (fresh fruit, vegetables, bread, meat, dairy — not hot food or restaurant meals)
  - Medical, health and childcare services
  - Education courses and materials
  - International travel and exports
  - Water and sewerage services (residential)
  - Financial services (interest, bank fees, insurance premiums)
  - Farmland and going concern sales (in some cases)

INPUT-TAXED SUPPLIES (no GST charged, no GST credit claimed):
  - Residential rents and accommodation
  - Financial supplies (loan interest, share dealings)
  - Life insurance

BAS EXCLUDED (do not report on BAS at all):
  - Wages, salaries and superannuation
  - PAYG instalments already withheld
  - Government grants (some)
  - Gifts of money

TAX INVOICES:
  - Required for any sale over $82.50 (inc. GST)
  - Must include: supplier ABN, date, description, GST amount, total amount
  - For purchases over $82.50 you must have a valid tax invoice to claim GST credits

CLAIMING GST CREDITS:
You can claim a GST credit (input tax credit) if:
  - You are registered for GST
  - The purchase was for your business
  - The purchase included GST
  - You hold a valid tax invoice
  - The purchase is not for private or exempt use

MIXED USE:
If something is used partly for business and partly private (e.g. a vehicle used 60% for work),
you can only claim the business portion of GST (60% in this case).
"""),

    # ── GST CODES REFERENCE ───────────────────────────────────────────────────
    ("GST Codes and BAS Labels — Quick Reference", "compliance", """
GST CODES FOR XERO AND BAS REPORTING

GST ON EXPENSES (INPUT2 / G11):
  Used for: standard business purchases where you can claim the full GST credit
  Examples: office supplies, software, professional services, fuel, rent, repairs
  BAS label: G11 — Other purchases

GST-FREE PURCHASES (FRE / G14):
  Used for: purchases that don't include GST
  Examples: bank fees, insurance premiums (life/health), fresh food purchases for resale,
            international freight, some medical supplies
  BAS label: G14 — Purchases for making input-taxed sales or for private use
  Note: You cannot claim a GST credit on these. The full cost is the expense.

BAS EXCLUDED / NO GST (NOINPUT / N-T):
  Used for: items not reported on BAS at all
  Examples: wages, superannuation, PAYG tax, loan repayments (principal component),
            shareholder distributions, private drawings
  Note: These never appear in G columns on BAS.

INPUT-TAXED (GSTNEXUS / G13):
  Used for: financial supplies and residential rent income/expense
  Examples: bank interest received, mortgage interest paid, residential rental expenses
  Note: Cannot claim GST credits. Expense is the full amount.

GST ON INCOME (OUTPUT2 / G1):
  Used for: your taxable sales where you collect GST from customers
  Examples: invoices for services, product sales
  BAS label: G1 — Total sales (include GST)

COMMON ACCOUNT CODE + GST CODE COMBINATIONS:
  Account 400 (Advertising)        → INPUT2 (taxable)
  Account 404 (Bank Charges)       → FRE (GST-free)
  Account 408 (Insurance)          → FRE (most premiums are GST-free)
  Account 410 (Meals/Entertainment)→ INPUT2 (but only 50% deductible — FBT may apply)
  Account 412 (Office Supplies)    → INPUT2 (taxable)
  Account 413 (Postage/Printing)   → INPUT2 (taxable — domestic)
  Account 414 (Professional Svcs)  → INPUT2 (taxable)
  Account 415 (Rent — commercial)  → INPUT2 (taxable)
  Account 416 (Repairs/Maintenance)→ INPUT2 (taxable)
  Account 453 (Software)           → INPUT2 (taxable)
  Account 476 (Superannuation)     → NOINPUT (BAS excluded)
  Account 477 (Wages)              → NOINPUT (BAS excluded)
  Account 489 (Motor Vehicle)      → INPUT2 (taxable)
  Account 493 (Travel)             → INPUT2 (domestic taxable; international GST-free)
  Account 499 (Other Expenses)     → INPUT2 (verify each case)
"""),

    # ── BUSINESS DEDUCTIONS ───────────────────────────────────────────────────
    ("Business Deductions A–Z — ATO Guide", "compliance", """
BUSINESS DEDUCTIONS — WHAT YOU CAN AND CANNOT CLAIM

The general rule: you can deduct a business expense if it was incurred to earn assessable income
and is not of a capital, private, or domestic nature.

ADVERTISING & MARKETING (Account 400):
  Fully deductible. Includes website costs, social media ads, printed materials,
  sponsorships for business purpose. GST claimable (INPUT2).

BANK CHARGES & FEES (Account 404):
  Fully deductible. Includes monthly account fees, merchant fees, transaction fees,
  EFTPOS terminal rental, Stripe/PayPal fees. Usually GST-FREE (FRE).
  Note: Loan interest is deductible but reported differently.

COMPUTER & SOFTWARE (Account 453):
  Fully deductible for outright purchase up to $20,000 under instant asset write-off.
  Subscriptions (SaaS) expensed immediately. GST claimable (INPUT2).
  Examples: Microsoft 365, Adobe Creative Cloud, Xero, MYOB, GitHub, Dropbox.

ENTERTAINMENT & MEALS (Account 410):
  Entertainment is generally NOT deductible (section 32-5 ITAA 1997).
  EXCEPTIONS where 50% deductible: meals provided for business purposes with clients.
  Staff meals on overnight travel: fully deductible.
  Morning tea/coffee provided to staff in office: generally non-deductible (FBT issue).
  Working lunches eaten alone: not entertainment, may be deductible.
  GST on entertainment: can only claim GST on the deductible portion.
  Fringe Benefits Tax (FBT): may apply to entertainment provided to employees.

FUEL & MOTOR VEHICLE (Account 489):
  Deductible to the extent used for business. Two methods:
  1. LOGBOOK METHOD: Keep a logbook for 12 consecutive weeks. Claim business %.
  2. CENTS PER KM: Up to 5,000km at ATO rate (currently 88c/km for 2024-25).
  Fuel receipts: GST claimable on the business portion (INPUT2).
  Purchases of vehicles over $68,108 (2024-25 luxury car limit): limits apply.

INSURANCE (Account 408):
  Business insurance premiums are fully deductible.
  Most insurance is GST-FREE (FRE): public liability, professional indemnity,
  workers compensation, life insurance, income protection.
  EXCEPTION: Some general insurance may include GST — check the tax invoice.
  Private health insurance: NOT deductible (personal expense).

INTEREST & LOAN COSTS (Account 404/Other):
  Interest on business loans is deductible. Principal repayments are NOT.
  Bank fees on business accounts: deductible, usually GST-free.
  Mixed use loans: only deductible on the business portion.

PROFESSIONAL SERVICES (Account 414):
  Fully deductible. Includes accounting fees, bookkeeping, legal advice,
  consulting, IT support, HR advice. GST claimable (INPUT2).
  Note: Legal costs for capital transactions (buying a business) are NOT deductible
  — they are added to the asset's cost base.

RENT & OCCUPANCY (Account 415):
  Commercial rent is fully deductible. GST claimable (INPUT2).
  Home office: can claim a portion using the ATO fixed rate (67c/hr in 2024-25)
  or actual expenses method. Cannot claim for mortgage interest or rates on home.

REPAIRS & MAINTENANCE (Account 416):
  Deductible if genuine repair/maintenance (not improvement).
  Replacing a broken window: deductible repair.
  Adding a new feature: capital improvement (depreciate, not expense).
  GST claimable (INPUT2).

SUPERANNUATION (Account 476):
  Employer super guarantee contributions are fully deductible.
  Must be paid by 28 days after quarter end to be deductible in that year.
  Rate: 11.5% for FY2024-25, 12% from FY2025-26.
  NOT on BAS (NOINPUT). No GST involved.

TRAVEL & TRANSPORT (Account 493):
  Business travel is deductible. Must have a business purpose.
  Airfares, taxis, ride-share, public transport: GST claimable (INPUT2 domestic).
  International airfares: GST-free (FRE).
  Overnight accommodation for business: deductible with receipts.
  Travel between home and work: generally NOT deductible (private travel).
  Travel between two workplaces on same day: deductible.

WAGES & SALARIES (Account 477):
  Fully deductible. NOT on BAS (NOINPUT). No GST.
  Includes: wages, salaries, bonuses, leave loadings, allowances paid to employees.
  Note: Super is reported separately (Account 476).

WHAT IS NOT DEDUCTIBLE:
  - Private or domestic expenses (home groceries, personal clothing, holidays)
  - Capital expenses (unless using immediate write-off provisions)
  - Fines and penalties (parking fines, ATO penalties)
  - Expenses to produce exempt income
  - Entertainment (subject to limited exceptions above)
  - Bribes and illegal payments
"""),

    # ── BAS GUIDE ─────────────────────────────────────────────────────────────
    ("Business Activity Statement (BAS) — Lodgement Guide", "compliance", """
BUSINESS ACTIVITY STATEMENT (BAS) — ATO GUIDE

The BAS reports your GST, PAYG withholding and PAYG instalments to the ATO.

BAS LODGEMENT FREQUENCY:
  Monthly:    Due 21st of the following month (turnover > $20M or voluntary)
  Quarterly:  Due 28 days after quarter end (most small businesses)
              Q1 (Jul-Sep): due 28 October
              Q2 (Oct-Dec): due 28 February (extended)
              Q3 (Jan-Mar): due 28 April
              Q4 (Apr-Jun): due 28 July
  Annual:     Due 31 October (if turnover under $75,000 and lodging via tax agent)

QUARTERLY DUE DATES — IMPORTANT:
  If using a registered tax agent, the due date may be extended.
  Always check with the ATO or agent for your specific lodgement date.

LABELS ON THE BAS:

GST SECTION:
  G1  — Total sales (inc GST). Report ALL sales including GST-free and input-taxed.
  G2  — Export sales (GST-free)
  G3  — Other GST-free sales
  G10 — Capital purchases (inc GST)
  G11 — Non-capital purchases (inc GST). Most general expenses go here.
  1A  — GST on sales (= G1 minus G2, G3, G4 / 11)
  1B  — GST credits (= G10 + G11 / 11)
  Net GST payable = 1A minus 1B

PAYG WITHHOLDING SECTION:
  W1  — Total salary, wages and other payments (gross, before tax)
  W2  — Total amounts withheld (tax withheld from employees)
  Due: 21st of month following payment (quarterly payers) or 28 days post quarter

PAYG INSTALMENT SECTION:
  T7  — PAYG instalment income (your business income)
  T8  — PAYG instalment amount (pre-calculated by ATO or use rate × income)

COMMON BAS MISTAKES:
  1. Including wages in G11 — wages are NOINPUT, not reported in GST section
  2. Claiming GST credits on purchases without a valid tax invoice
  3. Forgetting to include GST-free sales in G1
  4. Double-counting super (do not include in G11 or W1)
  5. Claiming GST on bank fees (usually GST-free)
  6. Claiming 100% GST on mixed-use expenses (only claim business portion)
  7. Not reconciling BAS to your accounting software before lodgement

RECORD KEEPING:
  Keep all tax invoices, receipts and business records for 5 years.
  The ATO can audit back 5 years from lodgement date.
"""),

    # ── FBT ───────────────────────────────────────────────────────────────────
    ("Fringe Benefits Tax (FBT) — Employer Guide", "compliance", """
FRINGE BENEFITS TAX (FBT) — ATO GUIDE

FBT applies to non-cash benefits provided to employees (and their associates) in connection
with their employment. FBT is paid by the EMPLOYER, not the employee.

FBT YEAR: 1 April to 31 March (different to income tax year)
FBT RATE: 47% (matches top marginal rate)
FBT RETURN: Due 21 May (or 25 June if lodged by tax agent)

COMMON FRINGE BENEFITS:
  CAR FRINGE BENEFIT: If an employer provides a car for private use.
  Two methods: Statutory Formula or Operating Cost (logbook).
  If car is used ONLY for business: no FBT.

  EXPENSE PAYMENT: Paying or reimbursing employee's private expenses.
  Examples: private health insurance, gym membership, personal phone bills.

  ENTERTAINMENT: Meals, recreation, accommodation provided to employees.
  Food and drink at work is generally an entertainment benefit.
  Minor benefits exemption: benefits under $300 per employee per occasion are exempt.
  The $300 threshold applies per occasion, not per year.
  Staff Christmas party on business premises, during a work day: exempt if minor.

  LAPTOP/PORTABLE DEVICE: One portable device primarily for work = FBT exempt.
  Additional devices of same type: may be taxable.

  TAXI TRAVEL: Travel in a taxi from or to a place of work is FBT exempt.

  CAR PARKING: Employer-provided parking may be taxable if near commercial parking.

MINOR BENEFITS EXEMPTION ($300 threshold):
  Benefits under $300 (inc. GST) per employee per occasion are exempt if they
  are infrequent and irregular and it would be unreasonable to expect the
  employer to keep records.
  Common uses: birthday gifts, isolated Christmas gifts, staff morning tea (occasional).
  NOT for regular ongoing benefits.

FBT AND GST:
  If you provide a fringe benefit and pay FBT, you can generally claim:
  - The GST credit on the purchase
  - The FBT paid as a deduction

FBT EXEMPTIONS FOR SMALL BUSINESSES:
  Electric vehicles (below luxury car limit) provided from 1 July 2022: FBT exempt.
  Work-related items: protective clothing, tools, briefcases, portable devices.
  Taxi/rideshare travel directly between work and a social function: check rules.

REPORTABLE FRINGE BENEFITS:
  Benefits over $2,000 grossed-up value must be reported on the employee's
  payment summary / income statement. This affects employee's income tests
  (e.g. Medicare levy surcharge, HECS repayment, family payments).
"""),

    # ── MOTOR VEHICLE ─────────────────────────────────────────────────────────
    ("Motor Vehicle Expenses — ATO Guide for Business", "compliance", """
MOTOR VEHICLE EXPENSES — ATO BUSINESS GUIDE

ELIGIBILITY:
You can claim vehicle expenses if the vehicle is used for business purposes.
Business use includes:
  - Travelling between workplaces on the same day
  - Travel to client meetings, work-related conferences, training
  - Transporting tools, equipment or supplies
NOT deductible: travel between home and your main place of business (private travel).

TWO METHODS FOR INDIVIDUALS AND SOLE TRADERS:

1. LOGBOOK METHOD (most accurate for high business use):
   - Keep a logbook for 12 continuous weeks that covers a representative period
   - Record every trip: date, odometer start/end, reason, kilometres
   - Calculate business use % from logbook
   - Claim that % of ALL vehicle running costs: fuel, insurance, rego, repairs,
     depreciation, lease payments, loan interest
   - Logbook valid for 5 years; remake if circumstances change significantly
   - GST claimable on business portion of expenses (INPUT2)
   - No cap on kilometres

2. CENTS PER KILOMETRE METHOD (simpler for lower use):
   - ATO set rate: 88 cents per km (2024-25), 85 cents per km (2023-24)
   - Claim up to 5,000 km per vehicle per year
   - Must be able to show business use (diary, records) — estimate is not enough
   - No separate fuel, oil or depreciation claims
   - GST NOT claimable (rate is all-inclusive)
   - Simpler but limited; not suited for high business use vehicles

FOR COMPANIES, TRUSTS, PARTNERSHIPS:
  - Always use logbook method (cents per km is only for individual taxpayers)
  - Company cars for employee use: FBT may apply on private use component
  - Electric vehicles below luxury car limit: may be FBT exempt from 1 Jul 2022

LUXURY CAR LIMIT (2024-25): $68,108 (fuel efficient: $76,950)
  - Depreciation and GST credits capped at the limit
  - GST credit capped at $6,192 (for standard vehicles)

FUEL TAX CREDITS:
  - Available to businesses for diesel or petrol used in heavy vehicles (over 4.5t GVM)
    travelling on public roads, or any vehicle used OFF public roads
  - Claim on BAS
  - Rate varies by fuel type — check ATO fuel tax credit rates
  - Light vehicles on public roads: NOT eligible for fuel tax credits
"""),

    # ── SMALL BUSINESS ENTITY ─────────────────────────────────────────────────
    ("Small Business Entity (SBE) Tax Concessions", "compliance", """
SMALL BUSINESS ENTITY (SBE) CONCESSIONS — ATO GUIDE

ELIGIBILITY: Business with aggregated annual turnover under $10 million.
Some concessions have lower thresholds — check each one.

INSTANT ASSET WRITE-OFF:
  - Claim the full cost of eligible depreciating assets in the year of purchase
  - Threshold for 2024-25: $20,000 per asset (subject to legislation)
  - Asset must be installed and ready for use in the income year
  - Applies to new AND second-hand assets (for SBE)
  - Does NOT apply to: horticultural plants, software developed in-house, assets
    leased to another entity, or assets costing $20,001 or more

SIMPLIFIED DEPRECIATION POOL:
  - Assets over $20,000 threshold go into a general small business pool
  - Depreciate at 15% in first year, 30% per year thereafter (diminishing value)
  - If pool balance < $20,000 at 30 June: write off entire pool

SIMPLIFIED TRADING STOCK RULES:
  - If your trading stock value changes by less than $5,000: do not need formal
    stocktake — can include estimate on tax return

CASH ACCOUNTING (SIMPLER BAS):
  - Option to report GST on cash basis (when money actually received/paid)
  - Rather than accruals basis (when invoice issued/received)
  - Suits businesses with large debtors or slow-paying clients

SMALL BUSINESS INCOME TAX OFFSET:
  - Sole traders: up to $1,000 offset against tax payable on business income
  - Rate: 16% of tax payable on business income (capped at $1,000)

PAY AS YOU GO (PAYG) INSTALMENTS:
  - ATO may ask you to pay instalments during the year
  - Based on prior year income or estimated current year
  - Can vary instalments if income changes significantly
  - Instalments offset against final tax bill

RECORD KEEPING:
  All businesses must keep records for 5 years from lodgement date.
  Electronic records are acceptable if they are accessible and readable.
"""),

    # ── SUPERANNUATION ────────────────────────────────────────────────────────
    ("Superannuation — Employer Obligations", "compliance", """
SUPERANNUATION GUARANTEE — EMPLOYER GUIDE

SUPER GUARANTEE RATE:
  2023-24: 11.0%
  2024-25: 11.5%
  2025-26: 12.0% (and stays at 12% indefinitely)

ELIGIBILITY — PAY SUPER TO:
  - All employees aged 18 and over earning $450 or more per month (NOTE: $450 threshold
    removed from 1 July 2022 — now pay for ALL earnings)
  - Employees under 18 if they work more than 30 hours per week
  - Contractors paid mainly for their labour (even if they have an ABN)

PAYMENT DEADLINES:
  Super must be received by the employee's fund by:
    Q1 (Jul-Sep): 28 October
    Q2 (Oct-Dec): 28 January
    Q3 (Jan-Mar): 28 April
    Q4 (Apr-Jun): 28 July
  Late super = super guarantee charge (SGC), which is NOT deductible.
  On-time super: deductible in the year it was paid.
  TIP: Allow 3-5 business days for processing — pay early.

WHAT TO CALCULATE SUPER ON (Ordinary Time Earnings — OTE):
  Include: base salary, casual loadings, commission, shift allowances, over-award payments
  Exclude: overtime (if separately identifiable), expense reimbursements, genuine allowances
  for special work conditions, tools/uniforms provided

CHOICE OF FUND:
  Employees can choose their super fund.
  If no choice made: use the fund specified by the employee's modern award,
  or if none, use the ATO-nominated 'stapled fund' (the employee's existing fund).

BOOKKEEPING:
  Account 476: Superannuation Expense
  GST code: NOINPUT (BAS excluded — no GST on super)
  Deductible: YES (when paid on time)
  Process: Super is NOT a BAS item. It is paid directly to the super fund.
  Clear it via payroll system (STP) — reported annually to ATO through Single Touch Payroll.

SUPER GUARANTEE CHARGE (if paid late):
  If super is paid late, the SGC applies:
  - SGC = super amount + interest (10% pa) + administration fee ($20 per employee per quarter)
  - SGC is NOT deductible (unlike on-time super which IS deductible)
  - Must lodge a SGC statement with ATO

SINGLE TOUCH PAYROLL (STP):
  All employers must report payroll (wages, PAYG, super) to ATO via STP.
  Phase 2: More detailed breakdown of income types required.
  Super reported through STP is a 'notification' — payment still goes direct to funds.
"""),

    # ── PAYG WITHHOLDING ──────────────────────────────────────────────────────
    ("PAYG Withholding — Employer Requirements", "compliance", """
PAY AS YOU GO (PAYG) WITHHOLDING — ATO GUIDE

WHAT IT IS:
PAYG withholding is the system where employers withhold tax from employee payments
and send it to the ATO on the employee's behalf.

WHO MUST WITHHOLD:
  - Employers paying salary, wages, allowances or leave payments to employees
  - Businesses paying other businesses that do not quote an ABN (47% withholding rate)
  - Payers of investment income (dividends, interest) where no TFN quoted (47%)

HOW MUCH TO WITHHOLD:
  Use ATO Tax Withheld Calculator or ATO tax tables:
  - Depends on gross wages, claim for tax-free threshold, tax offsets (LMITO/LITO)
  - Also depends on whether employee has HELP/HECS debt
  - Allowances: most taxable allowances have withholding (check ATO guidance)
  - Bonuses: use ATO extra payments method

WHEN TO REPORT AND PAY (via BAS):
  Small withholder (annual withholding under $25,000):
    - Report quarterly on BAS
    - Pay quarterly by 28 days after quarter end
  Medium withholder ($25,000 to $1M):
    - Report monthly on BAS
    - Pay monthly by 21st of following month
  Large withholder (over $1M):
    - Report and pay within 6-8 business days of payroll

SINGLE TOUCH PAYROLL (STP):
  Mandatory for all employers.
  Report every pay event (wages, PAYG, super) in real time via payroll software.
  ATO can see payroll data immediately after each pay run.
  Annual finalisation: finalise STP by 14 July each year (or later with extension).

PAYMENT SUMMARIES / INCOME STATEMENTS:
  Since STP Phase 2: payment summaries replaced by ATO income statements.
  Employees access via myGov — no separate summary required from employer.
  Employer must 'finalise' STP by 14 July each year.

BOOKKEEPING:
  Account: PAYG Withholding Liability (Balance Sheet, Account 2200 in Willow)
  GST code: NOINPUT (BAS excluded from GST section)
  Report on BAS: W1 (total wages) and W2 (amount withheld)
  Deductible: wages (W1) are deductible; W2 is just a payment to ATO on behalf of employee

PENALTIES:
  Failure to withhold: penalty equal to amount you should have withheld
  Late lodgement: Failure to Lodge penalty ($313 per 28 days, up to $1,565 for small entities)
  Late payment: General Interest Charge (GIC) at ~8.07% pa
"""),
]


# =============================================================================
# Ingestion runner
# =============================================================================

async def run_ingestion():
    """Connect to DB and ingest all ATO resources into the policy knowledge base."""
    import os
    import sys

    # Add backend to path
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

    from app.database import AsyncSessionLocal
    from app.services.policy_service import ingest_policy
    from sqlalchemy import text

    async with AsyncSessionLocal() as db:
        for title, category, content in ATO_RESOURCES:
            # Check if already ingested (by title)
            existing = await db.execute(
                text("SELECT id FROM policies WHERE title = :title"),
                {"title": title},
            )
            if existing.mappings().first():
                log.info(f"  SKIP (already exists): {title}")
                continue

            log.info(f"  Ingesting: {title}")
            try:
                policy_id = await ingest_policy(
                    db=db,
                    title=title,
                    category=category,
                    raw_text=content.strip(),
                    original_filename="ato_preload",
                    created_by=None,
                )
                log.info(f"  OK: {title} → {policy_id}")
            except Exception as e:
                log.error(f"  FAILED: {title} — {e}")

    log.info("ATO resource ingestion complete.")


if __name__ == "__main__":
    log.info("Starting ATO resource pre-load...")
    log.info(f"  {len(ATO_RESOURCES)} documents to ingest")
    asyncio.run(run_ingestion())
