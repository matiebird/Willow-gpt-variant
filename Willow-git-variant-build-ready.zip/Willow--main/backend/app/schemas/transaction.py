"""
Willows AI — Transaction Pydantic Schemas (Request/Response)
"""

import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Optional

from pydantic import BaseModel, Field, model_validator

from app.models.transaction import TransactionStatus, TransactionType, EntryType


class TransactionEntryBase(BaseModel):
    account_id: uuid.UUID
    entry_type: EntryType
    amount: Decimal = Field(gt=0)
    description: str | None = Field(default=None, max_length=200)


class TransactionEntryCreate(TransactionEntryBase):
    pass


class TransactionEntryRead(TransactionEntryBase):
    id: uuid.UUID
    transaction_id: uuid.UUID
    created_at: datetime

    model_config = {"from_attributes": True}


class TransactionBase(BaseModel):
    date: date
    description: str = Field(min_length=1, max_length=500)
    reference: str | None = Field(default=None, max_length=100)
    notes: str | None = None
    transaction_type: TransactionType = TransactionType.EXPENSE
    amount: Decimal = Field(ge=0)
    tax_amount: Decimal = Field(default=Decimal("0.00"), ge=0)
    currency: str = Field(default="AUD", max_length=3)
    vendor_name: str | None = Field(default=None, max_length=200)
    category_id: uuid.UUID | None = None


class TransactionCreate(TransactionBase):
    entries: list[TransactionEntryCreate] = Field(
        default_factory=list,
        description="Journal entry pairs. If empty, system auto-generates entries."
    )

    @model_validator(mode="after")
    def validate_entries_balance(self) -> "TransactionCreate":
        if not self.entries:
            return self  # Auto-generation path
        debits = sum(e.amount for e in self.entries if e.entry_type == EntryType.DEBIT)
        credits = sum(e.amount for e in self.entries if e.entry_type == EntryType.CREDIT)
        if debits != credits:
            raise ValueError(
                f"Journal entries must balance: debits ({debits}) ≠ credits ({credits})"
            )
        return self


class TransactionUpdate(BaseModel):
    date: Optional[date] = None
    description: str | None = Field(default=None, max_length=500)
    notes: str | None = None
    status: TransactionStatus | None = None
    category_id: uuid.UUID | None = None
    vendor_name: str | None = None


class TransactionRead(TransactionBase):
    id: uuid.UUID
    status: TransactionStatus
    ai_categorised: bool
    ai_confidence: float | None = None
    receipt_id: uuid.UUID | None = None
    invoice_id: uuid.UUID | None = None
    entries: list[TransactionEntryRead] = []
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class TransactionListResponse(BaseModel):
    items: list[TransactionRead]
    total: int
    page: int
    page_size: int
    total_pages: int


class TransactionSummary(BaseModel):
    """Financial summary for the dashboard."""
    period_start: date
    period_end: date
    total_income: Decimal
    total_expenses: Decimal
    net_profit: Decimal
    transaction_count: int
    pending_count: int
    currency: str = "AUD"
