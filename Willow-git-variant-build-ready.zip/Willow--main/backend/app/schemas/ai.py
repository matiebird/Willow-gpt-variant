"""
Willows AI — Pydantic Schemas for AI Extraction I/O
"""

from datetime import date
from typing import Any, Optional

from pydantic import BaseModel, Field, model_validator


class LineItem(BaseModel):
    description: str = Field(max_length=200)
    quantity: float = Field(default=1.0, ge=0)
    unit_price: float = Field(default=0.0, ge=0)
    amount: float = Field(default=0.0, ge=0)


class ExtractedReceiptData(BaseModel):
    """Structured financial data extracted from a receipt by the local LLM."""

    vendor_name: str | None = None
    date: Optional[date] = None
    total_amount: float = Field(default=0.0, ge=0)
    subtotal: float = Field(default=0.0, ge=0)
    tax_amount: float = Field(default=0.0, ge=0)
    tax_rate_percent: float | None = Field(default=None, ge=0, le=100)
    currency: str = Field(default="AUD", max_length=3)
    payment_method: str | None = None
    receipt_number: str | None = None
    abn: str | None = None
    category_suggestion: str = Field(default="Other", max_length=100)
    line_items: list[LineItem] = Field(default_factory=list)
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    notes: str | None = None

    @model_validator(mode="after")
    def ensure_subtotal(self) -> "ExtractedReceiptData":
        """If subtotal not set, derive it from total - tax."""
        if self.subtotal == 0.0 and self.total_amount > 0:
            self.subtotal = round(self.total_amount - self.tax_amount, 2)
        return self


class ExtractionResult(BaseModel):
    """
    Wrapper around an extraction attempt, including metadata about quality.
    """
    success: bool
    data: ExtractedReceiptData | None = None
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    raw_response: str | None = None
    error: str | None = None
    requires_human_review: bool = False


class TransactionClassification(BaseModel):
    """Result of classifying a bank transaction description."""
    category_suggestion: str = Field(default="Other")
    vendor_name: str | None = None
    transaction_type: str = Field(default="expense")  # income | expense | transfer
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    notes: str | None = None


# ── API Request / Response Schemas ───────────────────────────────────────────

class ReceiptUploadResponse(BaseModel):
    receipt_id: str
    status: str
    confidence: float | None = None
    extracted_data: ExtractedReceiptData | None = None
    requires_human_review: bool = False
    message: str = ""


class ClassifyTransactionRequest(BaseModel):
    description: str = Field(min_length=1, max_length=500)
    amount: float = Field(ge=0)
    currency: str = Field(default="AUD", max_length=3)
    date: Optional[date] = None


class AIHealthResponse(BaseModel):
    status: str
    configured_model: str
    model_available: bool
    available_models: list[str] = Field(default_factory=list)
    detail: str | None = None
