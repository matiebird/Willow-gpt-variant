"""
Willow Document Intake Pipeline
=================================
Receives documents from ANY channel (email, SMS, Telegram, web upload).

For every document:
  1. Convert original to PDF (preserve the source for audit trail)
  2. Run Grace (OCR + LLM extraction) to extract structured data
  3. Find or create the Xero contact
  4. Create a DRAFT bill/invoice in Xero (NEVER published — human approves)
  5. Attach the original PDF to the Xero draft
  6. Log everything to the document_intake table
  7. Create a task_queue entry for bookkeeper review

Supported input formats: JPEG, PNG, WEBP, PDF, HEIC, EML (email)
"""

import io
import base64
import logging
import os
import subprocess
import tempfile
import uuid
from datetime import datetime, timezone, date
from typing import Optional

import httpx
from pydantic import BaseModel

log = logging.getLogger(__name__)

BACKEND_URL = os.getenv("WILLOW_API_URL", "http://backend:8000")
WILLOW_API_KEY = os.getenv("WILLOW_API_KEY", "")
N8N_URL = os.getenv("N8N_BASE_URL", "http://n8n:5678")


# ── Data models ───────────────────────────────────────────────────────────────

class IntakeDocument(BaseModel):
    source: str                      # 'email' | 'sms' | 'telegram' | 'web' | 'voice'
    client_id: Optional[str] = None
    file_data: str                   # base64-encoded file bytes
    filename: str
    mime_type: str = "application/octet-stream"
    original_message: Optional[str] = None   # Text that accompanied the doc
    sender_identifier: Optional[str] = None  # email address / phone / telegram chat_id
    channel_contact_id: Optional[str] = None


class IntakeResult(BaseModel):
    intake_id: str
    xero_draft_id: Optional[str] = None
    xero_draft_type: Optional[str] = None   # 'invoice' | 'bill'
    pdf_path: Optional[str] = None
    extraction: Optional[dict] = None
    task_queue_id: Optional[str] = None
    status: str  # 'processing' | 'draft_created' | 'failed'
    message: str


# ── PDF conversion ────────────────────────────────────────────────────────────

def convert_to_pdf(file_bytes: bytes, filename: str, mime_type: str) -> bytes:
    """
    Convert any supported document to PDF bytes.
    Preserves the original for attachment to Xero drafts.
    
    Supported: images (img2pdf), existing PDFs (passthrough), EML emails (wkhtmltopdf).
    """
    ext = filename.lower().rsplit(".", 1)[-1] if "." in filename else ""

    # Already PDF — return as-is
    if mime_type == "application/pdf" or ext == "pdf":
        return file_bytes

    # Images — use img2pdf (lossless, preserves EXIF)
    if mime_type.startswith("image/") or ext in ("jpg", "jpeg", "png", "webp", "heic", "heif", "tiff"):
        try:
            import img2pdf
            return img2pdf.convert(io.BytesIO(file_bytes))
        except Exception as e:
            log.warning("intake.img2pdf_failed", error=str(e))
            # Fallback: convert via ImageMagick
            with tempfile.NamedTemporaryFile(suffix=f".{ext}", delete=False) as tmp_in:
                tmp_in.write(file_bytes)
                tmp_in_path = tmp_in.name
            tmp_out_path = tmp_in_path.replace(f".{ext}", ".pdf")
            try:
                subprocess.run(
                    ["convert", tmp_in_path, tmp_out_path],
                    check=True, timeout=30, capture_output=True
                )
                with open(tmp_out_path, "rb") as f:
                    return f.read()
            finally:
                for p in (tmp_in_path, tmp_out_path):
                    try: os.unlink(p)
                    except OSError: pass

    # EML / email — convert to PDF via wkhtmltopdf
    if mime_type in ("message/rfc822",) or ext == "eml":
        try:
            import email
            msg = email.message_from_bytes(file_bytes)
            html_body = ""
            for part in msg.walk():
                if part.get_content_type() == "text/html":
                    html_body = part.get_payload(decode=True).decode("utf-8", errors="replace")
                    break
                elif part.get_content_type() == "text/plain" and not html_body:
                    text = part.get_payload(decode=True).decode("utf-8", errors="replace")
                    html_body = f"<pre>{text}</pre>"
            
            subject = msg.get("Subject", "Email")
            sender  = msg.get("From", "")
            date_str = msg.get("Date", "")
            full_html = f"""
            <html><body>
            <h2>{subject}</h2>
            <p><strong>From:</strong> {sender}<br>
            <strong>Date:</strong> {date_str}</p>
            <hr>{html_body}
            </body></html>
            """
            with tempfile.NamedTemporaryFile(suffix=".html", delete=False, mode="w") as f:
                f.write(full_html)
                html_path = f.name
            pdf_path = html_path.replace(".html", ".pdf")
            subprocess.run(
                ["wkhtmltopdf", "--quiet", html_path, pdf_path],
                check=True, timeout=30, capture_output=True
            )
            with open(pdf_path, "rb") as f:
                return f.read()
        except Exception as e:
            log.error("intake.eml_conversion_failed", error=str(e))
            raise

    # Unknown format — return as-is and hope for the best
    log.warning("intake.unknown_format", filename=filename, mime=mime_type)
    return file_bytes


# ── Main intake service ───────────────────────────────────────────────────────

class DocumentIntakeService:

    def __init__(self, db, xero_service=None):
        self.db = db
        self.xero = xero_service   # May be None if Xero is not connected

    async def process(self, doc: IntakeDocument) -> IntakeResult:
        """
        Full intake pipeline: receive → PDF → Grace → Xero draft → attach → task.
        """
        intake_id = str(uuid.uuid4())
        log.info("intake.started", intake_id=intake_id, source=doc.source, filename=doc.filename)

        # 1. Decode file
        try:
            file_bytes = base64.b64decode(doc.file_data)
        except Exception as e:
            return IntakeResult(
                intake_id=intake_id, status="failed",
                message=f"Could not decode file data: {e}"
            )

        # 2. Convert to PDF
        try:
            pdf_bytes = convert_to_pdf(file_bytes, doc.filename, doc.mime_type)
        except Exception as e:
            log.error("intake.pdf_conversion_failed", error=str(e))
            pdf_bytes = file_bytes  # Use original if conversion fails

        # 3. Log to document_intake table
        from sqlalchemy import text
        pdf_filename = doc.filename.rsplit(".", 1)[0] + ".pdf"
        upload_dir = os.getenv("UPLOAD_DIR", "/app/uploads")
        pdf_path = os.path.join(upload_dir, f"{intake_id}_{pdf_filename}")
        os.makedirs(upload_dir, exist_ok=True)
        with open(pdf_path, "wb") as f:
            f.write(pdf_bytes)

        await self.db.execute(text("""
            INSERT INTO document_intake
                (id, source, client_id, original_filename, pdf_path, mime_type,
                 original_message, sender_identifier, channel_contact_id, status)
            VALUES
                (:id, :source, :client_id::uuid, :filename, :pdf_path, :mime,
                 :msg, :sender, :contact_id::uuid, 'processing')
        """), {
            "id": intake_id,
            "source": doc.source,
            "client_id": doc.client_id,
            "filename": doc.filename,
            "pdf_path": pdf_path,
            "mime": doc.mime_type,
            "msg": doc.original_message,
            "sender": doc.sender_identifier,
            "contact_id": doc.channel_contact_id,
        })
        await self.db.commit()

        # 4. Trigger Grace extraction (async — result comes back via n8n webhook)
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                await client.post(
                    f"{N8N_URL}/webhook/willow-grace-extraction",
                    files={"file": (doc.filename, file_bytes, doc.mime_type)},
                    data={"intake_id": intake_id, "client_id": doc.client_id or ""},
                )
        except Exception as e:
            log.warning("intake.grace_trigger_failed", error=str(e))

        # 5. Create Xero draft if service is available
        xero_draft_id = None
        xero_draft_type = None
        if self.xero and doc.client_id:
            try:
                xero_draft_id, xero_draft_type = await self._create_xero_draft(
                    intake_id, doc, pdf_bytes, pdf_filename
                )
            except Exception as e:
                log.error("intake.xero_draft_failed", error=str(e))

        # 6. Create task_queue entry for bookkeeper review
        task_id = str(uuid.uuid4())
        await self.db.execute(text("""
            INSERT INTO task_queue
                (id, priority, task_type, title, description, source, source_id,
                 client_id, status)
            VALUES
                (:id, 3, 'receipt_review',
                 :title, :desc, :source, :source_id::uuid,
                 :client_id::uuid, 'pending')
        """), {
            "id": task_id,
            "title": f"Review document from {doc.source}: {doc.filename}",
            "desc": (
                f"Received via {doc.source}. "
                f"{'Message: ' + doc.original_message if doc.original_message else ''} "
                f"{'Xero draft created: ' + xero_draft_id if xero_draft_id else 'Pending Xero draft — Grace extraction in progress.'}"
            ),
            "source": doc.source,
            "source_id": intake_id,
            "client_id": doc.client_id,
        })
        await self.db.execute(text("""
            UPDATE document_intake SET status='draft_created', task_queue_id=:tid
            WHERE id=:id
        """), {"tid": task_id, "id": intake_id})
        await self.db.commit()

        log.info("intake.complete", intake_id=intake_id, xero_draft_id=xero_draft_id)
        return IntakeResult(
            intake_id=intake_id,
            xero_draft_id=xero_draft_id,
            xero_draft_type=xero_draft_type,
            pdf_path=pdf_path,
            task_queue_id=task_id,
            status="draft_created" if xero_draft_id else "processing",
            message=(
                "Draft created in Xero and queued for bookkeeper review."
                if xero_draft_id else
                "Document received. Extraction in progress — draft will be created shortly."
            )
        )

    async def _create_xero_draft(
        self, intake_id: str, doc: IntakeDocument, pdf_bytes: bytes, pdf_filename: str
    ) -> tuple[str, str]:
        """Create a DRAFT bill in Xero and attach the original PDF."""
        from app.services.xero_service import XeroService
        from sqlalchemy import text

        # Get Xero tokens from DB
        result = await self.db.execute(text(
            "SELECT access_token, tenant_id FROM xero_tokens ORDER BY expires_at DESC LIMIT 1"
        ))
        token_row = result.mappings().first()
        if not token_row:
            raise RuntimeError("No Xero tokens — OAuth not completed")

        xero = XeroService(token_row["access_token"], token_row["tenant_id"])

        # Get client name for Xero contact lookup
        client_result = await self.db.execute(
            text("SELECT business_name, contact_email AS email FROM client_registry WHERE client_id=:id"),
            {"id": doc.client_id}
        )
        client = client_result.mappings().first()
        contact_name = client["business_name"] if client else "Unknown"
        contact_email = client.get("email", "") if client else ""

        # Find or create Xero contact
        contact_id = await xero.find_or_create_contact(contact_name, contact_email)

        # ── ATO-assisted account coding ─────────────────────────────────────
        # Check if this supplier has prior invoices in Xero/intake log.
        # If not, ask the ATO service to suggest a coding based on the filename
        # and any message context. This replaces the hardcoded placeholder.
        account_code = "499"  # Other Expenses (safe default)
        gst_type     = "INPUT2"
        ato_note     = None
        requires_review = True

        try:
            from app.services.ato_service import suggest_account_coding

            # Check prior invoice count for this supplier contact
            prior_count_result = await self.db.execute(
                text("""
                    SELECT COUNT(*) FROM document_intake
                    WHERE sender_identifier = :sender
                    AND status != 'failed'
                    AND id != :current_id
                """),
                {"sender": doc.sender_identifier or "", "current_id": intake_id},
            )
            prior_count = prior_count_result.scalar() or 0

            if prior_count == 0:
                # New supplier — use ATO service to suggest coding
                coding = await suggest_account_coding(
                    db=self.db,
                    supplier_name=contact_name,
                    description=doc.original_message or doc.filename,
                    amount=None,
                )
                account_code    = coding["account_code"]
                gst_type        = coding["gst_type"]
                ato_note        = coding.get("bookkeeper_note", "")
                requires_review = coding.get("requires_review", True)
                log.info(
                    "intake.ato_coding",
                    supplier=contact_name,
                    account=account_code,
                    confidence=coding.get("confidence"),
                    source=coding.get("source"),
                )
            else:
                # Returning supplier — use prior coding (Xero will have history)
                requires_review = False
                ato_note = None
        except Exception as e:
            log.warning("intake.ato_coding_failed", error=str(e))
            # Fall through with defaults

        # Build description for the Xero draft
        draft_description = f"Via {doc.source} — {doc.original_message or doc.filename}"
        if ato_note:
            draft_description += f" | ATO NOTE: {ato_note}"
        if requires_review:
            draft_description += " | ⚠ REQUIRES BOOKKEEPER REVIEW"

        # Create DRAFT bill (Grace will update line items with extracted amounts;
        # this initial draft uses ATO-suggested coding, not a hardcoded placeholder)
        today = date.today().isoformat()
        bill = await xero.create_bill_draft(
            contact_id=contact_id,
            line_items=[{
                "Description": (
                    f"Document intake — {doc.filename}. "
                    f"{'Awaiting Grace extraction.' if prior_count == 0 else 'Returning supplier — Grace will update.'}"
                    + (f" ATO guidance: {ato_note}" if ato_note else "")
                ),
                "Quantity": 1,
                "UnitAmount": 0.00,
                "AccountCode": account_code,
                "TaxType": gst_type,
            }],
            date=today,
            due_date=today,
            reference=f"WILLOW-{intake_id[:8].upper()}",
            description=draft_description,
        )

        invoice_id = bill.get("InvoiceID")

        # Attach original PDF to the Xero draft
        if invoice_id and pdf_bytes:
            await xero.attach_pdf_to_invoice(invoice_id, pdf_bytes, pdf_filename)

        # Log Xero draft reference
        await self.db.execute(text("""
            UPDATE document_intake
            SET xero_draft_id=:xid, xero_draft_type='bill'
            WHERE id=:id
        """), {"xid": invoice_id, "id": intake_id})

        return invoice_id, "bill"
