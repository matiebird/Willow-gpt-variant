"""Local AI orchestration helpers for Willow, Grace and Hayley.

These helpers are deliberately defensive for a sellable appliance:
- they prefer local Ollama
- they tolerate Ollama being offline during first boot
- they always return structured JSON envelopes so workflows do not crash
"""

from __future__ import annotations

import json
import re
from decimal import Decimal
from typing import Any

import httpx

from app.config import get_settings


JSON_RE = re.compile(r"\{[\s\S]*\}")


def extract_json_object(raw: str) -> dict[str, Any]:
    """Extract the first JSON object from an LLM response."""
    if not raw:
        return {}
    try:
        parsed = json.loads(raw)
        return parsed if isinstance(parsed, dict) else {}
    except Exception:
        pass
    match = JSON_RE.search(raw)
    if not match:
        return {}
    try:
        parsed = json.loads(match.group(0))
        return parsed if isinstance(parsed, dict) else {}
    except Exception:
        return {}


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None or value == "":
            return default
        return float(value)
    except Exception:
        return default


def normalise_confidence(value: Any, default: float = 0.5) -> float:
    confidence = _safe_float(value, default)
    if confidence > 1:
        confidence = confidence / 100
    return max(0.0, min(1.0, confidence))


async def chat_json(messages: list[dict[str, str]], temperature: float = 0.0) -> dict[str, Any]:
    """Call Ollama chat endpoint and return a parsed JSON object.

    The product API should remain usable during setup even if Ollama is not ready,
    so connection/model errors return a structured fallback instead of crashing.
    """
    settings = get_settings()
    payload = {
        "model": settings.ollama_model,
        "messages": messages,
        "stream": False,
        "options": {"temperature": temperature},
    }
    try:
        async with httpx.AsyncClient(timeout=settings.ollama_request_timeout) as client:
            response = await client.post(f"{settings.ollama_base_url.rstrip('/')}/api/chat", json=payload)
            response.raise_for_status()
            data = response.json()
    except Exception as exc:
        return {
            "ok": False,
            "ai_available": False,
            "error": f"Ollama unavailable or model not ready: {type(exc).__name__}: {exc}",
            "confidence": 0.0,
            "needs_human_review": True,
        }

    raw = data.get("message", {}).get("content") or data.get("response") or "{}"
    parsed = extract_json_object(raw)
    parsed.setdefault("raw_ai_response", raw)
    parsed.setdefault("ai_available", True)
    return parsed


def classify_email_fallback(payload: dict[str, Any]) -> dict[str, Any]:
    """Deterministic first-boot classifier used when Ollama is unavailable."""
    subject = (payload.get("subject") or "").lower()
    body = (payload.get("body") or payload.get("snippet") or "").lower()
    text = f"{subject}\n{body}"
    attachments = payload.get("attachments") or []

    document_type = "general_query"
    recommended_action = "create_task"
    if any(word in text for word in ["invoice", "tax invoice", "bill attached"]):
        document_type = "invoice"
        recommended_action = "send_to_grace"
    elif any(word in text for word in ["receipt", "eftpos", "purchase"]):
        document_type = "receipt"
        recommended_action = "send_to_grace"
    elif any(word in text for word in ["bas", "activity statement", "ato"]):
        document_type = "ato_correspondence"
        recommended_action = "notify_staff"
    elif any(word in text for word in ["unsubscribe", "newsletter", "marketing"]):
        document_type = "newsletter"
        recommended_action = "ignore"

    urgency = "routine"
    if any(word in text for word in ["urgent", "overdue", "final notice", "due today", "penalty"]):
        urgency = "urgent"
    elif any(word in text for word in ["due", "deadline", "tomorrow", "reminder"]):
        urgency = "time_sensitive"

    if attachments and document_type == "general_query":
        document_type = "invoice"
        recommended_action = "send_to_grace"

    return {
        "client_match": "unknown",
        "document_type": document_type,
        "urgency": urgency,
        "needs_human_review": True,
        "confidence": 0.55,
        "summary": (payload.get("subject") or "Email received")[:220],
        "recommended_action": recommended_action,
        "ai_available": False,
        "fallback_used": True,
    }


async def classify_email(payload: dict[str, Any]) -> dict[str, Any]:
    """Willow coordinator: classify inbound email into auditable routing intent."""
    system = (
        "You are Willow, the coordinator for an Australian bookkeeping firm. "
        "Classify inbound email and return ONLY valid JSON. Do not provide tax advice. "
        "AI may suggest, draft and route tasks, but humans approve financial actions. "
        "Use send_to_grace only for invoices, receipts, bank statements, statements, or attachments likely to contain documents."
    )
    user = {
        "from": payload.get("from") or payload.get("sender"),
        "subject": payload.get("subject"),
        "snippet": payload.get("snippet") or payload.get("text") or payload.get("body"),
        "attachment_count": len(payload.get("attachments") or []),
    }
    schema = {
        "client_match": "client name, new_enquiry, internal, unknown",
        "document_type": "invoice|receipt|statement|bank_statement|bas_query|payroll_query|general_query|ato_correspondence|government_notice|quote|purchase_order|spam|newsletter|irrelevant",
        "urgency": "urgent|time_sensitive|routine",
        "needs_human_review": True,
        "confidence": 0.0,
        "summary": "one sentence",
        "recommended_action": "create_task|send_to_grace|notify_staff|ignore|draft_reply",
    }
    result = await chat_json([
        {"role": "system", "content": system},
        {"role": "user", "content": f"Email: {json.dumps(user, ensure_ascii=False)}\nReturn JSON shaped like: {json.dumps(schema)}"},
    ])
    if not result.get("ai_available", True) or not result:
        return classify_email_fallback(payload)

    result.setdefault("client_match", "unknown")
    result.setdefault("document_type", "general_query")
    result.setdefault("urgency", "routine")
    result.setdefault("recommended_action", "create_task")
    result["confidence"] = normalise_confidence(result.get("confidence"), 0.6)
    result["needs_human_review"] = bool(result.get("needs_human_review", True))
    return result


def grace_fallback(payload: dict[str, Any]) -> dict[str, Any]:
    filename = payload.get("filename") or "document"
    text = f"{filename}\n{payload.get('text') or ''}\n{payload.get('email_subject') or ''}"
    amount_match = re.search(r"\$?\b([0-9]{1,3}(?:,[0-9]{3})*(?:\.[0-9]{2})|[0-9]+(?:\.[0-9]{2}))\b", text)
    amount = None
    if amount_match:
        try:
            amount = float(amount_match.group(1).replace(",", ""))
        except Exception:
            amount = None
    invoice_match = re.search(r"(?:invoice|inv|tax invoice)[\s:#-]*([A-Za-z0-9-]{3,})", text, re.I)
    vendor = (payload.get("sender") or "unknown").split("<")[-1].replace(">", "").strip() or "unknown"
    return {
        "document_type": "invoice" if "invoice" in text.lower() else "document",
        "vendor": vendor,
        "invoice_number": invoice_match.group(1) if invoice_match else None,
        "invoice_date": None,
        "due_date": None,
        "amount": amount,
        "gst": round(amount / 11, 2) if amount else None,
        "currency": "AUD",
        "abn": None,
        "line_items": [],
        "confidence": 0.35 if amount else 0.2,
        "needs_review": True,
        "recommended_action": "manual_review",
        "ai_available": False,
        "fallback_used": True,
        "summary": f"Document received for review: {filename}",
    }


async def grace_extract(payload: dict[str, Any]) -> dict[str, Any]:
    """Grace: extract document facts into a safe review-ready JSON object."""
    system = (
        "You are Grace, Willow's document extraction agent for an Australian bookkeeping firm. "
        "Extract facts only from the supplied document/email context. Do not invent missing values. "
        "Return ONLY valid JSON. Never recommend payment or lodgement."
    )
    schema = {
        "document_type": "invoice|receipt|statement|bank_statement|quote|purchase_order|unknown",
        "vendor": "supplier/business name or null",
        "invoice_number": "string or null",
        "invoice_date": "YYYY-MM-DD or null",
        "due_date": "YYYY-MM-DD or null",
        "amount": 0.0,
        "gst": 0.0,
        "currency": "AUD",
        "abn": "string or null",
        "line_items": [{"description": "string", "amount": 0.0, "gst": 0.0}],
        "confidence": 0.0,
        "needs_review": True,
        "recommended_action": "manual_review|send_to_hayley",
        "summary": "one sentence",
    }
    text_context = {
        "filename": payload.get("filename"),
        "sender": payload.get("sender"),
        "email_subject": payload.get("email_subject"),
        "text": (payload.get("text") or payload.get("ocr_text") or "")[:6000],
        "has_file_base64": bool(payload.get("file_base64")),
        "mime_type": payload.get("mime_type"),
    }
    result = await chat_json([
        {"role": "system", "content": system},
        {"role": "user", "content": f"Document context: {json.dumps(text_context, ensure_ascii=False)}\nReturn JSON shaped like: {json.dumps(schema)}"},
    ], temperature=0.0)
    if not result.get("ai_available", True) or not result:
        return grace_fallback(payload)

    fallback = grace_fallback(payload)
    for key, value in fallback.items():
        result.setdefault(key, value)
    result["confidence"] = normalise_confidence(result.get("confidence"), 0.4)
    result["needs_review"] = bool(result.get("needs_review", result["confidence"] < 0.85))
    if result["confidence"] >= 0.8 and result.get("amount"):
        result.setdefault("recommended_action", "send_to_hayley")
    return result


async def hayley_reconcile(payload: dict[str, Any]) -> dict[str, Any]:
    """Hayley: compare extracted document facts with supplied accounting context."""
    system = (
        "You are Hayley, Willow's reconciliation agent. You compare extracted invoice/receipt data "
        "against supplied transactions or accounting context. You only recommend a draft or review action. "
        "Return ONLY valid JSON. Never approve, lodge or pay anything."
    )
    schema = {
        "match_status": "matched|possible_match|duplicate_suspected|no_match|insufficient_data",
        "matched_transaction_id": "string or null",
        "duplicate_risk": "low|medium|high",
        "confidence": 0.0,
        "recommended_action": "create_draft_bill|attach_to_transaction|manual_review|reject_duplicate",
        "reason": "brief reason",
        "needs_review": True,
    }
    result = await chat_json([
        {"role": "system", "content": system},
        {"role": "user", "content": f"Reconcile payload: {json.dumps(payload, ensure_ascii=False, default=str)[:8000]}\nReturn JSON shaped like: {json.dumps(schema)}"},
    ], temperature=0.0)
    if not result.get("ai_available", True) or not result:
        invoice = payload.get("invoice") or payload.get("document") or {}
        return {
            "match_status": "insufficient_data",
            "matched_transaction_id": None,
            "duplicate_risk": "medium" if invoice.get("invoice_number") else "low",
            "confidence": 0.25,
            "recommended_action": "manual_review",
            "reason": "Hayley fallback: AI unavailable or insufficient transaction context.",
            "needs_review": True,
            "ai_available": False,
            "fallback_used": True,
        }
    result.setdefault("match_status", "insufficient_data")
    result.setdefault("matched_transaction_id", None)
    result.setdefault("duplicate_risk", "medium")
    result.setdefault("recommended_action", "manual_review")
    result.setdefault("reason", "Reconciliation completed with limited context")
    result["confidence"] = normalise_confidence(result.get("confidence"), 0.4)
    result["needs_review"] = bool(result.get("needs_review", True))
    return result


async def receptionist_turn(payload: dict[str, Any], context: dict[str, Any] | None = None) -> dict[str, Any]:
    """Willow receptionist turn. Returns safe action envelope for telephony/n8n."""
    context = context or {}
    system = (
        "You are Willow, a warm, concise AI receptionist for an Australian bookkeeping firm. "
        "You may provide general admin information only. Do not provide tax, legal or financial advice. "
        "When unsure, create a callback task. Return ONLY JSON."
    )
    schema = {
        "text": "spoken reply",
        "action": "continue|transfer|voicemail|callback|create_task",
        "extension": None,
        "priority": "normal|urgent",
        "confidence": 0.0,
        "reason": "brief reason",
    }
    user = {
        "caller_number": payload.get("caller_number"),
        "transcript": payload.get("transcript"),
        "turn_number": payload.get("turn_number"),
        "context": context,
    }
    result = await chat_json([
        {"role": "system", "content": system},
        {"role": "user", "content": f"Call turn: {json.dumps(user, ensure_ascii=False)}\nReturn JSON shaped like: {json.dumps(schema)}"},
    ], temperature=0.2)
    if not result.get("ai_available", True) or not result:
        return {
            "text": "Thanks, I can help organise that. I’ll create a callback task for the team.",
            "action": "callback",
            "extension": None,
            "priority": "normal",
            "confidence": 0.35,
            "reason": "Receptionist fallback: AI unavailable or first boot mode.",
            "needs_review": True,
            "ai_available": False,
            "fallback_used": True,
        }
    if result.get("action") not in {"continue", "transfer", "voicemail", "callback", "create_task"}:
        result["action"] = "callback"
    result["confidence"] = normalise_confidence(result.get("confidence"), 0.5)
    return result
