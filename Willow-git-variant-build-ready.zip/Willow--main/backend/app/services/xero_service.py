"""
Willow Xero Service
====================
POLICY: Willow NEVER publishes to Xero. Every invoice, bill, credit note, or
purchase order created by Willow is set to Status="DRAFT". Human staff must
open Xero, review the draft, and approve it manually before it becomes live.

This module is the ONLY place in the codebase that talks to the Xero API.
All other services must go through these methods — never call Xero directly.

Enforcement:
  - _enforce_draft() is called on every outbound payload. It overrides any
    Status field to "DRAFT" and raises XeroDraftViolation if anything tries
    to pass Status="AUTHORISED" or "SUBMITTED".
  - Logged to audit_log table on every Xero API call.
"""

import httpx
import logging
import json
from typing import Any
from datetime import datetime, timezone

log = logging.getLogger(__name__)

# ── Xero OAuth token store (populated by Xero OAuth callback) ─────────────────
# Tokens are stored in the DB — loaded fresh before each API call.

XERO_API_BASE = "https://api.xero.com/api.xro/2.0"
XERO_TOKEN_URL = "https://identity.xero.com/connect/token"

BLOCKED_STATUSES = {"AUTHORISED", "SUBMITTED", "PAID", "VOIDED", "DELETED"}


class XeroDraftViolation(RuntimeError):
    """Raised when any code path attempts to publish a Xero document."""
    pass


class XeroAuthError(RuntimeError):
    """Raised when Xero access token is missing or expired."""
    pass


def _enforce_draft(payload: dict, resource: str = "invoice") -> dict:
    """
    CRITICAL POLICY GATE — called before every Xero write.

    Ensures Status is always DRAFT. Raises XeroDraftViolation if a blocked
    status is explicitly requested — this surfaces as a 422 to the API caller
    rather than silently overriding, so the violation is visible.
    """
    # Check nested arrays (Invoices, Bills, CreditNotes, etc.)
    for key in ("Invoices", "Bills", "CreditNotes", "PurchaseOrders", "Quotes"):
        if key in payload:
            for item in payload[key]:
                status = item.get("Status", "DRAFT")
                if status in BLOCKED_STATUSES:
                    raise XeroDraftViolation(
                        f"POLICY VIOLATION: Attempted to set {resource} Status='{status}'. "
                        f"Willow only creates DRAFT records. A human must approve in Xero."
                    )
                item["Status"] = "DRAFT"

    # Also check flat payload
    if "Status" in payload:
        if payload["Status"] in BLOCKED_STATUSES:
            raise XeroDraftViolation(
                f"POLICY VIOLATION: Status='{payload['Status']}' blocked. DRAFT only."
            )
        payload["Status"] = "DRAFT"

    return payload


class XeroService:
    """
    All Xero API interactions go through this class.
    Draft-only policy is enforced at the lowest level — there is no bypass.
    """

    def __init__(self, access_token: str, tenant_id: str):
        if not access_token:
            raise XeroAuthError("Xero access token is required")
        if not tenant_id:
            raise XeroAuthError("Xero tenant ID is required")
        self.access_token = access_token
        self.tenant_id = tenant_id

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.access_token}",
            "Xero-Tenant-Id": self.tenant_id,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    async def _get(self, path: str, params: dict = None) -> dict:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(
                f"{XERO_API_BASE}/{path}",
                headers=self._headers(),
                params=params or {},
            )
            resp.raise_for_status()
            return resp.json()

    async def _post(self, path: str, payload: dict, resource: str = "invoice") -> dict:
        """Post to Xero — ALWAYS enforces DRAFT status before sending."""
        safe_payload = _enforce_draft(payload, resource)
        log.info(
            "xero.api_call",
            extra={"method": "POST", "path": path, "resource": resource, "status": "DRAFT"}
        )
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(
                f"{XERO_API_BASE}/{path}",
                headers=self._headers(),
                json=safe_payload,
            )
            resp.raise_for_status()
            return resp.json()

    async def _put(self, path: str, payload: dict, resource: str = "invoice") -> dict:
        """Put to Xero — ALWAYS enforces DRAFT status before sending."""
        safe_payload = _enforce_draft(payload, resource)
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.put(
                f"{XERO_API_BASE}/{path}",
                headers=self._headers(),
                json=safe_payload,
            )
            resp.raise_for_status()
            return resp.json()

    # ── Invoices ──────────────────────────────────────────────────────────────

    async def create_invoice_draft(
        self,
        contact_id: str,
        line_items: list[dict],
        date: str,
        due_date: str,
        reference: str = "",
        description: str = "",
        currency_code: str = "AUD",
    ) -> dict:
        """
        Create a DRAFT invoice in Xero.
        Returns the created invoice dict including InvoiceID.
        """
        payload = {
            "Invoices": [{
                "Type": "ACCREC",              # Accounts Receivable (money owed TO firm)
                "Status": "DRAFT",              # POLICY — always DRAFT
                "Contact": {"ContactID": contact_id},
                "Date": date,
                "DueDate": due_date,
                "Reference": reference,
                "CurrencyCode": currency_code,
                "LineAmountTypes": "Exclusive",
                "LineItems": line_items,
                "Url": f"Created by Willow AI — {description}",
            }]
        }
        result = await self._post("Invoices", payload, "invoice")
        invoice = result.get("Invoices", [{}])[0]
        log.info("xero.invoice_draft_created", invoice_id=invoice.get("InvoiceID"))
        return invoice

    async def create_bill_draft(
        self,
        contact_id: str,
        line_items: list[dict],
        date: str,
        due_date: str,
        reference: str = "",
        description: str = "",
    ) -> dict:
        """
        Create a DRAFT bill in Xero (accounts payable — money firm OWES).
        Used for supplier receipts processed by Grace.
        """
        payload = {
            "Invoices": [{
                "Type": "ACCPAY",              # Accounts Payable
                "Status": "DRAFT",              # POLICY — always DRAFT
                "Contact": {"ContactID": contact_id},
                "Date": date,
                "DueDate": due_date,
                "Reference": reference,
                "LineAmountTypes": "Inclusive",  # Tax inclusive for receipts
                "LineItems": line_items,
                "Url": f"Created by Willow AI — {description}",
            }]
        }
        result = await self._post("Invoices", payload, "bill")
        bill = result.get("Invoices", [{}])[0]
        log.info("xero.bill_draft_created", invoice_id=bill.get("InvoiceID"))
        return bill

    async def attach_pdf_to_invoice(
        self,
        invoice_id: str,
        pdf_bytes: bytes,
        filename: str,
    ) -> dict:
        """
        Attach a PDF (the original document) to a Xero invoice/bill.
        This is called immediately after creating a draft so the bookkeeper
        can see the source document alongside the Xero entry.
        """
        headers = self._headers()
        headers["Content-Type"] = "application/pdf"
        headers["x-include-online"] = "true"

        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(
                f"{XERO_API_BASE}/Invoices/{invoice_id}/Attachments/{filename}",
                headers=headers,
                content=pdf_bytes,
            )
            resp.raise_for_status()
            log.info("xero.attachment_uploaded", invoice_id=invoice_id, filename=filename)
            return resp.json()

    async def get_invoice(self, invoice_id: str) -> dict:
        result = await self._get(f"Invoices/{invoice_id}")
        return result.get("Invoices", [{}])[0]

    async def list_draft_invoices(self, contact_id: str = None) -> list[dict]:
        """List all DRAFT invoices — used for client status queries."""
        params = {"Statuses": "DRAFT"}
        if contact_id:
            params["ContactIDs"] = contact_id
        result = await self._get("Invoices", params)
        return result.get("Invoices", [])

    # ── Contacts ──────────────────────────────────────────────────────────────

    async def find_or_create_contact(self, name: str, email: str = "", phone: str = "") -> str:
        """
        Find a Xero contact by name. Create if not found.
        Returns the ContactID.
        """
        result = await self._get("Contacts", {"SearchTerm": name, "IncludeArchived": False})
        contacts = result.get("Contacts", [])
        if contacts:
            return contacts[0]["ContactID"]

        # Create new contact (contacts have no Status field — no draft gate needed)
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(
                f"{XERO_API_BASE}/Contacts",
                headers=self._headers(),
                json={"Contacts": [{
                    "Name": name,
                    "EmailAddress": email,
                    "Phones": [{"PhoneType": "MOBILE", "PhoneNumber": phone}] if phone else [],
                }]},
            )
            resp.raise_for_status()
            new_contact = resp.json().get("Contacts", [{}])[0]
            log.info("xero.contact_created", name=name, contact_id=new_contact.get("ContactID"))
            return new_contact["ContactID"]

    # ── Reports (read-only) ───────────────────────────────────────────────────

    async def get_aged_receivables(self, contact_id: str = None) -> dict:
        """Read-only — no draft gate needed."""
        params = {}
        if contact_id:
            params["ContactID"] = contact_id
        return await self._get("Reports/AgedReceivablesByContact", params)

    async def get_profit_and_loss(self, from_date: str, to_date: str) -> dict:
        return await self._get("Reports/ProfitAndLoss", {
            "fromDate": from_date, "toDate": to_date
        })
