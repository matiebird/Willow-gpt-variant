"""
ATO Reference Service
======================
Willow's built-in knowledge of Australian Tax Office rules.

Two use-cases:
  1. CODING ASSISTANCE — When Grace receives a document from a new supplier
     with no prior invoice history, this service suggests the correct account
     code and GST treatment using the local policy knowledge base.

  2. STAFF CONFIDENCE — When a staff member asks "I'm not sure how to code
     this" via chat, Willow retrieves the relevant ATO rule and explains it
     in plain English, citing the source policy.

Architecture:
  - Policy KB (pgvector) holds pre-loaded ATO guides (ingested at deploy time)
  - Query → embed → cosine search → top-K ATO chunks retrieved
  - Ollama (local) synthesises a plain-English answer with coding recommendation
  - No client data or amounts ever leave the network

Account code map (Xero Australian defaults):
  400: Advertising & Marketing      453: Software & Subscriptions
  404: Bank Charges                 476: Superannuation
  408: Insurance                    477: Wages & Salaries
  410: Meals & Entertainment        489: Motor Vehicle Expenses
  412: Office Supplies              493: Travel & Transport
  413: Postage & Printing           499: Other Expenses
  414: Professional Services        500: Cost of Goods Sold
  415: Rent & Occupancy
  416: Repairs & Maintenance
"""

import json
import logging
import os
import re
from typing import Optional

import httpx
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text

from app.services.policy_service import search_policies, format_policy_context

log = logging.getLogger(__name__)

OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://host.docker.internal:11434")
OLLAMA_MODEL    = os.getenv("OLLAMA_MODEL", "qwen2.5:7b-instruct-q4_K_M")

# Confidence threshold below which we flag for human review
LOW_CONFIDENCE_THRESHOLD = 0.55


# ── Keyword → account code fallback map ───────────────────────────────────────
# Used when the policy KB returns no matches (failsafe).
KEYWORD_ACCOUNT_MAP = [
    # (keywords_any_match, account_code, gst_type, description)
    (["software", "saas", "subscription", "licence", "license", "adobe", "microsoft",
      "xero", "myob", "atlassian", "github", "dropbox", "zoom", "slack"],
     "453", "INPUT2", "Software & Subscriptions"),

    (["fuel", "petrol", "diesel", "bowser", "service station", "bp", "shell",
      "caltex", "ampol", "7-eleven"],
     "489", "INPUT2", "Motor Vehicle Expenses"),

    (["car", "vehicle", "rego", "registration", "roadside", "tyres", "auto"],
     "489", "INPUT2", "Motor Vehicle Expenses"),

    (["rent", "lease", "occupancy", "office space", "storage", "commercial"],
     "415", "INPUT2", "Rent & Occupancy"),

    (["insurance", "premium", "policy", "cover", "allianz", "qbe", "suncorp",
      "aami", "budget direct", "nrma"],
     "408", "GSTNEXUS", "Insurance"),  # May be GST-free depending on type

    (["lawyer", "legal", "solicitor", "barrister", "law firm"],
     "414", "INPUT2", "Professional Services — Legal"),

    (["accountant", "accounting", "bookkeeper", "tax agent", "bdo", "kpmg",
      "deloitte", "pwc", "grant thornton"],
     "414", "INPUT2", "Professional Services — Accounting"),

    (["consultant", "advisory", "consulting", "strategy", "management"],
     "414", "INPUT2", "Professional Services — Consulting"),

    (["advertising", "marketing", "facebook ads", "google ads", "meta",
      "instagram", "tiktok", "seo", "social media"],
     "400", "INPUT2", "Advertising & Marketing"),

    (["restaurant", "cafe", "coffee", "lunch", "dinner", "meal", "catering",
      "uber eats", "deliveroo", "menulog", "doordash"],
     "410", "INPUT2", "Meals & Entertainment (50% deductible — check FBT)"),

    (["electricity", "power", "gas", "water", "internet", "broadband", "nbn",
      "telstra", "optus", "vodafone", "tpg"],
     "420", "INPUT2", "Utilities"),

    (["repair", "maintenance", "fix", "service", "plumber", "electrician",
      "handyman", "it support", "computer repair"],
     "416", "INPUT2", "Repairs & Maintenance"),

    (["office", "stationery", "paper", "ink", "toner", "supplies", "officeworks",
      "staples"],
     "412", "INPUT2", "Office Supplies"),

    (["postage", "courier", "delivery", "freight", "australia post", "fedex",
      "dhl", "toll", "startrack"],
     "413", "INPUT2", "Postage & Delivery"),

    (["flight", "airfare", "qantas", "virgin", "jetstar", "rex", "accommodation",
      "hotel", "airbnb", "travel"],
     "493", "INPUT2", "Travel & Transport"),

    (["bank", "fee", "merchant", "transaction", "bpay", "stripe", "paypal",
      "square", "interest charge"],
     "404", "FRE", "Bank Charges (usually GST-free)"),

    (["super", "superannuation", "australian super", "host plus", "rest",
      "sun super", "colonial first"],
     "476", "NOINPUT", "Superannuation (BAS excluded)"),

    (["wage", "salary", "payg", "payroll", "staff", "employee"],
     "477", "NOINPUT", "Wages & Salaries (BAS excluded)"),

    (["stock", "inventory", "goods", "product", "purchase", "raw material"],
     "500", "INPUT2", "Cost of Goods Sold"),
]

GST_TYPE_LABELS = {
    "INPUT2":  "GST on Expenses (10%)",
    "FRE":     "GST-Free",
    "NOINPUT": "BAS Excluded",
    "GSTNEXUS":"GST on Expenses — verify type (may be GST-free)",
    "OUTPUT2": "GST on Income (10%)",
}


def _keyword_fallback(supplier_name: str, description: str) -> dict:
    """
    Keyword-based fallback when policy KB has no matching chunks.
    Checks supplier name + description against known patterns.
    Returns best guess account code.
    """
    combined = (supplier_name + " " + description).lower()

    for keywords, code, gst, label in KEYWORD_ACCOUNT_MAP:
        if any(kw in combined for kw in keywords):
            return {
                "account_code": code,
                "gst_type": gst,
                "account_label": label,
                "confidence": 0.6,
                "source": "keyword_match",
                "ato_note": None,
                "bookkeeper_note": (
                    f"Suggested by Willow keyword match: {label}. "
                    f"GST: {GST_TYPE_LABELS.get(gst, gst)}. "
                    f"New supplier — please verify."
                ),
                "requires_review": True,
            }

    # Total unknown
    return {
        "account_code": "499",
        "gst_type": "INPUT2",
        "account_label": "Other Expenses",
        "confidence": 0.1,
        "source": "default_fallback",
        "ato_note": None,
        "bookkeeper_note": (
            "Unknown supplier — defaulted to Other Expenses (499). "
            "Please review account coding and GST treatment."
        ),
        "requires_review": True,
    }


# ── Core: LLM-assisted coding suggestion ──────────────────────────────────────

async def suggest_account_coding(
    db: AsyncSession,
    supplier_name: str,
    description: str,
    amount: Optional[float] = None,
    staff_user_id: Optional[str] = None,
) -> dict:
    """
    Suggest the correct Xero account code and GST type for a supplier invoice.

    1. Search policy KB for relevant ATO guidance
    2. Ask Ollama to synthesise a coding recommendation
    3. Parse the structured response
    4. Fall back to keyword map if LLM fails

    Returns:
        {account_code, gst_type, account_label, confidence,
         ato_note, bookkeeper_note, requires_review, source}
    """
    # 1. Search policy KB for ATO compliance chunks
    query = f"{supplier_name} {description} account coding GST treatment"
    chunks = await search_policies(
        db=db,
        query=query,
        top_k=3,
        category="compliance",
        context="coding_assistant",
        staff_user_id=staff_user_id,
    )

    policy_context = format_policy_context(chunks) if chunks else ""

    # 2. If no policy context, try keyword fallback directly
    if not policy_context:
        return _keyword_fallback(supplier_name, description)

    # 3. Ask Ollama to suggest coding
    prompt = f"""{policy_context}

You are an Australian bookkeeping assistant. A new supplier invoice has arrived.
Supplier: {supplier_name}
Description: {description}{f" | Amount: ${amount:,.2f}" if amount else ""}

Based on ATO guidelines above, respond in this EXACT JSON format (no other text):
{{
  "account_code": "<Xero account code, e.g. 453>",
  "account_label": "<human readable label, e.g. Software & Subscriptions>",
  "gst_type": "<INPUT2 | FRE | NOINPUT | GSTNEXUS>",
  "confidence": <0.0-1.0>,
  "ato_basis": "<one sentence citing the ATO rule that applies>",
  "bookkeeper_note": "<plain English note for the bookkeeper, max 2 sentences>"
}}"""

    try:
        async with httpx.AsyncClient(timeout=45.0) as client:
            resp = await client.post(
                f"{OLLAMA_BASE_URL}/api/generate",
                json={
                    "model": OLLAMA_MODEL,
                    "prompt": prompt,
                    "stream": False,
                    "options": {"temperature": 0.1},  # Low temp for factual coding
                },
            )
            resp.raise_for_status()
            raw = resp.json().get("response", "")

        # Extract JSON block from response
        json_match = re.search(r'\{[^{}]+\}', raw, re.DOTALL)
        if not json_match:
            raise ValueError("No JSON block in LLM response")

        result = json.loads(json_match.group())

        # Validate required fields
        if "account_code" not in result or "gst_type" not in result:
            raise ValueError("Missing required fields in LLM response")

        confidence = float(result.get("confidence", 0.5))
        requires_review = confidence < LOW_CONFIDENCE_THRESHOLD

        return {
            "account_code": str(result["account_code"]),
            "gst_type": str(result["gst_type"]),
            "account_label": result.get("account_label", ""),
            "confidence": confidence,
            "source": "ato_policy_rag",
            "ato_note": result.get("ato_basis", ""),
            "bookkeeper_note": result.get("bookkeeper_note", ""),
            "requires_review": requires_review,
        }

    except Exception as e:
        log.warning(f"ATO LLM coding failed: {e}. Falling back to keyword map.")
        return _keyword_fallback(supplier_name, description)


# ── Staff Q&A — plain English ATO answers ─────────────────────────────────────

async def answer_ato_question(
    db: AsyncSession,
    question: str,
    staff_user_id: Optional[str] = None,
) -> dict:
    """
    Answer a plain-English ATO / coding question from a staff member.
    Used when Willow detects uncertainty in the main assistant.

    Returns:
        {answer, policy_references, confidence, suggest_review}
    """
    # Search all compliance and general policies
    chunks = await search_policies(
        db=db,
        query=question,
        top_k=4,
        category=None,    # Search across all categories
        context="staff_qa",
        staff_user_id=staff_user_id,
    )

    if not chunks:
        return {
            "answer": (
                "I don't have a specific ATO policy loaded for this question. "
                "I'd recommend checking the ATO website directly at ato.gov.au "
                "or escalating to your senior bookkeeper."
            ),
            "policy_references": [],
            "confidence": 0.0,
            "suggest_review": True,
        }

    policy_context = format_policy_context(chunks)

    prompt = f"""{policy_context}

A bookkeeper has asked the following question:
"{question}"

Using ONLY the policy information above, provide:
1. A clear, plain-English answer (2-4 sentences)
2. The specific ATO rule or section that applies
3. Any caveats or "check with your senior" recommendations

Be direct and practical. Speak like a knowledgeable colleague, not a lawyer.
Do not invent rules not mentioned above."""

    try:
        async with httpx.AsyncClient(timeout=45.0) as client:
            resp = await client.post(
                f"{OLLAMA_BASE_URL}/api/generate",
                json={
                    "model": OLLAMA_MODEL,
                    "prompt": prompt,
                    "stream": False,
                    "options": {"temperature": 0.2},
                },
            )
            resp.raise_for_status()
            answer = resp.json().get("response", "").strip()
    except Exception as e:
        log.error(f"ATO Q&A LLM failed: {e}")
        answer = (
            "I found relevant ATO guidance but couldn't synthesise a response right now. "
            "Here are the relevant policy excerpts:\n\n" +
            "\n\n".join(c["chunk_text"][:300] + "..." for c in chunks[:2])
        )

    policy_refs = list({
        f"{c['policy_title']} ({c['category']})"
        for c in chunks
    })

    return {
        "answer": answer,
        "policy_references": policy_refs,
        "confidence": max((float(c["similarity"]) for c in chunks), default=0.0),
        "suggest_review": any(float(c["similarity"]) < 0.55 for c in chunks),
    }


# ── Uncertainty signal detection ──────────────────────────────────────────────

UNCERTAINTY_PATTERNS = [
    r"\bnot sure\b", r"\bunsure\b", r"\bdon'?t know\b", r"\bdont know\b",
    r"\bhow (to|do I|should I) code\b", r"\bwhich account\b", r"\bwhat (code|account|gst)\b",
    r"\bwhat'?s the gst\b", r"\bis this gst.?free\b", r"\bdeductible\b",
    r"\bwhat category\b", r"\bhelp (with|me) cod", r"\bnot confident\b",
    r"\bcheck the ato\b", r"\bato says\b", r"\bato (rule|guide|website)\b",
    r"\bwhat does (the )?ato\b", r"\bfbt\b", r"\bfuel tax credit\b",
]

def is_ato_question(text: str) -> bool:
    """Returns True if the message likely needs ATO guidance."""
    lower = text.lower()
    return any(re.search(p, lower) for p in UNCERTAINTY_PATTERNS)
