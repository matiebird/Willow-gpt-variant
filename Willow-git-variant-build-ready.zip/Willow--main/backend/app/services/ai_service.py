"""
Willows AI — Core AI Service
=============================================================================
Handles all communication with the local Ollama inference engine.
Zero data ever leaves the network — all LLM calls are made to the local
Ollama container at http://ollama:11434.

Key responsibilities:
  1. Build structured prompts for financial data extraction
  2. Execute HTTP calls to the Ollama /api/generate endpoint
  3. Parse, validate and sanitise the returned JSON
  4. Provide confidence scoring and fallback handling
=============================================================================
"""

import json
import re
import time
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from typing import Any

import httpx
import structlog
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from app.config import get_settings
from app.schemas.ai import (
    ExtractedReceiptData,
    ExtractionResult,
    TransactionClassification,
)

logger = structlog.get_logger(__name__)
settings = get_settings()

# ---------------------------------------------------------------------------
# Prompt Templates
# ---------------------------------------------------------------------------

RECEIPT_EXTRACTION_PROMPT = """\
You are a precise financial data extraction assistant for an accounting system.
Extract structured data from the provided receipt or invoice text.

CRITICAL RULES:
- Return ONLY a valid JSON object. No preamble, no explanation, no markdown.
- If a field cannot be determined with confidence, use null.
- All monetary amounts must be positive numbers (floats), never negative.
- Dates must be in ISO 8601 format: YYYY-MM-DD.
- Currency codes must be 3-letter ISO 4217 (default to "AUD" if unclear).

JSON SCHEMA TO RETURN:
{{
  "vendor_name": "string | null",
  "date": "YYYY-MM-DD | null",
  "total_amount": float,
  "subtotal": float,
  "tax_amount": float,
  "tax_rate_percent": float | null,
  "currency": "AUD",
  "payment_method": "cash | card | bank_transfer | null",
  "receipt_number": "string | null",
  "abn": "string | null",
  "category_suggestion": "one of the values below",
  "line_items": [
    {{"description": "string", "quantity": float, "unit_price": float, "amount": float}}
  ],
  "confidence": float,
  "notes": "string | null"
}}

VALID CATEGORY VALUES (choose the single best match):
"Office Supplies", "Travel & Transport", "Meals & Entertainment",
"Utilities", "Software & Subscriptions", "Professional Services",
"Equipment & Hardware", "Marketing & Advertising", "Rent & Occupancy",
"Motor Vehicle", "Insurance", "Bank Charges", "Wages & Salaries",
"Inventory", "Repairs & Maintenance", "Other"

CONFIDENCE SCORING (0.0 – 1.0):
- 0.9–1.0: All key fields clearly present (vendor, date, total, tax)
- 0.7–0.9: Most fields present, minor ambiguity
- 0.5–0.7: Partial data, some inference required
- 0.0–0.5: Very limited data — flag for human review

RECEIPT / INVOICE TEXT:
---
{text}
---

JSON RESPONSE:"""


TRANSACTION_CLASSIFICATION_PROMPT = """\
You are a bookkeeping assistant. Classify the following bank transaction.
Return ONLY a valid JSON object. No preamble, no markdown.

JSON SCHEMA:
{{
  "category_suggestion": "string (one of the valid categories)",
  "vendor_name": "string | null",
  "transaction_type": "income | expense | transfer",
  "confidence": float,
  "notes": "string | null"
}}

VALID CATEGORIES:
"Office Supplies", "Travel & Transport", "Meals & Entertainment",
"Utilities", "Software & Subscriptions", "Professional Services",
"Equipment & Hardware", "Marketing & Advertising", "Rent & Occupancy",
"Motor Vehicle", "Insurance", "Bank Charges", "Wages & Salaries",
"Inventory", "Repairs & Maintenance", "Other"

TRANSACTION:
Description: {description}
Amount: {amount} {currency}
Date: {date}

JSON RESPONSE:"""


# ---------------------------------------------------------------------------
# Ollama API Client
# ---------------------------------------------------------------------------

class OllamaClient:
    """
    Async HTTP client for the local Ollama inference API.
    All requests are made within the Docker network — no external calls.
    """

    def __init__(self):
        self.base_url = settings.ollama_base_url
        self.model = settings.ollama_model
        self.timeout = settings.ollama_request_timeout
        self.temperature = settings.ollama_temperature

    @retry(
        retry=retry_if_exception_type((httpx.TimeoutException, httpx.ConnectError)),
        stop=stop_after_attempt(settings.ollama_max_retries),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        reraise=True,
    )
    async def generate(
        self,
        prompt: str,
        format: str = "json",
        temperature: float | None = None,
    ) -> str:
        """
        Send a prompt to the local Ollama API and return the response text.

        Args:
            prompt:       The full prompt string
            format:       'json' enforces structured JSON output (Ollama feature)
            temperature:  Override default temperature (0.0 = deterministic)

        Returns:
            Raw response text from the model
        """
        payload = {
            "model": self.model,
            "prompt": prompt,
            "format": format,
            "stream": False,
            "options": {
                "temperature": temperature if temperature is not None else self.temperature,
                "num_predict": 1024,     # Max tokens for structured JSON responses
                "top_p": 0.9,
                "repeat_penalty": 1.1,
            },
        }

        log = logger.bind(model=self.model, prompt_length=len(prompt))
        log.debug("Sending prompt to Ollama")
        t0 = time.perf_counter()

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            try:
                response = await client.post(
                    f"{self.base_url}/api/generate",
                    json=payload,
                )
                response.raise_for_status()
            except httpx.HTTPStatusError as e:
                log.error("Ollama HTTP error", status_code=e.response.status_code, detail=e.response.text)
                raise
            except httpx.TimeoutException:
                log.error("Ollama request timed out", timeout_s=self.timeout)
                raise

        elapsed = time.perf_counter() - t0
        data = response.json()
        raw_response = data.get("response", "")

        log.info(
            "Ollama response received",
            elapsed_s=round(elapsed, 2),
            response_length=len(raw_response),
            eval_count=data.get("eval_count"),
        )

        return raw_response

    async def health_check(self) -> dict[str, Any]:
        """Check if Ollama is running and the configured model is available."""
        async with httpx.AsyncClient(timeout=10) as client:
            try:
                response = await client.get(f"{self.base_url}/api/tags")
                response.raise_for_status()
                models = response.json().get("models", [])
                model_names = [m["name"] for m in models]
                return {
                    "status": "ok",
                    "available_models": model_names,
                    "configured_model": self.model,
                    "model_available": any(self.model in name for name in model_names),
                }
            except Exception as e:
                return {"status": "error", "detail": str(e)}


# ---------------------------------------------------------------------------
# AI Service — Receipt Extraction
# ---------------------------------------------------------------------------

class AIService:
    """
    High-level service that orchestrates all AI-powered financial operations.
    Instantiate once and inject via FastAPI dependency.
    """

    def __init__(self):
        self.client = OllamaClient()

    # ── Receipt / Invoice Extraction ─────────────────────────────────────────

    async def extract_receipt_data(self, text: str) -> ExtractionResult:
        """
        Extract structured financial data from raw receipt/invoice text.

        The text may come from:
          - OCR output of a scanned receipt image
          - A PDF invoice (text extracted via pypdf)
          - A manually entered transaction string

        Returns an ExtractionResult containing the parsed data plus
        metadata about the extraction quality.
        """
        if not text or len(text.strip()) < 5:
            return ExtractionResult(
                success=False,
                error="Input text is too short to extract meaningful data.",
                requires_human_review=True,
            )

        # Sanitise — strip PII patterns before sending to LLM
        # (belt-and-suspenders: data stays local, but good practice)
        sanitised_text = self._sanitise_text(text)

        prompt = RECEIPT_EXTRACTION_PROMPT.format(text=sanitised_text)

        try:
            raw_response = await self.client.generate(prompt, format="json")
        except httpx.TimeoutException:
            return ExtractionResult(
                success=False,
                error="LLM inference timed out. Consider a lighter model or GPU acceleration.",
                requires_human_review=True,
            )
        except Exception as e:
            logger.error("AI extraction failed", error=str(e))
            return ExtractionResult(
                success=False,
                error=f"LLM error: {str(e)}",
                requires_human_review=True,
            )

        return self._parse_receipt_response(raw_response)

    def _parse_receipt_response(self, raw_response: str) -> ExtractionResult:
        """
        Parse and validate the JSON response from the LLM into a typed schema.
        Includes defensive handling for common LLM output quirks.
        """
        # Step 1: Extract JSON from response (LLMs sometimes add commentary)
        json_str = self._extract_json_block(raw_response)
        if not json_str:
            logger.warning("Could not find JSON in LLM response", raw=raw_response[:200])
            return ExtractionResult(
                success=False,
                error="LLM did not return valid JSON.",
                raw_response=raw_response,
                requires_human_review=True,
            )

        # Step 2: Parse JSON
        try:
            data: dict[str, Any] = json.loads(json_str)
        except json.JSONDecodeError as e:
            logger.warning("JSON parse error", error=str(e), raw=json_str[:200])
            return ExtractionResult(
                success=False,
                error=f"JSON parse error: {e}",
                raw_response=raw_response,
                requires_human_review=True,
            )

        # Step 3: Validate and coerce fields
        try:
            extracted = self._coerce_receipt_data(data)
        except Exception as e:
            logger.warning("Data coercion failed", error=str(e))
            return ExtractionResult(
                success=False,
                error=f"Data validation failed: {e}",
                raw_response=raw_response,
                requires_human_review=True,
            )

        confidence = extracted.confidence or 0.0
        requires_review = confidence < 0.65 or extracted.total_amount == 0.0

        return ExtractionResult(
            success=True,
            data=extracted,
            confidence=confidence,
            raw_response=raw_response,
            requires_human_review=requires_review,
        )

    def _coerce_receipt_data(self, raw: dict[str, Any]) -> ExtractedReceiptData:
        """
        Coerce LLM output into strongly-typed ExtractedReceiptData.
        Handles type mismatches common in LLM JSON (string amounts, etc.).
        """
        def to_decimal(v: Any, default: Decimal = Decimal("0.00")) -> Decimal:
            if v is None:
                return default
            try:
                # Strip currency symbols and whitespace
                cleaned = re.sub(r"[^\d.]", "", str(v))
                return Decimal(cleaned) if cleaned else default
            except InvalidOperation:
                return default

        def to_date(v: Any) -> date | None:
            if v is None:
                return None
            try:
                if isinstance(v, date):
                    return v
                # Try ISO format first
                return datetime.strptime(str(v).strip(), "%Y-%m-%d").date()
            except ValueError:
                try:
                    # Common Australian format: DD/MM/YYYY
                    return datetime.strptime(str(v).strip(), "%d/%m/%Y").date()
                except ValueError:
                    return None

        def to_float(v: Any, default: float = 0.0) -> float:
            try:
                return float(str(v)) if v is not None else default
            except (ValueError, TypeError):
                return default

        # Coerce line items
        line_items = []
        for item in raw.get("line_items", []) or []:
            if isinstance(item, dict):
                line_items.append({
                    "description": str(item.get("description", ""))[:200],
                    "quantity": to_float(item.get("quantity"), 1.0),
                    "unit_price": float(to_decimal(item.get("unit_price"))),
                    "amount": float(to_decimal(item.get("amount"))),
                })

        return ExtractedReceiptData(
            vendor_name=str(raw["vendor_name"])[:200] if raw.get("vendor_name") else None,
            date=to_date(raw.get("date")),
            total_amount=float(to_decimal(raw.get("total_amount"))),
            subtotal=float(to_decimal(raw.get("subtotal"))),
            tax_amount=float(to_decimal(raw.get("tax_amount"))),
            tax_rate_percent=to_float(raw.get("tax_rate_percent")),
            currency=(str(raw.get("currency", "AUD"))[:3]).upper() or "AUD",
            payment_method=str(raw["payment_method"])[:50] if raw.get("payment_method") else None,
            receipt_number=str(raw["receipt_number"])[:100] if raw.get("receipt_number") else None,
            abn=str(raw["abn"])[:20] if raw.get("abn") else None,
            category_suggestion=str(raw.get("category_suggestion", "Other"))[:100],
            line_items=line_items,
            confidence=to_float(raw.get("confidence"), 0.5),
            notes=str(raw["notes"])[:500] if raw.get("notes") else None,
        )

    # ── Transaction Classification ─────────────────────────────────────────

    async def classify_transaction(
        self,
        description: str,
        amount: float,
        currency: str = "AUD",
        transaction_date: date | None = None,
    ) -> TransactionClassification:
        """
        Classify a plain-text bank transaction description.
        Used for bulk CSV imports from bank statements.
        """
        prompt = TRANSACTION_CLASSIFICATION_PROMPT.format(
            description=description[:500],
            amount=amount,
            currency=currency,
            date=str(transaction_date or date.today()),
        )

        try:
            raw_response = await self.client.generate(prompt, format="json")
            json_str = self._extract_json_block(raw_response)
            if not json_str:
                raise ValueError("No JSON in response")
            data = json.loads(json_str)
        except Exception as e:
            logger.warning("Transaction classification failed", error=str(e))
            return TransactionClassification(
                category_suggestion="Other",
                transaction_type="expense",
                confidence=0.0,
            )

        return TransactionClassification(
            category_suggestion=str(data.get("category_suggestion", "Other")),
            vendor_name=str(data["vendor_name"]) if data.get("vendor_name") else None,
            transaction_type=str(data.get("transaction_type", "expense")),
            confidence=float(data.get("confidence", 0.5)),
            notes=str(data["notes"]) if data.get("notes") else None,
        )

    # ── Utilities ──────────────────────────────────────────────────────────

    @staticmethod
    def _extract_json_block(text: str) -> str | None:
        """
        Extract a JSON object from LLM output that may contain surrounding text.
        Handles markdown code fences and inline commentary.
        """
        if not text:
            return None

        text = text.strip()

        # Try 1: Entire response is JSON
        if text.startswith("{") and text.endswith("}"):
            return text

        # Try 2: Extract from markdown code fence ```json ... ```
        fence_match = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
        if fence_match:
            return fence_match.group(1)

        # Try 3: Find first { ... } block
        brace_match = re.search(r"\{.*\}", text, re.DOTALL)
        if brace_match:
            return brace_match.group(0)

        return None

    @staticmethod
    def _sanitise_text(text: str) -> str:
        """
        Light sanitisation before sending text to the LLM.
        Strips prompt injection attempts and excessive whitespace.
        """
        # Remove prompt injection patterns
        injections = [
            r"ignore previous instructions",
            r"system prompt",
            r"<\|.*?\|>",          # Special tokens
            r"###\s*instruction",
        ]
        for pattern in injections:
            text = re.sub(pattern, "", text, flags=re.IGNORECASE)

        # Normalise whitespace
        text = re.sub(r"\n{3,}", "\n\n", text)
        text = text.strip()

        # Truncate to a reasonable length (avoid token limit issues)
        return text[:4000]

    async def health_check(self) -> dict[str, Any]:
        """Delegate health check to the Ollama client."""
        return await self.client.health_check()


# ---------------------------------------------------------------------------
# FastAPI Dependency
# ---------------------------------------------------------------------------

_ai_service: AIService | None = None


def get_ai_service() -> AIService:
    """
    Returns the singleton AIService instance.
    The service is stateless (no session), so a single instance is safe.
    """
    global _ai_service
    if _ai_service is None:
        _ai_service = AIService()
    return _ai_service
