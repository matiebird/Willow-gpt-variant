"""
Willows AI — Receipt Processing Pipeline
=============================================================================
Orchestrates the full pipeline from raw file upload to a linked Transaction:

  1. Validate file (type, size, duplicate hash check)
  2. Store file securely in local uploads volume
  3. Extract text via OCR (Tesseract) or direct PDF text extraction
  4. Send text to AIService for LLM-based structured extraction
  5. Persist Receipt record and optionally auto-create a Transaction
=============================================================================
"""

import hashlib
import io
import os
import uuid
from pathlib import Path
from typing import BinaryIO

import aiofiles
import structlog
from PIL import Image
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

try:
    import pytesseract
    TESSERACT_AVAILABLE = True
except ImportError:
    TESSERACT_AVAILABLE = False

try:
    from pypdf import PdfReader
    PYPDF_AVAILABLE = True
except ImportError:
    PYPDF_AVAILABLE = False

from app.config import get_settings
from app.models.receipt import Receipt, ReceiptStatus
from app.models.transaction import Transaction, TransactionEntry, TransactionType, TransactionStatus, EntryType
from app.services.ai_service import AIService, get_ai_service
from app.schemas.ai import ExtractionResult

logger = structlog.get_logger(__name__)
settings = get_settings()


class ReceiptProcessingError(Exception):
    """Raised when the receipt pipeline encounters an unrecoverable error."""
    pass


class ReceiptProcessor:
    """
    Stateless service that processes a single receipt file through the
    full OCR → AI → Transaction pipeline.
    """

    def __init__(self, ai_service: AIService | None = None):
        self.ai_service = ai_service or get_ai_service()
        self.upload_dir = Path(settings.upload_dir)
        self.upload_dir.mkdir(parents=True, exist_ok=True)

    # ── Public Entry Point ────────────────────────────────────────────────

    async def process_upload(
        self,
        db: AsyncSession,
        file_data: bytes,
        original_filename: str,
        mime_type: str,
        auto_create_transaction: bool = False,
    ) -> Receipt:
        """
        Main entry point: accepts raw file bytes and returns a persisted Receipt.

        Args:
            db:                       Async SQLAlchemy session
            file_data:                Raw bytes of the uploaded file
            original_filename:        Original name from the upload form
            mime_type:                MIME type from Content-Type header
            auto_create_transaction:  If True and confidence >= 0.8, auto-creates a Transaction

        Returns:
            Persisted Receipt ORM instance with status set appropriately.
        """
        log = logger.bind(filename=original_filename, mime=mime_type)

        # 1. Validate
        self._validate_upload(file_data, mime_type)

        # 2. Duplicate detection
        file_hash = hashlib.sha256(file_data).hexdigest()
        existing = await self._find_by_hash(db, file_hash)
        if existing:
            log.warning("Duplicate receipt detected", existing_id=str(existing.id))
            existing.status = ReceiptStatus.DUPLICATE
            await db.flush()
            return existing

        # 3. Persist file to disk
        stored_filename = f"{uuid.uuid4().hex}_{Path(original_filename).name}"
        file_path = self.upload_dir / stored_filename
        await self._write_file(file_path, file_data)
        log.info("File stored", path=str(file_path))

        # 4. Create initial Receipt record
        receipt = Receipt(
            original_filename=original_filename[:500],
            stored_filename=stored_filename,
            file_path=str(file_path),
            mime_type=mime_type,
            file_size_bytes=len(file_data),
            file_hash=file_hash,
            status=ReceiptStatus.UPLOADED,
        )
        db.add(receipt)
        await db.flush()   # Get the UUID assigned

        # 5. OCR / text extraction
        receipt.status = ReceiptStatus.OCR_PROCESSING
        await db.flush()

        ocr_text, ocr_confidence = await self._extract_text(file_data, mime_type)
        receipt.ocr_text = ocr_text
        receipt.ocr_confidence = ocr_confidence
        receipt.status = ReceiptStatus.OCR_COMPLETE
        await db.flush()

        if not ocr_text or len(ocr_text.strip()) < 10:
            receipt.status = ReceiptStatus.REVIEW_NEEDED
            receipt.processing_error = "OCR extracted insufficient text. Manual entry required."
            log.warning("Insufficient OCR text", length=len(ocr_text or ""))
            return receipt

        # 6. AI Extraction
        receipt.status = ReceiptStatus.AI_PROCESSING
        receipt.processing_attempts += 1
        receipt.ai_model_used = settings.ollama_model
        await db.flush()

        extraction: ExtractionResult = await self.ai_service.extract_receipt_data(ocr_text)

        if not extraction.success or extraction.data is None:
            receipt.status = ReceiptStatus.FAILED
            receipt.processing_error = extraction.error or "AI extraction returned no data."
            log.error("AI extraction failed", error=receipt.processing_error)
            return receipt

        receipt.ai_extracted_data = extraction.data.model_dump(mode="json")
        receipt.ai_confidence = extraction.confidence
        receipt.status = ReceiptStatus.AI_COMPLETE

        if extraction.requires_human_review:
            receipt.status = ReceiptStatus.REVIEW_NEEDED
            log.info("Receipt flagged for review", confidence=extraction.confidence)

        # 7. Auto-create Transaction (optional)
        if auto_create_transaction and not extraction.requires_human_review:
            await self._create_transaction_from_extraction(db, receipt, extraction)

        log.info(
            "Receipt processed",
            status=receipt.status,
            confidence=receipt.ai_confidence,
            vendor=extraction.data.vendor_name,
        )
        return receipt

    # ── Text Extraction ───────────────────────────────────────────────────

    async def _extract_text(self, file_data: bytes, mime_type: str) -> tuple[str, float]:
        """
        Extract text from a file. Strategy depends on MIME type:
          - PDF: pypdf direct text extraction (fast, no quality loss)
          - Images: Tesseract OCR
        Returns (text, confidence_0_to_1).
        """
        if mime_type == "application/pdf":
            return self._extract_pdf_text(file_data)
        else:
            return self._extract_image_text(file_data)

    def _extract_pdf_text(self, data: bytes) -> tuple[str, float]:
        """Extract text from a PDF using pypdf."""
        if not PYPDF_AVAILABLE:
            return "", 0.0
        try:
            reader = PdfReader(io.BytesIO(data))
            pages_text = [page.extract_text() or "" for page in reader.pages]
            full_text = "\n\n".join(p for p in pages_text if p.strip())
            confidence = 0.95 if full_text.strip() else 0.0
            return full_text, confidence
        except Exception as e:
            logger.warning("PDF text extraction failed", error=str(e))
            return "", 0.0

    def _extract_image_text(self, data: bytes) -> tuple[str, float]:
        """Extract text from an image using Tesseract OCR."""
        if not TESSERACT_AVAILABLE:
            return "", 0.0
        try:
            img = Image.open(io.BytesIO(data))

            # Preprocess for better OCR accuracy
            img = self._preprocess_image(img)

            # Run Tesseract with confidence data
            ocr_data = pytesseract.image_to_data(
                img,
                lang="eng",
                config="--psm 4 --oem 3",   # PSM 4: single column; OEM 3: LSTM
                output_type=pytesseract.Output.DICT,
            )

            # Compute mean confidence (Tesseract returns -1 for non-text blocks)
            confidences = [c for c in ocr_data["conf"] if c != -1]
            mean_confidence = (sum(confidences) / len(confidences) / 100.0) if confidences else 0.0

            # Extract clean text
            full_text = pytesseract.image_to_string(img, lang="eng", config="--psm 4 --oem 3")
            return full_text.strip(), round(mean_confidence, 3)

        except Exception as e:
            logger.warning("Image OCR failed", error=str(e))
            return "", 0.0

    @staticmethod
    def _preprocess_image(img: Image.Image) -> Image.Image:
        """
        Apply image preprocessing to improve OCR accuracy on receipts.
        Receipts are often low-contrast thermal prints.
        """
        # Convert to grayscale
        img = img.convert("L")

        # Scale up small images (Tesseract works best at 300+ DPI)
        w, h = img.size
        if w < 1000:
            scale = max(1000 / w, 1.0)
            img = img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)

        return img

    # ── Transaction Creation ──────────────────────────────────────────────

    async def _create_transaction_from_extraction(
        self,
        db: AsyncSession,
        receipt: Receipt,
        extraction: ExtractionResult,
    ) -> Transaction | None:
        """
        Auto-create a draft Transaction from high-confidence AI extraction.
        Creates a simple debit/credit journal entry pair.
        """
        from datetime import date as date_type

        data = extraction.data
        if not data or data.total_amount <= 0:
            return None

        try:
            txn = Transaction(
                date=data.date or date_type.today(),
                description=f"Receipt: {data.vendor_name or 'Unknown vendor'}",
                transaction_type=TransactionType.EXPENSE,
                status=TransactionStatus.DRAFT,
                amount=data.total_amount,
                tax_amount=data.tax_amount or 0.0,
                currency=data.currency or "AUD",
                vendor_name=data.vendor_name,
                receipt_id=receipt.id,
                ai_categorised=True,
                ai_confidence=extraction.confidence,
                ai_raw_response=extraction.raw_response,
            )
            db.add(txn)
            await db.flush()

            receipt.status = ReceiptStatus.LINKED
            logger.info(
                "Auto-created transaction from receipt",
                transaction_id=str(txn.id),
                amount=data.total_amount,
                vendor=data.vendor_name,
            )
            return txn

        except Exception as e:
            logger.error("Failed to auto-create transaction", error=str(e))
            return None

    # ── Helpers ───────────────────────────────────────────────────────────

    def _validate_upload(self, data: bytes, mime_type: str) -> None:
        if len(data) > settings.max_upload_size_bytes:
            raise ReceiptProcessingError(
                f"File exceeds maximum size of {settings.max_upload_size_mb}MB."
            )
        if mime_type not in settings.allowed_upload_types:
            raise ReceiptProcessingError(
                f"File type '{mime_type}' is not allowed. "
                f"Accepted: {', '.join(settings.allowed_upload_types)}"
            )

    async def _find_by_hash(self, db: AsyncSession, file_hash: str) -> Receipt | None:
        result = await db.execute(
            select(Receipt).where(Receipt.file_hash == file_hash)
        )
        return result.scalar_one_or_none()

    @staticmethod
    async def _write_file(path: Path, data: bytes) -> None:
        async with aiofiles.open(path, "wb") as f:
            await f.write(data)


# ---------------------------------------------------------------------------
# FastAPI Dependency
# ---------------------------------------------------------------------------

_processor: ReceiptProcessor | None = None


def get_receipt_processor() -> ReceiptProcessor:
    global _processor
    if _processor is None:
        _processor = ReceiptProcessor()
    return _processor
