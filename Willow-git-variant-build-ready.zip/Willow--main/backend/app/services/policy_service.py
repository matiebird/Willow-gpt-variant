"""
Policy Service
==============
Manages Willow's internal knowledge base — company policies taught via
uploaded documents.

Pipeline:
  Upload (PDF/text) → Extract text → Chunk (400w, 50w overlap)
               → Embed via nomic-embed-text (Ollama)
               → Store in pgvector
               → Semantic search at query time → Inject into LLM prompt

All embedding happens locally. No text leaves the network.
"""

import json
import logging
import re
import uuid
from typing import Optional

import httpx
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
OLLAMA_BASE_URL = "http://host.docker.internal:11434"
EMBED_MODEL = "nomic-embed-text"          # 768-dim, CPU, ~270MB
CHUNK_WORDS = 400                          # Target words per chunk
CHUNK_OVERLAP = 50                         # Overlap words between chunks
TOP_K_DEFAULT = 4                          # Chunks returned per query
MIN_SIMILARITY = 0.35                      # Discard low-relevance chunks


# ---------------------------------------------------------------------------
# Text extraction
# ---------------------------------------------------------------------------

def extract_text_from_pdf(file_bytes: bytes) -> str:
    """Extract plain text from a PDF using pypdf."""
    from pypdf import PdfReader
    import io
    reader = PdfReader(io.BytesIO(file_bytes))
    parts = []
    for page in reader.pages:
        t = page.extract_text()
        if t:
            parts.append(t.strip())
    return "\n\n".join(parts)


def extract_text(file_bytes: bytes, filename: str, mime_type: str) -> str:
    """Route to the correct text extractor based on file type."""
    mime = (mime_type or "").lower()
    name = (filename or "").lower()

    if "pdf" in mime or name.endswith(".pdf"):
        return extract_text_from_pdf(file_bytes)

    # Plain text / markdown — decode best-effort
    for enc in ("utf-8", "latin-1", "cp1252"):
        try:
            return file_bytes.decode(enc)
        except UnicodeDecodeError:
            continue
    raise ValueError("Could not decode text from file. Upload PDF or plain text.")


# ---------------------------------------------------------------------------
# Chunking
# ---------------------------------------------------------------------------

def chunk_text(text: str, chunk_words: int = CHUNK_WORDS, overlap: int = CHUNK_OVERLAP) -> list[str]:
    """
    Split text into overlapping word-window chunks.
    Preserves paragraph boundaries where possible.
    """
    # Normalise whitespace
    text = re.sub(r"\n{3,}", "\n\n", text).strip()

    # Split into words (keep punctuation)
    words = text.split()
    if not words:
        return []

    chunks = []
    start = 0
    while start < len(words):
        end = min(start + chunk_words, len(words))
        chunk = " ".join(words[start:end])
        chunks.append(chunk)
        if end == len(words):
            break
        start += chunk_words - overlap

    return [c for c in chunks if len(c.strip()) > 50]  # Drop tiny fragments


# ---------------------------------------------------------------------------
# Embedding via Ollama
# ---------------------------------------------------------------------------

async def embed_text(text: str) -> list[float]:
    """
    Call the local Ollama embedding API.
    Returns a 768-dimensional float list.
    """
    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.post(
            f"{OLLAMA_BASE_URL}/api/embeddings",
            json={"model": EMBED_MODEL, "prompt": text},
        )
        response.raise_for_status()
        data = response.json()
        embedding = data.get("embedding")
        if not embedding:
            raise ValueError(f"Ollama returned no embedding. Response: {data}")
        return embedding


def _vec_to_pg(vec: list[float]) -> str:
    """Format a Python list as a PostgreSQL vector literal."""
    return "[" + ",".join(f"{v:.8f}" for v in vec) + "]"


# ---------------------------------------------------------------------------
# Ingestion
# ---------------------------------------------------------------------------

async def ingest_policy(
    db: AsyncSession,
    title: str,
    category: str,
    raw_text: str,
    original_filename: Optional[str],
    created_by: Optional[str],
) -> str:
    """
    Store a policy document and all its embedded chunks in the database.
    Returns the new policy UUID.
    """
    policy_id = str(uuid.uuid4())

    # Insert policy master record
    await db.execute(
        text("""
            INSERT INTO policies (id, title, category, original_filename, raw_text, created_by)
            VALUES (:id, :title, :cat, :fname, :raw, :by)
        """),
        {
            "id": policy_id,
            "title": title,
            "cat": category,
            "fname": original_filename,
            "raw": raw_text,
            "by": created_by,
        },
    )

    # Chunk + embed
    chunks = chunk_text(raw_text)
    logger.info(f"Policy '{title}': {len(chunks)} chunks to embed")

    for idx, chunk in enumerate(chunks):
        try:
            vec = await embed_text(chunk)
        except Exception as e:
            logger.warning(f"Embedding failed for chunk {idx}: {e}. Skipping.")
            continue

        await db.execute(
            text("""
                INSERT INTO policy_chunks (policy_id, chunk_index, chunk_text, embedding)
                VALUES (:pid, :idx, :text, :vec::vector)
            """),
            {
                "pid": policy_id,
                "idx": idx,
                "text": chunk,
                "vec": _vec_to_pg(vec),
            },
        )

    await db.commit()
    logger.info(f"Policy '{title}' ingested successfully — {len(chunks)} chunks stored.")
    return policy_id


# ---------------------------------------------------------------------------
# Semantic search
# ---------------------------------------------------------------------------

async def search_policies(
    db: AsyncSession,
    query: str,
    top_k: int = TOP_K_DEFAULT,
    category: Optional[str] = None,
    context: str = "api",
    staff_user_id: Optional[str] = None,
) -> list[dict]:
    """
    Embed the query and find the most relevant policy chunks via cosine similarity.
    Filters out chunks below MIN_SIMILARITY threshold.
    Logs every retrieval to policy_access_log for quality tuning.
    Returns a list of dicts: {chunk_text, policy_title, category, similarity}
    """
    if not query.strip():
        return []

    # Embed query
    try:
        query_vec = await embed_text(query)
    except Exception as e:
        logger.error(f"Policy search embedding failed: {e}")
        return []

    vec_str = _vec_to_pg(query_vec)

    # Cosine similarity search
    cat_filter = "AND p.category = :cat" if category else ""
    params = {"vec": vec_str, "top_k": top_k, "min_sim": MIN_SIMILARITY}
    if category:
        params["cat"] = category

    result = await db.execute(
        text(f"""
            SELECT
                pc.chunk_text,
                pc.policy_id,
                p.title          AS policy_title,
                p.category,
                1 - (pc.embedding <=> :vec::vector) AS similarity
            FROM policy_chunks pc
            JOIN policies p ON p.id = pc.policy_id
            WHERE p.active = TRUE
              {cat_filter}
              AND 1 - (pc.embedding <=> :vec::vector) >= :min_sim
            ORDER BY pc.embedding <=> :vec::vector
            LIMIT :top_k
        """),
        params,
    )

    rows = [dict(r) for r in result.mappings()]

    # Deduplicate by policy — avoid returning 4 chunks from the same doc
    seen_policies: dict[str, int] = {}
    deduped = []
    for row in rows:
        pid = row["policy_id"]
        seen_policies[pid] = seen_policies.get(pid, 0) + 1
        if seen_policies[pid] <= 2:  # Max 2 chunks per policy
            deduped.append(row)

    # Log retrieval
    try:
        policy_ids = list({r["policy_id"] for r in deduped})
        await db.execute(
            text("""
                INSERT INTO policy_access_log
                    (query_text, chunks_returned, policy_ids, context, staff_user_id)
                VALUES (:q, :n, :ids::jsonb, :ctx, :uid)
            """),
            {
                "q": query[:500],
                "n": len(deduped),
                "ids": json.dumps(policy_ids),
                "ctx": context,
                "uid": staff_user_id,
            },
        )
        await db.commit()
    except Exception:
        pass  # Never fail on logging

    return deduped


# ---------------------------------------------------------------------------
# Format for LLM injection
# ---------------------------------------------------------------------------

def format_policy_context(chunks: list[dict]) -> str:
    """
    Format retrieved chunks into a clean context block for injection
    into the LLM system prompt.
    """
    if not chunks:
        return ""

    lines = [
        "=== COMPANY POLICIES (retrieved from knowledge base) ===",
        "The following policies are relevant to this query. Follow them strictly.",
        "",
    ]

    for i, chunk in enumerate(chunks, 1):
        lines.append(
            f"[Policy {i}: {chunk['policy_title']} — {chunk['category'].upper()}]"
        )
        lines.append(chunk["chunk_text"].strip())
        lines.append("")

    lines.append("=== END POLICIES ===")
    return "\n".join(lines)
