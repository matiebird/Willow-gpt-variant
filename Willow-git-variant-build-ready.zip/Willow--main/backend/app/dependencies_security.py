"""
Willow product security dependencies.

These dependencies are intentionally simple for the appliance build:
- n8n, voice and other internal services authenticate with X-Willow-API-Key.
- Operators can pass X-Firm-ID to scope requests to a tenant/firm.
- End-user JWT/RBAC can be layered on top without changing the n8n-facing API.
"""

from __future__ import annotations

from uuid import UUID

from fastapi import Header, HTTPException, status

from app.config import get_settings


async def require_internal_api_key(
    x_willow_api_key: str | None = Header(default=None, alias="X-Willow-API-Key"),
) -> None:
    settings = get_settings()
    if not settings.willow_api_key or settings.willow_api_key == "change-me-local-dev":
        # Permit local development only when the default key is still set.
        if settings.environment == "development":
            return
    if not x_willow_api_key or x_willow_api_key != settings.willow_api_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing or invalid Willow API key",
        )


async def firm_scope(
    x_firm_id: str | None = Header(default=None, alias="X-Firm-ID"),
) -> UUID | None:
    if not x_firm_id:
        return None
    try:
        return UUID(x_firm_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="X-Firm-ID must be a UUID") from exc
