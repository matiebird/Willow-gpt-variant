#!/usr/bin/env bash
# =============================================================================
# WILLOW AI — Bootable ISO Builder
# Engineered Data Systems
# =============================================================================
# Builds a self-contained bootable Ubuntu 24.04 ISO that:
#   • Boots on any PC (UEFI or legacy BIOS)
#   • Installs Docker, NVIDIA/AMD/Intel GPU drivers automatically
#   • Clones the Willow repo to /opt/willow on first boot
#   • Runs 'make up-auto' on every subsequent boot
#   • Partitions the drive: EFI | OS (8GB) | Data (remainder = WILLOW_DATA_ROOT)
#
# Usage (runs inside the GitHub Actions Linux runner, or locally on Ubuntu):
#   sudo bash os/build.sh
#
# Output:
#   os/output/willow-os-<version>.iso
#
# Requirements:
#   debootstrap live-build squashfs-tools genisoimage syslinux-utils
#   (installed automatically below)
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
OUTPUT_DIR="$SCRIPT_DIR/output"

VERSION="${WILLOW_VERSION:-$(git -C "$REPO_ROOT" describe --tags --always 2>/dev/null || echo 'dev')}"
# Build variant: desktop (default) or server (headless — no GUI)
HEADLESS="${WILLOW_HEADLESS:-false}"
if [[ "$HEADLESS" == "true" ]]; then
  ISO_NAME="willow-os-${VERSION}-server.iso"
  ISO_VARIANT="server"
else
  ISO_NAME="willow-os-${VERSION}-desktop.iso"
  ISO_VARIANT="desktop"
fi
UBUNTU_CODENAME="noble"   # Ubuntu 24.04 LTS
WILLOW_REPO="${WILLOW_REPO_URL:-https://github.com/matiebird/Willow-.git}"

RED=$'\e[31m'; GREEN=$'\e[32m'; YELLOW=$'\e[33m'; CYAN=$'\e[36m'
BOLD=$'\e[1m'; RESET=$'\e[0m'

ok()      { echo "  ${GREEN}✓${RESET}  $*"; }
info()    { echo "  ${CYAN}➜${RESET}  $*"; }
warn()    { echo "  ${YELLOW}⚠${RESET}  $*"; }
heading() { echo ""; echo "${BOLD}${CYAN}══  $*  ══${RESET}"; echo ""; }
die()     { echo "  ${RED}✗${RESET}  $*" >&2; exit 1; }

[[ "$(id -u)" -eq 0 ]] || die "Must run as root (sudo bash os/build.sh)"

# =============================================================================
# 1 — Install build tools
# =============================================================================
heading "Installing build dependencies"

apt-get update -qq
apt-get install -y --no-install-recommends \
  live-build \
  debootstrap \
  squashfs-tools \
  genisoimage \
  syslinux-utils \
  xorriso \
  isolinux \
  grub-efi-amd64-bin \
  grub-pc-bin \
  mtools \
  git \
  curl \
  ca-certificates

ok "Build tools installed"

# =============================================================================
# 2 — Configure live-build
# =============================================================================
heading "Configuring live-build"

BUILD_DIR="$(mktemp -d /tmp/willow-iso-XXXXXX)"
cd "$BUILD_DIR"

# Ubuntu 24.04 live-build (3.0~a57-1ubuntu49.1) option notes:
# --bootloader grub2   → triggers lb_binary_grub2 (GRUB 2 / grub-pc) — NOT 'grub'
#                        'grub' triggers lb_binary_grub (GRUB Legacy) which tries to
#                        install grub-legacy — removed from Ubuntu since 14.04 → E:100
#                        'grub2' installs grub-pc (available on Ubuntu 24.04 ✓)
#                        lb_binary_grub2 also copies *.mod from chroot/usr/lib/grub/i386-pc/
#                        so grub-pc must also be in the chroot package list (see step 3)
# --memtest none       → skips memtest86+ (also pulled via syslinux)
# --uefi-secure-boot, --image-name, --bootloaders (plural) → not supported
# ISO renaming is handled after lb build (see step 8)
# GitHub Actions runners are Azure VMs — archive.ubuntu.com deadlocks from Azure.
# Use the local Azure mirror (same one the runner uses for its own apt).
# Fall back to the global mirror for local/on-prem builds.
if [ -n "${GITHUB_ACTIONS}" ]; then
  UBUNTU_MIRROR="http://azure.archive.ubuntu.com/ubuntu/"
else
  UBUNTU_MIRROR="http://archive.ubuntu.com/ubuntu/"
fi

lb config \
  --mode ubuntu \
  --distribution "$UBUNTU_CODENAME" \
  --architecture amd64 \
  --archive-areas "main restricted universe multiverse" \
  --mirror-bootstrap "${UBUNTU_MIRROR}" \
  --mirror-binary "${UBUNTU_MIRROR}" \
  --mirror-binary-security "http://security.ubuntu.com/ubuntu/" \
  --binary-images iso-hybrid \
  --bootloader grub2 \
  --memtest none \
  --debian-installer false \
  --apt-recommends false \
  --compression xz

ok "live-build configured in $BUILD_DIR"

# =============================================================================
# 3 — Package lists
# =============================================================================
heading "Writing package lists"

mkdir -p config/package-lists

# Base system
cat > config/package-lists/base.list.chroot << 'EOF'
# Kernel — required: without this initramfs-tools creates dangling symlinks
# and lb_chroot_hacks fails with exit code 123
linux-image-generic
linux-headers-generic
# initramfs-tools is only a Recommended dep of linux-image-generic.
# With --apt-recommends false it is silently skipped, leaving a dangling
# /boot/initrd.img symlink that causes lb_chroot_hacks to exit 123.
initramfs-tools
# GRUB 2 — lb_binary_grub2 (triggered by --bootloader grub2) copies
# *.mod files FROM chroot/usr/lib/grub/i386-pc/ into the ISO.
# grub-pc must be installed in the chroot or the module copy step fails.
grub-pc
# Base system
bash
curl
wget
ca-certificates
git
make
python3
python3-pip
openssl
jq
lsb-release
gnupg
apt-transport-https
software-properties-common
rsync
htop
nano
openssh-server
sudo
systemd
udev
# Hardware utils
pciutils
usbutils
lshw
nvme-cli
# Network
network-manager
iproute2
iputils-ping
# mDNS — makes the machine accessible as willow.local on any LAN browser
avahi-daemon
avahi-utils
libnss-mdns
python3-cryptography
EOF

# Desktop environment — only included when not building headless/server variant
if [[ "$HEADLESS" != "true" ]]; then

cat > config/package-lists/desktop.list.chroot << 'EOF'
# XFCE4 desktop + essentials
xfce4
xfce4-goodies
xfce4-terminal
xfce4-taskmanager
xfce4-screenshooter
lightdm
lightdm-gtk-greeter
lightdm-gtk-greeter-settings
# Compositor for smooth rendering
xfwm4
# Session management
xfce4-session
# System tray (needed for nm-applet)
network-manager-gnome
# Fonts
fonts-liberation
fonts-noto
fonts-noto-color-emoji
# Theming
arc-theme
papirus-icon-theme
EOF

# Productivity apps
cat > config/package-lists/productivity.list.chroot << 'EOF'
# Browser
chromium-browser
# Office suite
libreoffice-writer
libreoffice-calc
libreoffice-impress
libreoffice-draw
libreoffice-base
libreoffice-gtk3
# PDF viewer
evince
# Image viewer (receipts, scanned docs)
ristretto
# Image editor (receipt cleanup, annotations)
gimp
# File archiver
file-roller
# Remote desktop (client support)
remmina
remmina-plugin-rdp
remmina-plugin-vnc
# Password manager (offline vault — critical for a firm)
keepassxc
# Backup
rclone
# Printing
cups
system-config-printer
printer-driver-all
# Scanning (receipts + documents)
simple-scan
sane-utils
EOF

# Docker (installed via hook, not apt list — needs key setup)
# Docker packages are NOT in the standard Ubuntu archive.
# They are installed in hook 01 AFTER the repo is added.
# Do NOT add docker-ce/docker-ce-cli/containerd.io here — the chroot has
# no Docker apt source yet at package-list install time → exit 123.

fi  # end HEADLESS check

ok "Package lists written"

# =============================================================================
# 4 — Hooks (run inside the chroot during build)
# =============================================================================
heading "Writing chroot hooks"

mkdir -p config/hooks/normal

# ── Hook 01: Docker repo + NVIDIA/AMD/Intel driver repos ────────────────────
cat > config/hooks/normal/01-repos.hook.chroot << 'HOOK'
#!/bin/sh
set -e

# Docker official repo
install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
  | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
chmod a+r /etc/apt/keyrings/docker.gpg
echo "deb [arch=amd64 signed-by=/etc/apt/keyrings/docker.gpg] \
  https://download.docker.com/linux/ubuntu noble stable" \
  > /etc/apt/sources.list.d/docker.list

# NVIDIA Container Toolkit repo
curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey \
  | gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list \
  | sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' \
  | tee /etc/apt/sources.list.d/nvidia-container-toolkit.list

# AMD ROCm repo
wget -qO - https://repo.radeon.com/rocm/rocm.gpg.key \
  | gpg --dearmor -o /etc/apt/keyrings/rocm.gpg
echo "deb [arch=amd64 signed-by=/etc/apt/keyrings/rocm.gpg] \
  https://repo.radeon.com/amdgpu/6.3/ubuntu noble main" \
  > /etc/apt/sources.list.d/amdgpu.list
echo "deb [arch=amd64 signed-by=/etc/apt/keyrings/rocm.gpg] \
  https://repo.radeon.com/rocm/apt/6.3 noble main" \
  >> /etc/apt/sources.list.d/amdgpu.list

# Intel GPU compute runtime
wget -qO - https://repositories.intel.com/gpu/intel-graphics.key \
  | gpg --dearmor -o /usr/share/keyrings/intel-graphics.gpg
echo "deb [arch=amd64 signed-by=/usr/share/keyrings/intel-graphics.gpg] \
  https://repositories.intel.com/gpu/ubuntu noble client" \
  > /etc/apt/sources.list.d/intel-gpu.list

apt-get update -qq

# Install Docker packages now that the repo is configured
apt-get install -y --no-install-recommends \
  docker-ce docker-ce-cli containerd.io docker-compose-plugin
HOOK
chmod +x config/hooks/normal/01-repos.hook.chroot

# ── Hook 01b: Hostname + Avahi mDNS setup ───────────────────────────────────
cat > config/hooks/normal/01b-hostname.hook.chroot << 'HOOK'
#!/bin/sh
set -e

# Set hostname to "willow" so the machine is willow.local on the LAN
hostnamectl set-hostname willow 2>/dev/null || echo "willow" > /etc/hostname
echo "127.0.1.1  willow.local willow" >> /etc/hosts

# Configure nsswitch to resolve .local via mDNS
sed -i 's/^hosts:.*/hosts:          files mdns4_minimal [NOTFOUND=return] dns/'   /etc/nsswitch.conf

# Enable Avahi on boot
systemctl enable avahi-daemon

# Avahi service config — announce on all interfaces, no IPv6 required
cat > /etc/avahi/avahi-daemon.conf << 'CONF'
[server]
host-name=willow
domain-name=local
use-ipv4=yes
use-ipv6=no
ratelimit-interval-usec=1000000
ratelimit-burst=1000

[wide-area]
enable-wide-area=no

[publish]
publish-addresses=yes
publish-hinfo=yes
publish-workstation=yes
publish-domain=yes
CONF

# Avahi service file — announces Willow web UI on the LAN
mkdir -p /etc/avahi/services
cat > /etc/avahi/services/willow.service << 'SVC'
<?xml version="1.0" standalone='no'?>
<!DOCTYPE service-group SYSTEM "avahi-service.dtd">
<service-group>
  <name replace-wildcards="yes">Willow AI — %h</name>
  <service>
    <type>_http._tcp</type>
    <port>8080</port>
    <txt-record>path=/</txt-record>
    <txt-record>description=Willow AI Bookkeeping Dashboard</txt-record>
  </service>
</service-group>
SVC
HOOK
chmod +x config/hooks/normal/01b-hostname.hook.chroot

# ── Hook 02: Install GPU drivers + container toolkit ────────────────────────
cat > config/hooks/normal/02-gpu-drivers.hook.chroot << 'HOOK'
#!/bin/sh
# GPU drivers — all steps non-fatal; actual driver loaded at runtime based on hardware

# NVIDIA Container Toolkit
apt-get install -y --no-install-recommends nvidia-container-toolkit || true

# AMD ROCm — non-fatal (large download; repo may be unavailable in CI)
apt-get install -y --no-install-recommends \
  amdgpu-dkms rocm-hip-runtime rocm-opencl-runtime || true

# Intel Arc compute runtime — non-fatal
apt-get install -y --no-install-recommends \
  intel-opencl-icd intel-level-zero-gpu level-zero || true

# Configure NVIDIA runtime (no-op if toolkit not installed)
nvidia-ctk runtime configure --runtime=docker 2>/dev/null || true
HOOK
chmod +x config/hooks/normal/02-gpu-drivers.hook.chroot

# ── Hook 03: Docker post-install config ─────────────────────────────────────
cat > config/hooks/normal/03-docker.hook.chroot << 'HOOK'
#!/bin/sh
set -e

# Enable Docker on boot
systemctl enable docker

# Create willow user (non-root, in docker group)
useradd -m -s /bin/bash -G docker,video,render willow || true
echo "willow:willow" | chpasswd
echo "willow ALL=(ALL) NOPASSWD:ALL" > /etc/sudoers.d/willow

# Add willow to docker group (so make targets run without sudo)
usermod -aG docker willow
HOOK
chmod +x config/hooks/normal/03-docker.hook.chroot

# ── Hook 04: Clone Willow repo ───────────────────────────────────────────────
cat > config/hooks/normal/04-willow.hook.chroot << HOOK
#!/bin/sh
set -e

# Clone Willow repo to /opt/willow
git clone --depth 1 ${WILLOW_REPO} /opt/willow
chown -R willow:willow /opt/willow
chmod +x /opt/willow/install.sh /opt/willow/scripts/*.sh

# Create WILLOW_DATA_ROOT mount point (partition 3 gets mounted here on boot)
mkdir -p /mnt/willow-data
HOOK
chmod +x config/hooks/normal/04-willow.hook.chroot

# ── Hook 05: Systemd services ────────────────────────────────────────────────
cat > config/hooks/normal/05-systemd.hook.chroot << 'HOOK'
#!/bin/sh
set -e

# Copy pre-written service files from /opt/willow/os/config/
cp /opt/willow/os/config/willow-mount-data.service   /etc/systemd/system/
cp /opt/willow/os/config/willow-autostart.service    /etc/systemd/system/
cp /opt/willow/os/config/willow-first-run.service    /etc/systemd/system/
cp /opt/willow/os/config/willow-first-run.sh         /usr/local/bin/willow-first-run
chmod +x /usr/local/bin/willow-first-run

systemctl enable willow-mount-data.service
systemctl enable willow-first-run.service
systemctl enable willow-autostart.service

# Auto-login as willow user on tty1
mkdir -p /etc/systemd/system/getty@tty1.service.d
cat > /etc/systemd/system/getty@tty1.service.d/autologin.conf << 'CONF'
[Service]
ExecStart=
ExecStart=-/sbin/agetty --autologin willow --noclear %I $TERM
CONF
HOOK
chmod +x config/hooks/normal/05-systemd.hook.chroot

# ── Hook 06: Desktop environment config (skipped in headless/server build) ───
if [[ "$HEADLESS" != "true" ]]; then
cat > config/hooks/normal/06-desktop.hook.chroot << 'HOOK'
#!/bin/sh
set -e

# Configure LightDM for auto-login as willow user
cat > /etc/lightdm/lightdm.conf << 'CONF'
[Seat:*]
autologin-user=willow
autologin-user-timeout=0
user-session=xfce
greeter-session=lightdm-gtk-greeter
CONF

# LightDM greeter branding
cat > /etc/lightdm/lightdm-gtk-greeter.conf << 'CONF'
[greeter]
theme-name=Arc-Dark
icon-theme-name=Papirus-Dark
font-name=Liberation Sans 11
background=#01696F
indicators=~host;~spacer;~clock;~spacer;~power
clock-format=%A %d %B  %H:%M
CONF

# Enable LightDM
systemctl enable lightdm

# Copy desktop setup script — runs on first XFCE login
cp /opt/willow/os/config/willow-desktop-setup.sh /usr/local/bin/willow-desktop-setup
chmod +x /usr/local/bin/willow-desktop-setup

# XFCE autostart entry — runs desktop setup on first login
mkdir -p /etc/xdg/autostart
cat > /etc/xdg/autostart/willow-desktop-setup.desktop << 'DESKTOP'
[Desktop Entry]
Type=Application
Name=Willow Desktop Setup
Exec=/usr/local/bin/willow-desktop-setup
X-GNOME-Autostart-enabled=true
DESKTOP

# Open Chromium to Willow dashboard on every login
cat > /etc/xdg/autostart/willow-browser.desktop << 'DESKTOP'
[Desktop Entry]
Type=Application
Name=Willow Dashboard
Exec=chromium-browser --no-first-run --no-default-browser-check \
     --start-maximized \
     http://localhost:8080
X-GNOME-Autostart-enabled=true
DESKTOP

# Set CUPS to start on boot (printing)
systemctl enable cups
HOOK
chmod +x config/hooks/normal/06-desktop.hook.chroot
fi  # end HEADLESS check for hook 06

# ── Hook 07: Force initramfs generation ─────────────────────────────────────
# Without this, initramfs-tools defers update and leaves dangling symlinks at
# /boot/initrd.img — causing lb_chroot_hacks to fail with exit 123.
cat > config/hooks/normal/07-initramfs.hook.chroot << 'HOOK'
#!/bin/sh
set -e
# Force the initramfs to actually be built now (not deferred)
update-initramfs -u -k all
HOOK
chmod +x config/hooks/normal/07-initramfs.hook.chroot

ok "Chroot hooks written (7 hooks — desktop skipped in server build)"

# =============================================================================
# 5 — Copy OS config files into build
# =============================================================================
heading "Staging OS config files"

mkdir -p config/includes.chroot/opt/willow-os-config

# Copy systemd units + scripts from the repo's os/config/ directory
cp "$REPO_ROOT/os/config/"*.service \
   "$REPO_ROOT/os/config/"*.sh \
   config/includes.chroot/opt/willow-os-config/ 2>/dev/null || true

ok "Config files staged"

# =============================================================================
# 6 — GRUB config
# =============================================================================
heading "Writing GRUB config"

# lb_binary_grub2 (triggered by --bootloader grub2) looks for a custom
# grub.cfg override at config/binary_grub/grub.cfg — NOT config/bootloaders/.
# In Ubuntu/casper mode the kernel and initrd land in binary/casper/,
# so menu entries must reference /casper/vmlinuz and /casper/initrd.
# boot=casper activates the casper live-boot init.
mkdir -p config/binary_grub

GRUB_CFG_CONTENT='set default=0
set timeout=5

menuentry "Willow — Boot" {
    linux  /casper/vmlinuz boot=casper quiet splash nomodeset
    initrd /casper/initrd
}

menuentry "Willow — Safe Mode (nomodeset)" {
    linux  /casper/vmlinuz boot=casper nomodeset
    initrd /casper/initrd
}

menuentry "Willow — First Run Setup" {
    linux  /casper/vmlinuz boot=casper willow.firstrun=1
    initrd /casper/initrd
}'

echo "$GRUB_CFG_CONTENT" > config/binary_grub/grub.cfg

ok "GRUB config written (config/binary_grub/grub.cfg)"

# =============================================================================
# 7 — Build the ISO
# =============================================================================
heading "Building ISO (this takes 15–30 minutes)"

# isohybrid ────────────────────────────────────────────────────────────────────────────────────
# lb_binary_iso calls isohybrid after xorriso finishes to stamp a syslinux
# hybrid MBR.  With --bootloader grub2, lb_binary_grub2 already passes
# --grub2-mbr to xorriso which embeds the GRUB2 hybrid MBR record — the
# syslinux MBR that isohybrid would write is redundant and would overwrite
# the GRUB2 one, breaking BIOS USB boot.
#
# lb's subshells reset PATH to a fixed list (/usr/sbin:/usr/bin:/sbin:/bin)
# so exported PATH changes don't survive.  Write the no-op directly to
# /usr/bin/isohybrid — that path is in every live-build PATH reset and we
# are root inside the Docker container so the write is always permitted.
cat > /usr/bin/isohybrid << 'SHIM'
#!/bin/sh
# no-op: --grub2-mbr already wrote the hybrid MBR
exit 0
SHIM
chmod +x /usr/bin/isohybrid

# lb build output goes to both stdout and the log file.
# The workflow uploads os/build.log as an artifact on failure.
LOG_FILE="$SCRIPT_DIR/build.log"
lb build 2>&1 | tee "$LOG_FILE"
# Preserve exit code from lb build (tee always exits 0)
test "${PIPESTATUS[0]}" -eq 0 || { echo "lb build failed — see $LOG_FILE"; exit 1; }

# =============================================================================
# 8 — Move output
# =============================================================================
heading "Collecting output"

mkdir -p "$OUTPUT_DIR"

BUILT_ISO="$(find "$BUILD_DIR" -name "*.iso" | head -1)"
if [[ -z "$BUILT_ISO" ]]; then
  die "Build failed — no ISO produced. Check $SCRIPT_DIR/build.log"
fi

mv "$BUILT_ISO" "$OUTPUT_DIR/$ISO_NAME"
ISO_SIZE="$(du -sh "$OUTPUT_DIR/$ISO_NAME" | cut -f1)"

ok "ISO built: $OUTPUT_DIR/$ISO_NAME  (${ISO_SIZE})  [variant: ${ISO_VARIANT}]"
echo ""
echo "  ${BOLD}Flash to USB:${RESET}"
echo "    Linux:   sudo dd if=$OUTPUT_DIR/$ISO_NAME of=/dev/sdX bs=4M status=progress"
echo "    Windows: Use Rufus — https://rufus.ie  (DD mode, not ISO mode)"
echo "    macOS:   Use Balena Etcher — https://etcher.balena.io"
echo ""

# Clean up temp build dir
rm -rf "$BUILD_DIR"
