#!/usr/bin/env bash
# =============================================================================
# WILLOW AI — First-Run Setup Script
# Runs once on first boot. Configures .env, partitions data drive if needed,
# pulls models, then hands off to willow-autostart.service.
# =============================================================================
set -euo pipefail

WILLOW_DIR="/opt/willow"
DATA_MOUNT="/mnt/willow-data"

RED=$'\e[31m'; GREEN=$'\e[32m'; YELLOW=$'\e[33m'
CYAN=$'\e[36m'; BOLD=$'\e[1m'; RESET=$'\e[0m'

ok()      { echo "  ${GREEN}✓${RESET}  $*"; }
info()    { echo "  ${CYAN}➜${RESET}  $*"; }
warn()    { echo "  ${YELLOW}⚠${RESET}  $*"; }
heading() { echo ""; echo "${BOLD}${CYAN}══  $*  ══${RESET}"; echo ""; }

# Install python3-cryptography if not already present (needed by verify-license.py)
python3 -c "from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey" 2>/dev/null \
  || apt-get install -y --no-install-recommends python3-cryptography -qq 2>/dev/null \
  || true

clear
echo -e "${GREEN}"
cat << 'BANNER'
  ██╗    ██╗██╗██╗     ██╗      ██████╗ ██╗    ██╗
  ██║    ██║██║██║     ██║     ██╔═══██╗██║    ██║
  ██║ █╗ ██║██║██║     ██║     ██║   ██║██║ █╗ ██║
  ██║███╗██║██║██║     ██║     ██║   ██║██║███╗██║
  ╚███╔███╔╝██║███████╗███████╗╚██████╔╝╚███╔███╔╝
   ╚══╝╚══╝ ╚═╝╚══════╝╚══════╝ ╚═════╝  ╚══╝╚══╝
BANNER
echo -e "${RESET}"
echo -e "  ${BOLD}First Boot — Initial Setup${RESET}"
echo -e "  ${CYAN}Your books. Your server. Your rules.${RESET}"
echo ""

# =============================================================================
# Step 0 — License check
# =============================================================================
heading "0 of 4 — License Verification"
bash "$WILLOW_DIR/scripts/verify-license.sh" || true

# =============================================================================
# Step 1 — Detect GPU
# =============================================================================
heading "1 of 4 — GPU Detection"

GPU_TYPE="$(bash "$WILLOW_DIR/scripts/detect-gpu.sh" --quiet 2>/dev/null || echo "cpu")"
bash "$WILLOW_DIR/scripts/detect-gpu.sh" 2>/dev/null || true

# =============================================================================
# Step 2 — Verify data partition
# =============================================================================
heading "2 of 4 — Data Partition"

if mountpoint -q "$DATA_MOUNT"; then
  ok "Data partition mounted at $DATA_MOUNT"
  # Prepare directory structure
  bash "$WILLOW_DIR/scripts/prepare-usb.sh" "$DATA_MOUNT" 2>/dev/null || true
  DATA_ROOT="$DATA_MOUNT"
else
  warn "Data partition not mounted — Willow will use Docker named volumes instead."
  warn "For portable mode, ensure partition 3 of this drive is formatted ext4."
  DATA_ROOT=""
fi

# =============================================================================
# Step 3 — Run installer (non-interactive with defaults)
# =============================================================================
heading "3 of 4 — Installing Willow"

cd "$WILLOW_DIR"

# Detect LAN IP automatically
LAN_IP="$(ip route get 8.8.8.8 2>/dev/null | grep -oP 'src \K\S+' | head -1 || echo "localhost")"
info "Detected LAN IP: $LAN_IP"

# Run non-interactive installer
PORTABLE_FLAG="--portable"
[[ "$GPU_TYPE" == "cpu" ]] && PORTABLE_FLAG="--portable-cpu"

bash install.sh $PORTABLE_FLAG --yes

# Write WILLOW_DATA_ROOT into .env if data partition found
if [[ -n "$DATA_ROOT" ]]; then
  if grep -q "^WILLOW_DATA_ROOT=" docker/.env 2>/dev/null; then
    sed -i "s|^WILLOW_DATA_ROOT=.*|WILLOW_DATA_ROOT=$DATA_ROOT|" docker/.env
  else
    printf "\n# USB / PORTABLE MODE\nWILLOW_DATA_ROOT=%s\n" "$DATA_ROOT" >> docker/.env
  fi
  ok "WILLOW_DATA_ROOT set to $DATA_ROOT"
fi

# =============================================================================
# Step 4 — Pull Ollama models
# =============================================================================
heading "4 of 4 — Pulling AI Models"
info "This may take 10–20 minutes depending on your internet connection."
info "Models are stored on the data partition and only download once."

make models-portable || warn "Model pull failed — run 'make models-portable' manually after boot."

# =============================================================================
# Done
# =============================================================================

# Detect server vs desktop mode — server builds don't include LightDM
if command -v lightdm &>/dev/null; then
  SERVER_MODE=false
else
  SERVER_MODE=true
fi

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════╗${RESET}"
echo -e "${GREEN}║              Willow setup complete                       ║${RESET}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════╝${RESET}"
echo ""
echo -e "  ${BOLD}Services start automatically on every boot from here.${RESET}"
echo ""

if [[ "$SERVER_MODE" == "true" ]]; then
  echo -e "${BOLD}${CYAN}  ╔════════════════════════════════════════════════════╗${RESET}"
  echo -e "${BOLD}${CYAN}  ║   STAFF ACCESS — Chrome / Edge / Firefox on any PC ║${RESET}"
  echo -e "${BOLD}${CYAN}  ╚════════════════════════════════════════════════════╝${RESET}"
  echo ""
  echo -e "  ${BOLD}mDNS — any device on the LAN, no IP needed:${RESET}"
  echo ""
  echo -e "    ${BOLD}${GREEN}http://willow.local:8080${RESET}     Willow dashboard"
  echo -e "    ${BOLD}${GREEN}http://willow.local:5678${RESET}     n8n workflow editor"
  echo -e "    ${BOLD}${GREEN}http://willow.local:3000${RESET}     Open WebUI chat"
  echo -e "    ${BOLD}${GREEN}http://willow.local:8081${RESET}     Kanboard tasks"
  echo ""
  echo -e "  ${BOLD}Fallback — direct IP (if willow.local doesn't resolve):${RESET}"
  echo ""
  echo -e "    ${CYAN}http://${LAN_IP}:8080${RESET}     Willow dashboard"
  echo -e "    ${CYAN}http://${LAN_IP}:5678${RESET}     n8n workflow editor"
  echo -e "    ${CYAN}http://${LAN_IP}:3000${RESET}     Open WebUI chat"
  echo -e "    ${CYAN}http://${LAN_IP}:8081${RESET}     Kanboard tasks"
else
  echo -e "  ${BOLD}Access from this machine or any LAN device:${RESET}"
  echo ""
  echo -e "    ${BOLD}${GREEN}http://willow.local:8080${RESET}     Willow dashboard"
  echo -e "    ${BOLD}${GREEN}http://willow.local:5678${RESET}     n8n workflow editor"
  echo -e "    ${BOLD}${GREEN}http://willow.local:3000${RESET}     Open WebUI chat"
  echo -e "    ${BOLD}${GREEN}http://willow.local:8081${RESET}     Kanboard tasks"
  echo ""
  echo -e "  ${YELLOW}By IP: http://${LAN_IP}:8080  ·  :5678  ·  :3000  ·  :8081${RESET}"
fi

echo ""
echo -e "  ${BOLD}Two manual steps remaining:${RESET}"
echo -e "  1. Open n8n → Credentials → add ${BOLD}Xero OAuth2${RESET} + ${BOLD}Gmail OAuth2${RESET}"
echo -e "  2. Enable ${BOLD}willow-follow-up-executor${RESET} after confirming Approvals dashboard"
echo ""
echo -e "  ${YELLOW}Reboot now to go live.${RESET}"
echo ""
