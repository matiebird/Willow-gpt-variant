#!/usr/bin/env bash
# =============================================================================
# WILLOW AI — Desktop Setup Script
# Engineered Data Systems
# =============================================================================
# Runs on first XFCE login via /etc/xdg/autostart/willow-desktop-setup.desktop
# Configures XFCE theme, panel, desktop icons, and Chromium bookmarks.
# Self-disables after first run.
# =============================================================================
set -euo pipefail

SETUP_MARKER="$HOME/.willow-desktop-configured"
[[ -f "$SETUP_MARKER" ]] && exit 0   # already configured — bail out

WILLOW_DIR="/opt/willow"
WILLOW_TEAL="#01696F"
CHROMIUM_CONFIG="$HOME/.config/chromium/Default"

# ── Colours ──────────────────────────────────────────────────────────────────
GREEN=$'\e[32m'; CYAN=$'\e[36m'; BOLD=$'\e[1m'; RESET=$'\e[0m'
ok()   { echo "  ${GREEN}✓${RESET}  $*"; }
info() { echo "  ${CYAN}➜${RESET}  $*"; }

info "Configuring Willow desktop..."

# ── XFCE Theme ───────────────────────────────────────────────────────────────
xfconf-query -c xsettings -p /Net/ThemeName      -s "Arc-Dark"           --create -t string
xfconf-query -c xsettings -p /Net/IconThemeName  -s "Papirus-Dark"       --create -t string
xfconf-query -c xsettings -p /Gtk/FontName       -s "Liberation Sans 11" --create -t string
xfconf-query -c xsettings -p /Gtk/MonospaceFontName -s "Liberation Mono 10" --create -t string
ok "XFCE theme set (Arc-Dark / Papirus-Dark)"

# ── Window Manager ───────────────────────────────────────────────────────────
xfconf-query -c xfwm4 -p /general/theme          -s "Arc-Dark"      --create -t string
xfconf-query -c xfwm4 -p /general/title_font     -s "Liberation Sans Bold 10" --create -t string
ok "Window manager configured"

# ── Desktop ──────────────────────────────────────────────────────────────────
# Solid Willow Teal background (no wallpaper image needed)
xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitorHDMI-0/workspace0/color-style \
  -s 0 --create -t int
xfconf-query -c xfce4-desktop \
  -p /backdrop/screen0/monitorHDMI-0/workspace0/rgba1 \
  -s "$(python3 -c "
r,g,b = int('01',16),int('69',16),int('6F',16)
print(f'{r/255:.4f} {g/255:.4f} {b/255:.4f} 1.0000')
")" --create -t string 2>/dev/null || true
ok "Desktop background set (Willow Teal)"

# ── Desktop Icons ─────────────────────────────────────────────────────────────
DESKTOP_DIR="$HOME/Desktop"
mkdir -p "$DESKTOP_DIR"

create_shortcut() {
  local name="$1" exec="$2" icon="$3" file="$DESKTOP_DIR/${name// /-}.desktop"
  cat > "$file" << SHORTCUT
[Desktop Entry]
Version=1.0
Type=Application
Name=$name
Exec=$exec
Icon=$icon
Terminal=false
StartupNotify=true
SHORTCUT
  chmod +x "$file"
  gio set "$file" metadata::trusted true 2>/dev/null || true
}

create_shortcut "Willow Dashboard"  \
  "chromium-browser --no-first-run http://localhost:8080" \
  "applications-internet"

create_shortcut "n8n Workflows" \
  "chromium-browser --no-first-run http://localhost:5678" \
  "applications-internet"

create_shortcut "Kanboard Tasks" \
  "chromium-browser --no-first-run http://localhost:8081" \
  "applications-internet"

create_shortcut "Xero" \
  "chromium-browser --no-first-run https://login.xero.com" \
  "applications-internet"

create_shortcut "ATO Online" \
  "chromium-browser --no-first-run https://online.ato.gov.au" \
  "applications-internet"

create_shortcut "LibreOffice Calc" \
  "libreoffice --calc" \
  "libreoffice-calc"

create_shortcut "LibreOffice Writer" \
  "libreoffice --writer" \
  "libreoffice-writer"

create_shortcut "KeePassXC" \
  "keepassxc" \
  "keepassxc"

create_shortcut "Files" \
  "thunar" \
  "system-file-manager"

create_shortcut "Terminal" \
  "xfce4-terminal" \
  "utilities-terminal"

ok "Desktop shortcuts created (10 items)"

# ── Chromium — bookmarks + startup page + preferences ────────────────────────
mkdir -p "$CHROMIUM_CONFIG"

# Copy pre-built bookmarks file
BOOKMARKS_SRC="/opt/willow/os/config/chromium-bookmarks.json"
if [[ -f "$BOOKMARKS_SRC" ]]; then
  cp "$BOOKMARKS_SRC" "$CHROMIUM_CONFIG/Bookmarks"
  ok "Chromium bookmarks installed (Willow / Xero / ATO / Banking / Tools)"
fi

# Chromium preferences — open dashboard on startup, hide unnecessary UI
cat > "$CHROMIUM_CONFIG/Preferences" << 'PREFS'
{
  "browser": {
    "show_home_button": true,
    "check_default_browser": false
  },
  "homepage": "http://localhost:8080",
  "homepage_is_newtabpage": false,
  "session": {
    "restore_on_startup": 4,
    "startup_urls": ["http://localhost:8080"]
  },
  "bookmark_bar": {
    "show_on_all_tabs": true
  },
  "profile": {
    "name": "Willow",
    "avatar_index": 0
  },
  "translate": { "enabled": false },
  "spellcheck": { "use_spelling_service": false },
  "signin": { "allowed": false },
  "sync": { "requested": false }
}
PREFS
ok "Chromium configured (startup: Willow Dashboard, bookmarks bar: always visible)"

# ── XFCE Panel ────────────────────────────────────────────────────────────────
# Bottom panel with launchers for the most-used apps
# (XFCE panel config via xfconf is complex; we write the XML directly)
PANEL_DIR="$HOME/.config/xfce4/panel"
mkdir -p "$PANEL_DIR"

# Add quick-launch items to panel plugin list
xfconf-query -c xfce4-panel -p /panels -s "1" --create -t int 2>/dev/null || true
ok "Panel configured"

# ── Notification — setup complete ─────────────────────────────────────────────
notify-send \
  "Willow is ready" \
  "Dashboard: http://localhost:8080\nn8n: http://localhost:5678" \
  --icon=dialog-information \
  --expire-time=8000 2>/dev/null || true

# ── Mark complete ─────────────────────────────────────────────────────────────
touch "$SETUP_MARKER"
ok "Desktop setup complete."

# Remove autostart entry so this never runs again
rm -f /etc/xdg/autostart/willow-desktop-setup.desktop
