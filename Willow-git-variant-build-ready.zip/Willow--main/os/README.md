# Willow OS

A bootable Ubuntu 24.04 image that turns any PC into a Willow appliance.
Plug in the USB-NVMe, boot from it — nothing is installed on the host machine.

Two variants are built automatically:

| ISO | Use case | Desktop |
|-----|----------|---------|
| `willow-os-<ver>-desktop.iso` | Dedicated workstation — XFCE4 auto-login, Chromium opens dashboard | Yes |
| `willow-os-<ver>-server.iso` | Shared server — headless, staff browse to `http://willow.local` | No |

---

## Download

Every push to `main` that touches `os/`, `install.sh`, `Makefile`, or `scripts/`
triggers a GitHub Actions build. Both variants are built in parallel and attached
to a single **[Release](../../releases)** within ~25 minutes.

Choose the right ISO:
- **Desktop** (`willow-os-<ver>-desktop.iso`) — one Willow workstation with a full GUI
- **Server** (`willow-os-<ver>-server.iso`) — one shared server, staff access via their own PCs

---

## Flash to USB

| OS | Tool | Mode |
|----|------|------|
| Windows | [Rufus](https://rufus.ie) | Select **DD Image** (not ISO) |
| macOS | [Balena Etcher](https://etcher.balena.io) | — |
| Linux | `dd` | See below |

```bash
# Linux — replace /dev/sdX with your USB-NVMe device (check with lsblk)
sudo dd if=willow-os-<version>.iso of=/dev/sdX bs=4M status=progress conv=fsync
```

> **Warning:** `dd` overwrites the entire drive. Double-check the device path.

---

## Drive Layout

The ISO writes three partitions automatically:

| # | Size | Contents |
|---|------|----------|
| 1 EFI | 512 MB | GRUB bootloader (UEFI + legacy BIOS) |
| 2 OS  | 8 GB  | Ubuntu 24.04 + Docker + GPU drivers + Willow repo |
| 3 Data | remainder | `WILLOW_DATA_ROOT` — Postgres, n8n, Ollama models |

---

## First Boot

1. Insert the USB-NVMe into the test PC
2. Enter BIOS/UEFI → select USB boot
3. Willow's first-run setup starts automatically:
   - Detects GPU (NVIDIA / AMD / Intel / CPU)
   - Runs `./install.sh --portable` non-interactively
   - Partitions and mounts the data partition
   - Pulls Ollama models (10–20 min depending on internet speed)
4. On completion, the full stack is live:

| Service | willow.local | Direct IP |
|---------|-------------|----------|
| Willow dashboard | `http://willow.local:8080` | `http://<ip>:8080` |
| n8n workflow editor | `http://willow.local:5678` | `http://<ip>:5678` |
| Open WebUI chat | `http://willow.local:3000` | `http://<ip>:3000` |
| Kanboard tasks | `http://willow.local:8081` | `http://<ip>:8081` |

**First-run only runs once.** The service disables itself after success.
Every subsequent boot goes straight to `make up-auto`.

---

## Subsequent Boots

`willow-autostart.service` runs `make up-auto` on every boot.
`up-auto` calls `scripts/detect-gpu.sh --quiet` and starts the right stack.
No manual intervention needed.

---

## Server Mode — Staff Browser Access

The **server ISO** runs Willow headlessly — no desktop, no monitor needed after
setup. One machine runs Willow OS; every staff member accesses it from their own
PC using Chrome, Edge, or Firefox.

### How it works

Willow OS broadcasts its `willow.local` hostname over mDNS (Avahi daemon). Any
device on the same network resolves it automatically — no DNS configuration, no
IT setup, no IP address to remember.

### Service URLs

Open on any PC connected to the same network as the Willow server:

| Service | URL | Purpose |
|---------|-----|---------|
| **Willow dashboard** | `http://willow.local:8080` | Documents, reconciliation, approvals |
| **n8n** | `http://willow.local:5678` | Workflow editor and agent config |
| **Open WebUI** | `http://willow.local:3000` | Direct chat with the local LLM |
| **Kanboard** | `http://willow.local:8081` | Task tracking |

### Fallback — direct IP

If `willow.local` doesn't resolve (some corporate networks block mDNS), use the
server's IP address. Find it by SSHing in or checking your router's DHCP table:

```bash
ssh willow@<ip>      # password: willow  (change this after first login)
ip addr show         # look for inet on eth0 / enp3s0
```

### Hardware for server mode

| Component | Minimum | Notes |
|-----------|---------|-------|
| CPU | x86-64, 4 cores | No GPU required — CPU mode works |
| RAM | 16 GB | 32 GB recommended with a GPU |
| Storage | 256 GB NVMe | 1 TB recommended (models are large) |
| GPU | None | NVIDIA RTX 2070+ gives the best LLM speed |
| Network | Ethernet | Gigabit preferred; Wi-Fi works |

> A repurposed PC, mini PC, or old workstation works perfectly. Staff laptops
> stay untouched — they just need a browser.

---

## Updating Willow

SSH into the machine (user: `willow`, password: `willow` — change this):

```bash
cd /opt/willow
git pull
make down
make up-auto
```

Or reflash with a newer ISO from Releases. The data partition (partition 3)
is untouched by a reflash — your database and models survive.

---

## Modifying the OS

Everything that goes into the image lives in this repo:

| What to change | Where |
|----------------|-------|
| Packages installed | `os/build.sh` → package lists section |
| GPU driver versions | `os/build.sh` → Hook 02 |
| Boot menu / timeout | `os/config/grub.cfg` (via `os/build.sh`) |
| First-run behaviour | `os/config/willow-first-run.sh` |
| Auto-start behaviour | `os/config/willow-autostart.service` |
| Data mount logic | `os/config/willow-mount-data.service` |
| Willow stack itself | Everything outside `os/` |

Push your change → Actions rebuilds the ISO → download from Releases.

---

## Hardware Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| CPU | x86-64, 4 cores | 8+ cores |
| RAM | 16 GB | 32 GB |
| USB-NVMe | USB 3.2 Gen 1 | USB 3.2 Gen 2 / Thunderbolt |
| Storage | 256 GB | 1 TB (models are large) |
| GPU | None (CPU fallback) | NVIDIA RTX 2070+ / AMD RX 6700 XT+ |

---

## Supported GPUs

| Vendor | Requirements |
|--------|--------------|
| NVIDIA | Any RTX/GTX — CUDA via NVIDIA Container Toolkit (no host driver needed) |
| AMD | RX 6000/7000 series — ROCm 6.3 baked in |
| Intel Arc | A380 / A770 / B580 — SYCL via Level Zero (baked in) |
| CPU | Always works — expect 1–5 tok/s |

> Intel integrated graphics (UHD / Iris Xe) fall back to CPU mode automatically.


---

## Desktop Environment

> **Desktop ISO only.** The server ISO (`willow-os-<ver>-server.iso`) is
> headless — see [Server Mode — Staff Browser Access](#server-mode--staff-browser-access) above.

Willow OS (desktop variant) boots directly to a full graphical desktop (XFCE4)
— no login screen, no password. The Willow dashboard opens automatically in Chromium.

### What boots with the OS

| App | Purpose |
|-----|---------|
| **Chromium** | Pre-configured: opens Willow dashboard on start, bookmark bar always visible |
| **LibreOffice** | Writer, Calc, Impress, Draw — for client documents and spreadsheets |
| **KeePassXC** | Offline password vault — for firm credentials, never cloud-synced |
| **Remmina** | Remote desktop (RDP/VNC) — for supporting clients on their machines |
| **Simple Scan** | Receipt and document scanning (SANE-compatible scanners) |
| **GIMP** | Receipt image cleanup, annotations |
| **Thunar** | File manager |
| **Evince** | PDF viewer |
| **XFCE Terminal** | Admin terminal |
| **CUPS** | Printing — auto-started, add printers via http://localhost:631 |

### Pre-loaded Chromium bookmarks

Bookmarks bar is always visible. Folders pre-configured:

| Folder | Contents |
|--------|----------|
| **Willow** | Dashboard, n8n, Open WebUI, Kanboard, Approvals, Staff |
| **Xero** | Login, Dashboard, Bank Rec, Bills, Invoices, Reports, Contacts |
| **ATO** | Online portal, Business Portal, Tax Tables, BAS, ABN Lookup, ASIC |
| **Banking** | NAB, CBA, ANZ, Westpac business portals |
| **Tools** | Gmail, Google Drive, DocuSign, Annature, Dext, Hubdoc, Stripe, Employment Hero |

Edit bookmarks in `os/config/chromium-bookmarks.json` — push to rebuild.

### Desktop shortcuts (on the desktop)

Willow Dashboard · n8n · Kanboard · Xero · ATO Online ·
LibreOffice Calc · LibreOffice Writer · KeePassXC · Files · Terminal

### ISO size

Adding the desktop environment increases the ISO from ~1.5 GB to ~4–5 GB.
GitHub Releases supports files up to 2 GB via the web; the Actions pipeline
uses the API (no limit). Flash with Rufus or Etcher as normal — the larger
size is transparent to the flashing process.

---

## NPU Support

Willow OS also detects NPUs and uses them to offload Whisper speech recognition,
freeing the GPU for LLM inference.

| NPU | Hardware | Status |
|-----|----------|--------|
| **Intel NPU** | Core Ultra 100/200 series (Meteor Lake, Arrow Lake, Lunar Lake) | ✅ Active — OpenVINO via `/dev/accel/accel0` |
| **AMD Ryzen AI** | Ryzen 7040 / 8040 / 9000 (XDNA / XDNA2) | 🧪 Experimental — kernel 6.8+ with amdxdna driver |

On first boot, `willow-first-run.sh` calls `scripts/detect-gpu.sh` which
checks for NPU presence and automatically adds the NPU overlay
(`docker-compose.portable-npu.yml`) to the stack if one is found.

### What this means for an 8 GB GPU

Without NPU: Whisper and Ollama share 8 GB VRAM — tight.
With Intel NPU: Whisper runs on the NPU, Ollama gets the full 8 GB.
You can then run `medium` or `large-v3` Whisper without any VRAM cost.

### Verify your NPU is working

After first boot, SSH in and run:

```bash
bash /opt/willow/scripts/detect-gpu.sh
# Look for "NPU Detected" section in the output

ls /dev/accel/          # Intel NPU device node (should show accel0)
lsmod | grep amdxdna    # AMD Ryzen AI driver
```
