# Willow AI — Hardware Requirements
**Engineered Data Systems | Deployment planning reference**

---

## What Willow actually runs

| Component | Role | CPU-only viable? |
|-----------|------|-----------------|
| PostgreSQL + pgvector | Data store, vector search | Yes — pure CPU |
| n8n | Workflow engine | Yes — pure CPU |
| Mem0 | AI memory (embeddings via Ollama) | Yes — slower |
| Kanboard | Task management | Yes — pure CPU |
| Open WebUI | Staff dashboard | Yes — pure CPU |
| **Ollama** | LLM inference (qwen2.5) | Yes — but slow |
| **faster-whisper** | Voice transcription | Yes — but slow |
| Piper | Text-to-speech | Yes — pure CPU, fast |
| Cloudflared | Tunnel | Yes — pure CPU |

Everything except Ollama and Whisper is CPU-native and unaffected by
removing the GPU. The whole stack runs — the difference is response latency.

---

## Hardware tiers

### Tier 1 — Minimum viable (CPU-only, light use)
**Who:** Single bookkeeper, low invoice volume, non-time-critical voice input

| Component | Minimum |
|-----------|---------|
| CPU | 4-core x86\_64 with AVX2 (Intel 8th gen / Ryzen 3000 or newer) |
| RAM | 16 GB |
| Storage | 256 GB NVMe SSD (not HDD — Postgres needs random I/O) |
| Network | 1 GbE |
| OS | Ubuntu 22.04 LTS or any Linux with Docker 24+ |

**Real hardware examples (~$200–400 AUD):**
- Beelink Mini S12 Pro (N100, 16GB, 500GB NVMe)
- Repurposed business mini PC (Dell OptiPlex Micro, HP EliteDesk Mini)
- Any 8th-gen+ Intel NUC with 16GB RAM

**Performance expectations:**
- Ollama qwen2.5:3b q4: ~5–8 tokens/sec — workable for typed queries
- Whisper `small` model: ~5–8s per voice clip — acceptable
- Voice interaction: functional but noticeable lag
- Typed chat: responsive enough for daily bookkeeping use

**Required `.env` changes:**
```
OLLAMA_MODEL=qwen2.5:3b-instruct-q4_K_M   # down from 7b
WHISPER_MODEL=small                         # down from large-v3
```

---

### Tier 2 — Comfortable CPU-only
**Who:** 2–5 staff, moderate invoice volume, regular voice use

| Component | Recommended |
|-----------|------------|
| CPU | 8-core modern (Ryzen 7 5700U+, Core i7-12th gen+, or better) |
| RAM | 32 GB |
| Storage | 512 GB NVMe SSD |
| Network | 1 GbE |
| OS | Ubuntu 22.04/24.04 LTS |

**Real hardware examples (~$400–800 AUD):**
- Minisforum UM790 Pro (Ryzen 9 7940HS, up to 64GB RAM) — excellent value
- Beelink SER7 (Ryzen 7 7840HS, 32GB)
- Intel NUC 13 Pro / ASUS NUC 14 Pro
- Refurbished Dell OptiPlex 7090 MT or HP EliteDesk 800 G8 with RAM upgrade

**Performance expectations:**
- Ollama qwen2.5:7b q4: ~5–10 tokens/sec — comfortable for async use
- Whisper `medium` model: ~8–15s per voice clip — usable
- Full bookkeeping workflow: functional, not instant

**Required `.env` changes:**
```
OLLAMA_MODEL=qwen2.5:7b-instruct-q4_K_M   # same as GPU config
WHISPER_MODEL=medium                        # down from large-v3
```

---

### Tier 3 — Consumer GPU (current EDS deployment equivalent)
**Who:** 2–8 staff, high volume, real-time voice interaction expected

| Component | Recommended |
|-----------|------------|
| CPU | 8-core modern (any above) |
| RAM | 32 GB system RAM |
| GPU | NVIDIA RTX 3060 12GB VRAM or better |
| VRAM | 8 GB minimum, 12 GB recommended |
| Storage | 512 GB NVMe SSD |

**Real hardware examples (~$600–1,500 AUD total):**
- Second-hand gaming desktop with RTX 3060/3070 (eBay/Facebook Marketplace)
- Current EDS Unraid server with RTX 2070 — this is Tier 3
- New build: Ryzen 7 7700X + RTX 4060 Ti 16GB + 32GB DDR5

**GPU VRAM requirements by model:**
| Ollama model | VRAM needed |
|---|---|
| qwen2.5:3b q4 | ~2.5 GB |
| qwen2.5:7b q4 | ~4.5 GB |
| qwen2.5:14b q4 | ~8.5 GB — RTX 3080/4070 minimum |
| qwen2.5:32b q4 | ~20 GB — RTX 4090 or multi-GPU |
| qwen2.5:72b q4 | ~45 GB — requires DGX Spark or A100 |

**Performance expectations:**
- Ollama qwen2.5:7b: 40–80 tokens/sec — instant-feeling responses
- Whisper large-v3: <2s per voice clip — natural voice interaction
- Full `.env` defaults work unchanged

---

### Tier 4 — DGX Spark (planned future)

NVIDIA DGX Spark: 128 GB unified memory, GB10 Grace Blackwell Superchip.

Enables:
- `qwen2.5:72b-instruct` — highest quality reasoning
- `mxbai-embed-large` — better semantic memory via Mem0
- Parallel multi-agent execution without latency

`.env` changes when available (already commented in `.env.example`):
```
OLLAMA_MODEL=qwen2.5:72b-instruct
OLLAMA_EMBED_MODEL=mxbai-embed-large
```
No other changes needed.

---

## Deploying on CPU-only hardware

### 1. Use the CPU override

```bash
# Instead of: make up
make up-cpu

# CPU + USB drive:
make up-cpu-usb
```

This swaps faster-whisper to the CPU image and removes the GPU reservation.
Everything else is identical.

### 2. Adjust models in docker/.env

```bash
# Tier 1 (low RAM)
OLLAMA_MODEL=qwen2.5:3b-instruct-q4_K_M
WHISPER_MODEL=small

# Tier 2 (32GB RAM)
OLLAMA_MODEL=qwen2.5:7b-instruct-q4_K_M
WHISPER_MODEL=medium
```

### 3. Install Ollama on the host

Ollama runs on the host (not in Docker) for GPU passthrough. On CPU-only it
still runs on the host — same setup, just slower.

```bash
curl -fsSL https://ollama.ai/install.sh | sh
ollama pull qwen2.5:7b-instruct-q4_K_M
ollama pull nomic-embed-text
```

### 4. AVX2 is required

Ollama uses SIMD instructions for CPU inference. Verify before deploying:

```bash
grep avx2 /proc/cpuinfo | head -1
# Must return a result. If empty, the CPU is too old for Ollama.
```

Any Intel CPU from 2013 (Haswell) onwards and any AMD Ryzen has AVX2.

---

## RAM sizing guide

| Service | Typical usage |
|---------|--------------|
| OS + Docker daemon | ~2 GB |
| PostgreSQL | ~1–2 GB |
| n8n | ~1–2 GB |
| Open WebUI | ~1–2 GB |
| Mem0 + Kanboard + Piper | ~1 GB |
| **Ollama qwen2.5:3b q4** | ~2.5 GB |
| **Ollama qwen2.5:7b q4** | ~5 GB |
| **Whisper small (CPU)** | ~1.5 GB |
| **Whisper medium (CPU)** | ~3 GB |
| **Whisper large-v3 (CPU)** | ~6 GB |

**16 GB total with qwen2.5:3b + Whisper small:** ~12 GB used, tight but functional  
**32 GB total with qwen2.5:7b + Whisper medium:** ~18 GB used, comfortable headroom

---

## Storage: NVMe SSD is non-negotiable

PostgreSQL + pgvector performs vector similarity searches that require
sustained random I/O. Performance on spinning disks or USB 2.0 is poor.

| Storage type | Suitability |
|---|---|
| NVMe SSD (PCIe 3.0+) | Ideal |
| SATA SSD | Good |
| USB 3.x external SSD / NVMe enclosure | Acceptable (USB mode) |
| USB 2.0 thumb drive | Slow — avoid for production |
| HDD (spinning) | Too slow for pgvector |

Minimum 256 GB. 512 GB leaves room for Ollama models, Docker images,
database growth, and audit exports without running tight.

---

## Operating system

| OS | Status |
|---|--------|
| Ubuntu 22.04 LTS / 24.04 LTS | Recommended |
| Debian 12 | Fully supported |
| Unraid (current EDS standard) | Fully supported |
| Rocky Linux / AlmaLinux 9 | Supported |
| Windows (WSL2) | Functional for testing, not for production |
| macOS | Functional for testing; Docker networking differs |
| Raspberry Pi (ARM64) | Ollama runs on ARM, but very slow — not recommended |

The install script (`./install.sh`) targets any Linux with Docker 24+.

---

## Quick-start on a new Ubuntu machine

```bash
# 1. Install Docker
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER && newgrp docker

# 2. Install Ollama
curl -fsSL https://ollama.ai/install.sh | sh

# 3. Clone Willow
git clone https://github.com/your-org/willow.git && cd willow

# 4. Run the installer
./install.sh

# 5. Start (CPU mode if no GPU)
make up-cpu    # or: make up (if GPU is present)
```

---

*Engineered Data Systems · Willow v1.1 · docs/hardware-requirements.md*
