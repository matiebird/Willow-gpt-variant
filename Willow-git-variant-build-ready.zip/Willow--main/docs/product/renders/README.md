# Real UI renders

This folder intentionally contains **no placeholder screenshots**.

Generate real Willow UI screenshots only from the running frontend using:

```bash
cd frontend
npm ci --legacy-peer-deps
npm run build
npm run start
```

Then capture the actual pages from `http://localhost:3000` and save them here.
Do not commit internet-sourced or concept placeholder images as product renders.
