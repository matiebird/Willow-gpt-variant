# Willow Security Model — Sellable Appliance Baseline

Willow is designed as a local-first AI admin appliance. The aim is not to hide from legitimate IT controls, but to prevent casual browsing of bookkeeping data by anyone who does not need access.

## Principles

1. **Backend is the control layer** — n8n triggers work only; business logic, routing, audit and safety live in FastAPI.
2. **Least privilege** — each service gets only the credentials it needs.
3. **Private by default** — Ollama runs locally; client documents and transcripts stay on the appliance/network.
4. **Auditable AI** — AI suggestions create tasks and approval records; AI does not silently approve financial actions.
5. **Tenant scoped** — every production request should include `X-Firm-ID` and every material table should carry `firm_id`.

## Internal API Authentication

n8n, voice and other internal services must send:

```http
X-Willow-API-Key: <WILLOW_API_KEY>
X-Firm-ID: <firm uuid>
```

Do not expose FastAPI directly to the public internet. Put it behind nginx/VPN/reverse proxy access controls.

## Nosy-IT Resistant Controls

Use these controls for customers who want IT support without IT reading client data:

- Full disk encryption or encrypted VM volume.
- Separate Docker network for internal services.
- No direct Postgres port exposure outside the Docker network.
- n8n credentials restricted to service accounts.
- Postgres roles: app role, migration role, read-only support role.
- Audit log for admin access and export actions.
- Support bundle export that redacts client names, emails, phone numbers and document text by default.
- Backups encrypted before leaving the appliance.

## What Not To Do

- Do not store Gmail/Xero tokens in plaintext config files.
- Do not give IT shared admin credentials.
- Do not rely on security through obscurity.
- Do not let n8n run arbitrary raw SQL for customer data paths.

## First Production Hardening Checklist

- Change `WILLOW_API_KEY`.
- Set `ENVIRONMENT=production`.
- Disable public docs or bind backend to internal network only.
- Apply migration `007_product_layer_security.sql`.
- Import workflows from `n8n/workflows-product/`, not the prototype workflow folder.
- Confirm Postgres is not published to LAN/WAN.
- Confirm Ollama is not published to LAN/WAN unless authenticated/reverse-proxied.

## Licence security and nosy-IT boundary

Willow's licence model avoids dead-man behaviour. Paid deployments continue to operate after licence expiry under perpetual fallback. This is both a trust feature and a security feature: firms are never pressured to expose data or rush renewals just to regain access.

Operational controls:

- Licence verification is offline using Ed25519 signatures.
- No phone-home entitlement service is required.
- Paid `expired` mode pauses updates/support, not writes.
- Never-paid `readonly` mode blocks writes after trial expiry.
- Admin/support access should use auditable accounts and redacted support bundles.
- IT can maintain containers, backups and networking without direct Postgres/browser access to client records.
