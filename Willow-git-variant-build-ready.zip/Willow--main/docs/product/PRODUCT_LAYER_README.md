# Willow Product Layer

This patch turns Willow from workflow-heavy automation into a sellable product spine.

## New API endpoints

- `POST /v1/product/email/triage`
- `POST /v1/product/voice/turn`

Both require:

```http
X-Willow-API-Key: <WILLOW_API_KEY>
```

Optional but recommended:

```http
X-Firm-ID: <firm uuid>
```

## New DB tables

Migration: `database/migrations/007_product_layer_security.sql`

- `firms`
- `product_tasks`
- `product_audit_log`
- `staff_routing_rules`

## Updated workflow direction

Use files in:

```text
n8n/workflows-product/
```

These workflows call the backend API instead of directly doing SQL and AI decisions inside n8n.

## Agent responsibilities

- **Willow**: coordinator, receptionist, triage, routing, task creation.
- **Grace**: document extraction only.
- **Hayley**: reconciliation/matching suggestions only.

AI creates suggestions and tasks. Humans approve financial or client-facing actions.
