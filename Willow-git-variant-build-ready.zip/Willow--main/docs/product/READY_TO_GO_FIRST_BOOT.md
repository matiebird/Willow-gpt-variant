# Willow Ready-to-Go First Boot

This package is designed to boot as a local-first product appliance. It cannot include your real secrets, Gmail OAuth, Xero OAuth, or production phone credentials, so those still must be configured on site.

## First boot

```bash
cd docker
cp .env.example .env
# edit .env and replace every CHANGE_ME value, especially WILLOW_API_KEY, SECRET_KEY, POSTGRES_PASSWORD, REDIS_PASSWORD, N8N_ENCRYPTION_KEY

docker compose up -d --build
```

## Required model

Ollama is expected on the host by default.

```bash
ollama pull qwen2.5:7b-instruct-q4_K_M
```

If you run Ollama in Docker instead, change `OLLAMA_BASE_URL` in compose/.env accordingly.

## Health checks

```bash
curl http://localhost:8080/api/health
curl -H "X-Willow-API-Key: $WILLOW_API_KEY" http://localhost:8080/api/v1/product/health
```

Direct backend from inside the Docker network:

```bash
docker exec willow-backend curl -s http://localhost:8000/health
```

## Product API smoke test

From repo root after `.env` is configured:

```bash
./scripts/smoke-product-api.sh
```

Expected result: JSON responses from Willow, Grace, and Hayley. If Ollama is not ready, the API still returns safe fallback JSON and creates review tasks.

## n8n first test

Import this workflow first:

```text
n8n/workflows-product/willow-product-smoke-test.json
```

It needs no Gmail/Xero credentials. It calls the product API directly and proves the Willow → Grace → Hayley path.

Then import:

```text
n8n/workflows-product/willow-email-triage-product.json
n8n/workflows-product/willow-receptionist-product.json
```

Those require n8n credentials or a webhook caller.

## What is production-ready in this package

- Product API boundary exists.
- n8n is no longer intended to own business logic.
- Willow, Grace, and Hayley endpoints exist.
- Product task spine exists.
- Product audit spine exists.
- Grace extraction records exist.
- Hayley reconciliation records exist.
- API-key protected internal endpoints exist.
- Safe AI fallback mode exists for first boot.

## What must be configured per customer

- Real domain / reverse proxy / TLS.
- Gmail or Outlook OAuth credentials.
- Xero OAuth credentials.
- Staff users and routing rules.
- Firm identity and tenant settings.
- Phone/PBX provider credentials if using receptionist voice.
- Backup destination and retention policy.

## Secure deployment minimums

- Do not expose Postgres to LAN or internet.
- Do not expose Ollama to LAN or internet.
- Keep n8n behind auth/VPN/reverse proxy.
- Rotate `WILLOW_API_KEY` per customer.
- Store `.env` outside git.
- Give support staff redacted logs by default.
