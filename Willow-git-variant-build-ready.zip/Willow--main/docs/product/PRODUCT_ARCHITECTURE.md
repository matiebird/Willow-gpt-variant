# Willow Product Architecture

Willow is a private AI admin appliance for bookkeeping/accounting operations.

## Agent roles

- **Willow**: coordinator, receptionist, routing, task creation, audit envelope.
- **Grace**: document extraction from invoices, receipts, statements and uploaded documents.
- **Hayley**: reconciliation suggestions and duplicate-risk checks.
- **n8n**: trigger and transport layer only.
- **FastAPI backend**: product brain, security boundary, database access, audit, routing and task state.

## Core flow

```text
Email or voice event
  -> n8n trigger / webhook
  -> Willow Product API
  -> task + audit log
  -> Grace if document extraction is needed
  -> Hayley if reconciliation is needed
  -> human approval task
  -> external action later, never direct AI approval
```

## Non-negotiable product rules

1. n8n must not contain raw business SQL in production flows.
2. AI must not approve payments, submit BAS, lodge tax, delete records, or send final client communications without approval.
3. Every AI decision must create or update an auditable task.
4. Support/IT access must be operational, not data-browsing access.
5. Multi-tenant customer builds must scope data with `firm_id`.
