# Willow AI — Data Ownership & IP Boundary
**Engineered Data Systems | For engagement planning and offboarding**

---

## The short answer

Willow is **self-hosted on hardware that EDS supplies to the firm**.
The firm's data never leaves that hardware — there is no EDS cloud, no
phone-home, no remote telemetry.

| What | Owned by | Where it lives |
|------|----------|---------------|
| Codebase, workflows, agent logic, architecture | EDS (IP) | This git repo |
| Client list, ABNs, contact details | The firm | PostgreSQL on the appliance |
| Audit trail, action log | The firm | PostgreSQL on the appliance |
| Invoice fingerprints | The firm | PostgreSQL on the appliance |
| Staff register, approval limits | The firm | PostgreSQL on the appliance |
| Xero OAuth tokens | The firm | n8n encrypted credential store |
| Gmail / Outlook OAuth tokens | The firm | n8n encrypted credential store |
| Financial records (bills, P&L, BAS) | The firm's clients | Xero (not in Willow) |
| Email archives | The firm | Gmail / Outlook |
| Ollama AI models | EDS (configured) | Host machine GPU node |

---

## Hardware arrangement

EDS supplies and maintains the physical hardware (Unraid server + GPU node).
The Docker stack runs on that hardware. All data volumes are local to that machine.

```
┌─────────────────────────────────────────────────────────┐
│  EDS-supplied hardware (on the firm's premises / LAN)   │
│                                                         │
│  ┌──────────────┐   ┌─────────────────────────────┐    │
│  │  Willow      │   │  PostgreSQL (willow-db)     │    │
│  │  Docker      │──▶│  ├── staff_registry         │    │
│  │  Stack       │   │  ├── client_registry        │    │
│  │              │   │  ├── audit_log              │    │
│  │  (EDS IP)    │   │  ├── invoice_fingerprints   │    │
│  └──────────────┘   │  └── follow_up_sequences    │    │
│                     │  (all firm data)            │    │
│                     └─────────────────────────────┘    │
│                                                         │
│  EDS has no remote access to this machine by default.   │
└─────────────────────────────────────────────────────────┘
```

---

## Licence and data-access boundary

Willow licensing is intentionally separated from data custody. Paid customers are not locked out of operations when an update/licence period lapses. An expired paid licence pauses updates, new premium features and non-included support, but daily workflows and writes continue.

Read-only mode is used only when a never-paid trial expires. This protects the product without holding paid customer data hostage.

The licence file is verified locally on the appliance. There is no EDS cloud entitlement service and no dead-man flag.

## If EDS disengages from the firm

The firm retains:
- Full custody of the hardware (EDS may reclaim hardware under service terms)
- All data in the PostgreSQL database — run `make offboard` for a packaged export
- n8n workflow definitions (exported in the offboard package)
- Their Xero and Gmail credentials (they reconnect directly via OAuth2)
- The right to continue operating Willow under the perpetual-fallback model if a paid licence was installed — no EDS cloud connection or phone-home is required

EDS retains:
- The software IP (codebase, architecture, workflow designs)
- Nothing belonging to the firm — no copy of any firm data was ever held by EDS

### Practical steps if EDS disengages

```bash
# 1. Generate the complete data exit package
make offboard

# 2. Follow 07_credentials_notice.txt in the output
#    — save the N8N_ENCRYPTION_KEY before the hardware is reclaimed

# 3. If continuing independently: keep docker/.env and the hardware
#    A paid Willow install has no phone-home and keeps operating under perpetual fallback if updates/support are not renewed

# 4. If shutting down: archive the export files for 5 years (ATO obligation)
```

---

## If the firm disengages from EDS

EDS may need to:
- Reclaim the physical hardware
- Confirm no firm data was retained on EDS systems (it wasn't — self-hosted)
- Issue a final offboard package before hardware collection

The firm must:
- Run `make offboard` before hardware is collected
- Revoke Xero app access (developer.xero.com → My Apps)
- Revoke Gmail access (myaccount.google.com → Security → Third-party apps)
- Retain the export files for 5 years under s262A ITAA 1997

---

## Data that is NOT in Willow

| Data | Where it actually lives |
|------|------------------------|
| Tax invoices (source PDFs) | Attached to Xero bills |
| BAS lodgements | Xero (lodged by agent) |
| Bank statements | Client's bank |
| Client email correspondence | Gmail / Outlook archive |
| Payroll records | Xero Payroll |
| Superannuation records | Client's fund / Xero |

Willow stores a *SHA256 fingerprint* of each invoice — not the invoice itself.
The fingerprint proves the document was processed without alteration, but you need
the original (in Xero or Gmail) to produce the document to an auditor.

---

## The n8n encryption key

n8n encrypts all OAuth credentials at rest using `N8N_ENCRYPTION_KEY` from
`docker/.env`. This key must be preserved by the firm on disengagement — without
it, the credential store cannot be decrypted and Xero/Gmail connections would
need to be re-authorised from scratch.

The offboard script (`make offboard`) includes this key in
`07_credentials_notice.txt`. **Store it in a password manager immediately.**

---

## Multi-tenancy note

Willow is deployed **per firm** — one instance per engagement, each on
dedicated hardware. There is no shared EDS infrastructure connecting
multiple firm deployments. One firm's data is physically isolated from
every other firm's data.

---

*Engineered Data Systems · Willow v1.1 · docs/data-ownership.md*
