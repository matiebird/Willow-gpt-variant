# Willow AI — Project Review Brief for Perplexity Research

## What This Is

Willow is a **fully local, privacy-first AI bookkeeping and email triage appliance**
built for a small Australian professional services firm (Engineered Data Systems).
Everything runs on self-hosted hardware — no data ever leaves the network.

**Primary user:** Jen, an accountant who processes invoices, chases clients, and
monitors tax compliance deadlines. She uses the dashboard daily.

**Strategic context:** The project is being developed partly to support an
_Advance Queensland Ignite Spark_ grant application, so data sovereignty and
edge-compute architecture are explicit requirements, not preferences.

---

## Hardware

| Stage | Hardware | Notes |
|-------|----------|-------|
| Development | Unraid NAS, NVIDIA RTX 2070 (8 GB VRAM) | GPU at host level for Ollama passthrough |
| Production target | NVIDIA DGX Spark (GB10, 128 GB unified memory) | Ansible handles promotion |

---

## Current Tech Stack (all self-hosted, all Docker except Ollama)

| Component | Role | Container / service |
|-----------|------|---------------------|
| **n8n** | Workflow orchestration | `n8n` (Docker) |
| **Ollama** | Local LLM inference | Host-level (GPU passthrough), `qwen2.5:7b-instruct-q4_K_M` now, `qwen2.5:72b-instruct` on DGX Spark |
| **Mem0** | Persistent memory (vector + key-value) | `mem0` (Docker), pgvector backend |
| **PostgreSQL + pgvector** | Structured data + vector store | `willow-db` (Docker) |
| **faster-whisper-gpu** | Speech-to-text (OpenAI-compatible API) | `faster-whisper-gpu` (Docker) |
| **piper** | Text-to-speech | `piper` (Docker) |
| **Kanboard** | Task management (JSON-RPC API) | `kanboard` (Docker) |
| **Streamlit** | Hybrid Dashboard (temporary; custom UI planned) | `dashboard/app.py` |
| **Open WebUI** | Fallback chat UI | `open-webui` (Docker) |
| **Cloudflare Tunnel** | OAuth2 callbacks during dev (`elastic_tharp`) | `cloudflared-dev` (Docker, dev profile) |
| **Ansible** | Idempotent deployment to Unraid + DGX Spark | `ansible/deploy.yml` |

---

## Named Agents

### Willow (Manager Agent)
- Entry point for all staff interactions via chatTrigger webhook
- Authenticates staff via `staff_registry` lookup (role, approval_limit)
- Searches Mem0 in two scopes: personal (`tg_{user_id}`) and firm-wide (`willow_firm`)
- Routes to sub-agents via n8n `agentTool` / `toolWorkflow` nodes
- Writes conversation back to Mem0 and appends every action to `audit_log`

### Grace (Extraction Engine)
- Accepts: invoice images, PDFs, voice-dictated notes, HTML email bodies
- Uses Ollama vision (qwen2.5) for OCR + structured JSON extraction
- Output: `{supplier, date, line_items[], gst_amount, total, confidence}`

### Hayley (Reconciliation Core)
- Receives Grace's JSON
- SHA256 deduplication against `invoice_fingerprints`
- Validates supplier against Xero Contacts API
- Creates **DRAFT** bill in Xero (never AUTHORISED without human approval)
- Attaches PDF binary in-memory via Puppeteer (no local file storage)
- Archives source email, stores fingerprint, flags in Kanboard if confidence < threshold

---

## n8n Workflows Built (8 total)

| Workflow | Trigger | Purpose |
|----------|---------|---------|
| `willow-main-assistant` | chatTrigger (OpenAI-compatible webhook) | Core Willow agent with all tools |
| `willow-grace-extraction` | Webhook POST | OCR / parse invoice → structured JSON |
| `willow-hayley-reconciliation` | Webhook POST | Dedup → Xero DRAFT bill → PDF attach |
| `willow-email-triage` | Cron every 15 min (business hours) | Central firm inbox → classify → route to staff |
| `willow-morning-briefing` | Cron 7:30 AM AEST Mon–Fri | Per-staff digest: tasks, follow-ups, deadlines, email count |
| `willow-follow-up-executor` | Cron 9:00 AM AEST Mon–Fri | 3-5-7 day client follow-up sequences, escalating tone |
| `willow-deadline-warning` | Cron 9:00 AM AEST daily | AUS tax calendar (BAS, PAYG, Super, FBT, STP) — 14/7/3/1 day windows |
| `willow-client-onboarding` | Webhook POST (manager/admin only) | Insert client_registry + create Kanboard project |

---

## PostgreSQL Schema (key tables)

```sql
staff_registry      -- user_id, role (admin/manager/bookkeeper/viewer), client_ids JSONB, approval_limit
client_registry     -- display_name, contact_email, contact_domain, email_provider, xero_tenant_id, assigned_staff
audit_log           -- BIGSERIAL, immutable append-only, every financial action logged
invoice_fingerprints -- sha256_hash PK, source_type, xero_bill_id (deduplication)
follow_up_sequences  -- client_id, invoice_id, sequence_step, cadence_days INTEGER[], next_action_at
chat_sessions        -- n8n memoryPostgresChat backing table
kanboard_projects    -- client_id → kanboard_project_id mapping
```

---

## Streamlit Dashboard (`dashboard/app.py`)

- **First-run wizard** saves `dashboard/.willow.conf` (JSON, gitignored) with n8n host IP, port, webhook paths, staff ID
- **Settings panel** in sidebar allows reconfiguration without touching files
- Two-column layout: data/deadline panels (left) + chat interface (right)
- `st.audio_input` for browser-based voice dictation → POSTs WAV to n8n voice webhook
- n8n returns `{"transcription": "...", "output": "..."}` → both appended to chat
- Custom UI will replace Streamlit in a future phase

---

## Email Architecture

- **One central firm inbox** (Gmail OR Outlook, configurable via `FIRM_EMAIL_PROVIDER`)
- Clients are identified by matching `sender_email` or `sender_domain` against `client_registry`
- Dual-label filing: `Client/CompanyName` + `Type/Invoice` etc.
- Emails are **never deleted** — archived after processing
- Invoices are **never saved locally** — HTML→PDF in-memory (Puppeteer) → binary attached to Xero DRAFT

---

## Xero Integration Rules

- All bills created as `Status=DRAFT` — never `AUTHORISED` without explicit staff approval
- Multi-tenant: each client has its own `xero_tenant_id` in `client_registry`
- `Xero-Tenant-Id` header set per-request
- OAuth2 callbacks handled via Cloudflare tunnel in dev; client-registered URLs in production

---

## Ansible Deployment

- Single playbook `ansible/deploy.yml` with tagged roles: `prerequisites`, `nvidia_drivers`, `docker`, `willow_stack`, `ollama_models`, `database_migrations`, `verify`
- `inventory.example.yml` has two host groups: `unraid` (dev, skip docker install) and `dgx_spark` (production)
- Model and profile differences handled entirely through inventory vars
- Migrating to DGX Spark = `ansible-playbook --limit dgx_spark --tags models,deploy`

---

## Known Gaps / Open Questions for Research

Please research and suggest improvements for any of the following:

1. **n8n workflow resilience** — What are best practices for error handling, retry logic, and dead-letter queuing in n8n AI agent workflows? The current workflows have minimal error branching.

2. **Mem0 dual-scope pattern** — Is searching personal + firm memory in parallel before every agent call the right approach? Are there latency or relevance ranking improvements?

3. **Xero DRAFT bill workflow** — Are there better patterns for the human-approval step before a DRAFT becomes AUTHORISED? Should this be a Kanboard task, a chat confirmation, or a dedicated approval UI?

4. **Australian tax compliance** — Is the current tax calendar (BAS quarterly/monthly, PAYG monthly, Super quarterly, FBT annual, STP annual, Tax Return Oct 31) complete and accurate for a small firm with mixed client types?

5. **Streamlit dashboard limitations** — What are the practical limits of Streamlit for a multi-user accountancy dashboard? When should we switch to a proper React/Next.js frontend?

6. **M5Stack Echo / ESP32 voice hardware** — What is the recommended approach for programming an M5Stack Echo or similar ESP32-based device to POST WAV audio to a local HTTP endpoint and play back TTS audio? What libraries/frameworks are best?

7. **faster-whisper model selection** — What is the best faster-whisper model size for Australian English transcription on a single RTX 2070 with acceptable latency?

8. **PostgreSQL audit log immutability** — The current audit_log is append-only by convention. What PostgreSQL mechanisms (triggers, RLS, row-level security) should be added to make it genuinely tamper-evident?

9. **Ollama qwen2.5 prompt quality** — Are there known prompt engineering patterns that significantly improve qwen2.5:7b accuracy for structured JSON extraction from Australian invoice formats (GST, ABN, supplier details)?

10. **Security hardening** — The n8n chatTrigger webhook has no authentication beyond sessionId matching staff_registry. What should be added before this faces even a LAN network with multiple staff?

---

## What We Are NOT Doing (to avoid suggestions in these directions)

- No cloud LLM APIs (OpenAI, Anthropic, etc.) — data sovereignty requirement
- No per-client email credentials — central firm inbox only
- No local file storage of invoices — binary-to-Xero only
- No auto-sending emails — always draft for human review
- No AUTHORISED Xero bills without explicit approval
- No Telegram or other consumer messaging platforms

---

*Engineered Data Systems · Willow v1.1 · April 2026*
