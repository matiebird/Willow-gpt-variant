# Willow Licensing Model

Willow uses an offline, local-first licensing model designed for accounting and bookkeeping firms that cannot risk data lockout.

## Product principle

**Willow never holds a paid customer’s operational data hostage.**

A paid Willow appliance continues to run after its licence/update period expires. Renewal controls updates, new premium features and optional support — not access to the firm’s working records.

## Licence states

| Mode | Customer state | Writes allowed | Updates enabled | Support entitlement | Intended use |
|---|---|---:|---:|---:|---|
| `trial` | No paid licence, trial active | Yes | No | No | Evaluation period |
| `readonly` | Trial expired and no paid licence has ever been installed | No | No | No | Anti-piracy only |
| `full` | Paid licence active | Yes | Yes | Depends on SKU | Normal operation |
| `expiring` | Paid licence active, renewal due within 30 days | Yes | Yes | Depends on SKU | Renewal reminder |
| `expired` | Paid licence has lapsed | Yes | No | No, unless separately active | Perpetual fallback |
| `invalid` | Bad signature/wrong hardware and no paid fallback marker | No/limited | No | No | Tamper/wrong-server protection |

## Perpetual fallback

When a paid licence expires, Willow enters `expired` mode:

- email triage continues
- receptionist/callback workflows continue
- tasks and approvals continue
- data remains readable and writable
- exports/offboarding continue
- updates are paused
- new premium features are gated
- support is only available if a support SKU is active

The UI banner should read:

> Updates paused — renew to resume. Willow continues operating normally.

## Trial expiry

Read-only mode exists for one case only:

> the initial trial expired and no paid licence has ever been installed.

This is anti-piracy, not anti-customer. Existing data remains accessible, but new ingestion/writes are blocked until a paid licence is installed.

## Support SKU

Support is optional and separate from the base licence/update entitlement.

Suggested SKU:

| SKU | Price | Includes |
|---|---:|---|
| Priority Support | AUD $99/month | response-SLA support tickets, guided upgrades, configuration help, remote session by appointment |

Support can be encoded in the offline licence payload using:

```json
{
  "support_plan": "priority",
  "support_expires": "2027-04-29"
}
```

If support expires while the paid licence remains active, Willow continues normally but support is not shown as active.

## Offline verification

Willow licence files are signed offline using Ed25519. The appliance verifies them locally. There is:

- no phone-home requirement
- no cloud activation dependency
- no periodic online entitlement check
- no dead-man switch

The licence payload contains the firm name, tier, seats, hardware fingerprint, update expiry, and optional support entitlement.

## Operational enforcement

Backend middleware enforces only `readonly` mode for write-blocking. Paid `expired` mode is **not** read-only.

The frontend should show:

- licence mode
- writes allowed/blocked
- updates enabled/paused
- support active/inactive
- seats used/available

## Customer-facing FAQ

### Will Willow stop working if we do not renew?

No. If you have installed a paid licence, Willow keeps operating. Renewal resumes updates, new premium features and support entitlement.

### Can Willow lock us out of our data?

No. Paid customers retain access and operational use under perpetual fallback. Trial users who never purchase are moved to read-only after the trial ends.

### Does Willow need internet to validate the licence?

No. Verification is local and offline.

### What happens if the hardware changes?

Licences are bound to a hardware fingerprint. A hardware transfer requires a replacement licence key, but paid customers are not locked out of their existing appliance data during normal renewal expiry.

### What exactly are we renewing?

You renew updates, new premium features and any support entitlement. You are not paying to regain access to your existing data.
