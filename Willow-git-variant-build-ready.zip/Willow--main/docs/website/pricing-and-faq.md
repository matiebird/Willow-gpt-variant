# Willow Website Copy — Pricing & FAQ

## Pricing block

### Local AI admin for bookkeeping teams

Willow is sold as a local-first appliance licence. Your data stays on your server. Your paid system keeps running even if you pause renewals.

| Plan | Best for | Staff | Annual updates licence |
|---|---|---:|---:|
| Starter | Sole trader / small bookkeeping shop | 1–3 | AUD $3,600 |
| Professional | Growing bookkeeping firm | 4–10 | AUD $7,200 |
| Studio | Multi-team admin office | 11–25 | AUD $13,200 |
| Enterprise | Larger firm / custom deployment | 25+ | Contact us |

Optional add-on:

**Priority Support — AUD $99/month**  
Response-SLA support tickets, guided upgrades, configuration help and scheduled remote support.

## Perpetual fallback copy

Willow is not hostage software.

If you have installed a paid licence, Willow keeps operating even if your renewal lapses. You can keep handling emails, calls, tasks and approvals. Renewal resumes updates, new premium features and support entitlement.

## FAQ

### What happens if we stop renewing?

Your paid Willow appliance keeps operating. Writes continue. Your team can keep using the system. Updates, new premium features and optional support pause until renewal.

### Can Willow lock us out of our data?

No. Paid customers retain operational access. The only read-only state is an expired trial where no paid licence was ever installed.

### Does Willow call home to check licensing?

No. Licences are verified locally using offline cryptographic signatures.

### What does the support add-on include?

Priority Support includes response-SLA tickets, configuration help, guided updates and scheduled remote-support sessions. It does not give EDS unrestricted access to client data.

### Is support required?

No. Support is optional. Firms that want a phone number and faster help can add it; casual users can run without it.
