# Willow AI — Audit Readiness Guide
**Engineered Data Systems | For ATO, ASIC, or other regulatory reviews**

---

## The short answer

Willow is a **processing appliance**, not an accounting system. The authoritative financial records live in **Xero**. What Willow adds is a tamper-evident trail of *how* those records were created — who processed which invoice, when, by what method, and whether a human approved it.

In a review, you present both:

| Source | What it proves |
|--------|----------------|
| **Xero** | The financial position — bills, P&L, GST, BAS history, bank reconciliation |
| **Willow audit export** | The processing trail — who did what, when, through what workflow |

---

## What the ATO can ask for

Under **s262A ITAA 1997** and **s36-35 GST Act 1999**, a business must retain records for **5 years** from when the return was lodged or the activity occurred (whichever is later). Records must be:

- In English, or readily convertible to English
- Accessible and legible
- Capable of being produced to an authorised officer

For a GST-registered entity the ATO typically wants:

- **Tax invoices** from suppliers (≥ $82.50 inc-GST — must show supplier name, ABN, date, GST amount)
- **BAS workpapers** — the numbers behind each quarterly/monthly BAS lodgement
- **Bank statements** confirming payments
- **Evidence that records are complete** — i.e. that invoices were not altered after receipt

---

## Generating the audit package

```bash
# Current financial year (default)
make audit-export

# Specific date range
make audit-export FROM=2024-07-01 TO=2025-06-30

# Or run directly
./scripts/export-audit-package.sh 2024-07-01 2025-06-30
```

This produces a ZIP in `audit-exports/` containing seven CSV files plus a README that explains each one in plain English — written for an auditor, not a developer.

---

## What is in the export

### `01_audit_log.csv` — The master action trail
Every action Willow took, with timestamp, staff member, client, and result. Key action types an auditor will look for:

| Action | Meaning |
|--------|---------|
| `invoice_processed` | Supplier invoice received and sent to Xero as DRAFT |
| `email_classified` | Email routed in the central firm inbox |
| `client_onboarded` | New client added to the system |
| `follow_up_sent` | Automated chase email composed and sent |
| `deadline_warning_sent` | Tax deadline alert issued to staff |
| `morning_briefing_sent` | Daily digest delivered to staff |
| `staff_notification` | Internal system alert (deadline, urgent email, etc.) |

### `02_invoice_records.csv` — Invoice fingerprint ledger
Every supplier invoice processed. The `sha256_hash` column is computed from the **original document binary before any processing** — this proves the invoice content was not altered after Willow received it. The `xero_bill_id` links each record to the corresponding Xero bill.

**Cross-check drill:** Export bills from Xero for the same period and match `xero_bill_id` values. Every Willow-processed invoice should appear as a bill in Xero. Any Xero bill with a `Reference` field starting with `willow:` was created by this system.

### `03_client_register.csv` — Who the firm acts for
Client names, ABNs, Xero organisation IDs. Useful for confirming each client's identity and that their BAS frequency was set correctly.

### `04_staff_access_register.csv` — Who had access
Every staff member, their role, and their **approval limit** — the dollar threshold below which they could submit invoices to Xero automatically. Any invoice above a staff member's limit was flagged to Kanboard for manual review before being touched in Xero.

### `05_follow_up_communications.csv` — Client communication trail
Automated follow-up sequences run for outstanding invoices. Shows the client, subject, and escalation step reached. Relevant if a client disputes whether they were notified.

### `06_client_activity_summary.csv` — Activity counts by client
Aggregated summary per client — useful for a quick scan to confirm a client's data was handled.

### `07_invoice_value_summary.csv` — Monthly invoice totals
Total ex-GST, total GST, and total inc-GST per client per month. Cross-reference against the BAS lodgement for that quarter to confirm the numbers are consistent.

---

## Tamper-evidence: how to prove records were not modified

Migration `002_audit_hardening.sql` adds two protections to the database:

**1. Trigger-enforced immutability** — The database will raise an error if any process attempts to `UPDATE` or `DELETE` a row in `audit_log`. This is enforced at the PostgreSQL trigger level, not by application code.

**2. Row-level SHA256 hash** — Every `audit_log` row has a `row_hash` column computed at insert time from the key fields. To verify no rows were tampered with:

```sql
-- Run inside the database (make shell-db) to check integrity:
SELECT id, timestamp, action, is_valid
FROM fn_verify_audit_integrity('2024-07-01', '2025-06-30')
WHERE is_valid = false;

-- Should return zero rows if records are intact.
```

An auditor can request this query be run in their presence.

---

## Responding to an ATO data-match or audit letter

### Step 1 — Generate the Willow export

```bash
make audit-export FROM=<fy-start> TO=<fy-end>
```

### Step 2 — Export from Xero (for each client entity)

In Xero for each client:
- **Accounting → Reports → Profit & Loss** — for the period
- **Accounting → Reports → Balance Sheet** — at period end
- **GST → Returns** — all lodged BAS for the period
- **Accounts Payable → Unpaid Bills** — outstanding at period end
- **Accounting → Reports → General Ledger** — full transaction detail

### Step 3 — Retrieve source emails (if asked for original invoices)

Original invoices are attached directly to Xero bills as PDFs (Willow never saves them locally). In Gmail/Outlook the original emails are archived under labels `Client/<Name>` and `Type/Invoice`. The SHA256 in `02_invoice_records.csv` can be used to match a specific Xero attachment to the original email.

### Step 4 — Verify integrity on the spot

If an ATO officer questions whether records are complete:

```bash
make shell-db
# Then in psql:
SELECT COUNT(*) FROM audit_log WHERE timestamp >= '2024-07-01' AND timestamp < '2025-07-01';
SELECT COUNT(*) FROM invoice_fingerprints WHERE processed_at >= '2024-07-01';
SELECT COUNT(*) FROM fn_verify_audit_integrity('2024-07-01', '2025-07-01') WHERE is_valid = false;
-- Last query should return 0 rows.
```

---

## Record retention schedule

| Record type | Minimum retention | Location |
|-------------|-------------------|----------|
| Tax invoices (supplier) | 5 years | Xero (attached to bills) |
| BAS workpapers | 5 years | Xero + audit export |
| Audit log (action trail) | 5 years | PostgreSQL (append-only) |
| Invoice fingerprints | 5 years | PostgreSQL |
| Client correspondence | 5 years | Gmail/Outlook archive |
| Audit export ZIPs | 5 years | `audit-exports/` (back up offsite) |
| Payroll records | 7 years | Xero Payroll |

Run `make backup` weekly and store the resulting dump offsite (e.g. encrypted to a USB or NAS share outside the main system).

---

## What Willow does NOT replace

- Willow does **not** lodge BAS. BAS is lodged via Xero or your tax agent.
- Willow does **not** send final emails to clients without human review (all follow-up emails are composed by the LLM but sent only after the sequence is enabled by a staff member).
- Willow does **not** authorise Xero bills. Every bill created is `DRAFT` status until a human approves it in Xero.
- Willow does **not** provide tax advice. It tracks calendar deadlines as a reminder service only.

---

*Engineered Data Systems · Willow v1.1 · docs/audit-readiness.md*
