# Willow Fixed Repo — Change Log

This package is a cleaned, importable build based on the uploaded Willow repo.

## Fixed

- Added missing backend/internal service configuration:
  - `WILLOW_API_KEY`
  - `SMS_PROVIDER`
  - `ASTERISK_AMI_*`
  - `SECRET_KEY`
  - `REDIS_PASSWORD`
  - 3CX placeholders
- Added a module-level `settings = get_settings()` object in `backend/app/config.py` so routes importing `settings` do not crash.
- Fixed client schema mismatches caused by mixing `client_registry.id` / UUID-style references with the actual `client_registry.client_id` text key.
- Fixed backend client status API queries:
  - `client_id` instead of `id`
  - `primary_contact` instead of `contact_name`
  - `contact_email` instead of `email`
  - lowercase invoice statuses used by the current schema
  - safe interval parameter for timeline queries
- Fixed voice, intake, and document-intake joins to use `client_registry.client_id`.
- Fixed migrations 003 and 004 so downstream tables reference `client_registry(client_id)` correctly.
- Fixed n8n workflow schema mismatches in:
  - `willow-client-status.json`
  - `willow-sms.json`
  - `willow-telegram.json`
- Fixed Ansible role YAML errors by moving invalid inline `handlers:` blocks into proper role handler files:
  - `ansible/roles/docker/handlers/main.yml`
  - `ansible/roles/nvidia_drivers/handlers/main.yml`
- Updated Docker Compose so backend/celery receive `WILLOW_API_KEY` and SMS/Asterisk settings.

## Validation Performed

- Python syntax compile check passed for `backend/app`.
- All JSON workflow files parse successfully.
- All YAML/YML files parse successfully.

## Not Fully Solved Yet

These are product-level upgrades, not quick repo fixes:

- Replace remaining direct SQL inside n8n with FastAPI endpoints.
- Add proper database migrations through Alembic instead of relying only on Docker init SQL.
- Add automated tests for core backend routes.
- Add webhook signature checks to public n8n webhooks.
- Add multi-tenant `firm_id` support before selling Willow to multiple firms.

## First Run

```bash
cd Willow--main
cp docker/.env.example docker/.env
# edit docker/.env and replace CHANGE_ME values
make up-cpu
```

For your Unraid/GPU setup, use the appropriate target after `.env` is filled:

```bash
make up
# or
make up-auto
```
